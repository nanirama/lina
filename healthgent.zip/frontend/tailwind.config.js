const config = require("@healthgent/common/src/config/tailwind.config");
module.exports = { ...config };
