self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./components/landing/Testimonials.tsx":
/*!*********************************************!*\
  !*** ./components/landing/Testimonials.tsx ***!
  \*********************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "../node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SharpStars__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SharpStars */ "./components/landing/SharpStars.tsx");
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\Testimonials.tsx",
    _this = undefined;

/**
 * Shows testimonials on the landing page
 */



var Testimonial = function Testimonial(_ref) {
  var title = _ref.title,
      children = _ref.children,
      style = _ref.style;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "p-8 max-w-sm mb-4 w-full md:w-96 flex-shrink-0",
    style: style,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "text-sm font-bold mb-8",
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "leading-relaxed mb-8",
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_SharpStars__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, _this);
};

_c = Testimonial;
var testimonials = [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Miami",
  style: {
    backgroundColor: "rgba(77, 188, 195, 0.1)"
  },
  children: "My provider was kind and considerate. He asked me a lot of questions to get to the root of my feelings. The medication shipment was also super convenient for me. I'm so glad I was able to quickly book an appointment with Lina."
}, "testimonial-2", false, {
  fileName: _jsxFileName,
  lineNumber: 27,
  columnNumber: 3
}, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Pensacola",
  style: {
    backgroundColor: "rgba(255, 217, 208, 0.7)"
  },
  children: "I was able to book an appointment with Dr. P within a day. He was understanding, straightforward, and caring. He answered all my questions and made me feel confident about my treatment. It's been a great experience so far."
}, "testimonial-3", false, {
  fileName: _jsxFileName,
  lineNumber: 39,
  columnNumber: 3
}, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Tampa Bay",
  style: {
    backgroundColor: "rgba(77, 188, 195, 0.1)"
  },
  children: "Telehealth is so important, it enables people to get care with an actual person over video. Sometimes we can't physically get to a doctor's office, but now Lina offers something for everyone who can't do in-person. Thanks for creating this platform!"
}, "testimonial-1", false, {
  fileName: _jsxFileName,
  lineNumber: 49,
  columnNumber: 3
}, undefined)];

var Testimonials = function Testimonials(_ref2) {
  var heading = _ref2.heading,
      data = _ref2.data;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "flex flex-col md:flex-row",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "md:w-1/3",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
        className: "text-3xl md:text-4xl text-center md:text-left mb-8",
        children: heading ? heading : 'Life changing results from real members'
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "w-full flex flex-col justify-center md:justify-start md:flex-row overflow-auto md:space-x-4",
      children: testimonials
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 69,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 63,
    columnNumber: 5
  }, _this);
};

_c2 = Testimonials;
/* harmony default export */ __webpack_exports__["default"] = (Testimonials);

var _c, _c2;

$RefreshReg$(_c, "Testimonial");
$RefreshReg$(_c2, "Testimonials");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9sYW5kaW5nL1Rlc3RpbW9uaWFscy50c3giXSwibmFtZXMiOlsiVGVzdGltb25pYWwiLCJ0aXRsZSIsImNoaWxkcmVuIiwic3R5bGUiLCJ0ZXN0aW1vbmlhbHMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJUZXN0aW1vbmlhbHMiLCJoZWFkaW5nIiwiZGF0YSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQSxJQUFNQSxXQUFvRSxHQUFHLFNBQXZFQSxXQUF1RSxPQUl2RTtBQUFBLE1BSEpDLEtBR0ksUUFISkEsS0FHSTtBQUFBLE1BRkpDLFFBRUksUUFGSkEsUUFFSTtBQUFBLE1BREpDLEtBQ0ksUUFESkEsS0FDSTtBQUNKLHNCQUNFO0FBQ0UsYUFBUyxFQUFDLGdEQURaO0FBRUUsU0FBSyxFQUFFQSxLQUZUO0FBQUEsNEJBSUU7QUFBSyxlQUFTLEVBQUMsd0JBQWY7QUFBQSxnQkFBeUNGO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFKRixlQUtFO0FBQUssZUFBUyxFQUFDLHNCQUFmO0FBQUEsZ0JBQXVDQztBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTEYsZUFNRSw4REFBQyxnREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFVRCxDQWZEOztLQUFNRixXO0FBaUJOLElBQU1JLFlBQVksR0FBRyxjQUNuQiw4REFBQyxXQUFEO0FBRUUsT0FBSyxFQUFDLG9CQUZSO0FBR0UsT0FBSyxFQUFFO0FBQ0xDLG1CQUFlLEVBQUU7QUFEWixHQUhUO0FBQUE7QUFBQSxHQUNNLGVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURtQixlQWFuQiw4REFBQyxXQUFEO0FBRUUsT0FBSyxFQUFDLHdCQUZSO0FBR0UsT0FBSyxFQUFFO0FBQUVBLG1CQUFlLEVBQUU7QUFBbkIsR0FIVDtBQUFBO0FBQUEsR0FDTSxlQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFibUIsZUF1Qm5CLDhEQUFDLFdBQUQ7QUFFRSxPQUFLLEVBQUMsd0JBRlI7QUFHRSxPQUFLLEVBQUU7QUFBRUEsbUJBQWUsRUFBRTtBQUFuQixHQUhUO0FBQUE7QUFBQSxHQUNNLGVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXZCbUIsQ0FBckI7O0FBbUNBLElBQU1DLFlBQTZCLEdBQUcsU0FBaENBLFlBQWdDLFFBQXVCO0FBQUEsTUFBcEJDLE9BQW9CLFNBQXBCQSxPQUFvQjtBQUFBLE1BQVhDLElBQVcsU0FBWEEsSUFBVztBQUMzRCxzQkFDRTtBQUFLLGFBQVMsRUFBQywyQkFBZjtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLFVBQWY7QUFBQSw2QkFDRTtBQUFJLGlCQUFTLEVBQUMsb0RBQWQ7QUFBQSxrQkFDS0QsT0FBTyxHQUFHQSxPQUFILEdBQWE7QUFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQU1FO0FBQUssZUFBUyxFQUFDLDZGQUFmO0FBQUEsZ0JBQ0dIO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBWUQsQ0FiRDs7TUFBTUUsWTtBQWVOLCtEQUFlQSxZQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2luZGV4LmUyOTQxMGU0NzllOTA1MTZkOGMyLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFNob3dzIHRlc3RpbW9uaWFscyBvbiB0aGUgbGFuZGluZyBwYWdlXG4gKi9cbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBTaGFycFN0YXJzIGZyb20gXCIuL1NoYXJwU3RhcnNcIjtcblxuaW50ZXJmYWNlIFByb3BzIHsgfVxuXG5jb25zdCBUZXN0aW1vbmlhbDogUmVhY3QuRkM8eyB0aXRsZTogc3RyaW5nOyBzdHlsZTogUmVhY3QuQ1NTUHJvcGVydGllcyB9PiA9ICh7XG4gIHRpdGxlLFxuICBjaGlsZHJlbixcbiAgc3R5bGUsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwicC04IG1heC13LXNtIG1iLTQgdy1mdWxsIG1kOnctOTYgZmxleC1zaHJpbmstMFwiXG4gICAgICBzdHlsZT17c3R5bGV9XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCBtYi04XCI+e3RpdGxlfTwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWQgbWItOFwiPntjaGlsZHJlbn08L2Rpdj5cbiAgICAgIDxTaGFycFN0YXJzIC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5jb25zdCB0ZXN0aW1vbmlhbHMgPSBbXG4gIDxUZXN0aW1vbmlhbFxuICAgIGtleT1cInRlc3RpbW9uaWFsLTJcIlxuICAgIHRpdGxlPVwiUGF0aWVudCBmcm9tIE1pYW1pXCJcbiAgICBzdHlsZT17e1xuICAgICAgYmFja2dyb3VuZENvbG9yOiBcInJnYmEoNzcsIDE4OCwgMTk1LCAwLjEpXCIsXG4gICAgfX1cbiAgPlxuICAgIE15IHByb3ZpZGVyIHdhcyBraW5kIGFuZCBjb25zaWRlcmF0ZS4gSGUgYXNrZWQgbWUgYSBsb3Qgb2YgcXVlc3Rpb25zIHRvIGdldFxuICAgIHRvIHRoZSByb290IG9mIG15IGZlZWxpbmdzLiBUaGUgbWVkaWNhdGlvbiBzaGlwbWVudCB3YXMgYWxzbyBzdXBlclxuICAgIGNvbnZlbmllbnQgZm9yIG1lLiBJJmFwb3M7bSBzbyBnbGFkIEkgd2FzIGFibGUgdG8gcXVpY2tseSBib29rIGFuXG4gICAgYXBwb2ludG1lbnQgd2l0aCBMaW5hLlxuICA8L1Rlc3RpbW9uaWFsPixcbiAgPFRlc3RpbW9uaWFsXG4gICAga2V5PVwidGVzdGltb25pYWwtM1wiXG4gICAgdGl0bGU9XCJQYXRpZW50IGZyb20gUGVuc2Fjb2xhXCJcbiAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwicmdiYSgyNTUsIDIxNywgMjA4LCAwLjcpXCIgfX1cbiAgPlxuICAgIEkgd2FzIGFibGUgdG8gYm9vayBhbiBhcHBvaW50bWVudCB3aXRoIERyLiBQIHdpdGhpbiBhIGRheS4gSGUgd2FzXG4gICAgdW5kZXJzdGFuZGluZywgc3RyYWlnaHRmb3J3YXJkLCBhbmQgY2FyaW5nLiBIZSBhbnN3ZXJlZCBhbGwgbXkgcXVlc3Rpb25zIGFuZFxuICAgIG1hZGUgbWUgZmVlbCBjb25maWRlbnQgYWJvdXQgbXkgdHJlYXRtZW50LiBJdCZhcG9zO3MgYmVlbiBhIGdyZWF0IGV4cGVyaWVuY2VcbiAgICBzbyBmYXIuXG4gIDwvVGVzdGltb25pYWw+LFxuICA8VGVzdGltb25pYWxcbiAgICBrZXk9XCJ0ZXN0aW1vbmlhbC0xXCJcbiAgICB0aXRsZT1cIlBhdGllbnQgZnJvbSBUYW1wYSBCYXlcIlxuICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogXCJyZ2JhKDc3LCAxODgsIDE5NSwgMC4xKVwiIH19XG4gID5cbiAgICBUZWxlaGVhbHRoIGlzIHNvIGltcG9ydGFudCwgaXQgZW5hYmxlcyBwZW9wbGUgdG8gZ2V0IGNhcmUgd2l0aCBhbiBhY3R1YWxcbiAgICBwZXJzb24gb3ZlciB2aWRlby4gU29tZXRpbWVzIHdlIGNhbiZhcG9zO3QgcGh5c2ljYWxseSBnZXQgdG8gYSBkb2N0b3ImYXBvcztzXG4gICAgb2ZmaWNlLCBidXQgbm93IExpbmEgb2ZmZXJzIHNvbWV0aGluZyBmb3IgZXZlcnlvbmUgd2hvIGNhbiZhcG9zO3QgZG9cbiAgICBpbi1wZXJzb24uIFRoYW5rcyBmb3IgY3JlYXRpbmcgdGhpcyBwbGF0Zm9ybSFcbiAgPC9UZXN0aW1vbmlhbD4sXG5dO1xuXG5jb25zdCBUZXN0aW1vbmlhbHM6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGhlYWRpbmcsIGRhdGEgfSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvd1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDp3LTEvM1wiPlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgbWQ6dGV4dC00eGwgdGV4dC1jZW50ZXIgbWQ6dGV4dC1sZWZ0IG1iLThcIj5cbiAgICAgICAgICAgIHtoZWFkaW5nID8gaGVhZGluZyA6ICdMaWZlIGNoYW5naW5nIHJlc3VsdHMgZnJvbSByZWFsIG1lbWJlcnMnfSAgICAgICAgICBcbiAgICAgICAgPC9oMj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBtZDpqdXN0aWZ5LXN0YXJ0IG1kOmZsZXgtcm93IG92ZXJmbG93LWF1dG8gbWQ6c3BhY2UteC00XCI+XG4gICAgICAgIHt0ZXN0aW1vbmlhbHN9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFRlc3RpbW9uaWFscztcbiJdLCJzb3VyY2VSb290IjoiIn0=