self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./components/landing/LandingTemplate.tsx":
/*!************************************************!*\
  !*** ./components/landing/LandingTemplate.tsx ***!
  \************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "../node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_hooks_offer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/hooks/offer */ "./lib/hooks/offer.ts");
/* harmony import */ var _lib_hooks_utm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/hooks/utm */ "./lib/hooks/utm.ts");
/* harmony import */ var _EmergencyBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./EmergencyBar */ "./components/landing/EmergencyBar.tsx");
/* harmony import */ var _FAQ__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./FAQ */ "./components/landing/FAQ.tsx");
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Footer */ "./components/landing/Footer.tsx");
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Header */ "./components/landing/Header.tsx");
/* harmony import */ var _MedicalTeam__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./MedicalTeam */ "./components/landing/MedicalTeam.tsx");
/* harmony import */ var _NewCareProcess__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./NewCareProcess */ "./components/landing/NewCareProcess.tsx");
/* harmony import */ var _Pricing__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Pricing */ "./components/landing/Pricing.tsx");
/* harmony import */ var _Section__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Section */ "./components/landing/Section.tsx");
/* harmony import */ var _Testimonials__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Testimonials */ "./components/landing/Testimonials.tsx");
/* harmony import */ var _WhatWeTreat__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./WhatWeTreat */ "./components/landing/WhatWeTreat.tsx");
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\LandingTemplate.tsx",
    _this = undefined,
    _s = $RefreshSig$();

/**
 * Wrapper component used to provide template for the landing page.
 * Use this to create multiple variations of the landing page with
 * the same structure.
 */














var LandingTemplate = function LandingTemplate(_ref) {
  _s();

  var data = _ref.data,
      children = _ref.children;
  console.log('All data', data);
  var faq = data.faq,
      page = data.page;
  var fields = page.fields;
  var careProcessHeading = fields.careProcessHeading,
      careProcess = fields.careProcess;
  console.log('Titlte', careProcessHeading);
  (0,_lib_hooks_utm__WEBPACK_IMPORTED_MODULE_3__.useUtm)();

  var _useOffer = (0,_lib_hooks_offer__WEBPACK_IMPORTED_MODULE_2__.useOffer)(),
      offerText = _useOffer.offerText;

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Header__WEBPACK_IMPORTED_MODULE_7__.default, {
      title: "Lina",
      startOffer: offerText
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "desc",
      className: "flex justify-center bg-seashell relative",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container grid grid-cols-1 md:grid-cols-2",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 11
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "relative mt-8 md:mt-0",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
            src: "/images/ctabg.svg",
            width: "400",
            className: "ml-auto",
            style: {
              right: "4px"
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 39,
            columnNumber: 13
          }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
            width: "340",
            src: "/images/hero_image_small.png",
            className: "heroimage rounded-full absolute top-0"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 38,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "care_process",
      className: "flex justify-center",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_NewCareProcess__WEBPACK_IMPORTED_MODULE_9__.default, {
          heading: careProcessHeading,
          data: careProcess
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 55,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 53,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "testimonials",
      className: "flex justify-center bg-seashell",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Testimonials__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 59,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "what_we_treat",
      className: "flex justify-center bg-seashell",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_WhatWeTreat__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "medical_team",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_MedicalTeam__WEBPACK_IMPORTED_MODULE_8__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "pricing",
      className: "bg-seashell",
      noPadding: true,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Pricing__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 75,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "faq",
      className: "flex justify-center",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FAQ__WEBPACK_IMPORTED_MODULE_5__.default, {
          faq: faq
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 79,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "emergency",
      className: "flex justify-center",
      style: {
        backgroundColor: "rgba(244, 218, 213, 0.6)"
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_EmergencyBar__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 90,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 89,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Footer__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 93,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 33,
    columnNumber: 5
  }, _this);
};

_s(LandingTemplate, "A9a53XJ90MwUd3nc/qIbzNqRYoo=", false, function () {
  return [_lib_hooks_utm__WEBPACK_IMPORTED_MODULE_3__.useUtm, _lib_hooks_offer__WEBPACK_IMPORTED_MODULE_2__.useOffer];
});

_c = LandingTemplate;
/* harmony default export */ __webpack_exports__["default"] = (LandingTemplate);

var _c;

$RefreshReg$(_c, "LandingTemplate");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9sYW5kaW5nL0xhbmRpbmdUZW1wbGF0ZS50c3giXSwibmFtZXMiOlsiTGFuZGluZ1RlbXBsYXRlIiwiZGF0YSIsImNoaWxkcmVuIiwiY29uc29sZSIsImxvZyIsImZhcSIsInBhZ2UiLCJmaWVsZHMiLCJjYXJlUHJvY2Vzc0hlYWRpbmciLCJjYXJlUHJvY2VzcyIsInVzZVV0bSIsInVzZU9mZmVyIiwib2ZmZXJUZXh0IiwicmlnaHQiLCJiYWNrZ3JvdW5kQ29sb3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQSxJQUFNQSxlQUFnQyxHQUFHLFNBQW5DQSxlQUFtQyxPQUF3QjtBQUFBOztBQUFBLE1BQXJCQyxJQUFxQixRQUFyQkEsSUFBcUI7QUFBQSxNQUFmQyxRQUFlLFFBQWZBLFFBQWU7QUFDL0RDLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBd0JILElBQXhCO0FBRCtELE1BRXZESSxHQUZ1RCxHQUV6Q0osSUFGeUMsQ0FFdkRJLEdBRnVEO0FBQUEsTUFFbERDLElBRmtELEdBRXpDTCxJQUZ5QyxDQUVsREssSUFGa0Q7QUFBQSxNQUd2REMsTUFIdUQsR0FHNUNELElBSDRDLENBR3ZEQyxNQUh1RDtBQUFBLE1BSXZEQyxrQkFKdUQsR0FJbkJELE1BSm1CLENBSXZEQyxrQkFKdUQ7QUFBQSxNQUluQ0MsV0FKbUMsR0FJbkJGLE1BSm1CLENBSW5DRSxXQUptQztBQUsvRE4sU0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFzQkksa0JBQXRCO0FBQ0FFLHdEQUFNOztBQU55RCxrQkFPekNDLDBEQUFRLEVBUGlDO0FBQUEsTUFPdkRDLFNBUHVELGFBT3ZEQSxTQVB1RDs7QUFTL0Qsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsRUFBZjtBQUFBLDRCQUNFLDhEQUFDLDRDQUFEO0FBQVEsV0FBSyxFQUFDLE1BQWQ7QUFBcUIsZ0JBQVUsRUFBRUE7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGLGVBRUUsOERBQUMsOENBQUQ7QUFBUyxRQUFFLEVBQUMsTUFBWjtBQUFtQixlQUFTLEVBQUMsMENBQTdCO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLDJDQUFmO0FBQUEsZ0NBQ0U7QUFBQSxvQkFBTVY7QUFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFBSyxtQkFBUyxFQUFDLHVCQUFmO0FBQUEsa0NBQ0U7QUFDRSxlQUFHLEVBQUMsbUJBRE47QUFFRSxpQkFBSyxFQUFDLEtBRlI7QUFHRSxxQkFBUyxFQUFDLFNBSFo7QUFJRSxpQkFBSyxFQUFFO0FBQUVXLG1CQUFLLEVBQUU7QUFBVDtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFPRTtBQUNFLGlCQUFLLEVBQUMsS0FEUjtBQUVFLGVBQUcsRUFBQyw4QkFGTjtBQUdFLHFCQUFTLEVBQUM7QUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRkYsZUFvQkUsOERBQUMsOENBQUQ7QUFBUyxRQUFFLEVBQUMsY0FBWjtBQUEyQixlQUFTLEVBQUMscUJBQXJDO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSwrQkFDRSw4REFBQyxvREFBRDtBQUFnQixpQkFBTyxFQUFFTCxrQkFBekI7QUFBNkMsY0FBSSxFQUFFQztBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFwQkYsZUEwQkUsOERBQUMsOENBQUQ7QUFBUyxRQUFFLEVBQUMsY0FBWjtBQUEyQixlQUFTLEVBQUMsaUNBQXJDO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSwrQkFDRSw4REFBQyxtREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUExQkYsZUFnQ0UsOERBQUMsOENBQUQ7QUFBUyxRQUFFLEVBQUMsZUFBWjtBQUE0QixlQUFTLEVBQUMsaUNBQXRDO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSwrQkFDRSw4REFBQyxrREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFoQ0YsZUFzQ0UsOERBQUMsOENBQUQ7QUFBUyxRQUFFLEVBQUMsY0FBWjtBQUFBLDZCQUNFLDhEQUFDLGlEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdENGLGVBMENFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLFNBQVo7QUFBc0IsZUFBUyxFQUFDLGFBQWhDO0FBQThDLGVBQVMsTUFBdkQ7QUFBQSw2QkFDRSw4REFBQyw4Q0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTFDRixlQThDRSw4REFBQyw4Q0FBRDtBQUFTLFFBQUUsRUFBQyxLQUFaO0FBQWtCLGVBQVMsRUFBQyxxQkFBNUI7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUFBLCtCQUNFLDhEQUFDLHlDQUFEO0FBQUssYUFBRyxFQUFFSjtBQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTlDRixlQW1ERSw4REFBQyw4Q0FBRDtBQUNFLFFBQUUsRUFBQyxXQURMO0FBRUUsZUFBUyxFQUFDLHFCQUZaO0FBR0UsV0FBSyxFQUFFO0FBQUVTLHVCQUFlLEVBQUU7QUFBbkIsT0FIVDtBQUFBLDZCQUtFO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsK0JBQ0UsOERBQUMsa0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbkRGLGVBNERFLDhEQUFDLDRDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE1REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFnRUQsQ0F6RUQ7O0dBQU1kLGU7VUFNSlUsa0QsRUFDc0JDLHNEOzs7S0FQbEJYLGU7QUEyRU4sK0RBQWVBLGVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguNzljNGUxOWE0OTVjNGI3NDE5MTcuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogV3JhcHBlciBjb21wb25lbnQgdXNlZCB0byBwcm92aWRlIHRlbXBsYXRlIGZvciB0aGUgbGFuZGluZyBwYWdlLlxuICogVXNlIHRoaXMgdG8gY3JlYXRlIG11bHRpcGxlIHZhcmlhdGlvbnMgb2YgdGhlIGxhbmRpbmcgcGFnZSB3aXRoXG4gKiB0aGUgc2FtZSBzdHJ1Y3R1cmUuXG4gKi9cbmltcG9ydCB7IE5leHRQYWdlIH0gZnJvbSBcIm5leHRcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZU9mZmVyIH0gZnJvbSBcIi4uLy4uL2xpYi9ob29rcy9vZmZlclwiO1xuaW1wb3J0IHsgdXNlVXRtIH0gZnJvbSBcIi4uLy4uL2xpYi9ob29rcy91dG1cIjtcbmltcG9ydCBFbWVyZ2VuY3lCYXIgZnJvbSBcIi4vRW1lcmdlbmN5QmFyXCI7XG5pbXBvcnQgRkFRIGZyb20gXCIuL0ZBUVwiO1xuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi9Gb290ZXJcIjtcbmltcG9ydCBIZWFkZXIgZnJvbSBcIi4vSGVhZGVyXCI7XG5pbXBvcnQgTWVkaWNhbFRlYW0gZnJvbSBcIi4vTWVkaWNhbFRlYW1cIjtcbmltcG9ydCBOZXdDYXJlUHJvY2VzcyBmcm9tIFwiLi9OZXdDYXJlUHJvY2Vzc1wiO1xuaW1wb3J0IFByaWNpbmcgZnJvbSBcIi4vUHJpY2luZ1wiO1xuaW1wb3J0IFNlY3Rpb24gZnJvbSBcIi4vU2VjdGlvblwiO1xuaW1wb3J0IFRlc3RpbW9uaWFscyBmcm9tIFwiLi9UZXN0aW1vbmlhbHNcIjtcbmltcG9ydCBXaGF0V2VUcmVhdCBmcm9tIFwiLi9XaGF0V2VUcmVhdFwiO1xuXG5pbnRlcmZhY2UgUHJvcHMgeyB9XG5cbmNvbnN0IExhbmRpbmdUZW1wbGF0ZTogTmV4dFBhZ2U8UHJvcHM+ID0gKHsgZGF0YSwgY2hpbGRyZW4gfSkgPT4ge1xuICBjb25zb2xlLmxvZygnQWxsIGRhdGEnLCBkYXRhKVxuICBjb25zdCB7IGZhcSwgcGFnZSB9ID0gZGF0YVxuICBjb25zdCB7IGZpZWxkcyB9ID0gcGFnZVxuICBjb25zdCB7IGNhcmVQcm9jZXNzSGVhZGluZywgY2FyZVByb2Nlc3MgfSA9IGZpZWxkc1xuICBjb25zb2xlLmxvZygnVGl0bHRlJywgY2FyZVByb2Nlc3NIZWFkaW5nKVxuICB1c2VVdG0oKTtcbiAgY29uc3QgeyBvZmZlclRleHQgfSA9IHVzZU9mZmVyKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuICAgICAgPEhlYWRlciB0aXRsZT1cIkxpbmFcIiBzdGFydE9mZmVyPXtvZmZlclRleHR9IC8+XG4gICAgICA8U2VjdGlvbiBpZD1cImRlc2NcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGJnLXNlYXNoZWxsIHJlbGF0aXZlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyIGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICA8ZGl2PntjaGlsZHJlbn08L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG10LTggbWQ6bXQtMFwiPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBzcmM9XCIvaW1hZ2VzL2N0YWJnLnN2Z1wiXG4gICAgICAgICAgICAgIHdpZHRoPVwiNDAwXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtYXV0b1wiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHJpZ2h0OiBcIjRweFwiIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICB3aWR0aD1cIjM0MFwiXG4gICAgICAgICAgICAgIHNyYz1cIi9pbWFnZXMvaGVyb19pbWFnZV9zbWFsbC5wbmdcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoZXJvaW1hZ2Ugcm91bmRlZC1mdWxsIGFic29sdXRlIHRvcC0wXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuICAgICAgPFNlY3Rpb24gaWQ9XCJjYXJlX3Byb2Nlc3NcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgICAgPE5ld0NhcmVQcm9jZXNzIGhlYWRpbmc9e2NhcmVQcm9jZXNzSGVhZGluZ30gZGF0YT17Y2FyZVByb2Nlc3N9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICA8U2VjdGlvbiBpZD1cInRlc3RpbW9uaWFsc1wiIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgYmctc2Vhc2hlbGxcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICA8VGVzdGltb25pYWxzIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICA8U2VjdGlvbiBpZD1cIndoYXRfd2VfdHJlYXRcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGJnLXNlYXNoZWxsXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgICAgPFdoYXRXZVRyZWF0IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICA8U2VjdGlvbiBpZD1cIm1lZGljYWxfdGVhbVwiPlxuICAgICAgICA8TWVkaWNhbFRlYW0gLz5cbiAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgPFNlY3Rpb24gaWQ9XCJwcmljaW5nXCIgY2xhc3NOYW1lPVwiYmctc2Vhc2hlbGxcIiBub1BhZGRpbmc+XG4gICAgICAgIDxQcmljaW5nIC8+XG4gICAgICA8L1NlY3Rpb24+XG5cbiAgICAgIDxTZWN0aW9uIGlkPVwiZmFxXCIgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgICAgIDxGQVEgZmFxPXtmYXF9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuICAgICAgPFNlY3Rpb25cbiAgICAgICAgaWQ9XCJlbWVyZ2VuY3lcIlxuICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCJcbiAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcInJnYmEoMjQ0LCAyMTgsIDIxMywgMC42KVwiIH19XG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgICAgPEVtZXJnZW5jeUJhciAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvU2VjdGlvbj5cbiAgICAgIDxGb290ZXIgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IExhbmRpbmdUZW1wbGF0ZTtcbiJdLCJzb3VyY2VSb290IjoiIn0=