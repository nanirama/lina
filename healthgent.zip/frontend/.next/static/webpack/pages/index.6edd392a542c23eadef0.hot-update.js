self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./components/landing/LandingTemplate.tsx":
/*!************************************************!*\
  !*** ./components/landing/LandingTemplate.tsx ***!
  \************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "../node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_hooks_offer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/hooks/offer */ "./lib/hooks/offer.ts");
/* harmony import */ var _lib_hooks_utm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/hooks/utm */ "./lib/hooks/utm.ts");
/* harmony import */ var _EmergencyBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./EmergencyBar */ "./components/landing/EmergencyBar.tsx");
/* harmony import */ var _FAQ__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./FAQ */ "./components/landing/FAQ.tsx");
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Footer */ "./components/landing/Footer.tsx");
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Header */ "./components/landing/Header.tsx");
/* harmony import */ var _MedicalTeam__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./MedicalTeam */ "./components/landing/MedicalTeam.tsx");
/* harmony import */ var _NewCareProcess__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./NewCareProcess */ "./components/landing/NewCareProcess.tsx");
/* harmony import */ var _Pricing__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Pricing */ "./components/landing/Pricing.tsx");
/* harmony import */ var _Section__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Section */ "./components/landing/Section.tsx");
/* harmony import */ var _Testimonials__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Testimonials */ "./components/landing/Testimonials.tsx");
/* harmony import */ var _WhatWeTreat__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./WhatWeTreat */ "./components/landing/WhatWeTreat.tsx");
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\LandingTemplate.tsx",
    _this = undefined,
    _s = $RefreshSig$();

/**
 * Wrapper component used to provide template for the landing page.
 * Use this to create multiple variations of the landing page with
 * the same structure.
 */














var LandingTemplate = function LandingTemplate(_ref) {
  _s();

  var data = _ref.data,
      children = _ref.children;
  console.log('All data', data);
  var faq = data.faq,
      page = data.page;
  var fields = page.fields;
  var careProcessHeading = fields.careProcessHeading,
      careProcess = fields.careProcess,
      testimonialsHeading = fields.testimonialsHeading,
      testimonials = fields.testimonials;
  console.log('Titlte', careProcessHeading);
  (0,_lib_hooks_utm__WEBPACK_IMPORTED_MODULE_3__.useUtm)();

  var _useOffer = (0,_lib_hooks_offer__WEBPACK_IMPORTED_MODULE_2__.useOffer)(),
      offerText = _useOffer.offerText;

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Header__WEBPACK_IMPORTED_MODULE_7__.default, {
      title: "Lina",
      startOffer: offerText
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "desc",
      className: "flex justify-center bg-seashell relative",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container grid grid-cols-1 md:grid-cols-2",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 11
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "relative mt-8 md:mt-0",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
            src: "/images/ctabg.svg",
            width: "400",
            className: "ml-auto",
            style: {
              right: "4px"
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 13
          }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
            width: "340",
            src: "/images/hero_image_small.png",
            className: "heroimage rounded-full absolute top-0"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "care_process",
      className: "flex justify-center",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_NewCareProcess__WEBPACK_IMPORTED_MODULE_9__.default, {
          heading: careProcessHeading,
          data: careProcess
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "testimonials",
      className: "flex justify-center bg-seashell",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Testimonials__WEBPACK_IMPORTED_MODULE_12__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "what_we_treat",
      className: "flex justify-center bg-seashell",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_WhatWeTreat__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "medical_team",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_MedicalTeam__WEBPACK_IMPORTED_MODULE_8__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 76,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "pricing",
      className: "bg-seashell",
      noPadding: true,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Pricing__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "faq",
      className: "flex justify-center",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FAQ__WEBPACK_IMPORTED_MODULE_5__.default, {
          faq: faq
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "emergency",
      className: "flex justify-center",
      style: {
        backgroundColor: "rgba(244, 218, 213, 0.6)"
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_EmergencyBar__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 95,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 89,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Footer__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 98,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 38,
    columnNumber: 5
  }, _this);
};

_s(LandingTemplate, "A9a53XJ90MwUd3nc/qIbzNqRYoo=", false, function () {
  return [_lib_hooks_utm__WEBPACK_IMPORTED_MODULE_3__.useUtm, _lib_hooks_offer__WEBPACK_IMPORTED_MODULE_2__.useOffer];
});

_c = LandingTemplate;
/* harmony default export */ __webpack_exports__["default"] = (LandingTemplate);

var _c;

$RefreshReg$(_c, "LandingTemplate");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9sYW5kaW5nL0xhbmRpbmdUZW1wbGF0ZS50c3giXSwibmFtZXMiOlsiTGFuZGluZ1RlbXBsYXRlIiwiZGF0YSIsImNoaWxkcmVuIiwiY29uc29sZSIsImxvZyIsImZhcSIsInBhZ2UiLCJmaWVsZHMiLCJjYXJlUHJvY2Vzc0hlYWRpbmciLCJjYXJlUHJvY2VzcyIsInRlc3RpbW9uaWFsc0hlYWRpbmciLCJ0ZXN0aW1vbmlhbHMiLCJ1c2VVdG0iLCJ1c2VPZmZlciIsIm9mZmVyVGV4dCIsInJpZ2h0IiwiYmFja2dyb3VuZENvbG9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsSUFBTUEsZUFBZ0MsR0FBRyxTQUFuQ0EsZUFBbUMsT0FBd0I7QUFBQTs7QUFBQSxNQUFyQkMsSUFBcUIsUUFBckJBLElBQXFCO0FBQUEsTUFBZkMsUUFBZSxRQUFmQSxRQUFlO0FBQy9EQyxTQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCSCxJQUF4QjtBQUQrRCxNQUV2REksR0FGdUQsR0FFekNKLElBRnlDLENBRXZESSxHQUZ1RDtBQUFBLE1BRWxEQyxJQUZrRCxHQUV6Q0wsSUFGeUMsQ0FFbERLLElBRmtEO0FBQUEsTUFHdkRDLE1BSHVELEdBRzVDRCxJQUg0QyxDQUd2REMsTUFIdUQ7QUFBQSxNQUs3REMsa0JBTDZELEdBUzNERCxNQVQyRCxDQUs3REMsa0JBTDZEO0FBQUEsTUFNN0RDLFdBTjZELEdBUzNERixNQVQyRCxDQU03REUsV0FONkQ7QUFBQSxNQU83REMsbUJBUDZELEdBUzNESCxNQVQyRCxDQU83REcsbUJBUDZEO0FBQUEsTUFRN0RDLFlBUjZELEdBUzNESixNQVQyRCxDQVE3REksWUFSNkQ7QUFVL0RSLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBc0JJLGtCQUF0QjtBQUNBSSx3REFBTTs7QUFYeUQsa0JBWXpDQywwREFBUSxFQVppQztBQUFBLE1BWXZEQyxTQVp1RCxhQVl2REEsU0FadUQ7O0FBYy9ELHNCQUNFO0FBQUssYUFBUyxFQUFDLEVBQWY7QUFBQSw0QkFDRSw4REFBQyw0Q0FBRDtBQUFRLFdBQUssRUFBQyxNQUFkO0FBQXFCLGdCQUFVLEVBQUVBO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQUVFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLE1BQVo7QUFBbUIsZUFBUyxFQUFDLDBDQUE3QjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQywyQ0FBZjtBQUFBLGdDQUNFO0FBQUEsb0JBQU1aO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQUssbUJBQVMsRUFBQyx1QkFBZjtBQUFBLGtDQUNFO0FBQ0UsZUFBRyxFQUFDLG1CQUROO0FBRUUsaUJBQUssRUFBQyxLQUZSO0FBR0UscUJBQVMsRUFBQyxTQUhaO0FBSUUsaUJBQUssRUFBRTtBQUFFYSxtQkFBSyxFQUFFO0FBQVQ7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBT0U7QUFDRSxpQkFBSyxFQUFDLEtBRFI7QUFFRSxlQUFHLEVBQUMsOEJBRk47QUFHRSxxQkFBUyxFQUFDO0FBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUZGLGVBb0JFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLGNBQVo7QUFBMkIsZUFBUyxFQUFDLHFCQUFyQztBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsK0JBQ0UsOERBQUMsb0RBQUQ7QUFBZ0IsaUJBQU8sRUFBRVAsa0JBQXpCO0FBQTZDLGNBQUksRUFBRUM7QUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcEJGLGVBMEJFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLGNBQVo7QUFBMkIsZUFBUyxFQUFDLGlDQUFyQztBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsK0JBQ0UsOERBQUMsbURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMUJGLGVBZ0NFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLGVBQVo7QUFBNEIsZUFBUyxFQUFDLGlDQUF0QztBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsK0JBQ0UsOERBQUMsa0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaENGLGVBc0NFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLGNBQVo7QUFBQSw2QkFDRSw4REFBQyxpREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXRDRixlQTBDRSw4REFBQyw4Q0FBRDtBQUFTLFFBQUUsRUFBQyxTQUFaO0FBQXNCLGVBQVMsRUFBQyxhQUFoQztBQUE4QyxlQUFTLE1BQXZEO0FBQUEsNkJBQ0UsOERBQUMsOENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUExQ0YsZUE4Q0UsOERBQUMsOENBQUQ7QUFBUyxRQUFFLEVBQUMsS0FBWjtBQUFrQixlQUFTLEVBQUMscUJBQTVCO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSwrQkFDRSw4REFBQyx5Q0FBRDtBQUFLLGFBQUcsRUFBRUo7QUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE5Q0YsZUFtREUsOERBQUMsOENBQUQ7QUFDRSxRQUFFLEVBQUMsV0FETDtBQUVFLGVBQVMsRUFBQyxxQkFGWjtBQUdFLFdBQUssRUFBRTtBQUFFVyx1QkFBZSxFQUFFO0FBQW5CLE9BSFQ7QUFBQSw2QkFLRTtBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUFBLCtCQUNFLDhEQUFDLGtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW5ERixlQTRERSw4REFBQyw0Q0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBZ0VELENBOUVEOztHQUFNaEIsZTtVQVdKWSxrRCxFQUNzQkMsc0Q7OztLQVpsQmIsZTtBQWdGTiwrREFBZUEsZUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC42ZWRkMzkyYTU0MmMyM2VhZGVmMC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBXcmFwcGVyIGNvbXBvbmVudCB1c2VkIHRvIHByb3ZpZGUgdGVtcGxhdGUgZm9yIHRoZSBsYW5kaW5nIHBhZ2UuXG4gKiBVc2UgdGhpcyB0byBjcmVhdGUgbXVsdGlwbGUgdmFyaWF0aW9ucyBvZiB0aGUgbGFuZGluZyBwYWdlIHdpdGhcbiAqIHRoZSBzYW1lIHN0cnVjdHVyZS5cbiAqL1xuaW1wb3J0IHsgTmV4dFBhZ2UgfSBmcm9tIFwibmV4dFwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlT2ZmZXIgfSBmcm9tIFwiLi4vLi4vbGliL2hvb2tzL29mZmVyXCI7XG5pbXBvcnQgeyB1c2VVdG0gfSBmcm9tIFwiLi4vLi4vbGliL2hvb2tzL3V0bVwiO1xuaW1wb3J0IEVtZXJnZW5jeUJhciBmcm9tIFwiLi9FbWVyZ2VuY3lCYXJcIjtcbmltcG9ydCBGQVEgZnJvbSBcIi4vRkFRXCI7XG5pbXBvcnQgRm9vdGVyIGZyb20gXCIuL0Zvb3RlclwiO1xuaW1wb3J0IEhlYWRlciBmcm9tIFwiLi9IZWFkZXJcIjtcbmltcG9ydCBNZWRpY2FsVGVhbSBmcm9tIFwiLi9NZWRpY2FsVGVhbVwiO1xuaW1wb3J0IE5ld0NhcmVQcm9jZXNzIGZyb20gXCIuL05ld0NhcmVQcm9jZXNzXCI7XG5pbXBvcnQgUHJpY2luZyBmcm9tIFwiLi9QcmljaW5nXCI7XG5pbXBvcnQgU2VjdGlvbiBmcm9tIFwiLi9TZWN0aW9uXCI7XG5pbXBvcnQgVGVzdGltb25pYWxzIGZyb20gXCIuL1Rlc3RpbW9uaWFsc1wiO1xuaW1wb3J0IFdoYXRXZVRyZWF0IGZyb20gXCIuL1doYXRXZVRyZWF0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgTGFuZGluZ1RlbXBsYXRlOiBOZXh0UGFnZTxQcm9wcz4gPSAoeyBkYXRhLCBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnNvbGUubG9nKCdBbGwgZGF0YScsIGRhdGEpXG4gIGNvbnN0IHsgZmFxLCBwYWdlIH0gPSBkYXRhXG4gIGNvbnN0IHsgZmllbGRzIH0gPSBwYWdlXG4gIGNvbnN0IHtcbiAgICBjYXJlUHJvY2Vzc0hlYWRpbmcsXG4gICAgY2FyZVByb2Nlc3MsXG4gICAgdGVzdGltb25pYWxzSGVhZGluZyxcbiAgICB0ZXN0aW1vbmlhbHNcbiAgfSA9IGZpZWxkc1xuICBjb25zb2xlLmxvZygnVGl0bHRlJywgY2FyZVByb2Nlc3NIZWFkaW5nKVxuICB1c2VVdG0oKTtcbiAgY29uc3QgeyBvZmZlclRleHQgfSA9IHVzZU9mZmVyKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuICAgICAgPEhlYWRlciB0aXRsZT1cIkxpbmFcIiBzdGFydE9mZmVyPXtvZmZlclRleHR9IC8+XG4gICAgICA8U2VjdGlvbiBpZD1cImRlc2NcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGJnLXNlYXNoZWxsIHJlbGF0aXZlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyIGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICA8ZGl2PntjaGlsZHJlbn08L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG10LTggbWQ6bXQtMFwiPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBzcmM9XCIvaW1hZ2VzL2N0YWJnLnN2Z1wiXG4gICAgICAgICAgICAgIHdpZHRoPVwiNDAwXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtYXV0b1wiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHJpZ2h0OiBcIjRweFwiIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICB3aWR0aD1cIjM0MFwiXG4gICAgICAgICAgICAgIHNyYz1cIi9pbWFnZXMvaGVyb19pbWFnZV9zbWFsbC5wbmdcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoZXJvaW1hZ2Ugcm91bmRlZC1mdWxsIGFic29sdXRlIHRvcC0wXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuICAgICAgPFNlY3Rpb24gaWQ9XCJjYXJlX3Byb2Nlc3NcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgICAgPE5ld0NhcmVQcm9jZXNzIGhlYWRpbmc9e2NhcmVQcm9jZXNzSGVhZGluZ30gZGF0YT17Y2FyZVByb2Nlc3N9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICA8U2VjdGlvbiBpZD1cInRlc3RpbW9uaWFsc1wiIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgYmctc2Vhc2hlbGxcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICA8VGVzdGltb25pYWxzIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICA8U2VjdGlvbiBpZD1cIndoYXRfd2VfdHJlYXRcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGJnLXNlYXNoZWxsXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgICAgPFdoYXRXZVRyZWF0IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICA8U2VjdGlvbiBpZD1cIm1lZGljYWxfdGVhbVwiPlxuICAgICAgICA8TWVkaWNhbFRlYW0gLz5cbiAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgPFNlY3Rpb24gaWQ9XCJwcmljaW5nXCIgY2xhc3NOYW1lPVwiYmctc2Vhc2hlbGxcIiBub1BhZGRpbmc+XG4gICAgICAgIDxQcmljaW5nIC8+XG4gICAgICA8L1NlY3Rpb24+XG5cbiAgICAgIDxTZWN0aW9uIGlkPVwiZmFxXCIgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgICAgIDxGQVEgZmFxPXtmYXF9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuICAgICAgPFNlY3Rpb25cbiAgICAgICAgaWQ9XCJlbWVyZ2VuY3lcIlxuICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCJcbiAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcInJnYmEoMjQ0LCAyMTgsIDIxMywgMC42KVwiIH19XG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgICAgPEVtZXJnZW5jeUJhciAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvU2VjdGlvbj5cbiAgICAgIDxGb290ZXIgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IExhbmRpbmdUZW1wbGF0ZTtcbiJdLCJzb3VyY2VSb290IjoiIn0=