self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./components/landing/Testimonials.tsx":
/*!*********************************************!*\
  !*** ./components/landing/Testimonials.tsx ***!
  \*********************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "../node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "../node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SharpStars__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SharpStars */ "./components/landing/SharpStars.tsx");
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\Testimonials.tsx",
    _this = undefined;

/**
 * Shows testimonials on the landing page
 */



var Testimonial = function Testimonial(_ref) {
  var title = _ref.title,
      children = _ref.children,
      style = _ref.style;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "p-8 max-w-sm mb-4 w-full md:w-96 flex-shrink-0",
    style: style,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "text-sm font-bold mb-8",
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "leading-relaxed mb-8",
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_SharpStars__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, _this);
};

_c = Testimonial;
var testimonials = [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Miami",
  style: {
    backgroundColor: "rgba(77, 188, 195, 0.1)"
  },
  children: "My provider was kind and considerate. He asked me a lot of questions to get to the root of my feelings. The medication shipment was also super convenient for me. I'm so glad I was able to quickly book an appointment with Lina."
}, "testimonial-2", false, {
  fileName: _jsxFileName,
  lineNumber: 27,
  columnNumber: 3
}, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Pensacola",
  style: {
    backgroundColor: "rgba(255, 217, 208, 0.7)"
  },
  children: "I was able to book an appointment with Dr. P within a day. He was understanding, straightforward, and caring. He answered all my questions and made me feel confident about my treatment. It's been a great experience so far."
}, "testimonial-3", false, {
  fileName: _jsxFileName,
  lineNumber: 39,
  columnNumber: 3
}, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Tampa Bay",
  style: {
    backgroundColor: "rgba(77, 188, 195, 0.1)"
  },
  children: "Telehealth is so important, it enables people to get care with an actual person over video. Sometimes we can't physically get to a doctor's office, but now Lina offers something for everyone who can't do in-person. Thanks for creating this platform!"
}, "testimonial-1", false, {
  fileName: _jsxFileName,
  lineNumber: 49,
  columnNumber: 3
}, undefined)];

var Testimonials = function Testimonials(_ref2) {
  var heading = _ref2.heading,
      data = _ref2.data;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "flex flex-col md:flex-row",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "md:w-1/3",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
        className: "text-3xl md:text-4xl text-center md:text-left mb-8",
        children: heading ? heading : 'Our care process'
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 7
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "w-full flex flex-col justify-center md:justify-start md:flex-row overflow-auto md:space-x-4",
      children: testimonials
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 63,
    columnNumber: 5
  }, _this);
};

_c2 = Testimonials;
/* harmony default export */ __webpack_exports__["default"] = (Testimonials);

var _c, _c2;

$RefreshReg$(_c, "Testimonial");
$RefreshReg$(_c2, "Testimonials");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9sYW5kaW5nL1Rlc3RpbW9uaWFscy50c3giXSwibmFtZXMiOlsiVGVzdGltb25pYWwiLCJ0aXRsZSIsImNoaWxkcmVuIiwic3R5bGUiLCJ0ZXN0aW1vbmlhbHMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJUZXN0aW1vbmlhbHMiLCJoZWFkaW5nIiwiZGF0YSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQSxJQUFNQSxXQUFvRSxHQUFHLFNBQXZFQSxXQUF1RSxPQUl2RTtBQUFBLE1BSEpDLEtBR0ksUUFISkEsS0FHSTtBQUFBLE1BRkpDLFFBRUksUUFGSkEsUUFFSTtBQUFBLE1BREpDLEtBQ0ksUUFESkEsS0FDSTtBQUNKLHNCQUNFO0FBQ0UsYUFBUyxFQUFDLGdEQURaO0FBRUUsU0FBSyxFQUFFQSxLQUZUO0FBQUEsNEJBSUU7QUFBSyxlQUFTLEVBQUMsd0JBQWY7QUFBQSxnQkFBeUNGO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFKRixlQUtFO0FBQUssZUFBUyxFQUFDLHNCQUFmO0FBQUEsZ0JBQXVDQztBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTEYsZUFNRSw4REFBQyxnREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFVRCxDQWZEOztLQUFNRixXO0FBaUJOLElBQU1JLFlBQVksR0FBRyxjQUNuQiw4REFBQyxXQUFEO0FBRUUsT0FBSyxFQUFDLG9CQUZSO0FBR0UsT0FBSyxFQUFFO0FBQ0xDLG1CQUFlLEVBQUU7QUFEWixHQUhUO0FBQUE7QUFBQSxHQUNNLGVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURtQixlQWFuQiw4REFBQyxXQUFEO0FBRUUsT0FBSyxFQUFDLHdCQUZSO0FBR0UsT0FBSyxFQUFFO0FBQUVBLG1CQUFlLEVBQUU7QUFBbkIsR0FIVDtBQUFBO0FBQUEsR0FDTSxlQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFibUIsZUF1Qm5CLDhEQUFDLFdBQUQ7QUFFRSxPQUFLLEVBQUMsd0JBRlI7QUFHRSxPQUFLLEVBQUU7QUFBRUEsbUJBQWUsRUFBRTtBQUFuQixHQUhUO0FBQUE7QUFBQSxHQUNNLGVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXZCbUIsQ0FBckI7O0FBbUNBLElBQU1DLFlBQTZCLEdBQUcsU0FBaENBLFlBQWdDLFFBQXVCO0FBQUEsTUFBcEJDLE9BQW9CLFNBQXBCQSxPQUFvQjtBQUFBLE1BQVhDLElBQVcsU0FBWEEsSUFBVztBQUMzRCxzQkFDRTtBQUFLLGFBQVMsRUFBQywyQkFBZjtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLFVBQWY7QUFBQSw2QkFDRTtBQUFJLGlCQUFTLEVBQUMsb0RBQWQ7QUFBQSxrQkFDQ0QsT0FBTyxHQUFHQSxPQUFILEdBQWE7QUFEckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQU9FO0FBQUssZUFBUyxFQUFDLDZGQUFmO0FBQUEsZ0JBQ0dIO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBYUQsQ0FkRDs7TUFBTUUsWTtBQWdCTiwrREFBZUEsWUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC5kYzNmYmI0NjRmNWEzZTJjZDFkMS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBTaG93cyB0ZXN0aW1vbmlhbHMgb24gdGhlIGxhbmRpbmcgcGFnZVxuICovXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgU2hhcnBTdGFycyBmcm9tIFwiLi9TaGFycFN0YXJzXCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgVGVzdGltb25pYWw6IFJlYWN0LkZDPHsgdGl0bGU6IHN0cmluZzsgc3R5bGU6IFJlYWN0LkNTU1Byb3BlcnRpZXMgfT4gPSAoe1xuICB0aXRsZSxcbiAgY2hpbGRyZW4sXG4gIHN0eWxlLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cInAtOCBtYXgtdy1zbSBtYi00IHctZnVsbCBtZDp3LTk2IGZsZXgtc2hyaW5rLTBcIlxuICAgICAgc3R5bGU9e3N0eWxlfVxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgbWItOFwiPnt0aXRsZX08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkIG1iLThcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgICA8U2hhcnBTdGFycyAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuY29uc3QgdGVzdGltb25pYWxzID0gW1xuICA8VGVzdGltb25pYWxcbiAgICBrZXk9XCJ0ZXN0aW1vbmlhbC0yXCJcbiAgICB0aXRsZT1cIlBhdGllbnQgZnJvbSBNaWFtaVwiXG4gICAgc3R5bGU9e3tcbiAgICAgIGJhY2tncm91bmRDb2xvcjogXCJyZ2JhKDc3LCAxODgsIDE5NSwgMC4xKVwiLFxuICAgIH19XG4gID5cbiAgICBNeSBwcm92aWRlciB3YXMga2luZCBhbmQgY29uc2lkZXJhdGUuIEhlIGFza2VkIG1lIGEgbG90IG9mIHF1ZXN0aW9ucyB0byBnZXRcbiAgICB0byB0aGUgcm9vdCBvZiBteSBmZWVsaW5ncy4gVGhlIG1lZGljYXRpb24gc2hpcG1lbnQgd2FzIGFsc28gc3VwZXJcbiAgICBjb252ZW5pZW50IGZvciBtZS4gSSZhcG9zO20gc28gZ2xhZCBJIHdhcyBhYmxlIHRvIHF1aWNrbHkgYm9vayBhblxuICAgIGFwcG9pbnRtZW50IHdpdGggTGluYS5cbiAgPC9UZXN0aW1vbmlhbD4sXG4gIDxUZXN0aW1vbmlhbFxuICAgIGtleT1cInRlc3RpbW9uaWFsLTNcIlxuICAgIHRpdGxlPVwiUGF0aWVudCBmcm9tIFBlbnNhY29sYVwiXG4gICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcInJnYmEoMjU1LCAyMTcsIDIwOCwgMC43KVwiIH19XG4gID5cbiAgICBJIHdhcyBhYmxlIHRvIGJvb2sgYW4gYXBwb2ludG1lbnQgd2l0aCBEci4gUCB3aXRoaW4gYSBkYXkuIEhlIHdhc1xuICAgIHVuZGVyc3RhbmRpbmcsIHN0cmFpZ2h0Zm9yd2FyZCwgYW5kIGNhcmluZy4gSGUgYW5zd2VyZWQgYWxsIG15IHF1ZXN0aW9ucyBhbmRcbiAgICBtYWRlIG1lIGZlZWwgY29uZmlkZW50IGFib3V0IG15IHRyZWF0bWVudC4gSXQmYXBvcztzIGJlZW4gYSBncmVhdCBleHBlcmllbmNlXG4gICAgc28gZmFyLlxuICA8L1Rlc3RpbW9uaWFsPixcbiAgPFRlc3RpbW9uaWFsXG4gICAga2V5PVwidGVzdGltb25pYWwtMVwiXG4gICAgdGl0bGU9XCJQYXRpZW50IGZyb20gVGFtcGEgQmF5XCJcbiAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwicmdiYSg3NywgMTg4LCAxOTUsIDAuMSlcIiB9fVxuICA+XG4gICAgVGVsZWhlYWx0aCBpcyBzbyBpbXBvcnRhbnQsIGl0IGVuYWJsZXMgcGVvcGxlIHRvIGdldCBjYXJlIHdpdGggYW4gYWN0dWFsXG4gICAgcGVyc29uIG92ZXIgdmlkZW8uIFNvbWV0aW1lcyB3ZSBjYW4mYXBvczt0IHBoeXNpY2FsbHkgZ2V0IHRvIGEgZG9jdG9yJmFwb3M7c1xuICAgIG9mZmljZSwgYnV0IG5vdyBMaW5hIG9mZmVycyBzb21ldGhpbmcgZm9yIGV2ZXJ5b25lIHdobyBjYW4mYXBvczt0IGRvXG4gICAgaW4tcGVyc29uLiBUaGFua3MgZm9yIGNyZWF0aW5nIHRoaXMgcGxhdGZvcm0hXG4gIDwvVGVzdGltb25pYWw+LFxuXTtcblxuY29uc3QgVGVzdGltb25pYWxzOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBoZWFkaW5nLCBkYXRhIH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3dcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6dy0xLzNcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIG1kOnRleHQtNHhsIHRleHQtY2VudGVyIG1kOnRleHQtbGVmdCBtYi04XCI+XG4gICAgICAgIHtoZWFkaW5nID8gaGVhZGluZyA6ICdPdXIgY2FyZSBwcm9jZXNzJ31cbiAgICAgICAgICBcbiAgICAgICAgPC9oMj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBtZDpqdXN0aWZ5LXN0YXJ0IG1kOmZsZXgtcm93IG92ZXJmbG93LWF1dG8gbWQ6c3BhY2UteC00XCI+XG4gICAgICAgIHt0ZXN0aW1vbmlhbHN9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFRlc3RpbW9uaWFscztcbiJdLCJzb3VyY2VSb290IjoiIn0=