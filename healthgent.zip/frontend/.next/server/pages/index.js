(function() {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./components/core/Button.tsx":
/*!************************************!*\
  !*** ./components/core/Button.tsx ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\core\\Button.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

/**
 * Styled <button> component for the patient facing product
 */


const Button = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef((props, ref) => {
  const {
    asLink,
    children,
    buttonType,
    className,
    disabled,
    hidden,
    outline,
    processing
  } = props,
        otherProps = _objectWithoutProperties(props, ["asLink", "children", "buttonType", "className", "disabled", "hidden", "outline", "processing"]);

  const buttonClass = classnames__WEBPACK_IMPORTED_MODULE_2___default()("items-center justify-center p-3", "rounded outline-none focus:outline-none", {
    flex: !hidden,
    hidden: hidden,
    disabled: disabled // "bg-red-400": !buttonType,

  }, !outline ? {
    "text-white shadow bg-darkGray hover:bg-darkGray-800 active:bg-darkGray-800": !disabled && buttonType === "cta",
    "text-white shadow bg-coral hover:bg-coral-500 active:bg-coral-500": !disabled && buttonType === "primary" || !buttonType,
    "text-darkGray bg-transparent text-darkGray border border-solid border-darkGray hover:bg-darkGray hover:text-white rounded-full": buttonType === "header",
    "bg-gray-300 hover:bg-gray-300": disabled
  } : {
    "border border-coral text-coral hover:bg-coral hover:text-white": true
  }, className);

  if (asLink) {
    return (
      /*#__PURE__*/
      // @ts-ignore
      (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", _objectSpread(_objectSpread({
        className: buttonClass
      }, otherProps), {}, {
        children: children
      }), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 7
      }, undefined)
    );
  }

  return (
    /*#__PURE__*/
    // @ts-ignore
    (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", _objectSpread(_objectSpread({
      className: buttonClass,
      disabled: disabled
    }, otherProps), {}, {
      children: [children, processing ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
        className: "animate-spin ml-2 h-5 w-5 text-white",
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("circle", {
          className: "opacity-25",
          cx: "12",
          cy: "12",
          r: "10",
          stroke: "currentColor",
          strokeWidth: "4"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 108,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
          className: "opacity-75",
          fill: "currentColor",
          d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 116,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 102,
        columnNumber: 9
      }, undefined) : null]
    }), void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 99,
      columnNumber: 5
    }, undefined)
  );
});
/* harmony default export */ __webpack_exports__["default"] = (Button);

/***/ }),

/***/ "./components/landing/CTAButton.tsx":
/*!******************************************!*\
  !*** ./components/landing/CTAButton.tsx ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "../node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\CTAButton.tsx";

/**
 * Call to action button for landing page
 */




const CTAButton = ({
  className,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
    href: "/onboarding/intro/start",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
      href: "#",
      className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("flex items-center text-center rounded-full bg-teal hover:bg-teal-400 uppercase text-white text-sm font-bold p-2", className),
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: "text-center ml-auto",
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "ml-auto rounded-full flex items-center justify-center bg-seashell p-2",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
          width: "20",
          height: "20",
          viewBox: "0 0 20 20",
          fill: "none",
          xmlns: "http://www.w3.org/2000/svg",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
            d: "M9.78009 0.982666L8.60321 2.15955L15.9447 9.52906L0.445312 9.445V11.1263L15.9727 11.2103L8.77133 18.3837L9.94822 19.5886L19.1671 10.3697L9.78009 0.982666Z",
            fill: "#374146"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (CTAButton);

/***/ }),

/***/ "./components/landing/EmergencyBar.tsx":
/*!*********************************************!*\
  !*** ./components/landing/EmergencyBar.tsx ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\EmergencyBar.tsx";

/**
 * Shows numbers to call/dial in case of an emergency for landing
 */


const EmergencyBar = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "grid grid-cols-1 space-y-8 md:grid-cols-2 md:space-y-0",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
        src: "/images/distress.svg",
        className: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "ml-4 max-w-xs",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "text-3xl mb-6",
          children: "741-741"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          children: "If you're in emotional distress, text HOME to connect with a counselor immediately."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
        src: "/images/emergency.svg",
        className: ""
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "ml-4 max-w-xs",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "text-3xl mb-6",
          children: "911"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          children: "If you're having a medical or mental health emergency, call 911 or go to your local ER."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (EmergencyBar);

/***/ }),

/***/ "./components/landing/FAQ.tsx":
/*!************************************!*\
  !*** ./components/landing/FAQ.tsx ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "../node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contentful_rich_text_react_renderer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @contentful/rich-text-react-renderer */ "@contentful/rich-text-react-renderer");
/* harmony import */ var _contentful_rich_text_react_renderer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_contentful_rich_text_react_renderer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _FAQItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FAQItem */ "./components/landing/FAQItem.tsx");
/* harmony import */ var _core_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../core/Button */ "./components/core/Button.tsx");
/* harmony import */ var _lib_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../lib/api */ "./lib/api.ts");

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\FAQ.tsx";

/**
 * Component used to display FAQ on landing page and FAQ page.
 * Dynamically pulls list of states operated in from backend
 */








const FAQ = ({
  faq,
  title,
  showButton = true
}) => {
  const {
    0: states,
    1: setStates
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    (0,_lib_api__WEBPACK_IMPORTED_MODULE_6__.getStates)().then(setStates);
  }, []);
  const stateList = states.map(s => s.name);
  const stateEnding = stateList.slice(0, -1).join(", ") + " and " + stateList[stateList.length - 1];
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "flex flex-col justify-center items-center",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
      className: "text-3xl md:text-4xl text-center md:text-left mb-16",
      children: title ? title : "FAQs"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
      className: "w-full space-y-8",
      children: faq.map(({
        fields
      }, index) => {
        return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FAQItem__WEBPACK_IMPORTED_MODULE_4__.default, {
          title: fields.question,
          children: (0,_contentful_rich_text_react_renderer__WEBPACK_IMPORTED_MODULE_3__.documentToReactComponents)(fields.faqanswer)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 13
        }, undefined);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }, undefined), showButton ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
      href: "/faq",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_core_Button__WEBPACK_IMPORTED_MODULE_5__.default, {
        asLink: true,
        href: "#",
        buttonType: "secondary",
        className: "mt-8 w-full md:w-max text-center border border-darkGray border-1 hover:bg-darkGray hover:text-white",
        children: "Get answers to other questions"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 190,
        columnNumber: 11
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 189,
      columnNumber: 9
    }, undefined) : null]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (FAQ);

/***/ }),

/***/ "./components/landing/FAQItem.tsx":
/*!****************************************!*\
  !*** ./components/landing/FAQItem.tsx ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @headlessui/react */ "@headlessui/react");
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\FAQItem.tsx";

/**
 * Individual question/answer in the FAQ
 */



const FAQItem = ({
  title,
  children
}) => {
  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
    className: "border-b border-darkGray pb-2 flex flex-col justify-between items-center",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
      className: "w-full flex items-center text-left focus:outline-none",
      onClick: () => setOpen(!open),
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
        className: "text-lg font-light",
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "ml-auto",
        children: open ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
          className: "w-6 h-6",
          xmlns: "http://www.w3.org/2000/svg",
          fill: "none",
          viewBox: "0 0 24 24",
          stroke: "currentColor",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 1,
            d: "M20 12H4"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 13
        }, undefined) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
          className: "w-6 h-6",
          xmlns: "http://www.w3.org/2000/svg",
          fill: "none",
          viewBox: "0 0 24 24",
          stroke: "currentColor",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 1,
            d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 13
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
      show: open,
      className: "py-4",
      enter: "transition ease-out duration-200",
      enterFrom: "transform opacity-0 scale-95",
      enterTo: "transform opacity-100 scale-100",
      leave: "transition ease-in duration-75",
      leaveFrom: "transform opacity-100 scale-100",
      leaveTo: "transform opacity-0 scale-95",
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (FAQItem);

/***/ }),

/***/ "./components/landing/Footer.tsx":
/*!***************************************!*\
  !*** ./components/landing/Footer.tsx ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "../node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _LegitscriptSeal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./LegitscriptSeal */ "./components/landing/LegitscriptSeal.tsx");
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Logo */ "./components/landing/Logo.tsx");
/* harmony import */ var _svg_SocialMedia_Facebook__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../svg/SocialMedia/Facebook */ "./components/svg/SocialMedia/Facebook.tsx");
/* harmony import */ var _svg_SocialMedia_Instagram__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../svg/SocialMedia/Instagram */ "./components/svg/SocialMedia/Instagram.tsx");
/* harmony import */ var _svg_SocialMedia_LinkedIn__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../svg/SocialMedia/LinkedIn */ "./components/svg/SocialMedia/LinkedIn.tsx");

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\Footer.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

/**
 * Footer for landing page
 */








const SocialMediaLink = ({
  href,
  children
}) => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
  target: "_blank",
  rel: "noreferrer",
  className: "w-6",
  href: href,
  children: children
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 18,
  columnNumber: 3
}, undefined);

const FooterItem = (_ref) => {
  let {
    href,
    children,
    external = false
  } = _ref,
      props = _objectWithoutProperties(_ref, ["href", "children", "external"]);

  const link = /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", _objectSpread(_objectSpread({
    className: "border-b border-current hover:border-none",
    href: external ? href : undefined
  }, props), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 36,
    columnNumber: 5
  }, undefined);

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
    children: external ? link : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
      href: href,
      children: link
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 33
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 45,
    columnNumber: 10
  }, undefined);
};

const Footer = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("footer", {
    id: "footer",
    className: "px-6 py-12 md:py-28 flex justify-center bg-seashell",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "container grid grid-cols-1 md:grid-cols-2",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "flex flex-col space-y-4",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Logo__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_LegitscriptSeal__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "mt-8 md:mt-0 p-4 md:p-0 grid grid-cols-1 md:grid-cols-2",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
          className: "text-sm mb-4 lg:mb-8 flex flex-col gap-y-1",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FooterItem, {
            href: "/terms-of-service",
            children: "Terms of Service"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 61,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FooterItem, {
            href: "/privacy-policy",
            children: "Privacy Policy"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FooterItem, {
            href: "mailto:press@hellolina.com",
            external: true,
            children: "Press Inquiries"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 63,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FooterItem, {
            href: "https://boards.greenhouse.io/lina",
            target: "_blank",
            external: true,
            children: "Careers"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 66,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FooterItem, {
            href: "/refer-friend",
            children: "Refer a Friend"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FooterItem, {
            href: "/blog",
            children: "Blog"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 74,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
          className: "flex flex-col text-sm gap-y-1",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FooterItem, {
            href: "mailto:support@hellolina.com",
            external: true,
            children: "support@hellolina.com"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 77,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FooterItem, {
            href: "/faq",
            children: "FAQ"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            children: "9am-5pm EST, M-F"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: "flex pt-3 gap-x-3",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(SocialMediaLink, {
              href: "https://www.instagram.com/linamentalhealth/?hl=en",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_svg_SocialMedia_Instagram__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 84,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 83,
              columnNumber: 15
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(SocialMediaLink, {
              href: "https://www.linkedin.com/company/hellolina/",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_svg_SocialMedia_LinkedIn__WEBPACK_IMPORTED_MODULE_7__.default, {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 87,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 86,
              columnNumber: 15
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(SocialMediaLink, {
              href: "https://www.facebook.com/people/Lina/100068077291395/",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_svg_SocialMedia_Facebook__WEBPACK_IMPORTED_MODULE_5__.default, {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 90,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 89,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 82,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
          className: "text-xs mt-8",
          children: "\xA9 2021 Lina, a B&G Innovations company. All rights reserved."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 50,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Footer);

/***/ }),

/***/ "./components/landing/Header.tsx":
/*!***************************************!*\
  !*** ./components/landing/Header.tsx ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "../node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @headlessui/react */ "@headlessui/react");
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Logo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Logo */ "./components/landing/Logo.tsx");
/* harmony import */ var _core_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../core/Button */ "./components/core/Button.tsx");


var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\Header.tsx";

/**
 * Header for landing page
 */








const Header = ({
  title,
  startOffer,
  startColor,
  hideMenu
}) => {
  const {
    0: showOffer,
    1: setShowOffer
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(!!startOffer);
  const {
    0: showSidebar,
    1: setShowSidebar
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
  const {
    0: isTop,
    1: setIsTop
  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);

  const onScroll = () => {
    setIsTop(window.pageYOffset < 32);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(() => {
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const toggleClose = () => setShowSidebar(false);

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("title", {
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("w-full flex flex-col items-center justify-center fixed top-0 left-0 z-50 transition-colors duration-500", {
        "shadow-md": !isTop
      }, isTop ? startColor || "bg-seashell" : "bg-white"),
      children: [showOffer ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "z-50 t-0 bg-darkGray text-white h-8 w-full flex items-center justify-center text-center",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
          href: "/onboarding/intro/start",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
            href: "#",
            className: "underline hover:no-underline mx-auto",
            children: startOffer
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 55,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 13
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          onClick: () => setShowOffer(false),
          className: "mr-2",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            className: "h-6 w-6",
            fill: "none",
            viewBox: "0 0 24 24",
            stroke: "currentColor",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: 1,
              d: "M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 67,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 60,
            columnNumber: 15
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 13
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 11
      }, undefined) : null, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("nav", {
        className: "flex container items-center px-6 md:px-0 py-4",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
          href: "/",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
            href: "#",
            className: "flex items-center",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Logo__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 80,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: classnames__WEBPACK_IMPORTED_MODULE_4___default()("ml-auto md:hidden", hideMenu ? "hidden" : ""),
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
            onClick: () => setShowSidebar(true),
            className: "flex items-center py-2 px-3 text-coral rounded",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              className: "h-6 w-6 text-darkGray",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 96,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 89,
              columnNumber: 15
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
          className: "hidden lg:flex lg:items-center lg:w-auto lg:space-x-8 ml-auto mr-4",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "hidden lg:flex",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
              href: "/login",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_core_Button__WEBPACK_IMPORTED_MODULE_7__.default, {
                href: "#",
                asLink: true,
                buttonType: "secondary",
                className: "text-darkGray hover:underline",
                children: "Log In"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 115,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 114,
              columnNumber: 15
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
              href: "/onboarding/intro/start",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_core_Button__WEBPACK_IMPORTED_MODULE_7__.default, {
                buttonType: "header",
                className: "ml-2 uppercase text-sm px-4",
                children: "Get Started"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 125,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 124,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 13
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__.Transition, {
      show: showSidebar,
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__.Transition.Child, {
        enter: "transition-opacity ease-linear duration-100",
        enterFrom: "opacity-0",
        enterTo: "opacity-100",
        leave: "transition-opacity ease-linear duration-100",
        leaveFrom: "opacity-100",
        leaveTo: "opacity-0",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "fixed inset-0 bg-blueGray-800 opacity-25",
          onClick: () => setShowSidebar(false)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 147,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 139,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__.Transition.Child, {
        enter: "transition-all ease-linear duration-300",
        enterFrom: "-ml-64",
        enterTo: "ml-0",
        leave: "transition-all ease-linear duration-50",
        leaveTo: "-ml-64",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("nav", {
          className: "py-3 px-6 border-r top-0 w-96 bg-white fixed h-full overflow-auto z-50 ",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            className: "flex items-center mb-8 ",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
              href: "/",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                className: "",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Logo__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 163,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 162,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 161,
              columnNumber: 15
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("button", {
              onClick: () => setShowSidebar(false),
              className: "ml-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
                className: "h-6 w-6 cursor-pointer hover:text-blueGray-500",
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "2",
                  d: "M6 18L18 6M6 6l12 12"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 174,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 167,
                columnNumber: 17
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 166,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 160,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
              className: "hidden",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                className: "mb-1",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  className: "block p-4 text-sm",
                  href: "/#get_treatment",
                  onClick: toggleClose,
                  children: "Get Treatment"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 186,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 185,
                columnNumber: 17
              }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                className: "mb-1",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  className: "block p-4 text-sm",
                  href: "/#care_process",
                  onClick: toggleClose,
                  children: "Care Process"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 195,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 194,
                columnNumber: 17
              }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                className: "mb-1",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  className: "block p-4 text-sm",
                  href: "/#pricing",
                  onClick: toggleClose,
                  children: "Pricing"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 204,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 203,
                columnNumber: 17
              }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
                className: "mb-1",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  className: "block p-4 text-sm",
                  href: "/#faq",
                  onClick: toggleClose,
                  children: "FAQ"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 213,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 212,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 184,
              columnNumber: 15
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "mt-4 pt-6 border-t border-blueGray-100",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                href: "/onboarding/intro/start",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_core_Button__WEBPACK_IMPORTED_MODULE_7__.default, {
                  asLink: true,
                  children: "Get Started"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 224,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 223,
                columnNumber: 17
              }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                href: "/login",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_core_Button__WEBPACK_IMPORTED_MODULE_7__.default, {
                  asLink: true,
                  buttonType: "secondary",
                  className: "text-coral mt-2 border",
                  children: "Log In"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 227,
                  columnNumber: 19
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 226,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 222,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 183,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 159,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 152,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 138,
      columnNumber: 7
    }, undefined), showOffer ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "mb-16 bg-seashell"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 241,
      columnNumber: 9
    }, undefined) : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "mb-8 bg-seashell"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 243,
      columnNumber: 9
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: classnames__WEBPACK_IMPORTED_MODULE_4___default()(showOffer ? "mt-8" : undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 245,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ __webpack_exports__["default"] = (Header);

/***/ }),

/***/ "./components/landing/LandingTemplate.tsx":
/*!************************************************!*\
  !*** ./components/landing/LandingTemplate.tsx ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_hooks_offer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/hooks/offer */ "./lib/hooks/offer.ts");
/* harmony import */ var _lib_hooks_utm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/hooks/utm */ "./lib/hooks/utm.ts");
/* harmony import */ var _EmergencyBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./EmergencyBar */ "./components/landing/EmergencyBar.tsx");
/* harmony import */ var _FAQ__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./FAQ */ "./components/landing/FAQ.tsx");
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Footer */ "./components/landing/Footer.tsx");
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Header */ "./components/landing/Header.tsx");
/* harmony import */ var _MedicalTeam__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./MedicalTeam */ "./components/landing/MedicalTeam.tsx");
/* harmony import */ var _NewCareProcess__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./NewCareProcess */ "./components/landing/NewCareProcess.tsx");
/* harmony import */ var _Pricing__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Pricing */ "./components/landing/Pricing.tsx");
/* harmony import */ var _Section__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Section */ "./components/landing/Section.tsx");
/* harmony import */ var _Testimonials__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Testimonials */ "./components/landing/Testimonials.tsx");
/* harmony import */ var _WhatWeTreat__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./WhatWeTreat */ "./components/landing/WhatWeTreat.tsx");

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\LandingTemplate.tsx";

/**
 * Wrapper component used to provide template for the landing page.
 * Use this to create multiple variations of the landing page with
 * the same structure.
 */














const LandingTemplate = ({
  data,
  children
}) => {
  console.log('All data', data);
  const {
    faq,
    page
  } = data;
  const {
    fields
  } = page;
  const {
    careProcessHeading,
    careProcess,
    testimonialsHeading,
    testimonials
  } = fields;
  console.log('Titlte', careProcessHeading);
  (0,_lib_hooks_utm__WEBPACK_IMPORTED_MODULE_3__.useUtm)();
  const {
    offerText
  } = (0,_lib_hooks_offer__WEBPACK_IMPORTED_MODULE_2__.useOffer)();
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Header__WEBPACK_IMPORTED_MODULE_7__.default, {
      title: "Lina",
      startOffer: offerText
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "desc",
      className: "flex justify-center bg-seashell relative",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container grid grid-cols-1 md:grid-cols-2",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "relative mt-8 md:mt-0",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
            src: "/images/ctabg.svg",
            width: "400",
            className: "ml-auto",
            style: {
              right: "4px"
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 13
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
            width: "340",
            src: "/images/hero_image_small.png",
            className: "heroimage rounded-full absolute top-0"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "care_process",
      className: "flex justify-center",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_NewCareProcess__WEBPACK_IMPORTED_MODULE_9__.default, {
          heading: careProcessHeading,
          data: careProcess
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "testimonials",
      className: "flex justify-center bg-seashell",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Testimonials__WEBPACK_IMPORTED_MODULE_12__.default, {
          heading: testimonialsHeading,
          data: testimonials
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "what_we_treat",
      className: "flex justify-center bg-seashell",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_WhatWeTreat__WEBPACK_IMPORTED_MODULE_13__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "medical_team",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_MedicalTeam__WEBPACK_IMPORTED_MODULE_8__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 76,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "pricing",
      className: "bg-seashell",
      noPadding: true,
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Pricing__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "faq",
      className: "flex justify-center",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_FAQ__WEBPACK_IMPORTED_MODULE_5__.default, {
          faq: faq
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Section__WEBPACK_IMPORTED_MODULE_11__.default, {
      id: "emergency",
      className: "flex justify-center",
      style: {
        backgroundColor: "rgba(244, 218, 213, 0.6)"
      },
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_EmergencyBar__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 95,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 94,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 89,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_Footer__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 98,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 38,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (LandingTemplate);

/***/ }),

/***/ "./components/landing/LegitscriptSeal.tsx":
/*!************************************************!*\
  !*** ./components/landing/LegitscriptSeal.tsx ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\LegitscriptSeal.tsx";

/**
 * Displays the legit script seal with an <img>
 */


const LegitscriptSeal = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
    href: "https://legitscript.com/pharmacy/hellolina.com",
    target: "_blank",
    title: "Verify LegitScript Approval",
    rel: "noreferrer",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
      src: "https://static.legitscript.com/seals/10768692.png",
      alt: "LegitScript approved",
      width: "140",
      height: "100"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (LegitscriptSeal);

/***/ }),

/***/ "./components/landing/Logo.tsx":
/*!*************************************!*\
  !*** ./components/landing/Logo.tsx ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\Logo.tsx";

/**
 * Lina logo as an SVG
 */


const Logo = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
    width: "96",
    height: "24",
    viewBox: "5 0 50 17",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("circle", {
      r: "5.49671",
      transform: "matrix(-1 0 0 1 8.02234 5.79923)",
      fill: "#FF877A"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("circle", {
      r: "2.52551",
      transform: "matrix(-1 0 0 1 2.52575 14.3453)",
      fill: "#FF877A"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 23,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      d: "M18.4585 0V15.6582H20.3162V0H18.4585Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      d: "M23.6435 4.51168V15.6582H25.5013V4.51168H23.6435ZM23.1791 1.41543C23.1791 2.18949 23.7762 2.78662 24.5724 2.78662C25.3686 2.78662 25.9657 2.18949 25.9657 1.41543C25.9657 0.61925 25.3686 0 24.5724 0C23.7762 0 23.1791 0.61925 23.1791 1.41543Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      d: "M37.6292 7.80697C37.6292 5.59536 36.3906 4.33475 34.356 4.33475C32.8078 4.33475 31.4809 5.13093 30.6626 6.56847V4.51168H28.8048V15.6582H30.6626V10.9917C30.6626 7.89543 32.1886 6.01557 33.8473 6.01557C35.0858 6.01557 35.7714 6.76751 35.7714 8.29352V15.6582H37.6292V7.80697Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      d: "M42.4373 12.4513C42.4373 11.1907 43.4989 10.483 45.4009 10.483H47.3913V10.7484C47.3913 13.2696 45.7105 14.1543 44.273 14.1543C43.1008 14.1543 42.4373 13.5129 42.4373 12.4513ZM49.2491 8.5368C49.2491 5.57325 47.4134 4.33475 44.9586 4.33475C42.8575 4.33475 41.3094 5.5069 40.9998 7.38676L42.6364 7.76274C42.8796 6.65693 43.8085 6.01557 44.9586 6.01557C46.3076 6.01557 47.3913 6.59059 47.3913 8.31564V8.80219H45.5778C42.5258 8.80219 40.5353 10.0628 40.5353 12.4513C40.5353 14.8399 42.1277 15.8351 43.9854 15.8351C45.6442 15.8351 46.7721 15.1053 47.4798 14.0879L47.7894 15.6582H49.2491V8.5368Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Logo);

/***/ }),

/***/ "./components/landing/MedicalTeam.tsx":
/*!********************************************!*\
  !*** ./components/landing/MedicalTeam.tsx ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\MedicalTeam.tsx";

/**
 * Component displaying Dr. Patel and Dr. Patil
 * TODO: Can include more people + a link to everyone
 */


const PractitionerCard = ({
  title,
  name,
  imageUrl,
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "bg-white border solid shadow-lg rounded-lg p-8 max-w-md md:max-w-lg",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "flex mb-4",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "h-16 w-16 mr-4",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
          className: "rounded-full border b-2",
          src: imageUrl
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
          className: "font-bold text-xl",
          children: name
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h6", {
          className: "text-blue-400",
          children: title
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 22,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("p", {
      className: "",
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, undefined);
};

const MedicalTeam = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "flex flex-col",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "w-full",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
        className: "text-3xl md:text-4xl text-center mb-8",
        children: "Your medical team"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "w-full flex flex-col md:flex-row justify-center space-y-8 md:space-y-0 md:space-x-8",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(PractitionerCard, {
        name: "Dr. Vilas J. Patil",
        title: "MD",
        imageUrl: "/images/providers/dr_patil.jpg",
        children: ["Dr. Patil has 32 years of experience treating anxiety, depression, ADHD, and other psychiatric conditions. He is ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("i", {
          children: "quadruple"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 45,
          columnNumber: 57
        }, undefined), " board certified by the American Board of Psychiatry in adult, geriatric, and addiction psychiatry along with his specialization in child psychiatry. He served as chief of psychiatry for Osweo Hospital for 13 years."]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(PractitionerCard, {
        name: "Dr. Kartik Patel",
        title: "MD",
        imageUrl: "/images/providers/patel.jpg",
        children: "Dr. Patel has 9 years of experience in healthcare and is board-certified in Internal Medicine. His experience encompasses inpatient, ambulatory, and telehealth patient care. He has worked on projects spanning across process improvement, quality improvement, and operations to help improve patient care."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (MedicalTeam);

/***/ }),

/***/ "./components/landing/NewCareProcess.tsx":
/*!***********************************************!*\
  !*** ./components/landing/NewCareProcess.tsx ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\NewCareProcess.tsx";

/**
 * Shows the steps for the care process. "new" prefix is
 * a relic of when we had two options
 */


const StepNumber = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "center",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
      className: "border border-coral-300 inline-flex items-center justify-center  w-14 h-14 md:w-16 md:h-16 bg-seashell rounded-full text-coral text-xl font-bold",
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 5
  }, undefined);
};

const Line = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "center",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "bg-coral h-12",
      style: {
        width: "2px"
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 5
  }, undefined);
};

const NewCareProcess = ({
  heading,
  data
}) => {
  console.log('Heading inside', data);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "grid grid-cols-1 md:grid-cols-2",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
      className: "text-3xl md:text-4xl text-center md:text-left mb-8",
      children: heading ? heading : 'Our care process'
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "grid grid-cols-2 gap-y-2 md:gap-y-4 gap-x-1 mb-20 md:mb-0",
        children: [data && data.map(({
          fields
        }, index) => {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(StepNumber, {
              children: [index + 1, data.length]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 41,
              columnNumber: 15
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
              className: "h-12 flex flex-col",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                className: "font-bold",
                children: fields.careProcessName
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 43,
                columnNumber: 19
              }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                className: "text-sm",
                children: fields.careProcessDescription
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 44,
                columnNumber: 19
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 42,
              columnNumber: 17
            }, undefined), data.length != index + 1 && /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Line, {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 44
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 17
            }, undefined)]
          }, void 0, true);
        }), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 5
  }, undefined);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "grid grid-cols-1 md:grid-cols-2 mx-4",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
        className: "text-3xl md:text-4xl text-center md:text-left",
        children: "Our care process"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 99,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 98,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "md:-mt-8 grid grid-cols-2 space-y-16",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "flex justify-center  items-center px-4",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
          src: "/images/assessment.svg",
          className: "mr-4 mt-12"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 104,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "max-w-xs",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
          className: "text-xl mb-4",
          children: "Personalized Assessments"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 108,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "opacity-70",
          children: "In 10 minutes, we'll get to know you and suggest a provider that fits your unique needs."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 109,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 107,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "flex justify-center px-4",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
          src: "/images/appointment.svg",
          className: "mr-4"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 116,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 115,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "max-w-xs",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
          className: "text-xl mb-4",
          children: "Convenient Appointments"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 119,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "opacity-70",
          children: "Meet with a clinician from the comfort of your home."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 120,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 118,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "flex justify-center px-4",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
          src: "/images/prescription.svg",
          className: "mr-4"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 126,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 125,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "max-w-xs",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h3", {
          className: "text-xl mb-4",
          children: "Free Delivery"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 129,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: "opacity-70",
          children: "FREE medicine delivery in 2-3 business days."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 130,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 128,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 103,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 97,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (NewCareProcess);

/***/ }),

/***/ "./components/landing/Pricing.tsx":
/*!****************************************!*\
  !*** ./components/landing/Pricing.tsx ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "../node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CTAButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CTAButton */ "./components/landing/CTAButton.tsx");

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\Pricing.tsx";

/**
 * Component to display pricing on the landing page
 */




const Checkmark = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
    width: "16",
    height: "14",
    viewBox: "0 0 16 14",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    className: "ml-4 md:ml-0 mr-4 flex-shrink-0",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M6.84799 13.1968L15.6924 1.51835L14.0627 0.28418L6.44555 10.3421L1.93885 7.13624L0.753906 8.80196L6.84799 13.1968Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 5
  }, undefined);
};

const Pricing = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "grid grid-cols-1 md:py-12",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "relative",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "md:hidden z-10 absolute t-0 h-full w-full bg-black opacity-30"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
        className: "z-30 block md:hidden absolute t-0 h-full w-full text-center text-white text-3xl md:text-4xl mb-12",
        style: {
          top: "45%",
          bottom: "50%"
        },
        children: "It's time to be yourself again."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "h-96 md:hidden",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: "/images/pricing_image_3.jpeg",
          layout: "fill"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "px-4 md:px-10 py-12 md:py-4 md:max-w-xl flex flex-col justify-center mx-auto",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
        className: "text-center text-3xl md:text-4xl mb-8",
        children: "Affordable plans to help you feel better"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 49,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "text-2xl text-center mb-2 font-bold",
        children: ["Starting as low as ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("s", {
          children: "$95"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 30
        }, undefined), " $5 for your first month."]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "text-center text-sm mb-10",
        children: "Just $95 a month after that."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
        className: "flex flex-col gap-y-2 mb-8 w-full mx-auto md:w-4/5",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          className: "flex items-center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Checkmark, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 61,
            columnNumber: 13
          }, undefined), "Unlimited video consultations with your provider"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          className: "flex items-center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Checkmark, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 65,
            columnNumber: 13
          }, undefined), "Unlimited messaging with your provider"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          className: "flex items-center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Checkmark, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 13
          }, undefined), "Free medication delivery to your door"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
          className: "flex items-center",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Checkmark, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 13
          }, undefined), "Regular progress tracking"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_CTAButton__WEBPACK_IMPORTED_MODULE_3__.default, {
        className: "w-72 md:w-full mx-auto",
        children: "Start free assessment"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "mt-8 font-bold text-center",
        children: "Insurance accepted, but not needed."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "text-xs text-center",
        children: "Easy out of network claims. HSA/FSA eligible. Medications eligible for insurance coverage are billed separately."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Pricing);

/***/ }),

/***/ "./components/landing/Section.tsx":
/*!****************************************!*\
  !*** ./components/landing/Section.tsx ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "classnames");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\Section.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

/**
 * Used to denoate a section on the landing page
 */



const Section = (_ref) => {
  let {
    children,
    className,
    noPadding
  } = _ref,
      otherProps = _objectWithoutProperties(_ref, ["children", "className", "noPadding"]);

  const combinedClass = classnames__WEBPACK_IMPORTED_MODULE_2___default()(!noPadding ? "py-12 md:py-28 px-6" : "", className);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("section", _objectSpread(_objectSpread({
    className: combinedClass
  }, otherProps), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 26,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Section);

/***/ }),

/***/ "./components/landing/SharpStars.tsx":
/*!*******************************************!*\
  !*** ./components/landing/SharpStars.tsx ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\SharpStars.tsx";

/**
 * SVG displaying 5 pointed stars on the landing page
 */


const SharpStars = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
    width: "128",
    height: "21",
    viewBox: "0 0 128 21",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M11.1892 0.719791C11.0994 0.724152 11.0131 0.755698 10.9416 0.810267C10.8702 0.864835 10.817 0.939844 10.7891 1.02533L8.56326 7.70368H1.43465C1.34142 7.70398 1.25065 7.73366 1.17525 7.78851C1.09986 7.84336 1.04367 7.92057 1.01467 8.00919C0.985671 8.09781 0.98534 8.19331 1.01372 8.28212C1.04211 8.37094 1.09776 8.44854 1.17278 8.50391L6.96296 12.7379L4.73709 19.649C4.70812 19.7382 4.70817 19.8343 4.73725 19.9235C4.76632 20.0127 4.82292 20.0904 4.89891 20.1453C4.9749 20.2003 5.06635 20.2298 5.16014 20.2295C5.25392 20.2292 5.3452 20.1992 5.42085 20.1437L11.211 15.9098L17.0012 20.1437C17.0769 20.1992 17.1682 20.2292 17.2619 20.2295C17.3557 20.2298 17.4472 20.2003 17.5232 20.1453C17.5992 20.0904 17.6558 20.0127 17.6848 19.9235C17.7139 19.8343 17.714 19.7382 17.685 19.649L15.4591 12.7379L21.2493 8.50391C21.3243 8.44854 21.38 8.37094 21.4083 8.28212C21.4367 8.19331 21.4364 8.09781 21.4074 8.00919C21.3784 7.92057 21.3222 7.84336 21.2468 7.78851C21.1714 7.73366 21.0807 7.70398 20.9874 7.70368H13.8588L11.6329 1.02533C11.6028 0.932745 11.543 0.85266 11.4628 0.797438C11.3826 0.742216 11.2865 0.714932 11.1892 0.719791Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M64.1912 0.719791C64.1014 0.724152 64.015 0.755698 63.9436 0.810267C63.8721 0.864835 63.8189 0.939844 63.7911 1.02533L61.5652 7.70368H54.4366C54.3434 7.70398 54.2526 7.73366 54.1772 7.78851C54.1018 7.84336 54.0456 7.92057 54.0166 8.00919C53.9876 8.09781 53.9873 8.19331 54.0157 8.28212C54.0441 8.37094 54.0997 8.44854 54.1747 8.50391L59.9649 12.7379L57.739 19.649C57.7101 19.7382 57.7101 19.8343 57.7392 19.9235C57.7683 20.0127 57.8249 20.0904 57.9009 20.1453C57.9768 20.2003 58.0683 20.2298 58.1621 20.2295C58.2559 20.2292 58.3472 20.1992 58.4228 20.1437L64.213 15.9098L70.0032 20.1437C70.0788 20.1992 70.1701 20.2292 70.2639 20.2295C70.3577 20.2298 70.4491 20.2003 70.5251 20.1453C70.6011 20.0904 70.6577 20.0127 70.6868 19.9235C70.7159 19.8343 70.7159 19.7382 70.6869 19.649L68.4611 12.7379L74.2513 8.50391C74.3263 8.44854 74.3819 8.37094 74.4103 8.28212C74.4387 8.19331 74.4384 8.09781 74.4094 8.00919C74.3804 7.92057 74.3242 7.84336 74.2488 7.78851C74.1734 7.73366 74.0826 7.70398 73.9894 7.70368H66.8608L64.6349 1.02533C64.6047 0.932745 64.5449 0.85266 64.4647 0.797438C64.3846 0.742216 64.2884 0.714932 64.1912 0.719791Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M37.6902 0.719791C37.6004 0.724152 37.514 0.755698 37.4426 0.810267C37.3711 0.864835 37.318 0.939844 37.2901 1.02533L35.0642 7.70368H27.9356C27.8424 7.70398 27.7516 7.73366 27.6762 7.78851C27.6008 7.84336 27.5446 7.92057 27.5156 8.00919C27.4866 8.09781 27.4863 8.19331 27.5147 8.28212C27.5431 8.37094 27.5987 8.44854 27.6738 8.50391L33.4639 12.7379L31.2381 19.649C31.2091 19.7382 31.2091 19.8343 31.2382 19.9235C31.2673 20.0127 31.3239 20.0904 31.3999 20.1453C31.4759 20.2003 31.5673 20.2298 31.6611 20.2295C31.7549 20.2292 31.8462 20.1992 31.9218 20.1437L37.712 15.9098L43.5022 20.1437C43.5779 20.1992 43.6691 20.2292 43.7629 20.2295C43.8567 20.2298 43.9482 20.2003 44.0241 20.1453C44.1001 20.0904 44.1567 20.0127 44.1858 19.9235C44.2149 19.8343 44.2149 19.7382 44.186 19.649L41.9601 12.7379L47.7503 8.50391C47.8253 8.44854 47.8809 8.37094 47.9093 8.28212C47.9377 8.19331 47.9374 8.09781 47.9084 8.00919C47.8794 7.92057 47.8232 7.84336 47.7478 7.78851C47.6724 7.73366 47.5816 7.70398 47.4884 7.70368H40.3598L38.1339 1.02533C38.1038 0.932745 38.044 0.85266 37.9638 0.797438C37.8836 0.742216 37.7874 0.714932 37.6902 0.719791Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M90.6926 0.719791C90.6028 0.724152 90.5165 0.755698 90.445 0.810267C90.3736 0.864835 90.3204 0.939844 90.2926 1.02533L88.0667 7.70368H80.9381C80.8448 7.70398 80.7541 7.73366 80.6787 7.78851C80.6033 7.84336 80.5471 7.92057 80.5181 8.00919C80.4891 8.09781 80.4888 8.19331 80.5171 8.28212C80.5455 8.37094 80.6012 8.44854 80.6762 8.50391L86.4664 12.7379L84.2405 19.649C84.2115 19.7382 84.2116 19.8343 84.2407 19.9235C84.2697 20.0127 84.3263 20.0904 84.4023 20.1453C84.4783 20.2003 84.5698 20.2298 84.6636 20.2295C84.7573 20.2292 84.8486 20.1992 84.9243 20.1437L90.7145 15.9098L96.5046 20.1437C96.5803 20.1992 96.6716 20.2292 96.7654 20.2295C96.8591 20.2298 96.9506 20.2003 97.0266 20.1453C97.1026 20.0904 97.1592 20.0127 97.1882 19.9235C97.2173 19.8343 97.2174 19.7382 97.1884 19.649L94.9625 12.7379L100.753 8.50391C100.828 8.44854 100.883 8.37094 100.912 8.28212C100.94 8.19331 100.94 8.09781 100.911 8.00919C100.882 7.92057 100.826 7.84336 100.75 7.78851C100.675 7.73366 100.584 7.70398 100.491 7.70368H93.3622L91.1364 1.02533C91.1062 0.932745 91.0464 0.85266 90.9662 0.797438C90.886 0.742216 90.7899 0.714932 90.6926 0.719791Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M117.194 0.719791C117.104 0.724152 117.017 0.755698 116.946 0.810267C116.875 0.864835 116.821 0.939844 116.794 1.02533L114.568 7.70368H107.439C107.346 7.70398 107.255 7.73366 107.18 7.78851C107.104 7.84336 107.048 7.92057 107.019 8.00919C106.99 8.09781 106.99 8.19331 107.018 8.28212C107.047 8.37094 107.102 8.44854 107.177 8.50391L112.967 12.7379L110.741 19.649C110.713 19.7382 110.713 19.8343 110.742 19.9235C110.771 20.0127 110.827 20.0904 110.903 20.1453C110.979 20.2003 111.071 20.2298 111.165 20.2295C111.258 20.2292 111.35 20.1992 111.425 20.1437L117.215 15.9098L123.006 20.1437C123.081 20.1992 123.173 20.2292 123.266 20.2295C123.36 20.2298 123.452 20.2003 123.528 20.1453C123.604 20.0904 123.66 20.0127 123.689 19.9235C123.718 19.8343 123.718 19.7382 123.689 19.649L121.464 12.7379L127.254 8.50391C127.329 8.44854 127.384 8.37094 127.413 8.28212C127.441 8.19331 127.441 8.09781 127.412 8.00919C127.383 7.92057 127.327 7.84336 127.251 7.78851C127.176 7.73366 127.085 7.70398 126.992 7.70368H119.863L117.637 1.02533C117.607 0.932745 117.547 0.85266 117.467 0.797438C117.387 0.742216 117.291 0.714932 117.194 0.719791Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (SharpStars);

/***/ }),

/***/ "./components/landing/Testimonials.tsx":
/*!*********************************************!*\
  !*** ./components/landing/Testimonials.tsx ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SharpStars__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SharpStars */ "./components/landing/SharpStars.tsx");

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\Testimonials.tsx";

/**
 * Shows testimonials on the landing page
 */



const Testimonial = ({
  title,
  children,
  style
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "p-8 max-w-sm mb-4 w-full md:w-96 flex-shrink-0",
    style: style,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "text-sm font-bold mb-8",
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "leading-relaxed mb-8",
      children: children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_SharpStars__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 5
  }, undefined);
};

const testimonials = [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Miami",
  style: {
    backgroundColor: "rgba(77, 188, 195, 0.1)"
  },
  children: "My provider was kind and considerate. He asked me a lot of questions to get to the root of my feelings. The medication shipment was also super convenient for me. I'm so glad I was able to quickly book an appointment with Lina."
}, "testimonial-2", false, {
  fileName: _jsxFileName,
  lineNumber: 27,
  columnNumber: 3
}, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Pensacola",
  style: {
    backgroundColor: "rgba(255, 217, 208, 0.7)"
  },
  children: "I was able to book an appointment with Dr. P within a day. He was understanding, straightforward, and caring. He answered all my questions and made me feel confident about my treatment. It's been a great experience so far."
}, "testimonial-3", false, {
  fileName: _jsxFileName,
  lineNumber: 39,
  columnNumber: 3
}, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Testimonial, {
  title: "Patient from Tampa Bay",
  style: {
    backgroundColor: "rgba(77, 188, 195, 0.1)"
  },
  children: "Telehealth is so important, it enables people to get care with an actual person over video. Sometimes we can't physically get to a doctor's office, but now Lina offers something for everyone who can't do in-person. Thanks for creating this platform!"
}, "testimonial-1", false, {
  fileName: _jsxFileName,
  lineNumber: 49,
  columnNumber: 3
}, undefined)];

const Testimonials = ({
  heading,
  data
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "flex flex-col md:flex-row",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "md:w-1/3",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h2", {
        className: "text-3xl md:text-4xl text-center md:text-left mb-8",
        children: heading ? heading : 'Life changing results from real members'
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "w-full flex flex-col justify-center md:justify-start md:flex-row overflow-auto md:space-x-4",
      children: testimonials
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 69,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 63,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Testimonials);

/***/ }),

/***/ "./components/landing/WhatWeTreat.tsx":
/*!********************************************!*\
  !*** ./components/landing/WhatWeTreat.tsx ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\landing\\WhatWeTreat.tsx";

/**
 * Shows list of conditions treated.
 * unused?
 */


const Checkmark = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
    width: "16",
    height: "14",
    viewBox: "0 0 16 14",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    className: "ml-4 md:ml-0 mr-4 flex-shrink-0 text-darkGray",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      fillRule: "evenodd",
      clipRule: "evenodd",
      d: "M6.84799 13.1968L15.6924 1.51835L14.0627 0.28418L6.44555 10.3421L1.93885 7.13624L0.753906 8.80196L6.84799 13.1968Z",
      fill: "#374146"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 5
  }, undefined);
};

const TreatmentItem = ({
  children
}) => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
    className: "flex items-center",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Checkmark, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 7
    }, undefined), children]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 31,
    columnNumber: 5
  }, undefined);
};

const WhatWeTreat = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
    className: "flex flex-col md:flex-row",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "w-full md:w-1/3",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
        className: "text-3xl md:text-4xl text-center md:text-left mb-8",
        children: "Anxiety and depression come in many forms"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "text-center md:text-left",
        children: "That's why we specialize in treating the full spectrum of related conditions with personalized treatment plans that are right for you."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
      className: "mt-8 md:mt-0 grid grid-cols-2 mx-auto gap-x-4 gap-y-4 text-sm md:text-md",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Major depressive disorder"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Generalized anxiety disorder"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Insomnia"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Panic Disorder"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Acute Stress Disorder"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Postpartum depression"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Social anxiety"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Phobia"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 58,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Post Traumatic Stress Disorder (PTSD)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Seasonal Affective Disorder (SAD)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 60,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Premenstrual Dysphoric Disorder (PMDD)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(TreatmentItem, {
        children: "Obsessive Compulsive Disorder (OCD)"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 40,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (WhatWeTreat);

/***/ }),

/***/ "./components/svg/SocialMedia/Facebook.tsx":
/*!*************************************************!*\
  !*** ./components/svg/SocialMedia/Facebook.tsx ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\svg\\SocialMedia\\Facebook.tsx";


const Facebook = () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
  viewBox: "0 0 512 512",
  xmlns: "http://www.w3.org/2000/svg",
  fillRule: "evenodd",
  clipRule: "evenodd",
  strokeLinejoin: "round",
  strokeMiterlimit: "2",
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
    d: "M512 257.555c0-141.385-114.615-256-256-256S0 116.17 0 257.555c0 127.777 93.616 233.685 216 252.89v-178.89h-65v-74h65v-56.4c0-64.16 38.219-99.6 96.695-99.6 28.009 0 57.305 5 57.305 5v63h-32.281c-31.801 0-41.719 19.733-41.719 39.978v48.022h71l-11.35 74H296v178.89c122.385-19.205 216-125.113 216-252.89z",
    fillRule: "nonzero",
    fill: "currentColor"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 5
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 4,
  columnNumber: 3
}, undefined);

/* harmony default export */ __webpack_exports__["default"] = (Facebook);

/***/ }),

/***/ "./components/svg/SocialMedia/Instagram.tsx":
/*!**************************************************!*\
  !*** ./components/svg/SocialMedia/Instagram.tsx ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\svg\\SocialMedia\\Instagram.tsx";


const Instagram = () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
  viewBox: "0 0 600 600",
  xmlns: "http://www.w3.org/2000/svg",
  fillRule: "evenodd",
  clipRule: "evenodd",
  strokeLinejoin: "round",
  strokeMiterlimit: "2",
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("g", {
    fillRule: "nonzero",
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      d: "M300 44c-69.526 0-78.244.295-105.549 1.54-27.248 1.244-45.858 5.571-62.142 11.9-16.834 6.542-31.11 15.296-45.342 29.528-14.232 14.231-22.986 28.508-29.528 45.342-6.329 16.283-10.656 34.893-11.9 62.141C44.295 221.756 44 230.474 44 300c0 69.524.294 78.242 1.54 105.547 1.243 27.248 5.57 45.858 11.9 62.141 6.541 16.834 15.295 31.11 29.527 45.344 14.231 14.231 28.508 22.985 45.342 29.527 16.284 6.328 34.894 10.656 62.142 11.899 27.305 1.245 36.023 1.54 105.549 1.54 69.524 0 78.242-.295 105.547-1.54 27.248-1.243 45.858-5.571 62.141-11.899 16.834-6.542 31.11-15.296 45.344-29.527 14.231-14.233 22.985-28.51 29.527-45.344 6.328-16.283 10.656-34.893 11.899-62.14 1.245-27.306 1.54-36.024 1.54-105.548 0-69.526-.295-78.244-1.54-105.549-1.243-27.248-5.571-45.858-11.899-62.141-6.542-16.834-15.296-31.11-29.527-45.342-14.233-14.232-28.51-22.986-45.344-29.528-16.283-6.329-34.893-10.656-62.14-11.9C378.241 44.296 369.523 44 300 44zm0 46.127c68.354 0 76.45.26 103.445 1.492 24.96 1.139 38.514 5.31 47.535 8.814 11.95 4.644 20.477 10.192 29.435 19.15 8.959 8.958 14.506 17.487 19.15 29.435 3.506 9.02 7.676 22.576 8.815 47.535 1.231 26.995 1.492 35.092 1.492 103.447 0 68.354-.26 76.45-1.492 103.445-1.139 24.96-5.31 38.514-8.815 47.535-4.644 11.95-10.191 20.477-19.15 29.435-8.958 8.959-17.486 14.506-29.435 19.15-9.02 3.506-22.576 7.676-47.535 8.814-26.99 1.232-35.086 1.493-103.445 1.493-68.36 0-76.455-.26-103.447-1.493-24.96-1.138-38.514-5.308-47.535-8.814-11.95-4.644-20.477-10.191-29.436-19.15-8.958-8.958-14.506-17.486-19.149-29.435-3.506-9.02-7.676-22.576-8.815-47.535-1.232-26.994-1.492-35.091-1.492-103.445 0-68.355.26-76.452 1.492-103.447 1.139-24.96 5.31-38.514 8.815-47.535 4.643-11.948 10.191-20.477 19.15-29.435 8.958-8.958 17.486-14.506 29.435-19.15 9.02-3.505 22.576-7.675 47.535-8.814 26.995-1.232 35.092-1.492 103.447-1.492z",
      fill: "currentColor"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
      d: "M300 385.332c-47.13 0-85.334-38.205-85.334-85.332 0-47.13 38.205-85.334 85.334-85.334 47.127 0 85.332 38.205 85.332 85.334 0 47.127-38.205 85.332-85.332 85.332zm0-216.792c-72.604 0-131.46 58.856-131.46 131.46 0 72.602 58.856 131.458 131.46 131.458 72.602 0 131.458-58.856 131.458-131.458 0-72.604-58.856-131.46-131.458-131.46zM467.372 163.346c0 16.967-13.754 30.72-30.72 30.72s-30.72-13.753-30.72-30.72c0-16.966 13.754-30.719 30.72-30.719s30.72 13.753 30.72 30.72z",
      fill: "currentColor"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 5
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 4,
  columnNumber: 3
}, undefined);

/* harmony default export */ __webpack_exports__["default"] = (Instagram);

/***/ }),

/***/ "./components/svg/SocialMedia/LinkedIn.tsx":
/*!*************************************************!*\
  !*** ./components/svg/SocialMedia/LinkedIn.tsx ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\components\\svg\\SocialMedia\\LinkedIn.tsx";


const LinkedIn = () => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("svg", {
  viewBox: "0 0 512 512",
  xmlns: "http://www.w3.org/2000/svg",
  fillRule: "evenodd",
  clipRule: "evenodd",
  strokeLinejoin: "round",
  strokeMiterlimit: "2",
  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("path", {
    d: "M473.305-1.353c20.88 0 37.885 16.533 37.885 36.926v438.251c0 20.393-17.005 36.954-37.885 36.954H36.846c-20.839 0-37.773-16.561-37.773-36.954V35.573c0-20.393 16.934-36.926 37.773-36.926h436.459zm-37.829 436.389V301.002c0-65.822-14.212-116.427-91.12-116.427-36.955 0-61.739 20.263-71.867 39.476h-1.04V190.64h-72.811v244.396h75.866V314.158c0-31.883 6.031-62.773 45.554-62.773 38.981 0 39.468 36.461 39.468 64.802v118.849h75.95zM150.987 190.64H74.953v244.396h76.034V190.64zM112.99 69.151c-24.395 0-44.066 19.735-44.066 44.047 0 24.318 19.671 44.052 44.066 44.052 24.299 0 44.026-19.734 44.026-44.052 0-24.312-19.727-44.047-44.026-44.047z",
    fillRule: "nonzero",
    fill: "currentColor"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 12,
    columnNumber: 5
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 4,
  columnNumber: 3
}, undefined);

/* harmony default export */ __webpack_exports__["default"] = (LinkedIn);

/***/ }),

/***/ "./context/AppContext.tsx":
/*!********************************!*\
  !*** ./context/AppContext.tsx ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppContextProvider": function() { return /* binding */ AppContextProvider; },
/* harmony export */   "useAppContext": function() { return /* binding */ useAppContext; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\context\\AppContext.tsx";

/**
 * The primary context used in our frontend, which is done during onboarding.
 * Once a user signs up we can rely more on server state.
 */
 // This should be switched to useReducer or recoil.js at this point

// @ts-ignore
const AppContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
const AppContextProvider = ({
  children
}) => {
  const {
    0: selectedTimeSlot,
    1: setSelectedTimeSlot
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: email,
    1: setEmail
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: residenceState,
    1: setResidenceState
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: discountCode,
    1: setDiscountCode
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
  const {
    0: intakeId,
    1: setIntakeId
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: firstName,
    1: setFirstName
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: lastName,
    1: setLastName
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: phone,
    1: setPhone
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: zipCode,
    1: setZipCode
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: currentQuestionIdx,
    1: setCurrentQuestionIdx
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
  const {
    0: answers,
    1: setAnswers
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
  const {
    0: birthdate,
    1: setBirthdate
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(new Date());
  const {
    0: notification,
    1: setNotification
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: error,
    1: setError
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  const {
    0: initialParams,
    1: setInitialParams
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
  const {
    0: bookingContext,
    1: setBookingContext
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
    slotId: "",
    slotDate: new Date()
  });
  const state = {
    onboarding: {
      selectedTimeSlot,
      setSelectedTimeSlot,
      email,
      setEmail,
      residenceState,
      setResidenceState,
      intakeId,
      setIntakeId,
      firstName,
      setFirstName,
      lastName,
      setLastName,
      phone,
      setPhone,
      zipCode,
      setZipCode,
      currentQuestionIdx,
      setCurrentQuestionIdx,
      answers,
      setAnswers,
      birthdate,
      setBirthdate,
      notification,
      setNotification,
      error,
      setError
    },
    booking: bookingContext,
    setBookingContext: setBookingContext,
    discountCode,
    setDiscountCode,
    initialParams,
    setInitialParams
  };
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(AppContext.Provider, {
    value: state,
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 140,
    columnNumber: 10
  }, undefined);
};
function useAppContext() {
  return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AppContext);
}

/***/ }),

/***/ "./lib/api.ts":
/*!********************!*\
  !*** ./lib/api.ts ***!
  \********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStates": function() { return /* binding */ getStates; },
/* harmony export */   "register": function() { return /* binding */ register; },
/* harmony export */   "submitQuiz": function() { return /* binding */ submitQuiz; },
/* harmony export */   "submitCheckin": function() { return /* binding */ submitCheckin; },
/* harmony export */   "getProgressHistory": function() { return /* binding */ getProgressHistory; },
/* harmony export */   "checkState": function() { return /* binding */ checkState; },
/* harmony export */   "checkZip": function() { return /* binding */ checkZip; },
/* harmony export */   "joinWaitlist": function() { return /* binding */ joinWaitlist; },
/* harmony export */   "getAvailability": function() { return /* binding */ getAvailability; },
/* harmony export */   "getStripeClientSecret": function() { return /* binding */ getStripeClientSecret; },
/* harmony export */   "confirmPayment": function() { return /* binding */ confirmPayment; },
/* harmony export */   "updatePaymentMethod": function() { return /* binding */ updatePaymentMethod; },
/* harmony export */   "login": function() { return /* binding */ login; },
/* harmony export */   "superuser": function() { return /* binding */ superuser; },
/* harmony export */   "loginAs": function() { return /* binding */ loginAs; },
/* harmony export */   "bookAppointment": function() { return /* binding */ bookAppointment; },
/* harmony export */   "getUpcomingAppointment": function() { return /* binding */ getUpcomingAppointment; },
/* harmony export */   "getPreviousAppointments": function() { return /* binding */ getPreviousAppointments; },
/* harmony export */   "getProfile": function() { return /* binding */ getProfile; },
/* harmony export */   "updateEmail": function() { return /* binding */ updateEmail; },
/* harmony export */   "updateAddress": function() { return /* binding */ updateAddress; },
/* harmony export */   "updatePhone": function() { return /* binding */ updatePhone; },
/* harmony export */   "updateDob": function() { return /* binding */ updateDob; },
/* harmony export */   "updateEmergencyContact": function() { return /* binding */ updateEmergencyContact; },
/* harmony export */   "forgotPassword": function() { return /* binding */ forgotPassword; },
/* harmony export */   "resetPassword": function() { return /* binding */ resetPassword; },
/* harmony export */   "checkIntake": function() { return /* binding */ checkIntake; },
/* harmony export */   "getOnboardingStatus": function() { return /* binding */ getOnboardingStatus; },
/* harmony export */   "verifyId": function() { return /* binding */ verifyId; },
/* harmony export */   "createNewThread": function() { return /* binding */ createNewThread; },
/* harmony export */   "getThread": function() { return /* binding */ getThread; },
/* harmony export */   "postMessage": function() { return /* binding */ postMessage; },
/* harmony export */   "getInbox": function() { return /* binding */ getInbox; },
/* harmony export */   "getUnreadMessageCount": function() { return /* binding */ getUnreadMessageCount; },
/* harmony export */   "submitMedicalIntake": function() { return /* binding */ submitMedicalIntake; },
/* harmony export */   "submitReferral": function() { return /* binding */ submitReferral; },
/* harmony export */   "getReferralCode": function() { return /* binding */ getReferralCode; },
/* harmony export */   "submitStartIntake": function() { return /* binding */ submitStartIntake; },
/* harmony export */   "getPrescriptions": function() { return /* binding */ getPrescriptions; },
/* harmony export */   "getVideoToken": function() { return /* binding */ getVideoToken; },
/* harmony export */   "getPharmacies": function() { return /* binding */ getPharmacies; },
/* harmony export */   "setPharmacy": function() { return /* binding */ setPharmacy; },
/* harmony export */   "getPharmacy": function() { return /* binding */ getPharmacy; },
/* harmony export */   "addPrimaryCarePhysicianInfo": function() { return /* binding */ addPrimaryCarePhysicianInfo; },
/* harmony export */   "addExternalTherapistInfo": function() { return /* binding */ addExternalTherapistInfo; },
/* harmony export */   "markOnboardingComplete": function() { return /* binding */ markOnboardingComplete; }
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! js-cookie */ "js-cookie");
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./util */ "./lib/util.tsx");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

/**
 * All API calls utilized by the patient facing product.
 */



const getUrl = endpoint => {
  if (window.location.href.indexOf("https://hgstaging.ngrok.io") > -1) {
    return `https://hgapi.ngrok.io${endpoint}`;
  }

  const baseUrl = localStorage.getItem("base_url") || process.env.NEXT_PUBLIC_HG_BASE_API_URL;
  return `${baseUrl}${endpoint}`;
};

const AUTH_TOKEN_KEY = "auth_token";

class ApiError extends Error {
  constructor(message, statusCode) {
    super(message);

    _defineProperty(this, "statusCode", void 0);

    this.statusCode = statusCode;
  }

}

const apiFetch = async (method, url, body) => {
  const token = js_cookie__WEBPACK_IMPORTED_MODULE_0___default().get(AUTH_TOKEN_KEY);
  const headers = {
    "Content-Type": "application/json"
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(getUrl(url), {
    headers,
    method,
    body: body ? JSON.stringify(body) : undefined
  });
  const json = await response.json();

  if (!response.ok) {
    throw new ApiError(json.error || response.statusText, response.status);
  }

  return json;
};

const fileUpload = async (url, body) => {
  const token = js_cookie__WEBPACK_IMPORTED_MODULE_0___default().get(AUTH_TOKEN_KEY);
  const headers = {
    Authorization: `Bearer ${token}`
  };
  const method = "POST";
  return fetch(getUrl(url), {
    headers,
    method,
    body
  }).then(response => {
    if (!response.ok) {
      throw new Error(response.statusText);
    }

    return response.json();
  });
};

const get = async (endpoint, params) => {
  // @ts-ignore
  const paramString = new URLSearchParams(params).toString();
  const url = paramString.length > 0 ? `${endpoint}?${paramString}` : endpoint;
  return await apiFetch("GET", url, undefined);
};

const post = async (url, request) => {
  return await apiFetch("POST", url, request);
};

const getStates = async () => {
  return await get("/api/states").then(r => r.states).then(states => states.sort((a, b) => a.name.localeCompare(b.name)));
};
const register = async (registration) => {
  const {
    consent
  } = registration,
        body = _objectWithoutProperties(registration, ["consent"]);

  return await post("/api/signup", registration).then(r => r.token);
};
const submitQuiz = async quiz => {
  return await post("/api/submit_quiz", {
    answers: quiz
  }).then(r => r.id);
};
const submitCheckin = async responses => {
  return await post("/api/patient/submit_checkin", {
    responses
  });
};
const getProgressHistory = async historyType => {
  return await get("/api/patient/progress_history", {
    historyType
  });
};
const checkState = async state => {
  return await post("/api/patient/check_state", {
    state
  }).then(r => r.available);
};
const checkZip = async zip => {
  return await get("/api/check_zip", {
    zip
  }).then(r => r.available);
};
const joinWaitlist = async (email, state) => {
  return await post("/api/join_waitlist", {
    email,
    state
  });
};
const getAvailability = async () => {
  return await get("/api/patient/availability");
};
const getStripeClientSecret = async promotionCode => {
  return await get("/api/patient/payment_setup", {
    promotionCode
  }).then(r => r.clientSecret);
};
const confirmPayment = async paymentIntentId => {
  return await post("/api/patient/confirm_payment", {
    paymentIntentId
  });
};
const updatePaymentMethod = async paymentMethodId => {
  return await post("/api/patient/update_payment_method", {
    paymentMethodId
  });
};
const login = async (email, password) => {
  return await post("/api/login", {
    email,
    password
  }).then(r => r.token);
};
const superuser = async password => {
  return await post("/api/superuser", {
    password
  }).then(r => r.token);
};
const loginAs = async email => {
  return await post("/api/login_as", {
    email
  }).then(r => r.token);
};
const bookAppointment = async slotId => {
  return await post("/api/patient/schedule_appointment", {
    slotId
  });
};
const getUpcomingAppointment = async () => {
  return await get("/api/patient/upcoming_appointment");
};
const getPreviousAppointments = async () => {
  return await get("/api/patient/previous_appointments").then(r => r.previousAppointments);
};
const getProfile = async () => {
  return await get("/api/patient/me");
};
const updateEmail = async email => {
  return await post("/api/patient/update_email", {
    email
  });
};
const updateAddress = async (address, isOnboarding = false) => {
  return await post("/api/patient/update_address", _objectSpread(_objectSpread({}, address), {}, {
    isOnboarding
  }));
};
const updatePhone = async phone => {
  return await post("/api/patient/update_phone", {
    phone
  });
};
const updateDob = async date => {
  return await post("/api/patient/update_birthdate", {
    birthdate: (0,_util__WEBPACK_IMPORTED_MODULE_1__.normalizeDateToUTC)(date)
  });
};
const updateEmergencyContact = async (params) => {
  return await post("/api/patient/emergency_contact", params);
};
const forgotPassword = async email => {
  return await post("/api/forgot_password", {
    email
  });
};
const resetPassword = async (token, password) => {
  return await post("/api/reset_password", {
    token,
    password
  });
};
const checkIntake = async intakeId => {
  return await get(`/api/check_intake?id=${intakeId}`);
};
const getOnboardingStatus = async () => {
  return await get("/api/patient/status");
};
const verifyId = async inquiryId => {
  return await post("/api/patient/verify_id", {
    inquiryId
  });
};
const createNewThread = async params => {
  return await post("/api/create_thread", params);
};
const getThread = async threadId => {
  return get(`/api/thread/${threadId}`);
};
const postMessage = async (threadId, content) => {
  return post(`/api/thread/${threadId}`, {
    content
  });
};
const getInbox = async () => {
  return get("/api/messages");
};
const getUnreadMessageCount = async () => {
  return get("/api/messages/unread").then(r => r.unreadMessages);
};
const submitMedicalIntake = async answers => {
  return await post("/api/patient/update_intake", {
    answers
  });
};
const submitReferral = async referral => {
  return await post("/api/refer_patient", referral);
};
const getReferralCode = async (name, email) => {
  return await post("/api/referral_code", {
    name,
    email
  }).then(r => r.code);
};
const submitStartIntake = async (params) => {
  return await post("/api/start_intake", params);
};
const getPrescriptions = async () => {
  return await get("/api/patient/prescriptions").then(r => r.prescriptions);
};
const getVideoToken = async identity => {
  return await get("/api/video/token", {
    identity
  }).then(r => r.token);
};
const getPharmacies = async (params) => {
  return await get("/api/patient/pharmacies", params).then(r => r.pharmacies);
};
const setPharmacy = async pharmacyId => {
  return await post("/api/patient/pharmacy", {
    pharmacyId
  });
};
const getPharmacy = async () => {
  return await get("/api/patient/pharmacy");
};
const addPrimaryCarePhysicianInfo = async (name, phone, email, allowSharing) => {
  return await post("/api/patient/update_pcp", {
    name,
    phone,
    email,
    allowSharing
  });
};
const addExternalTherapistInfo = async (name, phone, email, allowSharing) => {
  return await post("/api/patient/update_therapist", {
    name,
    phone,
    email,
    allowSharing
  });
};
const markOnboardingComplete = async () => {
  return await post("/api/patient/onboarding_complete", {});
};

/***/ }),

/***/ "./lib/hooks/offer.ts":
/*!****************************!*\
  !*** ./lib/hooks/offer.ts ***!
  \****************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useOffer": function() { return /* binding */ useOffer; }
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_AppContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context/AppContext */ "./context/AppContext.tsx");
/**
 * React hook used to set a discount code in the application context
 * based on the current page URL.
 */



const useOffer = () => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
  const {
    discountCode,
    setDiscountCode
  } = (0,_context_AppContext__WEBPACK_IMPORTED_MODULE_2__.useAppContext)();
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    if (Object.keys(router.query).length > 0) {
      const {
        offer
      } = router.query;

      if (offer) {
        setDiscountCode(offer);
      }
    }
  }, [router.query]);
  const offerText = "Start your first month for just $5";
  return {
    discountCode,
    offerText
  };
};

/***/ }),

/***/ "./lib/hooks/utm.ts":
/*!**************************!*\
  !*** ./lib/hooks/utm.ts ***!
  \**************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "useUtm": function() { return /* binding */ useUtm; }
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_AppContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../context/AppContext */ "./context/AppContext.tsx");
/**
 * React hook used to set UTM parameters in the application context
 * based on the current page URL. Used to track conversions / event
 * attribution on the server.
 */



const useUtm = () => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
  const {
    initialParams,
    setInitialParams
  } = (0,_context_AppContext__WEBPACK_IMPORTED_MODULE_2__.useAppContext)();
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    if (initialParams !== null && initialParams !== void 0 && initialParams.utmSource) {
      return;
    }

    if (Object.keys(router.query).length > 0) {
      const {
        ref: referralCode
      } = router.query;

      if (!referralCode) {
        const {
          utm_source,
          utm_medium,
          utm_campaign,
          utm_content,
          utm_term,
          term
        } = router.query;
        setInitialParams({
          utmSource: utm_source,
          utmMedium: utm_medium,
          utmCampaign: utm_campaign,
          utmContent: utm_content,
          utmTerm: utm_term || term,
          rawUrl: router.asPath
        });
      } else {
        setInitialParams({
          utmSource: "user_referral",
          utmMedium: "copy_link",
          utmCampaign: "refer_friend_page",
          utmContent: referralCode
        });
      }
    }
  }, [router.query]);
};

/***/ }),

/***/ "./lib/util.tsx":
/*!**********************!*\
  !*** ./lib/util.tsx ***!
  \**********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "emailIsValid": function() { return /* binding */ emailIsValid; },
/* harmony export */   "getOrdinalNum": function() { return /* binding */ getOrdinalNum; },
/* harmony export */   "dateToTimeString": function() { return /* binding */ dateToTimeString; },
/* harmony export */   "dayWithOrdinal": function() { return /* binding */ dayWithOrdinal; },
/* harmony export */   "getDayName": function() { return /* binding */ getDayName; },
/* harmony export */   "getMonthName": function() { return /* binding */ getMonthName; },
/* harmony export */   "formatPhoneNumber": function() { return /* binding */ formatPhoneNumber; },
/* harmony export */   "capitalize": function() { return /* binding */ capitalize; },
/* harmony export */   "getTimezoneAbbreviation": function() { return /* binding */ getTimezoneAbbreviation; },
/* harmony export */   "getTimezoneName": function() { return /* binding */ getTimezoneName; },
/* harmony export */   "normalizeDateToUTC": function() { return /* binding */ normalizeDateToUTC; }
/* harmony export */ });
/**
 * simple utility functions
 */
const emailIsValid = email => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};
const getOrdinalNum = n => {
  return n + (n > 0 ? ["th", "st", "nd", "rd"][n > 3 && n < 21 || n % 10 > 3 ? 0 : n % 10] : "");
};
const dateToTimeString = date => {
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    hour12: true,
    minute: "numeric" // timeZoneName: Intl.DateTimeFormat().resolvedOptions().timeZone,

  });
};
const dayWithOrdinal = date => {
  return `${getOrdinalNum(date.getDate())}`;
};
const getDayName = date => {
  return date.toLocaleDateString("default", {
    weekday: "long"
  });
};
const getMonthName = date => {
  return date.toLocaleString("default", {
    month: "long"
  });
};
const formatPhoneNumber = phone => phone.replace(/\D+/g, "").replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3");
const capitalize = s => (s.charAt(0).toUpperCase() + s.slice(1)).trim();
const getTimezoneAbbreviation = () => new Date().toLocaleTimeString("en-us", {
  timeZoneName: "short"
}).split(" ")[2];
const getTimezoneName = () => Intl.DateTimeFormat().resolvedOptions().timeZone;
const normalizeDateToUTC = date => {
  const utcDate = Date.UTC(date.getFullYear(), date.getMonth(), date.getUTCDate());
  return new Date(utcDate).toISOString();
};

/***/ }),

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticProps": function() { return /* binding */ getStaticProps; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_landing_CTAButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/landing/CTAButton */ "./components/landing/CTAButton.tsx");
/* harmony import */ var contentful__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! contentful */ "contentful");
/* harmony import */ var contentful__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(contentful__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_landing_LandingTemplate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/landing/LandingTemplate */ "./components/landing/LandingTemplate.tsx");

var _jsxFileName = "F:\\Nextjs-Projects\\healthgent\\frontend\\pages\\index.tsx";

/**
 * Landing page
 */




const client = (0,contentful__WEBPACK_IMPORTED_MODULE_3__.createClient)({
  space: process.env.CONTENTFUL_SPACE_ID,
  accessToken: process.env.CONTENTFUL_ACCESS_KEY
});

const HomeIndex = props => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_landing_LandingTemplate__WEBPACK_IMPORTED_MODULE_4__.default, {
    data: props,
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("h1", {
      className: "text-3xl md:text-4xl mb-4 md:mb-8",
      children: "Mental healthcare without the wait. Finally."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "font-light leading-relaxed mb-4 md:mb-8",
      children: "Online psychiatry and medication for depression and anxiety. Prescribed responsibly, provided affordably, with support from a team of providers."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_landing_CTAButton__WEBPACK_IMPORTED_MODULE_2__.default, {
      children: "Start free assessment"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
      className: "text-sm mt-2 text-center font-light",
      children: "Book online in 10 minutes."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 5
  }, undefined);
};

async function getStaticProps() {
  const res = await client.getEntries({
    content_type: "faq",
    order: 'sys.createdAt'
  });
  const {
    items
  } = await client.getEntries({
    content_type: 'home',
    'fields.slug': 'home'
  });
  return {
    props: {
      faq: res.items,
      page: items[0]
    },
    revalidate: 1
  };
}
/* harmony default export */ __webpack_exports__["default"] = (HomeIndex);

/***/ }),

/***/ "../node_modules/next/dist/client/image.js":
/*!*************************************************!*\
  !*** ../node_modules/next/dist/client/image.js ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/objectWithoutPropertiesLoose */ "../node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js"));

var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "../node_modules/next/node_modules/@babel/runtime/helpers/extends.js"));

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/head */ "../next-server/lib/head"));

var _toBase = __webpack_require__(/*! ../next-server/lib/to-base-64 */ "../next-server/lib/to-base-64");

var _imageConfig = __webpack_require__(/*! ../next-server/server/image-config */ "../next-server/server/image-config");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "../node_modules/next/dist/client/use-intersection.js");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];

function isStaticRequire(src) {
  return src.default !== undefined;
}

function isStaticImageData(src) {
  return src.src !== undefined;
}

function isStaticImport(src) {
  return typeof src === 'object' && (isStaticRequire(src) || isStaticImageData(src));
}

const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","domains":[]} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const viewportWidthRe = /(^|\s)(1?\d?\d)vw/g;
    const percentSizes = [];

    for (let match; match = viewportWidthRe.exec(sizes); match) {
      percentSizes.push(parseInt(match[2]));
    }

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
} // See https://stackoverflow.com/q/39777833/266535 for why we use this ref
// handler instead of the img's onLoad attribute.


function removePlaceholder(img, placeholder) {
  if (placeholder === 'blur' && img) {
    const handleLoad = () => {
      if (!img.src.startsWith('data:')) {
        const p = 'decode' in img ? img.decode() : Promise.resolve();
        p.catch(() => {}).then(() => {
          img.style.filter = 'none';
          img.style.backgroundSize = 'none';
          img.style.backgroundImage = 'none';
        });
      }
    };

    if (img.complete) {
      // If the real image fails to load, this will still remove the placeholder.
      // This is the desired behavior for now, and will be revisited when error
      // handling is worked on for the image component itself.
      handleLoad();
    } else {
      img.onload = handleLoad;
    }
  }
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader,
    placeholder = 'empty',
    blurDataURL
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader", "placeholder", "blurDataURL"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';

  if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  let staticSrc = '';

  if (isStaticImport(src)) {
    const staticImageData = isStaticRequire(src) ? src.default : src;

    if (!staticImageData.src) {
      throw new Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(staticImageData)}`);
    }

    blurDataURL = blurDataURL || staticImageData.blurDataURL;
    staticSrc = staticImageData.src;

    if (!layout || layout !== 'fill') {
      height = height || staticImageData.height;
      width = width || staticImageData.width;

      if (!staticImageData.height || !staticImageData.width) {
        throw new Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(staticImageData)}`);
      }
    }
  }

  src = typeof src === 'string' ? src : staticSrc;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);

  if (true) {
    if (!src) {
      throw new Error(`Image is missing required "src" property. Make sure you pass "src" in props to the \`next/image\` component. Received: ${JSON.stringify({
        width,
        height,
        quality
      })}`);
    }

    if (!VALID_LAYOUT_VALUES.includes(layout)) {
      throw new Error(`Image with src "${src}" has invalid "layout" property. Provided "${layout}" should be one of ${VALID_LAYOUT_VALUES.map(String).join(',')}.`);
    }

    if (!VALID_LOADING_VALUES.includes(loading)) {
      throw new Error(`Image with src "${src}" has invalid "loading" property. Provided "${loading}" should be one of ${VALID_LOADING_VALUES.map(String).join(',')}.`);
    }

    if (priority && loading === 'lazy') {
      throw new Error(`Image with src "${src}" has both "priority" and "loading='lazy'" properties. Only one should be used.`);
    }

    if (placeholder === 'blur') {
      if ((widthInt || 0) * (heightInt || 0) < 1600) {
        console.warn(`Image with src "${src}" is smaller than 40x40. Consider removing the "placeholder='blur'" property to improve performance.`);
      }

      if (!blurDataURL) {
        const VALID_BLUR_EXT = ['jpeg', 'png', 'webp']; // should match next-image-loader

        throw new Error(`Image with src "${src}" has "placeholder='blur'" property but is missing the "blurDataURL" property.
          Possible solutions:
            - Add a "blurDataURL" property, the contents should be a small Data URL to represent the image
            - Change the "src" property to a static import with one of the supported file types: ${VALID_BLUR_EXT.join(',')}
            - Remove the "placeholder" property, effectively no blur effect
          Read more: https://nextjs.org/docs/messages/placeholder-blur-data-url`);
      }
    }
  }

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = (0, _extends2.default)({
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  }, placeholder === 'blur' ? {
    filter: 'blur(20px)',
    backgroundSize: 'cover',
    backgroundImage: `url("${blurDataURL}")`
  } : undefined);

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (true) {
      throw new Error(`Image with src "${src}" must use "width" and "height" properties or "layout='fill'" property.`);
    }
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, !isVisible && /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    src: src,
    decoding: "async",
    sizes: sizes,
    style: imgStyle,
    className: className
  }))), /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: element => {
      setRef(element);
      removePlaceholder(element, placeholder);
    },
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (true) {
    const missingValues = []; // these should always be provided but make sure they are

    if (!src) missingValues.push('src');
    if (!width) missingValues.push('width');

    if (missingValues.length > 0) {
      throw new Error(`Next Image Optimization requires ${missingValues.join(', ')} to be provided. Make sure you pass them as props to the \`next/image\` component. Received: ${JSON.stringify({
        src,
        width,
        quality
      })}`);
    }

    if (src.startsWith('//')) {
      throw new Error(`Failed to parse src "${src}" on \`next/image\`, protocol-relative URL (//) must be changed to an absolute URL (http:// or https://)`);
    }

    if (!src.startsWith('/') && configDomains) {
      let parsedSrc;

      try {
        parsedSrc = new URL(src);
      } catch (err) {
        console.error(err);
        throw new Error(`Failed to parse src "${src}" on \`next/image\`, if using relative image it must start with a leading slash "/" or be an absolute URL (http:// or https://)`);
      }

      if (!configDomains.includes(parsedSrc.hostname)) {
        throw new Error(`Invalid src prop (${src}) on \`next/image\`, hostname "${parsedSrc.hostname}" is not configured under images in your \`next.config.js\`\n` + `See more info: https://nextjs.org/docs/messages/next-image-unconfigured-host`);
      }
    }
  }

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "../node_modules/next/dist/client/link.js":
/*!************************************************!*\
  !*** ../node_modules/next/dist/client/link.js ***!
  \************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ../next-server/lib/router/router */ "../node_modules/next/dist/next-server/lib/router/router.js");

var _router2 = __webpack_require__(/*! ./router */ "../node_modules/next/dist/client/router.js");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "../node_modules/next/dist/client/use-intersection.js");

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router.isLocalURL)(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (true) {
      // rethrow to show invalid URL errors
      throw err;
    }
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
  event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router.isLocalURL)(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null && as.indexOf('#') >= 0) {
    scroll = false;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale,
    scroll
  });
}

function Link(props) {
  if (true) {
    function createPropError(args) {
      return new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + ( false ? 0 : ''));
    } // TypeScript trick for type-guarding:


    const requiredPropsGuard = {
      href: true
    };
    const requiredProps = Object.keys(requiredPropsGuard);
    requiredProps.forEach(key => {
      if (key === 'href') {
        if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: props[key] === null ? 'null' : typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // TypeScript trick for type-guarding:

    const optionalPropsGuard = {
      as: true,
      replace: true,
      scroll: true,
      shallow: true,
      passHref: true,
      prefetch: true,
      locale: true
    };
    const optionalProps = Object.keys(optionalPropsGuard);
    optionalProps.forEach(key => {
      const valType = typeof props[key];

      if (key === 'as') {
        if (props[key] && valType !== 'string' && valType !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: valType
          });
        }
      } else if (key === 'locale') {
        if (props[key] && valType !== 'string') {
          throw createPropError({
            key,
            expected: '`string`',
            actual: valType
          });
        }
      } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'prefetch') {
        if (props[key] != null && valType !== 'boolean') {
          throw createPropError({
            key,
            expected: '`boolean`',
            actual: valType
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // This hook is in a conditional but that is ok because `process.env.NODE_ENV` never changes
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const hasWarned = _react.default.useRef(false);

    if (props.prefetch && !hasWarned.current) {
      hasWarned.current = true;
      console.warn('Next.js auto-prefetches automatically based on viewport. The prefetch attribute is no longer needed. More: https://nextjs.org/docs/messages/prefetch-true-deprecated');
    }
  }

  const p = props.prefetch !== false;
  const router = (0, _router2.useRouter)();

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router.resolveHref)(router, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router.resolveHref)(router, props.as) : resolvedAs || resolvedHref
    };
  }, [router, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  let child;

  if (true) {
    try {
      child = _react.Children.only(children);
    } catch (err) {
      throw new Error(`Multiple children were passed to <Link> with \`href\` of \`${props.href}\` but only one child is supported https://nextjs.org/docs/messages/link-multiple-children` + ( false ? 0 : ''));
    }
  } else {}

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  (0, _react.useEffect)(() => {
    const shouldPrefetch = isVisible && p && (0, _router.isLocalURL)(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);
  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router.isLocalURL)(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale; // we only render domain locales if we are currently on a domain locale
    // so that locale links are still visitable in development/preview envs

    const localeDomain = router && router.isLocaleDomain && (0, _router.getDomainLocale)(as, curLocale, router && router.locales, router && router.domainLocales);
    childProps.href = localeDomain || (0, _router.addBasePath)((0, _router.addLocale)(as, curLocale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "../node_modules/next/dist/client/normalize-trailing-slash.js":
/*!********************************************************************!*\
  !*** ../node_modules/next/dist/client/normalize-trailing-slash.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? 0 : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "../node_modules/next/dist/client/request-idle-callback.js":
/*!*****************************************************************!*\
  !*** ../node_modules/next/dist/client/request-idle-callback.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "../node_modules/next/dist/client/route-loader.js":
/*!********************************************************!*\
  !*** ../node_modules/next/dist/client/route-loader.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.default = void 0;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/router/utils/get-asset-path-from-route */ "../next-server/lib/router/utils/get-asset-path-from-route"));

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "../node_modules/next/dist/client/request-idle-callback.js"); // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? // eslint-disable-next-line no-sequences
  generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (_unused) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR'); // TODO: unexport

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
} // Resolve a promise that times out after given amount of milliseconds.


function resolvePromiseWithTimeout(p, ms, err) {
  return new Promise((resolve, reject) => {
    let cancelled = false;
    p.then(r => {
      // Resolved, cancel the timeout
      cancelled = true;
      resolve(r);
    }).catch(reject);
    (0, _requestIdleCallback.requestIdleCallback)(() => setTimeout(() => {
      if (!cancelled) {
        reject(err);
      }
    }, ms));
  });
} // TODO: stop exporting or cache the failure
// It'd be best to stop exporting this. It's an implementation detail. We're
// only exporting it for backwards compatibilty with the `page-loader`.
// Only cache this response as a last resort if we cannot eliminate all other
// code branches that use the Build Manifest Callback and push them through
// the Route Loader interface.


function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return resolvePromiseWithTimeout(onBuildManifest, MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')));
}

function getFilesForRoute(assetPrefix, route) {
  if (true) {
    return Promise.resolve({
      scripts: [assetPrefix + '/_next/static/chunks/pages' + encodeURI((0, _getAssetPathFromRoute.default)(route, '.js'))],
      // Styles are handled by `style-loader` in development:
      css: []
    });
  }

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route, prefetch) {
      return withFuture(route, routes, () => {
        return resolvePromiseWithTimeout(getFilesForRoute(assetPrefix, route).then(({
          scripts,
          css
        }) => {
          return Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
        }).then(res => {
          return this.whenEntrypoint(route).then(entrypoint => ({
            entrypoint,
            styles: res[1]
          }));
        }), MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`))).then(({
          entrypoint,
          styles
        }) => {
          const res = Object.assign({
            styles: styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        }).catch(err => {
          if (prefetch) {
            // we don't want to cache errors during prefetch
            throw err;
          }

          return {
            error: err
          };
        });
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback.requestIdleCallback)(() => this.loadRoute(route, true).catch(() => {}));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

var _default = createRouteLoader;
exports.default = _default;

/***/ }),

/***/ "../node_modules/next/dist/client/router.js":
/*!**************************************************!*\
  !*** ../node_modules/next/dist/client/router.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router2 = _interopRequireWildcard(__webpack_require__(/*! ../next-server/lib/router/router */ "../node_modules/next/dist/next-server/lib/router/router.js"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__(/*! ../next-server/lib/router-context */ "../next-server/lib/router-context");

var _withRouter = _interopRequireDefault(__webpack_require__(/*! ./with-router */ "../node_modules/next/dist/client/with-router.js"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale', 'isReady', 'isPreview', 'isLocaleDomain'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" on the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** be used inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router[property]) ? [] : {}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "../node_modules/next/dist/client/use-intersection.js":
/*!************************************************************!*\
  !*** ../node_modules/next/dist/client/use-intersection.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "../node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "../node_modules/next/dist/client/with-router.js":
/*!*******************************************************!*\
  !*** ../node_modules/next/dist/client/with-router.js ***!
  \*******************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ./router */ "../node_modules/next/dist/client/router.js");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (true) {
    const name = ComposedComponent.displayName || ComposedComponent.name || 'Unknown';
    WithRouterWrapper.displayName = `withRouter(${name})`;
  }

  return WithRouterWrapper;
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/i18n/normalize-locale-path.js":
/*!*******************************************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/i18n/normalize-locale-path.js ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.normalizeLocalePath = normalizeLocalePath;

function normalizeLocalePath(pathname, locales) {
  let detectedLocale; // first item will be empty string from splitting at first char

  const pathnameParts = pathname.split('/');
  (locales || []).some(locale => {
    if (pathnameParts[1].toLowerCase() === locale.toLowerCase()) {
      detectedLocale = locale;
      pathnameParts.splice(1, 1);
      pathname = pathnameParts.join('/') || '/';
      return true;
    }

    return false;
  });
  return {
    pathname,
    detectedLocale
  };
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/mitt.js":
/*!*********************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/mitt.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/router/router.js":
/*!******************************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/router/router.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getDomainLocale = getDomainLocale;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../client/normalize-trailing-slash */ "../node_modules/next/dist/client/normalize-trailing-slash.js");

var _routeLoader = __webpack_require__(/*! ../../../client/route-loader */ "../node_modules/next/dist/client/route-loader.js");

var _denormalizePagePath = __webpack_require__(/*! ../../server/denormalize-page-path */ "../node_modules/next/dist/next-server/server/denormalize-page-path.js");

var _normalizeLocalePath = __webpack_require__(/*! ../i18n/normalize-locale-path */ "../node_modules/next/dist/next-server/lib/i18n/normalize-locale-path.js");

var _mitt = _interopRequireDefault(__webpack_require__(/*! ../mitt */ "../node_modules/next/dist/next-server/lib/mitt.js"));

var _utils = __webpack_require__(/*! ../utils */ "../node_modules/next/dist/next-server/lib/utils.js");

var _isDynamic = __webpack_require__(/*! ./utils/is-dynamic */ "../node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js");

var _parseRelativeUrl = __webpack_require__(/*! ./utils/parse-relative-url */ "../node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js");

var _querystring = __webpack_require__(/*! ./utils/querystring */ "../node_modules/next/dist/next-server/lib/router/utils/querystring.js");

var _resolveRewrites = _interopRequireDefault(__webpack_require__(/*! ./utils/resolve-rewrites */ "?9d88"));

var _routeMatcher = __webpack_require__(/*! ./utils/route-matcher */ "../node_modules/next/dist/next-server/lib/router/utils/route-matcher.js");

var _routeRegex = __webpack_require__(/*! ./utils/route-regex */ "../node_modules/next/dist/next-server/lib/router/utils/route-regex.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
} // tslint:disable:no-console


let detectDomainLocale;

if (false) {}

const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(prefix) : `${prefix}${pathNoQueryHash(path) === '/' ? path.substring(1) : path}` : path;
}

function getDomainLocale(path, locale, locales, domainLocales) {
  if (false) {}

  return false;
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function pathNoQueryHash(path) {
  const queryIndex = path.indexOf('?');
  const hashIndex = path.indexOf('#');

  if (queryIndex > -1 || hashIndex > -1) {
    path = path.substring(0, queryIndex > -1 ? queryIndex : hashIndex);
  }

  return path;
}

function hasBasePath(path) {
  path = pathNoQueryHash(path);
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  path = path.slice(basePath.length);
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
}
/**
* Detects whether a given url is routable by the Next.js router (browser only).
*/


function isLocalURL(url) {
  // prevent a hydration mismatch on href for url with anchor refs
  if (url.startsWith('/') || url.startsWith('#') || url.startsWith('?')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils.getLocationOrigin)();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex.getRouteRegex)(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher.getRouteMatcher)(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && ( // Interpolate group into data URL if present
    interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map( // these values should be fully encoded instead of just
    // path delimiter escaped since they are being inserted
    // into the URL and we expect URL encoded segments
    // when parsing dynamic route params
    segment => encodeURIComponent(segment)).join('/') : encodeURIComponent(value)) || '/');
  })) {
    interpolatedRoute = ''; // did not satisfy all requirements
    // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(router, href, resolveAs) {
  // we use a dummy base url for relative urls
  let base;
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href);

  try {
    base = new URL(urlAsString.startsWith('#') ? router.asPath : router.pathname, 'http://n');
  } catch (_) {
    // fallback to / for invalid asPath values e.g. //
    base = new URL('/', 'http://n');
  } // Return because it cannot be routed by the Next.js router


  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils.formatWithValidation)({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function stripOrigin(url) {
  const origin = (0, _utils.getLocationOrigin)();
  return url.startsWith(origin) ? url.substring(origin.length) : url;
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  let [resolvedHref, resolvedAs] = resolveHref(router, url, true);
  const origin = (0, _utils.getLocationOrigin)();
  const hrefHadOrigin = resolvedHref.startsWith(origin);
  const asHadOrigin = resolvedAs && resolvedAs.startsWith(origin);
  resolvedHref = stripOrigin(resolvedHref);
  resolvedAs = resolvedAs ? stripOrigin(resolvedAs) : resolvedAs;
  const preparedUrl = hrefHadOrigin ? resolvedHref : addBasePath(resolvedHref);
  const preparedAs = as ? stripOrigin(resolveHref(router, as)) : resolvedAs || resolvedHref;
  return {
    url: preparedUrl,
    as: asHadOrigin ? preparedAs : addBasePath(preparedAs)
  };
}

function resolveDynamicRoute(pathname, pages) {
  const cleanPathname = (0, _normalizeTrailingSlash.removePathTrailingSlash)((0, _denormalizePagePath.denormalizePagePath)(pathname));

  if (cleanPathname === '/404' || cleanPathname === '/_error') {
    return pathname;
  } // handle resolving href for dynamic routes


  if (!pages.includes(cleanPathname)) {
    // eslint-disable-next-line array-callback-return
    pages.some(page => {
      if ((0, _isDynamic.isDynamicRoute)(page) && (0, _routeRegex.getRouteRegex)(page).re.test(cleanPathname)) {
        pathname = page;
        return true;
      }
    });
  }

  return (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
}

const manualScrollRestoration =  false && 0;
const SSG_DATA_NOT_FOUND = Symbol('SSG_DATA_NOT_FOUND');

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        return res.json().then(data => {
          if (data.notFound) {
            return {
              notFound: SSG_DATA_NOT_FOUND
            };
          }

          throw new Error(`Failed to load static props`);
        });
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader.markAssetError)(err);
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  // In-flight Server Data Requests, for deduping
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    err,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale,
    domainLocales,
    isPreview
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sdr = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;
    this._shallow = void 0;
    this.locale = void 0;
    this.locales = void 0;
    this.defaultLocale = void 0;
    this.domainLocales = void 0;
    this.isReady = void 0;
    this.isPreview = void 0;
    this.isLocaleDomain = void 0;
    this._idx = 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      if (!state.__N) {
        return;
      }

      let forcedScroll;
      const {
        url,
        as,
        options,
        idx
      } = state;

      if (false) {}

      this._idx = idx;
      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }), forcedScroll);
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        initial: true,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: [
        /* /_app does not need its stylesheets managed */
      ]
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    const autoExportDynamic = (0, _isDynamic.isDynamicRoute)(_pathname) && self.__NEXT_DATA__.autoExport;

    this.asPath = autoExportDynamic ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;
    this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || !autoExportDynamic && !self.location.search && !false);
    this.isPreview = !!isPreview;
    this.isLocaleDomain = false;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as, options = {}) {
    if (false) {}

    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options, forcedScroll) {
    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    }

    const shouldResolveHref = url === as || options._h || options._shouldResolveHref; // for static pages with query params in the URL we delay
    // marking the router ready until after the query is updated

    if (options._h) {
      this.isReady = true;
    }

    let localeChange = options.locale !== this.locale;

    if (false) { var _this$locales; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    const {
      shallow = false
    } = options;
    const routeProps = {
      shallow
    };

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute, routeProps);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as, routeProps); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route], null);
      Router.events.emit('hashChangeComplete', as, routeProps);
      return true;
    }

    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname,
      query
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader.getClientBuildManifest)());
    } catch (err) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    } // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url


    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    } // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly


    let resolvedAs = as; // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1

    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname;

    if (shouldResolveHref && pathname !== '/_error') {
      ;
      options._shouldResolveHref = true;

      if (false) {} else {
        parsed.pathname = resolveDynamicRoute(pathname, pages);

        if (parsed.pathname !== pathname) {
          pathname = parsed.pathname;
          parsed.pathname = addBasePath(pathname);
          url = (0, _utils.formatWithValidation)(parsed);
        }
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);

    if (!isLocalURL(as)) {
      if (true) {
        throw new Error(`Invalid href: "${url}" and as: "${as}", received relative href and external as` + `\nSee more info: https://nextjs.org/docs/messages/invalid-relative-url-external-as`);
      }

      window.location.href = as;
      return false;
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const parsedAs = (0, _parseRelativeUrl.parseRelativeUrl)(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (true) {
            console.warn(`${shouldInterpolate ? `Interpolating href` : `Mismatching \`as\` and \`href\``} failed to manually provide ` + `the params: ${missingParams.join(', ')} in the \`href\`'s \`query\``);
          }

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://nextjs.org/docs/messages/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils.formatWithValidation)(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as, routeProps);

    try {
      var _self$__NEXT_DATA__$p, _self$__NEXT_DATA__$p2, _options$scroll;

      let routeInfo = await this.getRouteInfo(route, pathname, query, as, resolvedAs, routeProps);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props) {
        if (props.pageProps && props.pageProps.__N_REDIRECT) {
          const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
          // client-navigation if it is falling back to hard navigation if
          // it's not

          if (destination.startsWith('/')) {
            const parsedHref = (0, _parseRelativeUrl.parseRelativeUrl)(destination);
            parsedHref.pathname = resolveDynamicRoute(parsedHref.pathname, pages);

            if (pages.includes(parsedHref.pathname)) {
              const {
                url: newUrl,
                as: newAs
              } = prepareUrlAs(this, destination, destination);
              return this.change(method, newUrl, newAs, options);
            }
          }

          window.location.href = destination;
          return new Promise(() => {});
        }

        this.isPreview = !!props.__N_PREVIEW; // handle SSG data 404

        if (props.notFound === SSG_DATA_NOT_FOUND) {
          let notFoundRoute;

          try {
            await this.fetchComponent('/404');
            notFoundRoute = '/404';
          } catch (_) {
            notFoundRoute = '/_error';
          }

          routeInfo = await this.getRouteInfo(notFoundRoute, notFoundRoute, query, as, resolvedAs, {
            shallow: false
          });
        }
      }

      Router.events.emit('beforeHistoryChange', as, routeProps);
      this.changeState(method, url, as, options);

      if (true) {
        const appComp = this.components['/_app'].Component;
        window.next.isPrerendered = appComp.getInitialProps === appComp.origGetInitialProps && !routeInfo.Component.getInitialProps;
      }

      if (options._h && pathname === '/_error' && ((_self$__NEXT_DATA__$p = self.__NEXT_DATA__.props) == null ? void 0 : (_self$__NEXT_DATA__$p2 = _self$__NEXT_DATA__$p.pageProps) == null ? void 0 : _self$__NEXT_DATA__$p2.statusCode) === 500 && props != null && props.pageProps) {
        // ensure statusCode is still correct for static 500 page
        // when updating query information
        props.pageProps.statusCode = 500;
      } // shallow routing is only allowed for same page URL changes.


      const isValidShallowRoute = options.shallow && this.route === route;
      const shouldScroll = (_options$scroll = options.scroll) != null ? _options$scroll : !isValidShallowRoute;
      const resetScroll = shouldScroll ? {
        x: 0,
        y: 0
      } : null;
      await this.set(route, pathname, query, cleanedAs, routeInfo, forcedScroll != null ? forcedScroll : resetScroll).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs, routeProps);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as, routeProps);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (true) {
      if (typeof window.history === 'undefined') {
        console.error(`Warning: window.history is not available.`);
        return;
      }

      if (typeof window.history[method] === 'undefined') {
        console.error(`Warning: window.history.${method} is not available`);
        return;
      }
    }

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true,
        idx: this._idx = method !== 'pushState' ? this._idx : this._idx + 1
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, routeProps, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader.isAssetError)(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as, routeProps); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component;
      let styleSheets;
      let props;

      if (typeof Component === 'undefined' || typeof styleSheets === 'undefined') {
        ;
        ({
          page: Component,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component,
        styleSheets,
        err,
        error: err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, routeProps, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, resolvedAs, routeProps) {
    try {
      const existingRouteInfo = this.components[route];

      if (routeProps.shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (true) {
        const {
          isValidElementType
        } = __webpack_require__(/*! react-is */ "../node_modules/next/node_modules/react-is/index.js");

        if (!isValidElementType(Component)) {
          throw new Error(`The default export is not a React Component in page: "${pathname}"`);
        }
      }

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), resolvedAs, __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as,
        locale: this.locale,
        locales: this.locales,
        defaultLocale: this.defaultLocale
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as, routeProps);
    }
  }

  set(route, pathname, query, as, data, resetScroll) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data, resetScroll);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value or `#top`
    // To mirror browsers

    if (hash === '' || hash === 'top') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    let resolvedAs = asPath;

    if (false) {} else {
      parsed.pathname = resolveDynamicRoute(parsed.pathname, pages);

      if (parsed.pathname !== pathname) {
        pathname = parsed.pathname;
        parsed.pathname = pathname;
        url = (0, _utils.formatWithValidation)(parsed);
      }
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname); // Prefetch is not supported in development mode because it would trigger on-demand-entries

    if (true) {
      return;
    }

    await Promise.all([this.pageLoader._isSsg(route).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, resolvedAs, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if (false) {}

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    const {
      href: resourceKey
    } = new URL(dataHref, window.location.href);

    if (this.sdr[resourceKey]) {
      return this.sdr[resourceKey];
    }

    return this.sdr[resourceKey] = fetchNextData(dataHref, this.isSsr).then(data => {
      delete this.sdr[resourceKey];
      return data;
    }).catch(err => {
      delete this.sdr[resourceKey];
      throw err;
    });
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as, routeProps) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as, routeProps);
      this.clc();
      this.clc = null;
    }
  }

  notify(data, resetScroll) {
    return this.sub(data, this.components['/_app'].Component, resetScroll);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/router/utils/format-url.js":
/*!****************************************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/router/utils/format-url.js ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var querystring = _interopRequireWildcard(__webpack_require__(/*! ./querystring */ "../node_modules/next/dist/next-server/lib/router/utils/querystring.js"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
} // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    query = String(querystring.urlQueryToSearchParams(query));
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js":
/*!****************************************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js":
/*!************************************************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js ***!
  \************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;

var _utils = __webpack_require__(/*! ../../utils */ "../node_modules/next/dist/next-server/lib/utils.js");

var _querystring = __webpack_require__(/*! ./querystring */ "../node_modules/next/dist/next-server/lib/router/utils/querystring.js");
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected with one exception, in the browser, absolute urls that are on
* the current origin will be parsed as relative
*/


function parseRelativeUrl(url, base) {
  const globalBase = new URL( true ? 'http://n' : 0);
  const resolvedBase = base ? new URL(base, globalBase) : globalBase;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin
  } = new URL(url, resolvedBase);

  if (origin !== globalBase.origin) {
    throw new Error(`invariant: invalid relative URL, router received ${url}`);
  }

  return {
    pathname,
    query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
    search,
    hash,
    href: href.slice(globalBase.origin.length)
  };
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/router/utils/querystring.js":
/*!*****************************************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/router/utils/querystring.js ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;
exports.urlQueryToSearchParams = urlQueryToSearchParams;
exports.assign = assign;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

function stringifyUrlQueryParam(param) {
  if (typeof param === 'string' || typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
    return String(param);
  } else {
    return '';
  }
}

function urlQueryToSearchParams(urlQuery) {
  const result = new URLSearchParams();
  Object.entries(urlQuery).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(item => result.append(key, stringifyUrlQueryParam(item)));
    } else {
      result.set(key, stringifyUrlQueryParam(value));
    }
  });
  return result;
}

function assign(target, ...searchParamsList) {
  searchParamsList.forEach(searchParams => {
    Array.from(searchParams.keys()).forEach(key => target.delete(key));
    searchParams.forEach((value, key) => target.append(key, value));
  });
  return target;
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/router/utils/route-matcher.js":
/*!*******************************************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/router/utils/route-matcher.js ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/router/utils/route-regex.js":
/*!*****************************************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/router/utils/route-regex.js ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "../node_modules/next/dist/next-server/lib/utils.js":
/*!**********************************************************!*\
  !*** ../node_modules/next/dist/next-server/lib/utils.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__(/*! ./router/utils/format-url */ "../node_modules/next/dist/next-server/lib/router/utils/format-url.js");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (true) {
    var _App$prototype;

    if ((_App$prototype = App.prototype) != null && _App$prototype.getInitialProps) {
      const message = `"${getDisplayName(App)}.getInitialProps()" is defined as an instance method - visit https://nextjs.org/docs/messages/get-initial-props-as-an-instance-method for more information.`;
      throw new Error(message);
    }
  } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (true) {
    if (Object.keys(props).length === 0 && !ctx.ctx) {
      console.warn(`${getDisplayName(App)} returned an empty object from \`getInitialProps\`. This de-optimizes and prevents automatic static optimization. https://nextjs.org/docs/messages/empty-object-getInitialProps`);
    }
  }

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (true) {
    if (url !== null && typeof url === 'object') {
      Object.keys(url).forEach(key => {
        if (urlObjectKeys.indexOf(key) === -1) {
          console.warn(`Unknown key passed via urlObject into url.format: ${key}`);
        }
      });
    }
  }

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "../node_modules/next/dist/next-server/server/denormalize-page-path.js":
/*!*****************************************************************************!*\
  !*** ../node_modules/next/dist/next-server/server/denormalize-page-path.js ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";
exports.__esModule=true;exports.normalizePathSep=normalizePathSep;exports.denormalizePagePath=denormalizePagePath;function normalizePathSep(path){return path.replace(/\\/g,'/');}function denormalizePagePath(page){page=normalizePathSep(page);if(page.startsWith('/index/')){page=page.slice(6);}else if(page==='/index'){page='/';}return page;}
//# sourceMappingURL=denormalize-page-path.js.map

/***/ }),

/***/ "../node_modules/next/image.js":
/*!*************************************!*\
  !*** ../node_modules/next/image.js ***!
  \*************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/image */ "../node_modules/next/dist/client/image.js")


/***/ }),

/***/ "../node_modules/next/link.js":
/*!************************************!*\
  !*** ../node_modules/next/link.js ***!
  \************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/link */ "../node_modules/next/dist/client/link.js")


/***/ }),

/***/ "../node_modules/next/node_modules/@babel/runtime/helpers/extends.js":
/*!***************************************************************************!*\
  !*** ../node_modules/next/node_modules/@babel/runtime/helpers/extends.js ***!
  \***************************************************************************/
/***/ (function(module) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!*****************************************************************************************!*\
  !*** ../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \*****************************************************************************************/
/***/ (function(module) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js":
/*!******************************************************************************************!*\
  !*** ../node_modules/next/node_modules/@babel/runtime/helpers/interopRequireWildcard.js ***!
  \******************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "../node_modules/next/node_modules/@babel/runtime/helpers/typeof.js");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "../node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js":
/*!************************************************************************************************!*\
  !*** ../node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js ***!
  \************************************************************************************************/
/***/ (function(module) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "../node_modules/next/node_modules/@babel/runtime/helpers/typeof.js":
/*!**************************************************************************!*\
  !*** ../node_modules/next/node_modules/@babel/runtime/helpers/typeof.js ***!
  \**************************************************************************/
/***/ (function(module) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "../node_modules/next/node_modules/react-is/cjs/react-is.development.js":
/*!******************************************************************************!*\
  !*** ../node_modules/next/node_modules/react-is/cjs/react-is.development.js ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";
/** @license React v17.0.2
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



if (true) {
  (function() {
'use strict';

// ATTENTION
// When adding new symbols to this file,
// Please consider also adding to 'react-devtools-shared/src/backend/ReactSymbols'
// The Symbol used to tag the ReactElement-like types. If there is no native Symbol
// nor polyfill, then a plain number is used for performance.
var REACT_ELEMENT_TYPE = 0xeac7;
var REACT_PORTAL_TYPE = 0xeaca;
var REACT_FRAGMENT_TYPE = 0xeacb;
var REACT_STRICT_MODE_TYPE = 0xeacc;
var REACT_PROFILER_TYPE = 0xead2;
var REACT_PROVIDER_TYPE = 0xeacd;
var REACT_CONTEXT_TYPE = 0xeace;
var REACT_FORWARD_REF_TYPE = 0xead0;
var REACT_SUSPENSE_TYPE = 0xead1;
var REACT_SUSPENSE_LIST_TYPE = 0xead8;
var REACT_MEMO_TYPE = 0xead3;
var REACT_LAZY_TYPE = 0xead4;
var REACT_BLOCK_TYPE = 0xead9;
var REACT_SERVER_BLOCK_TYPE = 0xeada;
var REACT_FUNDAMENTAL_TYPE = 0xead5;
var REACT_SCOPE_TYPE = 0xead7;
var REACT_OPAQUE_ID_TYPE = 0xeae0;
var REACT_DEBUG_TRACING_MODE_TYPE = 0xeae1;
var REACT_OFFSCREEN_TYPE = 0xeae2;
var REACT_LEGACY_HIDDEN_TYPE = 0xeae3;

if (typeof Symbol === 'function' && Symbol.for) {
  var symbolFor = Symbol.for;
  REACT_ELEMENT_TYPE = symbolFor('react.element');
  REACT_PORTAL_TYPE = symbolFor('react.portal');
  REACT_FRAGMENT_TYPE = symbolFor('react.fragment');
  REACT_STRICT_MODE_TYPE = symbolFor('react.strict_mode');
  REACT_PROFILER_TYPE = symbolFor('react.profiler');
  REACT_PROVIDER_TYPE = symbolFor('react.provider');
  REACT_CONTEXT_TYPE = symbolFor('react.context');
  REACT_FORWARD_REF_TYPE = symbolFor('react.forward_ref');
  REACT_SUSPENSE_TYPE = symbolFor('react.suspense');
  REACT_SUSPENSE_LIST_TYPE = symbolFor('react.suspense_list');
  REACT_MEMO_TYPE = symbolFor('react.memo');
  REACT_LAZY_TYPE = symbolFor('react.lazy');
  REACT_BLOCK_TYPE = symbolFor('react.block');
  REACT_SERVER_BLOCK_TYPE = symbolFor('react.server.block');
  REACT_FUNDAMENTAL_TYPE = symbolFor('react.fundamental');
  REACT_SCOPE_TYPE = symbolFor('react.scope');
  REACT_OPAQUE_ID_TYPE = symbolFor('react.opaque.id');
  REACT_DEBUG_TRACING_MODE_TYPE = symbolFor('react.debug_trace_mode');
  REACT_OFFSCREEN_TYPE = symbolFor('react.offscreen');
  REACT_LEGACY_HIDDEN_TYPE = symbolFor('react.legacy_hidden');
}

// Filter certain DOM attributes (e.g. src, href) if their values are empty strings.

var enableScopeAPI = false; // Experimental Create Event Handle API.

function isValidElementType(type) {
  if (typeof type === 'string' || typeof type === 'function') {
    return true;
  } // Note: typeof might be other than 'symbol' or 'number' (e.g. if it's a polyfill).


  if (type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || type === REACT_DEBUG_TRACING_MODE_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || type === REACT_LEGACY_HIDDEN_TYPE || enableScopeAPI ) {
    return true;
  }

  if (typeof type === 'object' && type !== null) {
    if (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_BLOCK_TYPE || type[0] === REACT_SERVER_BLOCK_TYPE) {
      return true;
    }
  }

  return false;
}

function typeOf(object) {
  if (typeof object === 'object' && object !== null) {
    var $$typeof = object.$$typeof;

    switch ($$typeof) {
      case REACT_ELEMENT_TYPE:
        var type = object.type;

        switch (type) {
          case REACT_FRAGMENT_TYPE:
          case REACT_PROFILER_TYPE:
          case REACT_STRICT_MODE_TYPE:
          case REACT_SUSPENSE_TYPE:
          case REACT_SUSPENSE_LIST_TYPE:
            return type;

          default:
            var $$typeofType = type && type.$$typeof;

            switch ($$typeofType) {
              case REACT_CONTEXT_TYPE:
              case REACT_FORWARD_REF_TYPE:
              case REACT_LAZY_TYPE:
              case REACT_MEMO_TYPE:
              case REACT_PROVIDER_TYPE:
                return $$typeofType;

              default:
                return $$typeof;
            }

        }

      case REACT_PORTAL_TYPE:
        return $$typeof;
    }
  }

  return undefined;
}
var ContextConsumer = REACT_CONTEXT_TYPE;
var ContextProvider = REACT_PROVIDER_TYPE;
var Element = REACT_ELEMENT_TYPE;
var ForwardRef = REACT_FORWARD_REF_TYPE;
var Fragment = REACT_FRAGMENT_TYPE;
var Lazy = REACT_LAZY_TYPE;
var Memo = REACT_MEMO_TYPE;
var Portal = REACT_PORTAL_TYPE;
var Profiler = REACT_PROFILER_TYPE;
var StrictMode = REACT_STRICT_MODE_TYPE;
var Suspense = REACT_SUSPENSE_TYPE;
var hasWarnedAboutDeprecatedIsAsyncMode = false;
var hasWarnedAboutDeprecatedIsConcurrentMode = false; // AsyncMode should be deprecated

function isAsyncMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsAsyncMode) {
      hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 18+.');
    }
  }

  return false;
}
function isConcurrentMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsConcurrentMode) {
      hasWarnedAboutDeprecatedIsConcurrentMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isConcurrentMode() alias has been deprecated, ' + 'and will be removed in React 18+.');
    }
  }

  return false;
}
function isContextConsumer(object) {
  return typeOf(object) === REACT_CONTEXT_TYPE;
}
function isContextProvider(object) {
  return typeOf(object) === REACT_PROVIDER_TYPE;
}
function isElement(object) {
  return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}
function isForwardRef(object) {
  return typeOf(object) === REACT_FORWARD_REF_TYPE;
}
function isFragment(object) {
  return typeOf(object) === REACT_FRAGMENT_TYPE;
}
function isLazy(object) {
  return typeOf(object) === REACT_LAZY_TYPE;
}
function isMemo(object) {
  return typeOf(object) === REACT_MEMO_TYPE;
}
function isPortal(object) {
  return typeOf(object) === REACT_PORTAL_TYPE;
}
function isProfiler(object) {
  return typeOf(object) === REACT_PROFILER_TYPE;
}
function isStrictMode(object) {
  return typeOf(object) === REACT_STRICT_MODE_TYPE;
}
function isSuspense(object) {
  return typeOf(object) === REACT_SUSPENSE_TYPE;
}

exports.ContextConsumer = ContextConsumer;
exports.ContextProvider = ContextProvider;
exports.Element = Element;
exports.ForwardRef = ForwardRef;
exports.Fragment = Fragment;
exports.Lazy = Lazy;
exports.Memo = Memo;
exports.Portal = Portal;
exports.Profiler = Profiler;
exports.StrictMode = StrictMode;
exports.Suspense = Suspense;
exports.isAsyncMode = isAsyncMode;
exports.isConcurrentMode = isConcurrentMode;
exports.isContextConsumer = isContextConsumer;
exports.isContextProvider = isContextProvider;
exports.isElement = isElement;
exports.isForwardRef = isForwardRef;
exports.isFragment = isFragment;
exports.isLazy = isLazy;
exports.isMemo = isMemo;
exports.isPortal = isPortal;
exports.isProfiler = isProfiler;
exports.isStrictMode = isStrictMode;
exports.isSuspense = isSuspense;
exports.isValidElementType = isValidElementType;
exports.typeOf = typeOf;
  })();
}


/***/ }),

/***/ "../node_modules/next/node_modules/react-is/index.js":
/*!***********************************************************!*\
  !*** ../node_modules/next/node_modules/react-is/index.js ***!
  \***********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/react-is.development.js */ "../node_modules/next/node_modules/react-is/cjs/react-is.development.js");
}


/***/ }),

/***/ "@contentful/rich-text-react-renderer":
/*!*******************************************************!*\
  !*** external "@contentful/rich-text-react-renderer" ***!
  \*******************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("@contentful/rich-text-react-renderer");;

/***/ }),

/***/ "@headlessui/react":
/*!************************************!*\
  !*** external "@headlessui/react" ***!
  \************************************/
/***/ (function(module) {

"use strict";
module.exports = require("@headlessui/react");;

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ (function(module) {

"use strict";
module.exports = require("classnames");;

/***/ }),

/***/ "contentful":
/*!*****************************!*\
  !*** external "contentful" ***!
  \*****************************/
/***/ (function(module) {

"use strict";
module.exports = require("contentful");;

/***/ }),

/***/ "js-cookie":
/*!****************************!*\
  !*** external "js-cookie" ***!
  \****************************/
/***/ (function(module) {

"use strict";
module.exports = require("js-cookie");;

/***/ }),

/***/ "../next-server/lib/head":
/*!****************************************************!*\
  !*** external "next/dist/next-server/lib/head.js" ***!
  \****************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ "../next-server/lib/router-context":
/*!**************************************************************!*\
  !*** external "next/dist/next-server/lib/router-context.js" ***!
  \**************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ "../next-server/lib/router/utils/get-asset-path-from-route":
/*!**************************************************************************************!*\
  !*** external "next/dist/next-server/lib/router/utils/get-asset-path-from-route.js" ***!
  \**************************************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ "../next-server/lib/to-base-64":
/*!**********************************************************!*\
  !*** external "next/dist/next-server/lib/to-base-64.js" ***!
  \**********************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ "../next-server/server/image-config":
/*!***************************************************************!*\
  !*** external "next/dist/next-server/server/image-config.js" ***!
  \***************************************************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ (function(module) {

"use strict";
module.exports = require("next/router");;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-dev-runtime");;

/***/ }),

/***/ "?9d88":
/*!******************************************!*\
  !*** ./utils/resolve-rewrites (ignored) ***!
  \******************************************/
/***/ (function() {

/* (ignored) */

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvY29yZS9CdXR0b24udHN4Iiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4vY29tcG9uZW50cy9sYW5kaW5nL0NUQUJ1dHRvbi50c3giLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi9jb21wb25lbnRzL2xhbmRpbmcvRW1lcmdlbmN5QmFyLnRzeCIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvbGFuZGluZy9GQVEudHN4Iiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4vY29tcG9uZW50cy9sYW5kaW5nL0ZBUUl0ZW0udHN4Iiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4vY29tcG9uZW50cy9sYW5kaW5nL0Zvb3Rlci50c3giLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi9jb21wb25lbnRzL2xhbmRpbmcvSGVhZGVyLnRzeCIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvbGFuZGluZy9MYW5kaW5nVGVtcGxhdGUudHN4Iiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4vY29tcG9uZW50cy9sYW5kaW5nL0xlZ2l0c2NyaXB0U2VhbC50c3giLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi9jb21wb25lbnRzL2xhbmRpbmcvTG9nby50c3giLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi9jb21wb25lbnRzL2xhbmRpbmcvTWVkaWNhbFRlYW0udHN4Iiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4vY29tcG9uZW50cy9sYW5kaW5nL05ld0NhcmVQcm9jZXNzLnRzeCIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvbGFuZGluZy9QcmljaW5nLnRzeCIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvbGFuZGluZy9TZWN0aW9uLnRzeCIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvbGFuZGluZy9TaGFycFN0YXJzLnRzeCIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvbGFuZGluZy9UZXN0aW1vbmlhbHMudHN4Iiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4vY29tcG9uZW50cy9sYW5kaW5nL1doYXRXZVRyZWF0LnRzeCIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvc3ZnL1NvY2lhbE1lZGlhL0ZhY2Vib29rLnRzeCIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2NvbXBvbmVudHMvc3ZnL1NvY2lhbE1lZGlhL0luc3RhZ3JhbS50c3giLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi9jb21wb25lbnRzL3N2Zy9Tb2NpYWxNZWRpYS9MaW5rZWRJbi50c3giLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi9jb250ZXh0L0FwcENvbnRleHQudHN4Iiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4vbGliL2FwaS50cyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2xpYi9ob29rcy9vZmZlci50cyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uL2xpYi9ob29rcy91dG0udHMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi9saWIvdXRpbC50c3giLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi9wYWdlcy9pbmRleC50c3giLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvaW1hZ2UuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvbGluay5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9ub3JtYWxpemUtdHJhaWxpbmctc2xhc2guanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvcmVxdWVzdC1pZGxlLWNhbGxiYWNrLmpzIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3JvdXRlLWxvYWRlci5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9yb3V0ZXIuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9jbGllbnQvdXNlLWludGVyc2VjdGlvbi5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC93aXRoLXJvdXRlci5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9pMThuL25vcm1hbGl6ZS1sb2NhbGUtcGF0aC5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9taXR0LmpzIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci9yb3V0ZXIuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL2Zvcm1hdC11cmwuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL2lzLWR5bmFtaWMuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL3BhcnNlLXJlbGF0aXZlLXVybC5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcXVlcnlzdHJpbmcuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL3JvdXRlLW1hdGNoZXIuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL3JvdXRlLXJlZ2V4LmpzIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3V0aWxzLmpzIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvc2VydmVyL2Rlbm9ybWFsaXplLXBhZ2UtcGF0aC5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9pbWFnZS5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9saW5rLmpzIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4uL25vZGVfbW9kdWxlcy9uZXh0L25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2V4dGVuZHMuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0LmpzIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kLy4uL25vZGVfbW9kdWxlcy9uZXh0L25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlV2lsZGNhcmQuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZS5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy90eXBlb2YuanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvLi4vbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL3JlYWN0LWlzL2Nqcy9yZWFjdC1pcy5kZXZlbG9wbWVudC5qcyIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC8uLi9ub2RlX21vZHVsZXMvbmV4dC9ub2RlX21vZHVsZXMvcmVhY3QtaXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvZXh0ZXJuYWwgXCJAY29udGVudGZ1bC9yaWNoLXRleHQtcmVhY3QtcmVuZGVyZXJcIiIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC9leHRlcm5hbCBcIkBoZWFkbGVzc3VpL3JlYWN0XCIiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvZXh0ZXJuYWwgXCJjbGFzc25hbWVzXCIiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvZXh0ZXJuYWwgXCJjb250ZW50ZnVsXCIiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvZXh0ZXJuYWwgXCJqcy1jb29raWVcIiIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC9leHRlcm5hbCBcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvaGVhZC5qc1wiIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9yb3V0ZXItY29udGV4dC5qc1wiIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvZ2V0LWFzc2V0LXBhdGgtZnJvbS1yb3V0ZS5qc1wiIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0LmpzXCIiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvZXh0ZXJuYWwgXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvc2VydmVyL2ltYWdlLWNvbmZpZy5qc1wiIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kL2V4dGVybmFsIFwibmV4dC9oZWFkXCIiLCJ3ZWJwYWNrOi8vQGhlYWx0aGdlbnQvZnJvbnRlbmQvZXh0ZXJuYWwgXCJuZXh0L3JvdXRlclwiIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly9AaGVhbHRoZ2VudC9mcm9udGVuZC9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovL0BoZWFsdGhnZW50L2Zyb250ZW5kL2lnbm9yZWR8RjpcXE5leHRqcy1Qcm9qZWN0c1xcaGVhbHRoZ2VudFxcbm9kZV9tb2R1bGVzXFxuZXh0XFxkaXN0XFxuZXh0LXNlcnZlclxcbGliXFxyb3V0ZXJ8Li91dGlscy9yZXNvbHZlLXJld3JpdGVzIl0sIm5hbWVzIjpbIkJ1dHRvbiIsIlJlYWN0IiwicHJvcHMiLCJyZWYiLCJhc0xpbmsiLCJjaGlsZHJlbiIsImJ1dHRvblR5cGUiLCJjbGFzc05hbWUiLCJkaXNhYmxlZCIsImhpZGRlbiIsIm91dGxpbmUiLCJwcm9jZXNzaW5nIiwib3RoZXJQcm9wcyIsImJ1dHRvbkNsYXNzIiwiY3giLCJmbGV4IiwiQ1RBQnV0dG9uIiwiRW1lcmdlbmN5QmFyIiwiRkFRIiwiZmFxIiwidGl0bGUiLCJzaG93QnV0dG9uIiwic3RhdGVzIiwic2V0U3RhdGVzIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJnZXRTdGF0ZXMiLCJ0aGVuIiwic3RhdGVMaXN0IiwibWFwIiwicyIsIm5hbWUiLCJzdGF0ZUVuZGluZyIsInNsaWNlIiwiam9pbiIsImxlbmd0aCIsImZpZWxkcyIsImluZGV4IiwicXVlc3Rpb24iLCJkb2N1bWVudFRvUmVhY3RDb21wb25lbnRzIiwiZmFxYW5zd2VyIiwiRkFRSXRlbSIsIm9wZW4iLCJzZXRPcGVuIiwiU29jaWFsTWVkaWFMaW5rIiwiaHJlZiIsIkZvb3Rlckl0ZW0iLCJleHRlcm5hbCIsImxpbmsiLCJ1bmRlZmluZWQiLCJGb290ZXIiLCJIZWFkZXIiLCJzdGFydE9mZmVyIiwic3RhcnRDb2xvciIsImhpZGVNZW51Iiwic2hvd09mZmVyIiwic2V0U2hvd09mZmVyIiwic2hvd1NpZGViYXIiLCJzZXRTaG93U2lkZWJhciIsImlzVG9wIiwic2V0SXNUb3AiLCJvblNjcm9sbCIsIndpbmRvdyIsInBhZ2VZT2Zmc2V0IiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJ0b2dnbGVDbG9zZSIsIkxhbmRpbmdUZW1wbGF0ZSIsImRhdGEiLCJjb25zb2xlIiwibG9nIiwicGFnZSIsImNhcmVQcm9jZXNzSGVhZGluZyIsImNhcmVQcm9jZXNzIiwidGVzdGltb25pYWxzSGVhZGluZyIsInRlc3RpbW9uaWFscyIsInVzZVV0bSIsIm9mZmVyVGV4dCIsInVzZU9mZmVyIiwicmlnaHQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJMZWdpdHNjcmlwdFNlYWwiLCJMb2dvIiwiUHJhY3RpdGlvbmVyQ2FyZCIsImltYWdlVXJsIiwiTWVkaWNhbFRlYW0iLCJTdGVwTnVtYmVyIiwiTGluZSIsIndpZHRoIiwiTmV3Q2FyZVByb2Nlc3MiLCJoZWFkaW5nIiwiY2FyZVByb2Nlc3NOYW1lIiwiY2FyZVByb2Nlc3NEZXNjcmlwdGlvbiIsIkNoZWNrbWFyayIsIlByaWNpbmciLCJ0b3AiLCJib3R0b20iLCJTZWN0aW9uIiwibm9QYWRkaW5nIiwiY29tYmluZWRDbGFzcyIsIlNoYXJwU3RhcnMiLCJUZXN0aW1vbmlhbCIsInN0eWxlIiwiVGVzdGltb25pYWxzIiwiVHJlYXRtZW50SXRlbSIsIldoYXRXZVRyZWF0IiwiRmFjZWJvb2siLCJJbnN0YWdyYW0iLCJMaW5rZWRJbiIsIkFwcENvbnRleHQiLCJjcmVhdGVDb250ZXh0IiwiQXBwQ29udGV4dFByb3ZpZGVyIiwic2VsZWN0ZWRUaW1lU2xvdCIsInNldFNlbGVjdGVkVGltZVNsb3QiLCJlbWFpbCIsInNldEVtYWlsIiwicmVzaWRlbmNlU3RhdGUiLCJzZXRSZXNpZGVuY2VTdGF0ZSIsImRpc2NvdW50Q29kZSIsInNldERpc2NvdW50Q29kZSIsImludGFrZUlkIiwic2V0SW50YWtlSWQiLCJmaXJzdE5hbWUiLCJzZXRGaXJzdE5hbWUiLCJsYXN0TmFtZSIsInNldExhc3ROYW1lIiwicGhvbmUiLCJzZXRQaG9uZSIsInppcENvZGUiLCJzZXRaaXBDb2RlIiwiY3VycmVudFF1ZXN0aW9uSWR4Iiwic2V0Q3VycmVudFF1ZXN0aW9uSWR4IiwiYW5zd2VycyIsInNldEFuc3dlcnMiLCJiaXJ0aGRhdGUiLCJzZXRCaXJ0aGRhdGUiLCJEYXRlIiwibm90aWZpY2F0aW9uIiwic2V0Tm90aWZpY2F0aW9uIiwiZXJyb3IiLCJzZXRFcnJvciIsImluaXRpYWxQYXJhbXMiLCJzZXRJbml0aWFsUGFyYW1zIiwiYm9va2luZ0NvbnRleHQiLCJzZXRCb29raW5nQ29udGV4dCIsInNsb3RJZCIsInNsb3REYXRlIiwic3RhdGUiLCJvbmJvYXJkaW5nIiwiYm9va2luZyIsInVzZUFwcENvbnRleHQiLCJ1c2VDb250ZXh0IiwiZ2V0VXJsIiwiZW5kcG9pbnQiLCJsb2NhdGlvbiIsImluZGV4T2YiLCJiYXNlVXJsIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19IR19CQVNFX0FQSV9VUkwiLCJBVVRIX1RPS0VOX0tFWSIsIkFwaUVycm9yIiwiRXJyb3IiLCJjb25zdHJ1Y3RvciIsIm1lc3NhZ2UiLCJzdGF0dXNDb2RlIiwiYXBpRmV0Y2giLCJtZXRob2QiLCJ1cmwiLCJib2R5IiwidG9rZW4iLCJDb29raWVzIiwiaGVhZGVycyIsIkF1dGhvcml6YXRpb24iLCJyZXNwb25zZSIsImZldGNoIiwiSlNPTiIsInN0cmluZ2lmeSIsImpzb24iLCJvayIsInN0YXR1c1RleHQiLCJzdGF0dXMiLCJmaWxlVXBsb2FkIiwiZ2V0IiwicGFyYW1zIiwicGFyYW1TdHJpbmciLCJVUkxTZWFyY2hQYXJhbXMiLCJ0b1N0cmluZyIsInBvc3QiLCJyZXF1ZXN0IiwiciIsInNvcnQiLCJhIiwiYiIsImxvY2FsZUNvbXBhcmUiLCJyZWdpc3RlciIsInJlZ2lzdHJhdGlvbiIsImNvbnNlbnQiLCJzdWJtaXRRdWl6IiwicXVpeiIsImlkIiwic3VibWl0Q2hlY2tpbiIsInJlc3BvbnNlcyIsImdldFByb2dyZXNzSGlzdG9yeSIsImhpc3RvcnlUeXBlIiwiY2hlY2tTdGF0ZSIsImF2YWlsYWJsZSIsImNoZWNrWmlwIiwiemlwIiwiam9pbldhaXRsaXN0IiwiZ2V0QXZhaWxhYmlsaXR5IiwiZ2V0U3RyaXBlQ2xpZW50U2VjcmV0IiwicHJvbW90aW9uQ29kZSIsImNsaWVudFNlY3JldCIsImNvbmZpcm1QYXltZW50IiwicGF5bWVudEludGVudElkIiwidXBkYXRlUGF5bWVudE1ldGhvZCIsInBheW1lbnRNZXRob2RJZCIsImxvZ2luIiwicGFzc3dvcmQiLCJzdXBlcnVzZXIiLCJsb2dpbkFzIiwiYm9va0FwcG9pbnRtZW50IiwiZ2V0VXBjb21pbmdBcHBvaW50bWVudCIsImdldFByZXZpb3VzQXBwb2ludG1lbnRzIiwicHJldmlvdXNBcHBvaW50bWVudHMiLCJnZXRQcm9maWxlIiwidXBkYXRlRW1haWwiLCJ1cGRhdGVBZGRyZXNzIiwiYWRkcmVzcyIsImlzT25ib2FyZGluZyIsInVwZGF0ZVBob25lIiwidXBkYXRlRG9iIiwiZGF0ZSIsIm5vcm1hbGl6ZURhdGVUb1VUQyIsInVwZGF0ZUVtZXJnZW5jeUNvbnRhY3QiLCJmb3Jnb3RQYXNzd29yZCIsInJlc2V0UGFzc3dvcmQiLCJjaGVja0ludGFrZSIsImdldE9uYm9hcmRpbmdTdGF0dXMiLCJ2ZXJpZnlJZCIsImlucXVpcnlJZCIsImNyZWF0ZU5ld1RocmVhZCIsImdldFRocmVhZCIsInRocmVhZElkIiwicG9zdE1lc3NhZ2UiLCJjb250ZW50IiwiZ2V0SW5ib3giLCJnZXRVbnJlYWRNZXNzYWdlQ291bnQiLCJ1bnJlYWRNZXNzYWdlcyIsInN1Ym1pdE1lZGljYWxJbnRha2UiLCJzdWJtaXRSZWZlcnJhbCIsInJlZmVycmFsIiwiZ2V0UmVmZXJyYWxDb2RlIiwiY29kZSIsInN1Ym1pdFN0YXJ0SW50YWtlIiwiZ2V0UHJlc2NyaXB0aW9ucyIsInByZXNjcmlwdGlvbnMiLCJnZXRWaWRlb1Rva2VuIiwiaWRlbnRpdHkiLCJnZXRQaGFybWFjaWVzIiwicGhhcm1hY2llcyIsInNldFBoYXJtYWN5IiwicGhhcm1hY3lJZCIsImdldFBoYXJtYWN5IiwiYWRkUHJpbWFyeUNhcmVQaHlzaWNpYW5JbmZvIiwiYWxsb3dTaGFyaW5nIiwiYWRkRXh0ZXJuYWxUaGVyYXBpc3RJbmZvIiwibWFya09uYm9hcmRpbmdDb21wbGV0ZSIsInJvdXRlciIsInVzZVJvdXRlciIsIk9iamVjdCIsImtleXMiLCJxdWVyeSIsIm9mZmVyIiwidXRtU291cmNlIiwicmVmZXJyYWxDb2RlIiwidXRtX3NvdXJjZSIsInV0bV9tZWRpdW0iLCJ1dG1fY2FtcGFpZ24iLCJ1dG1fY29udGVudCIsInV0bV90ZXJtIiwidGVybSIsInV0bU1lZGl1bSIsInV0bUNhbXBhaWduIiwidXRtQ29udGVudCIsInV0bVRlcm0iLCJyYXdVcmwiLCJhc1BhdGgiLCJlbWFpbElzVmFsaWQiLCJ0ZXN0IiwiZ2V0T3JkaW5hbE51bSIsIm4iLCJkYXRlVG9UaW1lU3RyaW5nIiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiaG91ciIsImhvdXIxMiIsIm1pbnV0ZSIsImRheVdpdGhPcmRpbmFsIiwiZ2V0RGF0ZSIsImdldERheU5hbWUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJ3ZWVrZGF5IiwiZ2V0TW9udGhOYW1lIiwidG9Mb2NhbGVTdHJpbmciLCJtb250aCIsImZvcm1hdFBob25lTnVtYmVyIiwicmVwbGFjZSIsImNhcGl0YWxpemUiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInRyaW0iLCJnZXRUaW1lem9uZUFiYnJldmlhdGlvbiIsInRpbWVab25lTmFtZSIsInNwbGl0IiwiZ2V0VGltZXpvbmVOYW1lIiwiSW50bCIsIkRhdGVUaW1lRm9ybWF0IiwicmVzb2x2ZWRPcHRpb25zIiwidGltZVpvbmUiLCJ1dGNEYXRlIiwiVVRDIiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldFVUQ0RhdGUiLCJ0b0lTT1N0cmluZyIsImNsaWVudCIsImNyZWF0ZUNsaWVudCIsInNwYWNlIiwiQ09OVEVOVEZVTF9TUEFDRV9JRCIsImFjY2Vzc1Rva2VuIiwiQ09OVEVOVEZVTF9BQ0NFU1NfS0VZIiwiSG9tZUluZGV4IiwiZ2V0U3RhdGljUHJvcHMiLCJyZXMiLCJnZXRFbnRyaWVzIiwiY29udGVudF90eXBlIiwib3JkZXIiLCJpdGVtcyIsInJldmFsaWRhdGUiLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwicmVxdWlyZSIsImV4cG9ydHMiLCJJbWFnZSIsIl9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlMiIsIl9leHRlbmRzMiIsIl9yZWFjdCIsIl9oZWFkIiwiX3RvQmFzZSIsIl9pbWFnZUNvbmZpZyIsIl91c2VJbnRlcnNlY3Rpb24iLCJnbG9iYWwiLCJfX05FWFRfSU1BR0VfSU1QT1JURUQiLCJWQUxJRF9MT0FESU5HX1ZBTFVFUyIsImxvYWRlcnMiLCJNYXAiLCJpbWdpeExvYWRlciIsImNsb3VkaW5hcnlMb2FkZXIiLCJha2FtYWlMb2FkZXIiLCJkZWZhdWx0TG9hZGVyIiwiVkFMSURfTEFZT1VUX1ZBTFVFUyIsImlzU3RhdGljUmVxdWlyZSIsInNyYyIsImRlZmF1bHQiLCJpc1N0YXRpY0ltYWdlRGF0YSIsImlzU3RhdGljSW1wb3J0IiwiZGV2aWNlU2l6ZXMiLCJjb25maWdEZXZpY2VTaXplcyIsImltYWdlU2l6ZXMiLCJjb25maWdJbWFnZVNpemVzIiwibG9hZGVyIiwiY29uZmlnTG9hZGVyIiwicGF0aCIsImNvbmZpZ1BhdGgiLCJkb21haW5zIiwiY29uZmlnRG9tYWlucyIsImltYWdlQ29uZmlnRGVmYXVsdCIsImFsbFNpemVzIiwiZ2V0V2lkdGhzIiwibGF5b3V0Iiwic2l6ZXMiLCJ2aWV3cG9ydFdpZHRoUmUiLCJwZXJjZW50U2l6ZXMiLCJtYXRjaCIsImV4ZWMiLCJwdXNoIiwicGFyc2VJbnQiLCJzbWFsbGVzdFJhdGlvIiwiTWF0aCIsIm1pbiIsIndpZHRocyIsImZpbHRlciIsImtpbmQiLCJTZXQiLCJ3IiwiZmluZCIsInAiLCJnZW5lcmF0ZUltZ0F0dHJzIiwidW5vcHRpbWl6ZWQiLCJxdWFsaXR5Iiwic3JjU2V0IiwibGFzdCIsImkiLCJnZXRJbnQiLCJ4IiwiZGVmYXVsdEltYWdlTG9hZGVyIiwibG9hZGVyUHJvcHMiLCJsb2FkIiwicm9vdCIsIlZBTElEX0xPQURFUlMiLCJyZW1vdmVQbGFjZWhvbGRlciIsImltZyIsInBsYWNlaG9sZGVyIiwiaGFuZGxlTG9hZCIsInN0YXJ0c1dpdGgiLCJkZWNvZGUiLCJQcm9taXNlIiwicmVzb2x2ZSIsImNhdGNoIiwiYmFja2dyb3VuZFNpemUiLCJiYWNrZ3JvdW5kSW1hZ2UiLCJjb21wbGV0ZSIsIm9ubG9hZCIsIl9yZWYiLCJwcmlvcml0eSIsImxvYWRpbmciLCJoZWlnaHQiLCJvYmplY3RGaXQiLCJvYmplY3RQb3NpdGlvbiIsImJsdXJEYXRhVVJMIiwiYWxsIiwicmVzdCIsInN0YXRpY1NyYyIsInN0YXRpY0ltYWdlRGF0YSIsIndpZHRoSW50IiwiaGVpZ2h0SW50IiwicXVhbGl0eUludCIsImluY2x1ZGVzIiwiU3RyaW5nIiwid2FybiIsIlZBTElEX0JMVVJfRVhUIiwiaXNMYXp5Iiwic2V0UmVmIiwiaXNJbnRlcnNlY3RlZCIsInVzZUludGVyc2VjdGlvbiIsInJvb3RNYXJnaW4iLCJpc1Zpc2libGUiLCJ3cmFwcGVyU3R5bGUiLCJzaXplclN0eWxlIiwic2l6ZXJTdmciLCJpbWdTdHlsZSIsInBvc2l0aW9uIiwibGVmdCIsImJveFNpemluZyIsInBhZGRpbmciLCJib3JkZXIiLCJtYXJnaW4iLCJkaXNwbGF5IiwibWluV2lkdGgiLCJtYXhXaWR0aCIsIm1pbkhlaWdodCIsIm1heEhlaWdodCIsInF1b3RpZW50IiwicGFkZGluZ1RvcCIsImlzTmFOIiwib3ZlcmZsb3ciLCJpbWdBdHRyaWJ1dGVzIiwiY3JlYXRlRWxlbWVudCIsImFsdCIsInJvbGUiLCJ0b0Jhc2U2NCIsImFzc2lnbiIsImRlY29kaW5nIiwiZWxlbWVudCIsImtleSIsInJlbCIsImFzIiwiaW1hZ2VzcmNzZXQiLCJpbWFnZXNpemVzIiwibm9ybWFsaXplU3JjIiwicGFyYW1zU3RyaW5nIiwibWlzc2luZ1ZhbHVlcyIsInBhcnNlZFNyYyIsIlVSTCIsImVyciIsImhvc3RuYW1lIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwiX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQiLCJfcm91dGVyIiwiX3JvdXRlcjIiLCJwcmVmZXRjaGVkIiwicHJlZmV0Y2giLCJvcHRpb25zIiwiaXNMb2NhbFVSTCIsImN1ckxvY2FsZSIsImxvY2FsZSIsImlzTW9kaWZpZWRFdmVudCIsImV2ZW50IiwidGFyZ2V0IiwiY3VycmVudFRhcmdldCIsIm1ldGFLZXkiLCJjdHJsS2V5Iiwic2hpZnRLZXkiLCJhbHRLZXkiLCJuYXRpdmVFdmVudCIsIndoaWNoIiwibGlua0NsaWNrZWQiLCJlIiwic2hhbGxvdyIsInNjcm9sbCIsIm5vZGVOYW1lIiwicHJldmVudERlZmF1bHQiLCJMaW5rIiwiY3JlYXRlUHJvcEVycm9yIiwiYXJncyIsImV4cGVjdGVkIiwiYWN0dWFsIiwicmVxdWlyZWRQcm9wc0d1YXJkIiwicmVxdWlyZWRQcm9wcyIsImZvckVhY2giLCJfIiwib3B0aW9uYWxQcm9wc0d1YXJkIiwicGFzc0hyZWYiLCJvcHRpb25hbFByb3BzIiwidmFsVHlwZSIsImhhc1dhcm5lZCIsInVzZVJlZiIsImN1cnJlbnQiLCJ1c2VNZW1vIiwicmVzb2x2ZWRIcmVmIiwicmVzb2x2ZWRBcyIsInJlc29sdmVIcmVmIiwiY2hpbGQiLCJDaGlsZHJlbiIsIm9ubHkiLCJjaGlsZFJlZiIsInNldEludGVyc2VjdGlvblJlZiIsInVzZUNhbGxiYWNrIiwiZWwiLCJzaG91bGRQcmVmZXRjaCIsImlzUHJlZmV0Y2hlZCIsImNoaWxkUHJvcHMiLCJvbkNsaWNrIiwiZGVmYXVsdFByZXZlbnRlZCIsIm9uTW91c2VFbnRlciIsInR5cGUiLCJsb2NhbGVEb21haW4iLCJpc0xvY2FsZURvbWFpbiIsImdldERvbWFpbkxvY2FsZSIsImxvY2FsZXMiLCJkb21haW5Mb2NhbGVzIiwiYWRkQmFzZVBhdGgiLCJhZGRMb2NhbGUiLCJkZWZhdWx0TG9jYWxlIiwiY2xvbmVFbGVtZW50IiwiX2RlZmF1bHQiLCJyZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCIsImVuZHNXaXRoIiwibm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2giLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwic2VsZiIsImNiIiwic3RhcnQiLCJub3ciLCJzZXRUaW1lb3V0IiwiZGlkVGltZW91dCIsInRpbWVSZW1haW5pbmciLCJtYXgiLCJjYW5jZWxJZGxlQ2FsbGJhY2siLCJjbGVhclRpbWVvdXQiLCJtYXJrQXNzZXRFcnJvciIsImlzQXNzZXRFcnJvciIsImdldENsaWVudEJ1aWxkTWFuaWZlc3QiLCJfZ2V0QXNzZXRQYXRoRnJvbVJvdXRlIiwiX3JlcXVlc3RJZGxlQ2FsbGJhY2siLCJNU19NQVhfSURMRV9ERUxBWSIsIndpdGhGdXR1cmUiLCJnZW5lcmF0b3IiLCJlbnRyeSIsImZ1dHVyZSIsInJlc29sdmVyIiwicHJvbSIsInNldCIsInZhbHVlIiwiaGFzUHJlZmV0Y2giLCJkb2N1bWVudCIsIk1TSW5wdXRNZXRob2RDb250ZXh0IiwiZG9jdW1lbnRNb2RlIiwicmVsTGlzdCIsInN1cHBvcnRzIiwiX3VudXNlZCIsImNhblByZWZldGNoIiwicHJlZmV0Y2hWaWFEb20iLCJyZWoiLCJxdWVyeVNlbGVjdG9yIiwiY3Jvc3NPcmlnaW4iLCJvbmVycm9yIiwiaGVhZCIsImFwcGVuZENoaWxkIiwiQVNTRVRfTE9BRF9FUlJPUiIsIlN5bWJvbCIsImRlZmluZVByb3BlcnR5IiwiYXBwZW5kU2NyaXB0Iiwic2NyaXB0IiwicmVqZWN0IiwicmVzb2x2ZVByb21pc2VXaXRoVGltZW91dCIsIm1zIiwiY2FuY2VsbGVkIiwiX19CVUlMRF9NQU5JRkVTVCIsIm9uQnVpbGRNYW5pZmVzdCIsIl9fQlVJTERfTUFOSUZFU1RfQ0IiLCJnZXRGaWxlc0ZvclJvdXRlIiwiYXNzZXRQcmVmaXgiLCJyb3V0ZSIsInNjcmlwdHMiLCJlbmNvZGVVUkkiLCJjc3MiLCJtYW5pZmVzdCIsImFsbEZpbGVzIiwidiIsImNyZWF0ZVJvdXRlTG9hZGVyIiwiZW50cnlwb2ludHMiLCJsb2FkZWRTY3JpcHRzIiwic3R5bGVTaGVldHMiLCJyb3V0ZXMiLCJtYXliZUV4ZWN1dGVTY3JpcHQiLCJmZXRjaFN0eWxlU2hlZXQiLCJ0ZXh0Iiwid2hlbkVudHJ5cG9pbnQiLCJvbkVudHJ5cG9pbnQiLCJleGVjdXRlIiwiZm4iLCJjb21wb25lbnQiLCJpbnB1dCIsIm9sZCIsImxvYWRSb3V0ZSIsImhhcyIsImVudHJ5cG9pbnQiLCJzdHlsZXMiLCJjbiIsIm5hdmlnYXRvciIsImNvbm5lY3Rpb24iLCJzYXZlRGF0YSIsImVmZmVjdGl2ZVR5cGUiLCJvdXRwdXQiLCJtYWtlUHVibGljUm91dGVySW5zdGFuY2UiLCJOZXh0Um91dGVyIiwiX3JvdXRlckNvbnRleHQiLCJfd2l0aFJvdXRlciIsInNpbmdsZXRvblJvdXRlciIsInJlYWR5Q2FsbGJhY2tzIiwicmVhZHkiLCJ1cmxQcm9wZXJ0eUZpZWxkcyIsInJvdXRlckV2ZW50cyIsImNvcmVNZXRob2RGaWVsZHMiLCJldmVudHMiLCJmaWVsZCIsImdldFJvdXRlciIsIm9uIiwiZXZlbnRGaWVsZCIsInN1YnN0cmluZyIsIl9zaW5nbGV0b25Sb3V0ZXIiLCJzdGFjayIsIlJvdXRlckNvbnRleHQiLCJjcmVhdGVSb3V0ZXIiLCJpbnN0YW5jZSIsInByb3BlcnR5IiwiQXJyYXkiLCJpc0FycmF5IiwiaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIiLCJJbnRlcnNlY3Rpb25PYnNlcnZlciIsImlzRGlzYWJsZWQiLCJ1bm9ic2VydmUiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsInRhZ05hbWUiLCJvYnNlcnZlIiwiaWRsZUNhbGxiYWNrIiwiY2FsbGJhY2siLCJvYnNlcnZlciIsImVsZW1lbnRzIiwiY3JlYXRlT2JzZXJ2ZXIiLCJkZWxldGUiLCJzaXplIiwiZGlzY29ubmVjdCIsIm9ic2VydmVycyIsImVudHJpZXMiLCJpc0ludGVyc2VjdGluZyIsImludGVyc2VjdGlvblJhdGlvIiwid2l0aFJvdXRlciIsIkNvbXBvc2VkQ29tcG9uZW50IiwiV2l0aFJvdXRlcldyYXBwZXIiLCJnZXRJbml0aWFsUHJvcHMiLCJvcmlnR2V0SW5pdGlhbFByb3BzIiwiZGlzcGxheU5hbWUiLCJub3JtYWxpemVMb2NhbGVQYXRoIiwicGF0aG5hbWUiLCJkZXRlY3RlZExvY2FsZSIsInBhdGhuYW1lUGFydHMiLCJzb21lIiwidG9Mb3dlckNhc2UiLCJzcGxpY2UiLCJtaXR0IiwiY3JlYXRlIiwiaGFuZGxlciIsIm9mZiIsImVtaXQiLCJldnRzIiwiZGVsTG9jYWxlIiwiaGFzQmFzZVBhdGgiLCJkZWxCYXNlUGF0aCIsImludGVycG9sYXRlQXMiLCJfbm9ybWFsaXplVHJhaWxpbmdTbGFzaCIsIl9yb3V0ZUxvYWRlciIsIl9kZW5vcm1hbGl6ZVBhZ2VQYXRoIiwiX25vcm1hbGl6ZUxvY2FsZVBhdGgiLCJfbWl0dCIsIl91dGlscyIsIl9pc0R5bmFtaWMiLCJfcGFyc2VSZWxhdGl2ZVVybCIsIl9xdWVyeXN0cmluZyIsIl9yZXNvbHZlUmV3cml0ZXMiLCJfcm91dGVNYXRjaGVyIiwiX3JvdXRlUmVnZXgiLCJvYmoiLCJfX2VzTW9kdWxlIiwiZGV0ZWN0RG9tYWluTG9jYWxlIiwiYmFzZVBhdGgiLCJidWlsZENhbmNlbGxhdGlvbkVycm9yIiwiYWRkUGF0aFByZWZpeCIsInByZWZpeCIsInBhdGhOb1F1ZXJ5SGFzaCIsInF1ZXJ5SW5kZXgiLCJoYXNoSW5kZXgiLCJsb2NhdGlvbk9yaWdpbiIsImdldExvY2F0aW9uT3JpZ2luIiwicmVzb2x2ZWQiLCJvcmlnaW4iLCJhc1BhdGhuYW1lIiwiaW50ZXJwb2xhdGVkUm91dGUiLCJkeW5hbWljUmVnZXgiLCJnZXRSb3V0ZVJlZ2V4IiwiZHluYW1pY0dyb3VwcyIsImdyb3VwcyIsImR5bmFtaWNNYXRjaGVzIiwiZ2V0Um91dGVNYXRjaGVyIiwiZXZlcnkiLCJwYXJhbSIsInJlcGVhdCIsIm9wdGlvbmFsIiwicmVwbGFjZWQiLCJzZWdtZW50IiwicmVzdWx0Iiwib21pdFBhcm1zRnJvbVF1ZXJ5IiwiZmlsdGVyZWRRdWVyeSIsInJlc29sdmVBcyIsImJhc2UiLCJ1cmxBc1N0cmluZyIsImZvcm1hdFdpdGhWYWxpZGF0aW9uIiwiZmluYWxVcmwiLCJpbnRlcnBvbGF0ZWRBcyIsImlzRHluYW1pY1JvdXRlIiwic2VhcmNoUGFyYW1zIiwic2VhcmNoUGFyYW1zVG9VcmxRdWVyeSIsImhhc2giLCJzdHJpcE9yaWdpbiIsInByZXBhcmVVcmxBcyIsImhyZWZIYWRPcmlnaW4iLCJhc0hhZE9yaWdpbiIsInByZXBhcmVkVXJsIiwicHJlcGFyZWRBcyIsInJlc29sdmVEeW5hbWljUm91dGUiLCJwYWdlcyIsImNsZWFuUGF0aG5hbWUiLCJkZW5vcm1hbGl6ZVBhZ2VQYXRoIiwicmUiLCJtYW51YWxTY3JvbGxSZXN0b3JhdGlvbiIsIlNTR19EQVRBX05PVF9GT1VORCIsImZldGNoUmV0cnkiLCJhdHRlbXB0cyIsImNyZWRlbnRpYWxzIiwibm90Rm91bmQiLCJmZXRjaE5leHREYXRhIiwiZGF0YUhyZWYiLCJpc1NlcnZlclJlbmRlciIsIlJvdXRlciIsIl9wYXRobmFtZSIsIl9xdWVyeSIsIl9hcyIsImluaXRpYWxQcm9wcyIsInBhZ2VMb2FkZXIiLCJBcHAiLCJ3cmFwQXBwIiwiQ29tcG9uZW50Iiwic3Vic2NyaXB0aW9uIiwiaXNGYWxsYmFjayIsImlzUHJldmlldyIsImNvbXBvbmVudHMiLCJzZGMiLCJzZHIiLCJzdWIiLCJjbGMiLCJfYnBzIiwiX3dyYXBBcHAiLCJpc1NzciIsIl9pbkZsaWdodFJvdXRlIiwiX3NoYWxsb3ciLCJpc1JlYWR5IiwiX2lkeCIsIm9uUG9wU3RhdGUiLCJjaGFuZ2VTdGF0ZSIsImdldFVSTCIsIl9fTiIsImZvcmNlZFNjcm9sbCIsImlkeCIsInBhcnNlUmVsYXRpdmVVcmwiLCJjaGFuZ2UiLCJpbml0aWFsIiwiX19OX1NTRyIsIl9fTl9TU1AiLCJhdXRvRXhwb3J0RHluYW1pYyIsIl9fTkVYVF9EQVRBX18iLCJhdXRvRXhwb3J0IiwiZ3NzcCIsImdpcCIsInNlYXJjaCIsInJlbG9hZCIsImJhY2siLCJoaXN0b3J5Iiwic2hvdWxkUmVzb2x2ZUhyZWYiLCJfaCIsIl9zaG91bGRSZXNvbHZlSHJlZiIsImxvY2FsZUNoYW5nZSIsIlNUIiwicGVyZm9ybWFuY2UiLCJtYXJrIiwicm91dGVQcm9wcyIsImFib3J0Q29tcG9uZW50TG9hZCIsImNsZWFuZWRBcyIsIm9ubHlBSGFzaENoYW5nZSIsInNjcm9sbFRvSGFzaCIsIm5vdGlmeSIsInBhcnNlZCIsInJld3JpdGVzIiwiZ2V0UGFnZUxpc3QiLCJfX3Jld3JpdGVzIiwidXJsSXNOZXciLCJwYXJzZWRBcyIsInJvdXRlUmVnZXgiLCJyb3V0ZU1hdGNoIiwic2hvdWxkSW50ZXJwb2xhdGUiLCJtaXNzaW5nUGFyYW1zIiwiX3NlbGYkX19ORVhUX0RBVEFfXyRwIiwiX3NlbGYkX19ORVhUX0RBVEFfXyRwMiIsIl9vcHRpb25zJHNjcm9sbCIsInJvdXRlSW5mbyIsImdldFJvdXRlSW5mbyIsInBhZ2VQcm9wcyIsIl9fTl9SRURJUkVDVCIsImRlc3RpbmF0aW9uIiwicGFyc2VkSHJlZiIsIm5ld1VybCIsIm5ld0FzIiwiX19OX1BSRVZJRVciLCJub3RGb3VuZFJvdXRlIiwiZmV0Y2hDb21wb25lbnQiLCJhcHBDb21wIiwibmV4dCIsImlzUHJlcmVuZGVyZWQiLCJpc1ZhbGlkU2hhbGxvd1JvdXRlIiwic2hvdWxkU2Nyb2xsIiwicmVzZXRTY3JvbGwiLCJ5IiwiaGFuZGxlUm91dGVJbmZvRXJyb3IiLCJsb2FkRXJyb3JGYWlsIiwiZ2lwRXJyIiwicm91dGVJbmZvRXJyIiwiZXhpc3RpbmdSb3V0ZUluZm8iLCJjYWNoZWRSb3V0ZUluZm8iLCJtb2QiLCJpc1ZhbGlkRWxlbWVudFR5cGUiLCJnZXREYXRhSHJlZiIsIl9nZXREYXRhIiwiX2dldFN0YXRpY0RhdGEiLCJfZ2V0U2VydmVyRGF0YSIsImJlZm9yZVBvcFN0YXRlIiwib2xkVXJsTm9IYXNoIiwib2xkSGFzaCIsIm5ld1VybE5vSGFzaCIsIm5ld0hhc2giLCJzY3JvbGxUbyIsImlkRWwiLCJnZXRFbGVtZW50QnlJZCIsInNjcm9sbEludG9WaWV3IiwibmFtZUVsIiwiZ2V0RWxlbWVudHNCeU5hbWUiLCJfaXNTc2ciLCJpc1NzZyIsImNhbmNlbCIsImNvbXBvbmVudFJlc3VsdCIsImxvYWRQYWdlIiwiY2FjaGVLZXkiLCJyZXNvdXJjZUtleSIsImN0eCIsIkFwcFRyZWUiLCJsb2FkR2V0SW5pdGlhbFByb3BzIiwiZm9ybWF0VXJsIiwicXVlcnlzdHJpbmciLCJfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUiLCJXZWFrTWFwIiwiY2FjaGUiLCJuZXdPYmoiLCJoYXNQcm9wZXJ0eURlc2NyaXB0b3IiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJwcm90b3R5cGUiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJkZXNjIiwic2xhc2hlZFByb3RvY29scyIsInVybE9iaiIsImF1dGgiLCJwcm90b2NvbCIsImhvc3QiLCJwb3J0IiwidXJsUXVlcnlUb1NlYXJjaFBhcmFtcyIsInN1YnN0ciIsInNsYXNoZXMiLCJURVNUX1JPVVRFIiwiZ2xvYmFsQmFzZSIsInJlc29sdmVkQmFzZSIsInN0cmluZ2lmeVVybFF1ZXJ5UGFyYW0iLCJ1cmxRdWVyeSIsIml0ZW0iLCJhcHBlbmQiLCJzZWFyY2hQYXJhbXNMaXN0IiwiZnJvbSIsImRlY29kZVVSSUNvbXBvbmVudCIsInNsdWdOYW1lIiwiZyIsIm0iLCJwb3MiLCJlc2NhcGVSZWdleCIsInN0ciIsInBhcnNlUGFyYW1ldGVyIiwibm9ybWFsaXplZFJvdXRlIiwic2VnbWVudHMiLCJncm91cEluZGV4IiwicGFyYW1ldGVyaXplZFJvdXRlIiwicm91dGVLZXlDaGFyQ29kZSIsInJvdXRlS2V5Q2hhckxlbmd0aCIsImdldFNhZmVSb3V0ZUtleSIsInJvdXRlS2V5IiwiZnJvbUNoYXJDb2RlIiwicm91dGVLZXlzIiwibmFtZWRQYXJhbWV0ZXJpemVkUm91dGUiLCJjbGVhbmVkS2V5IiwiaW52YWxpZEtleSIsIlJlZ0V4cCIsIm5hbWVkUmVnZXgiLCJleGVjT25jZSIsImdldERpc3BsYXlOYW1lIiwiaXNSZXNTZW50IiwiX2Zvcm1hdFVybCIsInVzZWQiLCJmaW5pc2hlZCIsImhlYWRlcnNTZW50IiwiX0FwcCRwcm90b3R5cGUiLCJ1cmxPYmplY3RLZXlzIiwiU1AiLCJtZWFzdXJlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBOENBLE1BQU1BLE1BQU0sZ0JBQUdDLHVEQUFBLENBQW1DLENBQUNDLEtBQUQsRUFBUUMsR0FBUixLQUFnQjtBQUNoRSxRQUFNO0FBQ0pDLFVBREk7QUFFSkMsWUFGSTtBQUdKQyxjQUhJO0FBSUpDLGFBSkk7QUFLSkMsWUFMSTtBQU1KQyxVQU5JO0FBT0pDLFdBUEk7QUFRSkM7QUFSSSxNQVVGVCxLQVZKO0FBQUEsUUFTS1UsVUFUTCw0QkFVSVYsS0FWSjs7QUFXQSxRQUFNVyxXQUFXLEdBQUdDLGlEQUFFLENBQ3BCLGlDQURvQixFQUVwQix5Q0FGb0IsRUFHcEI7QUFDRUMsUUFBSSxFQUFFLENBQUNOLE1BRFQ7QUFFRUEsVUFBTSxFQUFFQSxNQUZWO0FBR0VELFlBQVEsRUFBRUEsUUFIWixDQUlFOztBQUpGLEdBSG9CLEVBU3BCLENBQUNFLE9BQUQsR0FDSTtBQUNBLGtGQUNFLENBQUNGLFFBQUQsSUFBYUYsVUFBVSxLQUFLLEtBRjlCO0FBR0EseUVBQ0csQ0FBQ0UsUUFBRCxJQUFhRixVQUFVLEtBQUssU0FBN0IsSUFBMkMsQ0FBQ0EsVUFKOUM7QUFLQSxzSUFDRUEsVUFBVSxLQUFLLFFBTmpCO0FBT0EscUNBQWlDRTtBQVBqQyxHQURKLEdBVUk7QUFDQSxzRUFDRTtBQUZGLEdBbkJnQixFQXdCcEJELFNBeEJvQixDQUF0Qjs7QUEwQkEsTUFBSUgsTUFBSixFQUFZO0FBQ1Y7QUFBQTtBQUNFO0FBQ0E7QUFBRyxpQkFBUyxFQUFFUztBQUFkLFNBQStCRCxVQUEvQjtBQUFBLGtCQUNHUDtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQU1EOztBQUNEO0FBQUE7QUFDRTtBQUNBO0FBQVEsZUFBUyxFQUFFUSxXQUFuQjtBQUFnQyxjQUFRLEVBQUVMO0FBQTFDLE9BQXdESSxVQUF4RDtBQUFBLGlCQUNHUCxRQURILEVBRUdNLFVBQVUsZ0JBQ1Q7QUFDRSxpQkFBUyxFQUFDLHNDQURaO0FBRUUsYUFBSyxFQUFDLDRCQUZSO0FBR0UsWUFBSSxFQUFDLE1BSFA7QUFJRSxlQUFPLEVBQUMsV0FKVjtBQUFBLGdDQU1FO0FBQ0UsbUJBQVMsRUFBQyxZQURaO0FBRUUsWUFBRSxFQUFDLElBRkw7QUFHRSxZQUFFLEVBQUMsSUFITDtBQUlFLFdBQUMsRUFBQyxJQUpKO0FBS0UsZ0JBQU0sRUFBQyxjQUxUO0FBTUUscUJBQVcsRUFBQztBQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkYsZUFjRTtBQUNFLG1CQUFTLEVBQUMsWUFEWjtBQUVFLGNBQUksRUFBQyxjQUZQO0FBR0UsV0FBQyxFQUFDO0FBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRFMsR0FxQlAsSUF2Qk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkY7QUE0QkQsQ0ExRWMsQ0FBZjtBQTRFQSwrREFBZVgsTUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBTUEsTUFBTWdCLFNBQTBCLEdBQUcsQ0FBQztBQUFFVCxXQUFGO0FBQWFGO0FBQWIsQ0FBRCxLQUE2QjtBQUM5RCxzQkFDRSw4REFBQyxrREFBRDtBQUFNLFFBQUksRUFBQyx5QkFBWDtBQUFBLDJCQUNFO0FBQ0UsVUFBSSxFQUFDLEdBRFA7QUFFRSxlQUFTLEVBQUVTLGlEQUFFLENBQ1gsaUhBRFcsRUFFWFAsU0FGVyxDQUZmO0FBQUEsOEJBT0U7QUFBTSxpQkFBUyxFQUFDLHFCQUFoQjtBQUFBLGtCQUF1Q0Y7QUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQVFFO0FBQUssaUJBQVMsRUFBQyx1RUFBZjtBQUFBLCtCQUNFO0FBQ0UsZUFBSyxFQUFDLElBRFI7QUFFRSxnQkFBTSxFQUFDLElBRlQ7QUFHRSxpQkFBTyxFQUFDLFdBSFY7QUFJRSxjQUFJLEVBQUMsTUFKUDtBQUtFLGVBQUssRUFBQyw0QkFMUjtBQUFBLGlDQU9FO0FBQ0UsYUFBQyxFQUFDLDRKQURKO0FBRUUsZ0JBQUksRUFBQztBQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUEyQkQsQ0E1QkQ7O0FBOEJBLCtEQUFlVyxTQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6Q0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsTUFBTUMsWUFBNkIsR0FBRyxNQUFNO0FBQzFDLHNCQUNFO0FBQUssYUFBUyxFQUFDLHdEQUFmO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsTUFBZjtBQUFBLDhCQUNFO0FBQUssV0FBRyxFQUFDLHNCQUFUO0FBQWdDLGlCQUFTLEVBQUM7QUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUssaUJBQVMsRUFBQyxlQUFmO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLGVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBV0U7QUFBSyxlQUFTLEVBQUMsTUFBZjtBQUFBLDhCQUNFO0FBQUssV0FBRyxFQUFDLHVCQUFUO0FBQWlDLGlCQUFTLEVBQUM7QUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUssaUJBQVMsRUFBQyxlQUFmO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLGVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBd0JELENBekJEOztBQTJCQSwrREFBZUEsWUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQU9BLE1BQU1DLEdBQW9CLEdBQUcsQ0FBQztBQUFFQyxLQUFGO0FBQU9DLE9BQVA7QUFBY0MsWUFBVSxHQUFHO0FBQTNCLENBQUQsS0FBdUM7QUFDbEUsUUFBTTtBQUFBLE9BQUNDLE1BQUQ7QUFBQSxPQUFTQztBQUFULE1BQXNCQywrQ0FBUSxDQUFpQixFQUFqQixDQUFwQztBQUNBQyxrREFBUyxDQUFDLE1BQU07QUFDZEMsdURBQVMsR0FBR0MsSUFBWixDQUFpQkosU0FBakI7QUFDRCxHQUZRLEVBRU4sRUFGTSxDQUFUO0FBSUEsUUFBTUssU0FBUyxHQUFHTixNQUFNLENBQUNPLEdBQVAsQ0FBWUMsQ0FBRCxJQUFPQSxDQUFDLENBQUNDLElBQXBCLENBQWxCO0FBQ0EsUUFBTUMsV0FBVyxHQUNmSixTQUFTLENBQUNLLEtBQVYsQ0FBZ0IsQ0FBaEIsRUFBbUIsQ0FBQyxDQUFwQixFQUF1QkMsSUFBdkIsQ0FBNEIsSUFBNUIsSUFDQSxPQURBLEdBRUFOLFNBQVMsQ0FBQ0EsU0FBUyxDQUFDTyxNQUFWLEdBQW1CLENBQXBCLENBSFg7QUFJQSxzQkFDRTtBQUFLLGFBQVMsRUFBQywyQ0FBZjtBQUFBLDRCQUNFO0FBQUksZUFBUyxFQUFDLHFEQUFkO0FBQUEsZ0JBQ0dmLEtBQUssR0FBR0EsS0FBSCxHQUFXO0FBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFJRTtBQUFJLGVBQVMsRUFBQyxrQkFBZDtBQUFBLGdCQUNJRCxHQUFHLENBQUNVLEdBQUosQ0FBUSxDQUFDO0FBQUNPO0FBQUQsT0FBRCxFQUFXQyxLQUFYLEtBQW1CO0FBQzNCLDRCQUNFLDhEQUFDLDZDQUFEO0FBQVMsZUFBSyxFQUFFRCxNQUFNLENBQUNFLFFBQXZCO0FBQUEsb0JBQ0dDLCtGQUF5QixDQUFDSCxNQUFNLENBQUNJLFNBQVI7QUFENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQUtELE9BTkM7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLEVBNEpHbkIsVUFBVSxnQkFDVCw4REFBQyxrREFBRDtBQUFNLFVBQUksRUFBQyxNQUFYO0FBQUEsNkJBQ0UsOERBQUMsaURBQUQ7QUFDRSxjQUFNLEVBQUUsSUFEVjtBQUVFLFlBQUksRUFBQyxHQUZQO0FBR0Usa0JBQVUsRUFBQyxXQUhiO0FBSUUsaUJBQVMsRUFBQyxxR0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRFMsR0FXUCxJQXZLTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTJLRCxDQXRMRDs7QUF3TEEsK0RBQWVILEdBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM01BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsTUFBTXVCLE9BQW9DLEdBQUcsQ0FBQztBQUFFckIsT0FBRjtBQUFTZjtBQUFULENBQUQsS0FBeUI7QUFDcEUsUUFBTTtBQUFBLE9BQUNxQyxJQUFEO0FBQUEsT0FBT0M7QUFBUCxNQUFrQm5CLCtDQUFRLENBQUMsS0FBRCxDQUFoQztBQUNBLHNCQUNFO0FBQUksYUFBUyxFQUFDLDBFQUFkO0FBQUEsNEJBQ0U7QUFDRSxlQUFTLEVBQUMsdURBRFo7QUFFRSxhQUFPLEVBQUUsTUFBTW1CLE9BQU8sQ0FBQyxDQUFDRCxJQUFGLENBRnhCO0FBQUEsOEJBSUU7QUFBTSxpQkFBUyxFQUFDLG9CQUFoQjtBQUFBLGtCQUFzQ3RCO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkYsZUFLRTtBQUFLLGlCQUFTLEVBQUMsU0FBZjtBQUFBLGtCQUNHc0IsSUFBSSxnQkFDSDtBQUNFLG1CQUFTLEVBQUMsU0FEWjtBQUVFLGVBQUssRUFBQyw0QkFGUjtBQUdFLGNBQUksRUFBQyxNQUhQO0FBSUUsaUJBQU8sRUFBQyxXQUpWO0FBS0UsZ0JBQU0sRUFBQyxjQUxUO0FBQUEsaUNBT0U7QUFDRSx5QkFBYSxFQUFDLE9BRGhCO0FBRUUsMEJBQWMsRUFBQyxPQUZqQjtBQUdFLHVCQUFXLEVBQUUsQ0FIZjtBQUlFLGFBQUMsRUFBQztBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURHLGdCQWdCSDtBQUNFLG1CQUFTLEVBQUMsU0FEWjtBQUVFLGVBQUssRUFBQyw0QkFGUjtBQUdFLGNBQUksRUFBQyxNQUhQO0FBSUUsaUJBQU8sRUFBQyxXQUpWO0FBS0UsZ0JBQU0sRUFBQyxjQUxUO0FBQUEsaUNBT0U7QUFDRSx5QkFBYSxFQUFDLE9BRGhCO0FBRUUsMEJBQWMsRUFBQyxPQUZqQjtBQUdFLHVCQUFXLEVBQUUsQ0FIZjtBQUlFLGFBQUMsRUFBQztBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBd0NFLDhEQUFDLHlEQUFEO0FBQ0UsVUFBSSxFQUFFQSxJQURSO0FBRUUsZUFBUyxFQUFDLE1BRlo7QUFHRSxXQUFLLEVBQUMsa0NBSFI7QUFJRSxlQUFTLEVBQUMsOEJBSlo7QUFLRSxhQUFPLEVBQUMsaUNBTFY7QUFNRSxXQUFLLEVBQUMsZ0NBTlI7QUFPRSxlQUFTLEVBQUMsaUNBUFo7QUFRRSxhQUFPLEVBQUMsOEJBUlY7QUFBQSxnQkFVR3JDO0FBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUF1REQsQ0F6REQ7O0FBMkRBLCtEQUFlb0MsT0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBTUEsTUFBTUcsZUFBeUMsR0FBRyxDQUFDO0FBQUVDLE1BQUY7QUFBUXhDO0FBQVIsQ0FBRCxrQkFDaEQ7QUFBRyxRQUFNLEVBQUMsUUFBVjtBQUFtQixLQUFHLEVBQUMsWUFBdkI7QUFBb0MsV0FBUyxFQUFDLEtBQTlDO0FBQW9ELE1BQUksRUFBRXdDLElBQTFEO0FBQUEsWUFDR3hDO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGOztBQVlBLE1BQU15QyxVQUErQixHQUFHLFVBS2xDO0FBQUEsTUFMbUM7QUFDdkNELFFBRHVDO0FBRXZDeEMsWUFGdUM7QUFHdkMwQyxZQUFRLEdBQUc7QUFINEIsR0FLbkM7QUFBQSxNQUREN0MsS0FDQzs7QUFDSixRQUFNOEMsSUFBSSxnQkFDUjtBQUNFLGFBQVMsRUFBQywyQ0FEWjtBQUVFLFFBQUksRUFBRUQsUUFBUSxHQUFHRixJQUFILEdBQVVJO0FBRjFCLEtBR00vQyxLQUhOO0FBQUEsY0FLR0c7QUFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7O0FBVUEsc0JBQU87QUFBQSxjQUFLMEMsUUFBUSxHQUFHQyxJQUFILGdCQUFVLDhEQUFDLGtEQUFEO0FBQU0sVUFBSSxFQUFFSCxJQUFaO0FBQUEsZ0JBQW1CRztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUDtBQUNELENBakJEOztBQW1CQSxNQUFNRSxNQUFNLEdBQUcsTUFBTTtBQUNuQixzQkFDRTtBQUNFLE1BQUUsRUFBQyxRQURMO0FBRUUsYUFBUyxFQUFDLHFEQUZaO0FBQUEsMkJBSUU7QUFBSyxlQUFTLEVBQUMsMkNBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMseUJBQWY7QUFBQSxnQ0FDRSw4REFBQywwQ0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUUsOERBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFLRTtBQUFLLGlCQUFTLEVBQUMseURBQWY7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsNENBQWQ7QUFBQSxrQ0FDRSw4REFBQyxVQUFEO0FBQVksZ0JBQUksRUFBQyxtQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRSw4REFBQyxVQUFEO0FBQVksZ0JBQUksRUFBQyxpQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkYsZUFHRSw4REFBQyxVQUFEO0FBQVksZ0JBQUksRUFBQyw0QkFBakI7QUFBOEMsb0JBQVEsTUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEYsZUFNRSw4REFBQyxVQUFEO0FBQ0UsZ0JBQUksRUFBQyxtQ0FEUDtBQUVFLGtCQUFNLEVBQUMsUUFGVDtBQUdFLG9CQUFRLE1BSFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTkYsZUFhRSw4REFBQyxVQUFEO0FBQVksZ0JBQUksRUFBQyxlQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFiRixlQWNFLDhEQUFDLFVBQUQ7QUFBWSxnQkFBSSxFQUFDLE9BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQWlCRTtBQUFJLG1CQUFTLEVBQUMsK0JBQWQ7QUFBQSxrQ0FDRSw4REFBQyxVQUFEO0FBQVksZ0JBQUksRUFBQyw4QkFBakI7QUFBZ0Qsb0JBQVEsTUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFJRSw4REFBQyxVQUFEO0FBQVksZ0JBQUksRUFBQyxNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKRixlQUtFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUxGLGVBTUU7QUFBSSxxQkFBUyxFQUFDLG1CQUFkO0FBQUEsb0NBQ0UsOERBQUMsZUFBRDtBQUFpQixrQkFBSSxFQUFDLG1EQUF0QjtBQUFBLHFDQUNFLDhEQUFDLCtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBSUUsOERBQUMsZUFBRDtBQUFpQixrQkFBSSxFQUFDLDZDQUF0QjtBQUFBLHFDQUNFLDhEQUFDLDhEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUpGLGVBT0UsOERBQUMsZUFBRDtBQUFpQixrQkFBSSxFQUFDLHVEQUF0QjtBQUFBLHFDQUNFLDhEQUFDLDhEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBakJGLGVBbUNFO0FBQUcsbUJBQVMsRUFBQyxjQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBcURELENBdEREOztBQXdEQSwrREFBZUEsTUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBU0EsTUFBTUMsTUFBdUIsR0FBRyxDQUFDO0FBQy9CL0IsT0FEK0I7QUFFL0JnQyxZQUYrQjtBQUcvQkMsWUFIK0I7QUFJL0JDO0FBSitCLENBQUQsS0FLMUI7QUFDSixRQUFNO0FBQUEsT0FBQ0MsU0FBRDtBQUFBLE9BQVlDO0FBQVosTUFBNEJoQywrQ0FBUSxDQUFDLENBQUMsQ0FBQzRCLFVBQUgsQ0FBMUM7QUFDQSxRQUFNO0FBQUEsT0FBQ0ssV0FBRDtBQUFBLE9BQWNDO0FBQWQsTUFBZ0NsQywrQ0FBUSxDQUFDLEtBQUQsQ0FBOUM7QUFDQSxRQUFNO0FBQUEsT0FBQ21DLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CcEMsK0NBQVEsQ0FBQyxJQUFELENBQWxDOztBQUVBLFFBQU1xQyxRQUFRLEdBQUcsTUFBTTtBQUNyQkQsWUFBUSxDQUFDRSxNQUFNLENBQUNDLFdBQVAsR0FBcUIsRUFBdEIsQ0FBUjtBQUNELEdBRkQ7O0FBR0F0QyxrREFBUyxDQUFDLE1BQU07QUFDZHFDLFVBQU0sQ0FBQ0UsZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0NILFFBQWxDO0FBQ0EsV0FBTyxNQUFNQyxNQUFNLENBQUNHLG1CQUFQLENBQTJCLFFBQTNCLEVBQXFDSixRQUFyQyxDQUFiO0FBQ0QsR0FIUSxFQUdOLEVBSE0sQ0FBVDs7QUFLQSxRQUFNSyxXQUFXLEdBQUcsTUFBTVIsY0FBYyxDQUFDLEtBQUQsQ0FBeEM7O0FBQ0Esc0JBQ0U7QUFBQSw0QkFDRSw4REFBQyxrREFBRDtBQUFBLDhCQUNFO0FBQUEsa0JBQVF0QztBQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFNLFdBQUcsRUFBQyxNQUFWO0FBQWlCLFlBQUksRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUtFO0FBQ0UsZUFBUyxFQUFFTixpREFBRSxDQUNYLHlHQURXLEVBRVg7QUFBRSxxQkFBYSxDQUFDNkM7QUFBaEIsT0FGVyxFQUdYQSxLQUFLLEdBQUdOLFVBQVUsSUFBSSxhQUFqQixHQUFpQyxVQUgzQixDQURmO0FBQUEsaUJBT0dFLFNBQVMsZ0JBQ1I7QUFBSyxpQkFBUyxFQUFDLHlGQUFmO0FBQUEsZ0NBQ0UsOERBQUMsa0RBQUQ7QUFBTSxjQUFJLEVBQUMseUJBQVg7QUFBQSxpQ0FDRTtBQUFHLGdCQUFJLEVBQUMsR0FBUjtBQUFZLHFCQUFTLEVBQUMsc0NBQXRCO0FBQUEsc0JBQ0dIO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFNRTtBQUFLLGlCQUFPLEVBQUUsTUFBTUksWUFBWSxDQUFDLEtBQUQsQ0FBaEM7QUFBeUMsbUJBQVMsRUFBQyxNQUFuRDtBQUFBLGlDQUNFO0FBQ0UsaUJBQUssRUFBQyw0QkFEUjtBQUVFLHFCQUFTLEVBQUMsU0FGWjtBQUdFLGdCQUFJLEVBQUMsTUFIUDtBQUlFLG1CQUFPLEVBQUMsV0FKVjtBQUtFLGtCQUFNLEVBQUMsY0FMVDtBQUFBLG1DQU9FO0FBQ0UsMkJBQWEsRUFBQyxPQURoQjtBQUVFLDRCQUFjLEVBQUMsT0FGakI7QUFHRSx5QkFBVyxFQUFFLENBSGY7QUFJRSxlQUFDLEVBQUM7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURRLEdBd0JOLElBL0JOLGVBZ0NFO0FBQUssaUJBQVMsRUFBQywrQ0FBZjtBQUFBLGdDQUNFLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLEdBQVg7QUFBQSxpQ0FDRTtBQUFHLGdCQUFJLEVBQUMsR0FBUjtBQUFZLHFCQUFTLEVBQUMsbUJBQXRCO0FBQUEsbUNBQ0UsOERBQUMsMENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBT0U7QUFBSyxtQkFBUyxFQUFFMUMsaURBQUUsQ0FBQyxtQkFBRCxFQUFzQndDLFFBQVEsR0FBRyxRQUFILEdBQWMsRUFBNUMsQ0FBbEI7QUFBQSxpQ0FDRTtBQUNFLG1CQUFPLEVBQUUsTUFBTUksY0FBYyxDQUFDLElBQUQsQ0FEL0I7QUFFRSxxQkFBUyxFQUFDLGdEQUZaO0FBQUEsbUNBSUU7QUFDRSxtQkFBSyxFQUFDLDRCQURSO0FBRUUsdUJBQVMsRUFBQyx1QkFGWjtBQUdFLGtCQUFJLEVBQUMsTUFIUDtBQUlFLHFCQUFPLEVBQUMsV0FKVjtBQUtFLG9CQUFNLEVBQUMsY0FMVDtBQUFBLHFDQU9FO0FBQ0UsNkJBQWEsRUFBQyxPQURoQjtBQUVFLDhCQUFjLEVBQUMsT0FGakI7QUFHRSwyQkFBVyxFQUFFLENBSGY7QUFJRSxpQkFBQyxFQUFDO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFQRixlQW1DRTtBQUFJLG1CQUFTLEVBQUMsb0VBQWQ7QUFBQSxpQ0FDRTtBQUFLLHFCQUFTLEVBQUMsZ0JBQWY7QUFBQSxvQ0FDRSw4REFBQyxrREFBRDtBQUFNLGtCQUFJLEVBQUMsUUFBWDtBQUFBLHFDQUNFLDhEQUFDLGlEQUFEO0FBQ0Usb0JBQUksRUFBQyxHQURQO0FBRUUsc0JBQU0sTUFGUjtBQUdFLDBCQUFVLEVBQUMsV0FIYjtBQUlFLHlCQUFTLEVBQUMsK0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBV0UsOERBQUMsa0RBQUQ7QUFBTSxrQkFBSSxFQUFDLHlCQUFYO0FBQUEscUNBQ0UsOERBQUMsaURBQUQ7QUFDRSwwQkFBVSxFQUFDLFFBRGI7QUFFRSx5QkFBUyxFQUFDLDZCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRixlQWtHRSw4REFBQyx5REFBRDtBQUFZLFVBQUksRUFBRUQsV0FBbEI7QUFBQSw4QkFDRSw4REFBQywrREFBRDtBQUNFLGFBQUssRUFBQyw2Q0FEUjtBQUVFLGlCQUFTLEVBQUMsV0FGWjtBQUdFLGVBQU8sRUFBQyxhQUhWO0FBSUUsYUFBSyxFQUFDLDZDQUpSO0FBS0UsaUJBQVMsRUFBQyxhQUxaO0FBTUUsZUFBTyxFQUFDLFdBTlY7QUFBQSwrQkFRRTtBQUNFLG1CQUFTLEVBQUMsMENBRFo7QUFFRSxpQkFBTyxFQUFFLE1BQU1DLGNBQWMsQ0FBQyxLQUFEO0FBRi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBY0UsOERBQUMsK0RBQUQ7QUFDRSxhQUFLLEVBQUMseUNBRFI7QUFFRSxpQkFBUyxFQUFDLFFBRlo7QUFHRSxlQUFPLEVBQUMsTUFIVjtBQUlFLGFBQUssRUFBQyx3Q0FKUjtBQUtFLGVBQU8sRUFBQyxRQUxWO0FBQUEsK0JBT0U7QUFBSyxtQkFBUyxFQUFDLHlFQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLHlCQUFmO0FBQUEsb0NBQ0UsOERBQUMsa0RBQUQ7QUFBTSxrQkFBSSxFQUFDLEdBQVg7QUFBQSxxQ0FDRTtBQUFHLHlCQUFTLEVBQUMsRUFBYjtBQUFBLHVDQUNFLDhEQUFDLDBDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQU1FO0FBQVEscUJBQU8sRUFBRSxNQUFNQSxjQUFjLENBQUMsS0FBRCxDQUFyQztBQUE4Qyx1QkFBUyxFQUFDLFNBQXhEO0FBQUEscUNBQ0U7QUFDRSx5QkFBUyxFQUFDLGdEQURaO0FBRUUscUJBQUssRUFBQyw0QkFGUjtBQUdFLG9CQUFJLEVBQUMsTUFIUDtBQUlFLHVCQUFPLEVBQUMsV0FKVjtBQUtFLHNCQUFNLEVBQUMsY0FMVDtBQUFBLHVDQU9FO0FBQ0UsK0JBQWEsRUFBQyxPQURoQjtBQUVFLGdDQUFjLEVBQUMsT0FGakI7QUFHRSw2QkFBVyxFQUFDLEdBSGQ7QUFJRSxtQkFBQyxFQUFDO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQXdCRTtBQUFBLG9DQUNFO0FBQUksdUJBQVMsRUFBQyxRQUFkO0FBQUEsc0NBQ0U7QUFBSSx5QkFBUyxFQUFDLE1BQWQ7QUFBQSx1Q0FDRTtBQUNFLDJCQUFTLEVBQUMsbUJBRFo7QUFFRSxzQkFBSSxFQUFDLGlCQUZQO0FBR0UseUJBQU8sRUFBRVEsV0FIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFVRTtBQUFJLHlCQUFTLEVBQUMsTUFBZDtBQUFBLHVDQUNFO0FBQ0UsMkJBQVMsRUFBQyxtQkFEWjtBQUVFLHNCQUFJLEVBQUMsZ0JBRlA7QUFHRSx5QkFBTyxFQUFFQSxXQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFWRixlQW1CRTtBQUFJLHlCQUFTLEVBQUMsTUFBZDtBQUFBLHVDQUNFO0FBQ0UsMkJBQVMsRUFBQyxtQkFEWjtBQUVFLHNCQUFJLEVBQUMsV0FGUDtBQUdFLHlCQUFPLEVBQUVBLFdBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQW5CRixlQTRCRTtBQUFJLHlCQUFTLEVBQUMsTUFBZDtBQUFBLHVDQUNFO0FBQ0UsMkJBQVMsRUFBQyxtQkFEWjtBQUVFLHNCQUFJLEVBQUMsT0FGUDtBQUdFLHlCQUFPLEVBQUVBLFdBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUF1Q0U7QUFBSyx1QkFBUyxFQUFDLHdDQUFmO0FBQUEsc0NBQ0UsOERBQUMsa0RBQUQ7QUFBTSxvQkFBSSxFQUFDLHlCQUFYO0FBQUEsdUNBQ0UsOERBQUMsaURBQUQ7QUFBUSx3QkFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUlFLDhEQUFDLGtEQUFEO0FBQU0sb0JBQUksRUFBQyxRQUFYO0FBQUEsdUNBQ0UsOERBQUMsaURBQUQ7QUFDRSx3QkFBTSxNQURSO0FBRUUsNEJBQVUsRUFBQyxXQUZiO0FBR0UsMkJBQVMsRUFBQyx3QkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWxHRixFQXdNR1gsU0FBUyxnQkFDUjtBQUFLLGVBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRFEsZ0JBR1I7QUFBSyxlQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTNNSixlQTZNRTtBQUFLLGVBQVMsRUFBRXpDLGlEQUFFLENBQUN5QyxTQUFTLEdBQUcsTUFBSCxHQUFZTixTQUF0QjtBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTdNRjtBQUFBLGtCQURGO0FBaU5ELENBcE9EOztBQXNPQSwrREFBZUUsTUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDelBBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFJQSxNQUFNZ0IsZUFBZ0MsR0FBRyxDQUFDO0FBQUVDLE1BQUY7QUFBUS9EO0FBQVIsQ0FBRCxLQUF3QjtBQUMvRGdFLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBd0JGLElBQXhCO0FBQ0EsUUFBTTtBQUFFakQsT0FBRjtBQUFPb0Q7QUFBUCxNQUFnQkgsSUFBdEI7QUFDQSxRQUFNO0FBQUVoQztBQUFGLE1BQWFtQyxJQUFuQjtBQUNBLFFBQU07QUFDSkMsc0JBREk7QUFFSkMsZUFGSTtBQUdKQyx1QkFISTtBQUlKQztBQUpJLE1BS0Z2QyxNQUxKO0FBTUFpQyxTQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCRSxrQkFBdEI7QUFDQUksd0RBQU07QUFDTixRQUFNO0FBQUVDO0FBQUYsTUFBZ0JDLDBEQUFRLEVBQTlCO0FBRUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsRUFBZjtBQUFBLDRCQUNFLDhEQUFDLDRDQUFEO0FBQVEsV0FBSyxFQUFDLE1BQWQ7QUFBcUIsZ0JBQVUsRUFBRUQ7QUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLE1BQVo7QUFBbUIsZUFBUyxFQUFDLDBDQUE3QjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQywyQ0FBZjtBQUFBLGdDQUNFO0FBQUEsb0JBQU14RTtBQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFLLG1CQUFTLEVBQUMsdUJBQWY7QUFBQSxrQ0FDRTtBQUNFLGVBQUcsRUFBQyxtQkFETjtBQUVFLGlCQUFLLEVBQUMsS0FGUjtBQUdFLHFCQUFTLEVBQUMsU0FIWjtBQUlFLGlCQUFLLEVBQUU7QUFBRTBFLG1CQUFLLEVBQUU7QUFBVDtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFPRTtBQUNFLGlCQUFLLEVBQUMsS0FEUjtBQUVFLGVBQUcsRUFBQyw4QkFGTjtBQUdFLHFCQUFTLEVBQUM7QUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGLGVBb0JFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLGNBQVo7QUFBMkIsZUFBUyxFQUFDLHFCQUFyQztBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsK0JBQ0UsOERBQUMsb0RBQUQ7QUFBZ0IsaUJBQU8sRUFBRVAsa0JBQXpCO0FBQTZDLGNBQUksRUFBRUM7QUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXBCRixlQTBCRSw4REFBQyw4Q0FBRDtBQUFTLFFBQUUsRUFBQyxjQUFaO0FBQTJCLGVBQVMsRUFBQyxpQ0FBckM7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUFBLCtCQUNFLDhEQUFDLG1EQUFEO0FBQWMsaUJBQU8sRUFBRUMsbUJBQXZCO0FBQTRDLGNBQUksRUFBRUM7QUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTFCRixlQWdDRSw4REFBQyw4Q0FBRDtBQUFTLFFBQUUsRUFBQyxlQUFaO0FBQTRCLGVBQVMsRUFBQyxpQ0FBdEM7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUFBLCtCQUNFLDhEQUFDLGtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFoQ0YsZUFzQ0UsOERBQUMsOENBQUQ7QUFBUyxRQUFFLEVBQUMsY0FBWjtBQUFBLDZCQUNFLDhEQUFDLGlEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXRDRixlQTBDRSw4REFBQyw4Q0FBRDtBQUFTLFFBQUUsRUFBQyxTQUFaO0FBQXNCLGVBQVMsRUFBQyxhQUFoQztBQUE4QyxlQUFTLE1BQXZEO0FBQUEsNkJBQ0UsOERBQUMsOENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMUNGLGVBOENFLDhEQUFDLDhDQUFEO0FBQVMsUUFBRSxFQUFDLEtBQVo7QUFBa0IsZUFBUyxFQUFDLHFCQUE1QjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsK0JBQ0UsOERBQUMseUNBQUQ7QUFBSyxhQUFHLEVBQUV4RDtBQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE5Q0YsZUFtREUsOERBQUMsOENBQUQ7QUFDRSxRQUFFLEVBQUMsV0FETDtBQUVFLGVBQVMsRUFBQyxxQkFGWjtBQUdFLFdBQUssRUFBRTtBQUFFNkQsdUJBQWUsRUFBRTtBQUFuQixPQUhUO0FBQUEsNkJBS0U7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSwrQkFDRSw4REFBQyxrREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbkRGLGVBNERFLDhEQUFDLDRDQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0VELENBOUVEOztBQWdGQSwrREFBZWIsZUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEdBO0FBQ0E7QUFDQTtBQUNBOztBQUlBLE1BQU1jLGVBQWdDLEdBQUcsTUFBTTtBQUM3QyxzQkFDRTtBQUNFLFFBQUksRUFBQyxnREFEUDtBQUVFLFVBQU0sRUFBQyxRQUZUO0FBR0UsU0FBSyxFQUFDLDZCQUhSO0FBSUUsT0FBRyxFQUFDLFlBSk47QUFBQSwyQkFNRTtBQUNFLFNBQUcsRUFBQyxtREFETjtBQUVFLFNBQUcsRUFBQyxzQkFGTjtBQUdFLFdBQUssRUFBQyxLQUhSO0FBSUUsWUFBTSxFQUFDO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBaEJEOztBQWtCQSwrREFBZUEsZUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekJBO0FBQ0E7QUFDQTtBQUVBOztBQUlBLE1BQU1DLElBQXFCLEdBQUcsTUFBTTtBQUNsQyxzQkFDRTtBQUNFLFNBQUssRUFBQyxJQURSO0FBRUUsVUFBTSxFQUFDLElBRlQ7QUFHRSxXQUFPLEVBQUMsV0FIVjtBQUlFLFFBQUksRUFBQyxNQUpQO0FBS0UsU0FBSyxFQUFDLDRCQUxSO0FBQUEsNEJBT0U7QUFDRSxPQUFDLEVBQUMsU0FESjtBQUVFLGVBQVMsRUFBQyxrQ0FGWjtBQUdFLFVBQUksRUFBQztBQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUEYsZUFZRTtBQUNFLE9BQUMsRUFBQyxTQURKO0FBRUUsZUFBUyxFQUFDLGtDQUZaO0FBR0UsVUFBSSxFQUFDO0FBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFaRixlQWlCRTtBQUFNLE9BQUMsRUFBQyx1Q0FBUjtBQUFnRCxVQUFJLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqQkYsZUFrQkU7QUFDRSxPQUFDLEVBQUMsa1BBREo7QUFFRSxVQUFJLEVBQUM7QUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWxCRixlQXNCRTtBQUNFLE9BQUMsRUFBQyxrUkFESjtBQUVFLFVBQUksRUFBQztBQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdEJGLGVBMEJFO0FBQ0UsT0FBQyxFQUFDLDhrQkFESjtBQUVFLFVBQUksRUFBQztBQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBaUNELENBbENEOztBQW9DQSwrREFBZUEsSUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsTUFBTUMsZ0JBSUosR0FBRyxDQUFDO0FBQUUvRCxPQUFGO0FBQVNXLE1BQVQ7QUFBZXFELFVBQWY7QUFBeUIvRTtBQUF6QixDQUFELEtBQXlDO0FBQzVDLHNCQUNFO0FBQUssYUFBUyxFQUFDLHFFQUFmO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsV0FBZjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyxnQkFBZjtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyx5QkFBZjtBQUF5QyxhQUFHLEVBQUUrRTtBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUlFO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLG1CQUFkO0FBQUEsb0JBQW1DckQ7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUksbUJBQVMsRUFBQyxlQUFkO0FBQUEsb0JBQStCWDtBQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFVRTtBQUFHLGVBQVMsRUFBQyxFQUFiO0FBQUEsZ0JBQWlCZjtBQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBY0QsQ0FuQkQ7O0FBcUJBLE1BQU1nRixXQUE0QixHQUFHLE1BQU07QUFDekMsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsZUFBZjtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLFFBQWY7QUFBQSw2QkFDRTtBQUFJLGlCQUFTLEVBQUMsdUNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBTUU7QUFBSyxlQUFTLEVBQUMscUZBQWY7QUFBQSw4QkFDRSw4REFBQyxnQkFBRDtBQUNFLFlBQUksRUFBQyxvQkFEUDtBQUVFLGFBQUssRUFBQyxJQUZSO0FBR0UsZ0JBQVEsRUFBQyxnQ0FIWDtBQUFBLHFKQU1nRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFOaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBYUUsOERBQUMsZ0JBQUQ7QUFDRSxZQUFJLEVBQUMsa0JBRFA7QUFFRSxhQUFLLEVBQUMsSUFGUjtBQUdFLGdCQUFRLEVBQUMsNkJBSFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBa0NELENBbkNEOztBQXFDQSwrREFBZUEsV0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUlBLE1BQU1DLFVBQW9CLEdBQUcsQ0FBQztBQUFFakY7QUFBRixDQUFELEtBQWtCO0FBQzdDLHNCQUNFO0FBQUssYUFBUyxFQUFDLFFBQWY7QUFBQSwyQkFDRTtBQUFNLGVBQVMsRUFBQyxrSkFBaEI7QUFBQSxnQkFDR0E7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBT0QsQ0FSRDs7QUFVQSxNQUFNa0YsSUFBYyxHQUFHLE1BQU07QUFDM0Isc0JBQ0U7QUFBSyxhQUFTLEVBQUMsUUFBZjtBQUFBLDJCQUNFO0FBQUssZUFBUyxFQUFDLGVBQWY7QUFBK0IsV0FBSyxFQUFFO0FBQUVDLGFBQUssRUFBRTtBQUFUO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFLRCxDQU5EOztBQVFBLE1BQU1DLGNBQStCLEdBQUcsQ0FBQztBQUFFQyxTQUFGO0FBQVd0QjtBQUFYLENBQUQsS0FBdUI7QUFDN0RDLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaLEVBQThCRixJQUE5QjtBQUNBLHNCQUNFO0FBQUssYUFBUyxFQUFDLGlDQUFmO0FBQUEsNEJBQ0U7QUFBSSxlQUFTLEVBQUMsb0RBQWQ7QUFBQSxnQkFDR3NCLE9BQU8sR0FBR0EsT0FBSCxHQUFhO0FBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFJRTtBQUFBLDZCQUVFO0FBQUssaUJBQVMsRUFBQywyREFBZjtBQUFBLG1CQUVJdEIsSUFBSSxJQUFJQSxJQUFJLENBQUN2QyxHQUFMLENBQVMsQ0FBQztBQUFDTztBQUFELFNBQUQsRUFBV0MsS0FBWCxLQUFtQjtBQUNwQyw4QkFDRTtBQUFBLG9DQUNBLDhEQUFDLFVBQUQ7QUFBQSx5QkFBYUEsS0FBSyxHQUFDLENBQW5CLEVBQXNCK0IsSUFBSSxDQUFDakMsTUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURBLGVBRUU7QUFBSyx1QkFBUyxFQUFDLG9CQUFmO0FBQUEsc0NBQ0U7QUFBTSx5QkFBUyxFQUFDLFdBQWhCO0FBQUEsMEJBQTZCQyxNQUFNLENBQUN1RDtBQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBRUU7QUFBTSx5QkFBUyxFQUFDLFNBQWhCO0FBQUEsMEJBQTJCdkQsTUFBTSxDQUFDd0Q7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkYsRUFNR3hCLElBQUksQ0FBQ2pDLE1BQUwsSUFBZUUsS0FBSyxHQUFDLENBQXJCLGlCQUEwQiw4REFBQyxJQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTjdCLGVBT0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFQRjtBQUFBLDBCQURGO0FBV0QsU0FaUyxDQUZaLGVBdURFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFtRUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsc0NBQWY7QUFBQSw0QkFDRTtBQUFBLDZCQUNFO0FBQUksaUJBQVMsRUFBQywrQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFNRTtBQUFLLGVBQVMsRUFBQyxzQ0FBZjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyx3Q0FBZjtBQUFBLCtCQUNFO0FBQUssYUFBRyxFQUFDLHdCQUFUO0FBQWtDLG1CQUFTLEVBQUM7QUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFJRTtBQUFLLGlCQUFTLEVBQUMsVUFBZjtBQUFBLGdDQUNFO0FBQUksbUJBQVMsRUFBQyxjQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUU7QUFBSyxtQkFBUyxFQUFDLFlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBWUU7QUFBSyxpQkFBUyxFQUFDLDBCQUFmO0FBQUEsK0JBQ0U7QUFBSyxhQUFHLEVBQUMseUJBQVQ7QUFBbUMsbUJBQVMsRUFBQztBQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaRixlQWVFO0FBQUssaUJBQVMsRUFBQyxVQUFmO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLGNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFLLG1CQUFTLEVBQUMsWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZkYsZUFzQkU7QUFBSyxpQkFBUyxFQUFDLDBCQUFmO0FBQUEsK0JBQ0U7QUFBSyxhQUFHLEVBQUMsMEJBQVQ7QUFBb0MsbUJBQVMsRUFBQztBQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF0QkYsZUF5QkU7QUFBSyxpQkFBUyxFQUFDLFVBQWY7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsY0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUssbUJBQVMsRUFBQyxZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBeUNELENBOUdEOztBQWdIQSwrREFBZW9ELGNBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsTUFBTUksU0FBUyxHQUFHLE1BQU07QUFDdEIsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsSUFEUjtBQUVFLFVBQU0sRUFBQyxJQUZUO0FBR0UsV0FBTyxFQUFDLFdBSFY7QUFJRSxRQUFJLEVBQUMsTUFKUDtBQUtFLFNBQUssRUFBQyw0QkFMUjtBQU1FLGFBQVMsRUFBQyxpQ0FOWjtBQUFBLDJCQVFFO0FBQ0UsY0FBUSxFQUFDLFNBRFg7QUFFRSxjQUFRLEVBQUMsU0FGWDtBQUdFLE9BQUMsRUFBQyxvSEFISjtBQUlFLFVBQUksRUFBQztBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFpQkQsQ0FsQkQ7O0FBb0JBLE1BQU1DLE9BQXdCLEdBQUcsTUFBTTtBQUNyQyxzQkFDRTtBQUFLLGFBQVMsRUFBQywyQkFBZjtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLFVBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFDRSxpQkFBUyxFQUFDLG1HQURaO0FBRUUsYUFBSyxFQUFFO0FBQUVDLGFBQUcsRUFBRSxLQUFQO0FBQWNDLGdCQUFNLEVBQUU7QUFBdEIsU0FGVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRixlQVFFO0FBQUssaUJBQVMsRUFBQyxnQkFBZjtBQUFBLCtCQUNFLDhEQUFDLG1EQUFEO0FBQU8sYUFBRyxFQUFDLDhCQUFYO0FBQTBDLGdCQUFNLEVBQUM7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBYUU7QUFBSyxlQUFTLEVBQUMsOEVBQWY7QUFBQSw4QkFJRTtBQUFJLGlCQUFTLEVBQUMsdUNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkYsZUFPRTtBQUFLLGlCQUFTLEVBQUMscUNBQWY7QUFBQSx1REFDcUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQVVFO0FBQUssaUJBQVMsRUFBQywyQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFWRixlQWNFO0FBQUksaUJBQVMsRUFBQyxvREFBZDtBQUFBLGdDQUNFO0FBQUksbUJBQVMsRUFBQyxtQkFBZDtBQUFBLGtDQUNFLDhEQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFLRTtBQUFJLG1CQUFTLEVBQUMsbUJBQWQ7QUFBQSxrQ0FDRSw4REFBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUxGLGVBU0U7QUFBSSxtQkFBUyxFQUFDLG1CQUFkO0FBQUEsa0NBQ0UsOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFURixlQWFFO0FBQUksbUJBQVMsRUFBQyxtQkFBZDtBQUFBLGtDQUNFLDhEQUFDLFNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWRGLGVBZ0NFLDhEQUFDLCtDQUFEO0FBQVcsaUJBQVMsRUFBQyx3QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaENGLGVBbUNFO0FBQUssaUJBQVMsRUFBQyw0QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuQ0YsZUFzQ0U7QUFBSyxpQkFBUyxFQUFDLHFCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUEyREQsQ0E1REQ7O0FBOERBLCtEQUFlRixPQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFhQSxNQUFNRyxPQUF3QixHQUFHLFVBSzNCO0FBQUEsTUFMNEI7QUFDaEM1RixZQURnQztBQUVoQ0UsYUFGZ0M7QUFHaEMyRjtBQUhnQyxHQUs1QjtBQUFBLE1BRER0RixVQUNDOztBQUNKLFFBQU11RixhQUFhLEdBQUdyRixpREFBRSxDQUFDLENBQUNvRixTQUFELEdBQWEscUJBQWIsR0FBcUMsRUFBdEMsRUFBMEMzRixTQUExQyxDQUF4QjtBQUNBLHNCQUNFO0FBQVMsYUFBUyxFQUFFNEY7QUFBcEIsS0FBdUN2RixVQUF2QztBQUFBLGNBQ0dQO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBS0QsQ0FaRDs7QUFjQSwrREFBZTRGLE9BQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9CQTtBQUNBO0FBQ0E7QUFFQTs7QUFJQSxNQUFNRyxVQUEyQixHQUFHLE1BQU07QUFDeEMsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsS0FEUjtBQUVFLFVBQU0sRUFBQyxJQUZUO0FBR0UsV0FBTyxFQUFDLFlBSFY7QUFJRSxRQUFJLEVBQUMsTUFKUDtBQUtFLFNBQUssRUFBQyw0QkFMUjtBQUFBLDRCQU9FO0FBQ0UsY0FBUSxFQUFDLFNBRFg7QUFFRSxjQUFRLEVBQUMsU0FGWDtBQUdFLE9BQUMsRUFBQyxvbUNBSEo7QUFJRSxVQUFJLEVBQUM7QUFKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBGLGVBYUU7QUFDRSxjQUFRLEVBQUMsU0FEWDtBQUVFLGNBQVEsRUFBQyxTQUZYO0FBR0UsT0FBQyxFQUFDLHltQ0FISjtBQUlFLFVBQUksRUFBQztBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYkYsZUFtQkU7QUFDRSxjQUFRLEVBQUMsU0FEWDtBQUVFLGNBQVEsRUFBQyxTQUZYO0FBR0UsT0FBQyxFQUFDLHVtQ0FISjtBQUlFLFVBQUksRUFBQztBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbkJGLGVBeUJFO0FBQ0UsY0FBUSxFQUFDLFNBRFg7QUFFRSxjQUFRLEVBQUMsU0FGWDtBQUdFLE9BQUMsRUFBQyx1bUNBSEo7QUFJRSxVQUFJLEVBQUM7QUFKUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXpCRixlQStCRTtBQUNFLGNBQVEsRUFBQyxTQURYO0FBRUUsY0FBUSxFQUFDLFNBRlg7QUFHRSxPQUFDLEVBQUMsc21DQUhKO0FBSUUsVUFBSSxFQUFDO0FBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUF3Q0QsQ0F6Q0Q7O0FBMkNBLCtEQUFlQSxVQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsTUFBTUMsV0FBb0UsR0FBRyxDQUFDO0FBQzVFakYsT0FENEU7QUFFNUVmLFVBRjRFO0FBRzVFaUc7QUFINEUsQ0FBRCxLQUl2RTtBQUNKLHNCQUNFO0FBQ0UsYUFBUyxFQUFDLGdEQURaO0FBRUUsU0FBSyxFQUFFQSxLQUZUO0FBQUEsNEJBSUU7QUFBSyxlQUFTLEVBQUMsd0JBQWY7QUFBQSxnQkFBeUNsRjtBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBS0U7QUFBSyxlQUFTLEVBQUMsc0JBQWY7QUFBQSxnQkFBdUNmO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEYsZUFNRSw4REFBQyxnREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBVUQsQ0FmRDs7QUFpQkEsTUFBTXNFLFlBQVksR0FBRyxjQUNuQiw4REFBQyxXQUFEO0FBRUUsT0FBSyxFQUFDLG9CQUZSO0FBR0UsT0FBSyxFQUFFO0FBQ0xLLG1CQUFlLEVBQUU7QUFEWixHQUhUO0FBQUE7QUFBQSxHQUNNLGVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURtQixlQWFuQiw4REFBQyxXQUFEO0FBRUUsT0FBSyxFQUFDLHdCQUZSO0FBR0UsT0FBSyxFQUFFO0FBQUVBLG1CQUFlLEVBQUU7QUFBbkIsR0FIVDtBQUFBO0FBQUEsR0FDTSxlQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFibUIsZUF1Qm5CLDhEQUFDLFdBQUQ7QUFFRSxPQUFLLEVBQUMsd0JBRlI7QUFHRSxPQUFLLEVBQUU7QUFBRUEsbUJBQWUsRUFBRTtBQUFuQixHQUhUO0FBQUE7QUFBQSxHQUNNLGVBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXZCbUIsQ0FBckI7O0FBbUNBLE1BQU11QixZQUE2QixHQUFHLENBQUM7QUFBRWIsU0FBRjtBQUFXdEI7QUFBWCxDQUFELEtBQXVCO0FBQzNELHNCQUNFO0FBQUssYUFBUyxFQUFDLDJCQUFmO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsVUFBZjtBQUFBLDZCQUNFO0FBQUksaUJBQVMsRUFBQyxvREFBZDtBQUFBLGtCQUNLc0IsT0FBTyxHQUFHQSxPQUFILEdBQWE7QUFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFNRTtBQUFLLGVBQVMsRUFBQyw2RkFBZjtBQUFBLGdCQUNHZjtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFZRCxDQWJEOztBQWVBLCtEQUFlNEIsWUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0VBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBSUEsTUFBTVYsU0FBUyxHQUFHLE1BQU07QUFDdEIsc0JBQ0U7QUFDRSxTQUFLLEVBQUMsSUFEUjtBQUVFLFVBQU0sRUFBQyxJQUZUO0FBR0UsV0FBTyxFQUFDLFdBSFY7QUFJRSxRQUFJLEVBQUMsTUFKUDtBQUtFLFNBQUssRUFBQyw0QkFMUjtBQU1FLGFBQVMsRUFBQywrQ0FOWjtBQUFBLDJCQVFFO0FBQ0UsY0FBUSxFQUFDLFNBRFg7QUFFRSxjQUFRLEVBQUMsU0FGWDtBQUdFLE9BQUMsRUFBQyxvSEFISjtBQUlFLFVBQUksRUFBQztBQUpQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFpQkQsQ0FsQkQ7O0FBb0JBLE1BQU1XLGFBQXVCLEdBQUcsQ0FBQztBQUFFbkc7QUFBRixDQUFELEtBQWtCO0FBQ2hELHNCQUNFO0FBQUksYUFBUyxFQUFDLG1CQUFkO0FBQUEsNEJBQ0UsOERBQUMsU0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLEVBRUdBLFFBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFNRCxDQVBEOztBQVNBLE1BQU1vRyxXQUE0QixHQUFHLE1BQU07QUFDekMsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsMkJBQWY7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQyxpQkFBZjtBQUFBLDhCQUNFO0FBQUksaUJBQVMsRUFBQyxvREFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUlFO0FBQUssaUJBQVMsRUFBQywwQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFVRTtBQUFJLGVBQVMsRUFBQywwRUFBZDtBQUFBLDhCQUNFLDhEQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRSw4REFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBR0UsOERBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIRixlQUlFLDhEQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkYsZUFLRSw4REFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBTUUsOERBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORixlQU9FLDhEQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEYsZUFRRSw4REFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJGLGVBU0UsOERBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURixlQVVFLDhEQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVkYsZUFXRSw4REFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhGLGVBWUUsOERBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUEyQkQsQ0E1QkQ7O0FBOEJBLCtEQUFlQSxXQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25FQTs7QUFFQSxNQUFNQyxRQUFRLEdBQUcsbUJBQ2Y7QUFDRSxTQUFPLEVBQUMsYUFEVjtBQUVFLE9BQUssRUFBQyw0QkFGUjtBQUdFLFVBQVEsRUFBQyxTQUhYO0FBSUUsVUFBUSxFQUFDLFNBSlg7QUFLRSxnQkFBYyxFQUFDLE9BTGpCO0FBTUUsa0JBQWdCLEVBQUMsR0FObkI7QUFBQSx5QkFRRTtBQUNFLEtBQUMsRUFBQyw4U0FESjtBQUVFLFlBQVEsRUFBQyxTQUZYO0FBR0UsUUFBSSxFQUFDO0FBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERjs7QUFpQkEsK0RBQWVBLFFBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJBOztBQUVBLE1BQU1DLFNBQVMsR0FBRyxtQkFDaEI7QUFDRSxTQUFPLEVBQUMsYUFEVjtBQUVFLE9BQUssRUFBQyw0QkFGUjtBQUdFLFVBQVEsRUFBQyxTQUhYO0FBSUUsVUFBUSxFQUFDLFNBSlg7QUFLRSxnQkFBYyxFQUFDLE9BTGpCO0FBTUUsa0JBQWdCLEVBQUMsR0FObkI7QUFBQSx5QkFRRTtBQUFHLFlBQVEsRUFBQyxTQUFaO0FBQUEsNEJBQ0U7QUFDRSxPQUFDLEVBQUMsNnlEQURKO0FBRUUsVUFBSSxFQUFDO0FBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUtFO0FBQ0UsT0FBQyxFQUFDLGtkQURKO0FBRUUsVUFBSSxFQUFDO0FBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREY7O0FBc0JBLCtEQUFlQSxTQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCQTs7QUFFQSxNQUFNQyxRQUFRLEdBQUcsbUJBQ2Y7QUFDRSxTQUFPLEVBQUMsYUFEVjtBQUVFLE9BQUssRUFBQyw0QkFGUjtBQUdFLFVBQVEsRUFBQyxTQUhYO0FBSUUsVUFBUSxFQUFDLFNBSlg7QUFLRSxnQkFBYyxFQUFDLE9BTGpCO0FBTUUsa0JBQWdCLEVBQUMsR0FObkI7QUFBQSx5QkFRRTtBQUNFLEtBQUMsRUFBQywybkJBREo7QUFFRSxZQUFRLEVBQUMsU0FGWDtBQUdFLFFBQUksRUFBQztBQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREY7O0FBaUJBLCtEQUFlQSxRQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJBO0FBQ0E7QUFDQTtBQUNBO0NBY0E7O0FBNkRBO0FBQ0EsTUFBTUMsVUFBVSxnQkFBR0Msb0RBQWEsQ0FBYyxFQUFkLENBQWhDO0FBRU8sTUFBTUMsa0JBQWdDLEdBQUcsQ0FBQztBQUFFMUc7QUFBRixDQUFELEtBQWtCO0FBQ2hFLFFBQU07QUFBQSxPQUFDMkcsZ0JBQUQ7QUFBQSxPQUFtQkM7QUFBbkIsTUFBMEN6RiwrQ0FBUSxDQUFDLEVBQUQsQ0FBeEQ7QUFDQSxRQUFNO0FBQUEsT0FBQzBGLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CM0YsK0NBQVEsQ0FBQyxFQUFELENBQWxDO0FBQ0EsUUFBTTtBQUFBLE9BQUM0RixjQUFEO0FBQUEsT0FBaUJDO0FBQWpCLE1BQXNDN0YsK0NBQVEsQ0FBQyxFQUFELENBQXBEO0FBQ0EsUUFBTTtBQUFBLE9BQUM4RixZQUFEO0FBQUEsT0FBZUM7QUFBZixNQUFrQy9GLCtDQUFRLEVBQWhEO0FBQ0EsUUFBTTtBQUFBLE9BQUNnRyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQmpHLCtDQUFRLENBQUMsRUFBRCxDQUF4QztBQUNBLFFBQU07QUFBQSxPQUFDa0csU0FBRDtBQUFBLE9BQVlDO0FBQVosTUFBNEJuRywrQ0FBUSxDQUFDLEVBQUQsQ0FBMUM7QUFDQSxRQUFNO0FBQUEsT0FBQ29HLFFBQUQ7QUFBQSxPQUFXQztBQUFYLE1BQTBCckcsK0NBQVEsQ0FBQyxFQUFELENBQXhDO0FBQ0EsUUFBTTtBQUFBLE9BQUNzRyxLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQnZHLCtDQUFRLENBQUMsRUFBRCxDQUFsQztBQUNBLFFBQU07QUFBQSxPQUFDd0csT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0J6RywrQ0FBUSxDQUFDLEVBQUQsQ0FBdEM7QUFDQSxRQUFNO0FBQUEsT0FBQzBHLGtCQUFEO0FBQUEsT0FBcUJDO0FBQXJCLE1BQThDM0csK0NBQVEsQ0FBQyxDQUFELENBQTVEO0FBQ0EsUUFBTTtBQUFBLE9BQUM0RyxPQUFEO0FBQUEsT0FBVUM7QUFBVixNQUF3QjdHLCtDQUFRLENBQTBCLEVBQTFCLENBQXRDO0FBQ0EsUUFBTTtBQUFBLE9BQUM4RyxTQUFEO0FBQUEsT0FBWUM7QUFBWixNQUE0Qi9HLCtDQUFRLENBQU8sSUFBSWdILElBQUosRUFBUCxDQUExQztBQUNBLFFBQU07QUFBQSxPQUFDQyxZQUFEO0FBQUEsT0FBZUM7QUFBZixNQUFrQ2xILCtDQUFRLENBQUMsRUFBRCxDQUFoRDtBQUNBLFFBQU07QUFBQSxPQUFDbUgsS0FBRDtBQUFBLE9BQVFDO0FBQVIsTUFBb0JwSCwrQ0FBUSxDQUFDLEVBQUQsQ0FBbEM7QUFDQSxRQUFNO0FBQUEsT0FBQ3FILGFBQUQ7QUFBQSxPQUFnQkM7QUFBaEIsTUFBb0N0SCwrQ0FBUSxFQUFsRDtBQUVBLFFBQU07QUFBQSxPQUFDdUgsY0FBRDtBQUFBLE9BQWlCQztBQUFqQixNQUFzQ3hILCtDQUFRLENBQWlCO0FBQ25FeUgsVUFBTSxFQUFFLEVBRDJEO0FBRW5FQyxZQUFRLEVBQUUsSUFBSVYsSUFBSjtBQUZ5RCxHQUFqQixDQUFwRDtBQUtBLFFBQU1XLEtBQUssR0FBRztBQUNaQyxjQUFVLEVBQUU7QUFDVnBDLHNCQURVO0FBRVZDLHlCQUZVO0FBR1ZDLFdBSFU7QUFJVkMsY0FKVTtBQUtWQyxvQkFMVTtBQU1WQyx1QkFOVTtBQU9WRyxjQVBVO0FBUVZDLGlCQVJVO0FBU1ZDLGVBVFU7QUFVVkMsa0JBVlU7QUFXVkMsY0FYVTtBQVlWQyxpQkFaVTtBQWFWQyxXQWJVO0FBY1ZDLGNBZFU7QUFlVkMsYUFmVTtBQWdCVkMsZ0JBaEJVO0FBaUJWQyx3QkFqQlU7QUFrQlZDLDJCQWxCVTtBQW1CVkMsYUFuQlU7QUFvQlZDLGdCQXBCVTtBQXFCVkMsZUFyQlU7QUFzQlZDLGtCQXRCVTtBQXVCVkUsa0JBdkJVO0FBd0JWQyxxQkF4QlU7QUF5QlZDLFdBekJVO0FBMEJWQztBQTFCVSxLQURBO0FBNkJaUyxXQUFPLEVBQUVOLGNBN0JHO0FBOEJaQyxxQkFBaUIsRUFBRUEsaUJBOUJQO0FBK0JaMUIsZ0JBL0JZO0FBZ0NaQyxtQkFoQ1k7QUFpQ1pzQixpQkFqQ1k7QUFrQ1pDO0FBbENZLEdBQWQ7QUFvQ0Esc0JBQU8sOERBQUMsVUFBRCxDQUFZLFFBQVo7QUFBcUIsU0FBSyxFQUFFSyxLQUE1QjtBQUFBLGNBQW9DOUk7QUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFQO0FBQ0QsQ0EzRE07QUE2REEsU0FBU2lKLGFBQVQsR0FBeUI7QUFDOUIsU0FBT0MsaURBQVUsQ0FBYzFDLFVBQWQsQ0FBakI7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEpEO0FBQ0E7QUFDQTtBQWtCQTtBQUVBOztBQUVBLE1BQU0yQyxNQUFNLEdBQUlDLFFBQUQsSUFBc0I7QUFDbkMsTUFBSTNGLE1BQU0sQ0FBQzRGLFFBQVAsQ0FBZ0I3RyxJQUFoQixDQUFxQjhHLE9BQXJCLENBQTZCLDRCQUE3QixJQUE2RCxDQUFDLENBQWxFLEVBQXFFO0FBQ25FLFdBQVEseUJBQXdCRixRQUFTLEVBQXpDO0FBQ0Q7O0FBQ0QsUUFBTUcsT0FBTyxHQUNYQyxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsVUFBckIsS0FBb0NDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQywyQkFEbEQ7QUFFQSxTQUFRLEdBQUVMLE9BQVEsR0FBRUgsUUFBUyxFQUE3QjtBQUNELENBUEQ7O0FBU0EsTUFBTVMsY0FBYyxHQUFHLFlBQXZCOztBQUVBLE1BQU1DLFFBQU4sU0FBdUJDLEtBQXZCLENBQTZCO0FBRzNCQyxhQUFXLENBQUNDLE9BQUQsRUFBa0JDLFVBQWxCLEVBQXNDO0FBQy9DLFVBQU1ELE9BQU47O0FBRCtDOztBQUUvQyxTQUFLQyxVQUFMLEdBQWtCQSxVQUFsQjtBQUNEOztBQU4wQjs7QUFTN0IsTUFBTUMsUUFBUSxHQUFHLE9BQ2ZDLE1BRGUsRUFFZkMsR0FGZSxFQUdmQyxJQUhlLEtBSUE7QUFDZixRQUFNQyxLQUFLLEdBQUdDLG9EQUFBLENBQVlYLGNBQVosQ0FBZDtBQUNBLFFBQU1ZLE9BQW9CLEdBQUc7QUFBRSxvQkFBZ0I7QUFBbEIsR0FBN0I7O0FBQ0EsTUFBSUYsS0FBSixFQUFXO0FBQ1RFLFdBQU8sQ0FBQ0MsYUFBUixHQUF5QixVQUFTSCxLQUFNLEVBQXhDO0FBQ0Q7O0FBQ0QsUUFBTUksUUFBUSxHQUFHLE1BQU1DLEtBQUssQ0FBQ3pCLE1BQU0sQ0FBQ2tCLEdBQUQsQ0FBUCxFQUFjO0FBQ3hDSSxXQUR3QztBQUV4Q0wsVUFGd0M7QUFHeENFLFFBQUksRUFBRUEsSUFBSSxHQUFHTyxJQUFJLENBQUNDLFNBQUwsQ0FBZVIsSUFBZixDQUFILEdBQTBCMUg7QUFISSxHQUFkLENBQTVCO0FBS0EsUUFBTW1JLElBQUksR0FBRyxNQUFNSixRQUFRLENBQUNJLElBQVQsRUFBbkI7O0FBQ0EsTUFBSSxDQUFDSixRQUFRLENBQUNLLEVBQWQsRUFBa0I7QUFDaEIsVUFBTSxJQUFJbEIsUUFBSixDQUFhaUIsSUFBSSxDQUFDekMsS0FBTCxJQUFjcUMsUUFBUSxDQUFDTSxVQUFwQyxFQUFnRE4sUUFBUSxDQUFDTyxNQUF6RCxDQUFOO0FBQ0Q7O0FBQ0QsU0FBT0gsSUFBUDtBQUNELENBcEJEOztBQXNCQSxNQUFNSSxVQUFVLEdBQUcsT0FBVWQsR0FBVixFQUF1QkMsSUFBdkIsS0FBc0Q7QUFDdkUsUUFBTUMsS0FBSyxHQUFHQyxvREFBQSxDQUFZWCxjQUFaLENBQWQ7QUFDQSxRQUFNWSxPQUFPLEdBQUc7QUFBRUMsaUJBQWEsRUFBRyxVQUFTSCxLQUFNO0FBQWpDLEdBQWhCO0FBQ0EsUUFBTUgsTUFBTSxHQUFHLE1BQWY7QUFFQSxTQUFPUSxLQUFLLENBQUN6QixNQUFNLENBQUNrQixHQUFELENBQVAsRUFBYztBQUN4QkksV0FEd0I7QUFFeEJMLFVBRndCO0FBR3hCRTtBQUh3QixHQUFkLENBQUwsQ0FJSmhKLElBSkksQ0FJRXFKLFFBQUQsSUFBYztBQUNwQixRQUFJLENBQUNBLFFBQVEsQ0FBQ0ssRUFBZCxFQUFrQjtBQUNoQixZQUFNLElBQUlqQixLQUFKLENBQVVZLFFBQVEsQ0FBQ00sVUFBbkIsQ0FBTjtBQUNEOztBQUNELFdBQU9OLFFBQVEsQ0FBQ0ksSUFBVCxFQUFQO0FBQ0QsR0FUTSxDQUFQO0FBVUQsQ0FmRDs7QUFpQkEsTUFBTUssR0FBRyxHQUFHLE9BQ1ZoQyxRQURVLEVBRVZpQyxNQUZVLEtBR0s7QUFDZjtBQUNBLFFBQU1DLFdBQVcsR0FBRyxJQUFJQyxlQUFKLENBQW9CRixNQUFwQixFQUE0QkcsUUFBNUIsRUFBcEI7QUFDQSxRQUFNbkIsR0FBRyxHQUFHaUIsV0FBVyxDQUFDeEosTUFBWixHQUFxQixDQUFyQixHQUEwQixHQUFFc0gsUUFBUyxJQUFHa0MsV0FBWSxFQUFwRCxHQUF3RGxDLFFBQXBFO0FBQ0EsU0FBTyxNQUFNZSxRQUFRLENBQUMsS0FBRCxFQUFRRSxHQUFSLEVBQWF6SCxTQUFiLENBQXJCO0FBQ0QsQ0FSRDs7QUFVQSxNQUFNNkksSUFBSSxHQUFHLE9BQVVwQixHQUFWLEVBQXVCcUIsT0FBdkIsS0FBdUQ7QUFDbEUsU0FBTyxNQUFNdkIsUUFBUSxDQUFDLE1BQUQsRUFBU0UsR0FBVCxFQUFjcUIsT0FBZCxDQUFyQjtBQUNELENBRkQ7O0FBSU8sTUFBTXJLLFNBQVMsR0FBRyxZQUFZO0FBQ25DLFNBQU8sTUFBTStKLEdBQUcsQ0FBNkIsYUFBN0IsQ0FBSCxDQUNWOUosSUFEVSxDQUNKcUssQ0FBRCxJQUFPQSxDQUFDLENBQUMxSyxNQURKLEVBRVZLLElBRlUsQ0FFSkwsTUFBRCxJQUFZQSxNQUFNLENBQUMySyxJQUFQLENBQVksQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVVELENBQUMsQ0FBQ25LLElBQUYsQ0FBT3FLLGFBQVAsQ0FBcUJELENBQUMsQ0FBQ3BLLElBQXZCLENBQXRCLENBRlAsQ0FBYjtBQUdELENBSk07QUFNQSxNQUFNc0ssUUFBUSxHQUFHLE9BQ3RCQyxZQURzQixLQUVGO0FBQ3BCLFFBQU07QUFBRUM7QUFBRixNQUF1QkQsWUFBN0I7QUFBQSxRQUFvQjNCLElBQXBCLDRCQUE2QjJCLFlBQTdCOztBQUNBLFNBQU8sTUFBTVIsSUFBSSxDQUFvQixhQUFwQixFQUFtQ1EsWUFBbkMsQ0FBSixDQUFxRDNLLElBQXJELENBQ1ZxSyxDQUFELElBQU9BLENBQUMsQ0FBQ3BCLEtBREUsQ0FBYjtBQUdELENBUE07QUFTQSxNQUFNNEIsVUFBVSxHQUFHLE1BQU9DLElBQVAsSUFBeUM7QUFDakUsU0FBTyxNQUFNWCxJQUFJLENBQWlCLGtCQUFqQixFQUFxQztBQUNwRDFELFdBQU8sRUFBRXFFO0FBRDJDLEdBQXJDLENBQUosQ0FFVjlLLElBRlUsQ0FFSnFLLENBQUQsSUFBT0EsQ0FBQyxDQUFDVSxFQUZKLENBQWI7QUFHRCxDQUpNO0FBTUEsTUFBTUMsYUFBYSxHQUFHLE1BQU9DLFNBQVAsSUFBOEM7QUFDekUsU0FBTyxNQUFNZCxJQUFJLENBQUMsNkJBQUQsRUFBZ0M7QUFBRWM7QUFBRixHQUFoQyxDQUFqQjtBQUNELENBRk07QUFJQSxNQUFNQyxrQkFBa0IsR0FBRyxNQUFPQyxXQUFQLElBQStCO0FBQy9ELFNBQU8sTUFBTXJCLEdBQUcsQ0FBZ0IsK0JBQWhCLEVBQWlEO0FBQy9EcUI7QUFEK0QsR0FBakQsQ0FBaEI7QUFHRCxDQUpNO0FBTUEsTUFBTUMsVUFBVSxHQUFHLE1BQU81RCxLQUFQLElBQXlCO0FBQ2pELFNBQU8sTUFBTTJDLElBQUksQ0FBeUIsMEJBQXpCLEVBQXFEO0FBQ3BFM0M7QUFEb0UsR0FBckQsQ0FBSixDQUVWeEgsSUFGVSxDQUVKcUssQ0FBRCxJQUFPQSxDQUFDLENBQUNnQixTQUZKLENBQWI7QUFHRCxDQUpNO0FBTUEsTUFBTUMsUUFBUSxHQUFHLE1BQU9DLEdBQVAsSUFBdUI7QUFDN0MsU0FBTyxNQUFNekIsR0FBRyxDQUF5QixnQkFBekIsRUFBMkM7QUFDekR5QjtBQUR5RCxHQUEzQyxDQUFILENBRVZ2TCxJQUZVLENBRUpxSyxDQUFELElBQU9BLENBQUMsQ0FBQ2dCLFNBRkosQ0FBYjtBQUdELENBSk07QUFNQSxNQUFNRyxZQUFZLEdBQUcsT0FBT2pHLEtBQVAsRUFBc0JpQyxLQUF0QixLQUF3QztBQUNsRSxTQUFPLE1BQU0yQyxJQUFJLENBQUMsb0JBQUQsRUFBdUI7QUFBRTVFLFNBQUY7QUFBU2lDO0FBQVQsR0FBdkIsQ0FBakI7QUFDRCxDQUZNO0FBSUEsTUFBTWlFLGVBQWUsR0FBRyxZQUFZO0FBQ3pDLFNBQU8sTUFBTTNCLEdBQUcsQ0FBdUIsMkJBQXZCLENBQWhCO0FBQ0QsQ0FGTTtBQUlBLE1BQU00QixxQkFBcUIsR0FBRyxNQUFPQyxhQUFQLElBQWtDO0FBQ3JFLFNBQU8sTUFBTTdCLEdBQUcsQ0FBMkIsNEJBQTNCLEVBQXlEO0FBQ3ZFNkI7QUFEdUUsR0FBekQsQ0FBSCxDQUVWM0wsSUFGVSxDQUVKcUssQ0FBRCxJQUFPQSxDQUFDLENBQUN1QixZQUZKLENBQWI7QUFHRCxDQUpNO0FBTUEsTUFBTUMsY0FBYyxHQUFHLE1BQU9DLGVBQVAsSUFBbUM7QUFDL0QsU0FBTyxNQUFNM0IsSUFBSSxDQUFDLDhCQUFELEVBQWlDO0FBQ2hEMkI7QUFEZ0QsR0FBakMsQ0FBakI7QUFHRCxDQUpNO0FBTUEsTUFBTUMsbUJBQW1CLEdBQUcsTUFBT0MsZUFBUCxJQUFtQztBQUNwRSxTQUFPLE1BQU03QixJQUFJLENBQUMsb0NBQUQsRUFBdUM7QUFBRTZCO0FBQUYsR0FBdkMsQ0FBakI7QUFDRCxDQUZNO0FBSUEsTUFBTUMsS0FBSyxHQUFHLE9BQ25CMUcsS0FEbUIsRUFFbkIyRyxRQUZtQixLQUdDO0FBQ3BCLFNBQU8sTUFBTS9CLElBQUksQ0FBb0IsWUFBcEIsRUFBa0M7QUFBRTVFLFNBQUY7QUFBUzJHO0FBQVQsR0FBbEMsQ0FBSixDQUEyRGxNLElBQTNELENBQ1ZxSyxDQUFELElBQU9BLENBQUMsQ0FBQ3BCLEtBREUsQ0FBYjtBQUdELENBUE07QUFTQSxNQUFNa0QsU0FBUyxHQUFHLE1BQU9ELFFBQVAsSUFBNkM7QUFDcEUsU0FBTyxNQUFNL0IsSUFBSSxDQUFvQixnQkFBcEIsRUFBc0M7QUFBRStCO0FBQUYsR0FBdEMsQ0FBSixDQUF3RGxNLElBQXhELENBQ1ZxSyxDQUFELElBQU9BLENBQUMsQ0FBQ3BCLEtBREUsQ0FBYjtBQUdELENBSk07QUFNQSxNQUFNbUQsT0FBTyxHQUFHLE1BQU83RyxLQUFQLElBQTBDO0FBQy9ELFNBQU8sTUFBTTRFLElBQUksQ0FBb0IsZUFBcEIsRUFBcUM7QUFBRTVFO0FBQUYsR0FBckMsQ0FBSixDQUFvRHZGLElBQXBELENBQ1ZxSyxDQUFELElBQU9BLENBQUMsQ0FBQ3BCLEtBREUsQ0FBYjtBQUdELENBSk07QUFNQSxNQUFNb0QsZUFBZSxHQUFHLE1BQU8vRSxNQUFQLElBQTBCO0FBQ3ZELFNBQU8sTUFBTTZDLElBQUksQ0FBQyxtQ0FBRCxFQUFzQztBQUNyRDdDO0FBRHFELEdBQXRDLENBQWpCO0FBR0QsQ0FKTTtBQU1BLE1BQU1nRixzQkFBc0IsR0FBRyxZQUFZO0FBQ2hELFNBQU8sTUFBTXhDLEdBQUcsQ0FDZCxtQ0FEYyxDQUFoQjtBQUdELENBSk07QUFNQSxNQUFNeUMsdUJBQXVCLEdBQUcsWUFBWTtBQUNqRCxTQUFPLE1BQU16QyxHQUFHLENBQ2Qsb0NBRGMsQ0FBSCxDQUVYOUosSUFGVyxDQUVMcUssQ0FBRCxJQUFPQSxDQUFDLENBQUNtQyxvQkFGSCxDQUFiO0FBR0QsQ0FKTTtBQU1BLE1BQU1DLFVBQVUsR0FBRyxZQUFZO0FBQ3BDLFNBQU8sTUFBTTNDLEdBQUcsQ0FBYyxpQkFBZCxDQUFoQjtBQUNELENBRk07QUFJQSxNQUFNNEMsV0FBVyxHQUFHLE1BQU9uSCxLQUFQLElBQXlCO0FBQ2xELFNBQU8sTUFBTTRFLElBQUksQ0FBQywyQkFBRCxFQUE4QjtBQUFFNUU7QUFBRixHQUE5QixDQUFqQjtBQUNELENBRk07QUFJQSxNQUFNb0gsYUFBYSxHQUFHLE9BQU9DLE9BQVAsRUFBeUJDLFlBQVksR0FBRyxLQUF4QyxLQUFrRDtBQUM3RSxTQUFPLE1BQU0xQyxJQUFJLENBQUMsNkJBQUQsa0NBQ1p5QyxPQURZO0FBRWZDO0FBRmUsS0FBakI7QUFJRCxDQUxNO0FBT0EsTUFBTUMsV0FBVyxHQUFHLE1BQU8zRyxLQUFQLElBQXlCO0FBQ2xELFNBQU8sTUFBTWdFLElBQUksQ0FBQywyQkFBRCxFQUE4QjtBQUFFaEU7QUFBRixHQUE5QixDQUFqQjtBQUNELENBRk07QUFJQSxNQUFNNEcsU0FBUyxHQUFHLE1BQU9DLElBQVAsSUFBc0I7QUFDN0MsU0FBTyxNQUFNN0MsSUFBSSxDQUFDLCtCQUFELEVBQWtDO0FBQ2pEeEQsYUFBUyxFQUFFc0cseURBQWtCLENBQUNELElBQUQ7QUFEb0IsR0FBbEMsQ0FBakI7QUFHRCxDQUpNO0FBTUEsTUFBTUUsc0JBQXNCLEdBQUcsT0FDcENuRCxNQURvQyxLQUVqQztBQUNILFNBQU8sTUFBTUksSUFBSSxDQUNmLGdDQURlLEVBRWZKLE1BRmUsQ0FBakI7QUFJRCxDQVBNO0FBU0EsTUFBTW9ELGNBQWMsR0FBRyxNQUFPNUgsS0FBUCxJQUF5QjtBQUNyRCxTQUFPLE1BQU00RSxJQUFJLENBQUMsc0JBQUQsRUFBeUI7QUFBRTVFO0FBQUYsR0FBekIsQ0FBakI7QUFDRCxDQUZNO0FBSUEsTUFBTTZILGFBQWEsR0FBRyxPQUFPbkUsS0FBUCxFQUFzQmlELFFBQXRCLEtBQTJDO0FBQ3RFLFNBQU8sTUFBTS9CLElBQUksQ0FBQyxxQkFBRCxFQUF3QjtBQUFFbEIsU0FBRjtBQUFTaUQ7QUFBVCxHQUF4QixDQUFqQjtBQUNELENBRk07QUFJQSxNQUFNbUIsV0FBVyxHQUFHLE1BQU94SCxRQUFQLElBQTRCO0FBQ3JELFNBQU8sTUFBTWlFLEdBQUcsQ0FDYix3QkFBdUJqRSxRQUFTLEVBRG5CLENBQWhCO0FBR0QsQ0FKTTtBQU1BLE1BQU15SCxtQkFBbUIsR0FBRyxZQUFZO0FBQzdDLFNBQU8sTUFBTXhELEdBQUcsQ0FBbUIscUJBQW5CLENBQWhCO0FBQ0QsQ0FGTTtBQUlBLE1BQU15RCxRQUFRLEdBQUcsTUFBT0MsU0FBUCxJQUE2QjtBQUNuRCxTQUFPLE1BQU1yRCxJQUFJLENBQUMsd0JBQUQsRUFBMkI7QUFBRXFEO0FBQUYsR0FBM0IsQ0FBakI7QUFDRCxDQUZNO0FBSUEsTUFBTUMsZUFBZSxHQUFHLE1BQU8xRCxNQUFQLElBQXNDO0FBQ25FLFNBQU8sTUFBTUksSUFBSSxDQUFDLG9CQUFELEVBQXVCSixNQUF2QixDQUFqQjtBQUNELENBRk07QUFJQSxNQUFNMkQsU0FBUyxHQUFHLE1BQU9DLFFBQVAsSUFBNEI7QUFDbkQsU0FBTzdELEdBQUcsQ0FBVSxlQUFjNkQsUUFBUyxFQUFqQyxDQUFWO0FBQ0QsQ0FGTTtBQUlBLE1BQU1DLFdBQVcsR0FBRyxPQUFPRCxRQUFQLEVBQXlCRSxPQUF6QixLQUE2QztBQUN0RSxTQUFPMUQsSUFBSSxDQUFFLGVBQWN3RCxRQUFTLEVBQXpCLEVBQTRCO0FBQUVFO0FBQUYsR0FBNUIsQ0FBWDtBQUNELENBRk07QUFJQSxNQUFNQyxRQUFRLEdBQUcsWUFBWTtBQUNsQyxTQUFPaEUsR0FBRyxDQUFRLGVBQVIsQ0FBVjtBQUNELENBRk07QUFJQSxNQUFNaUUscUJBQXFCLEdBQUcsWUFBWTtBQUMvQyxTQUFPakUsR0FBRyxDQUE2QixzQkFBN0IsQ0FBSCxDQUF3RDlKLElBQXhELENBQ0pxSyxDQUFELElBQU9BLENBQUMsQ0FBQzJELGNBREosQ0FBUDtBQUdELENBSk07QUFNQSxNQUFNQyxtQkFBbUIsR0FBRyxNQUFPeEgsT0FBUCxJQUEyQjtBQUM1RCxTQUFPLE1BQU0wRCxJQUFJLENBQWlCLDRCQUFqQixFQUErQztBQUFFMUQ7QUFBRixHQUEvQyxDQUFqQjtBQUNELENBRk07QUFJQSxNQUFNeUgsY0FBYyxHQUFHLE1BQU9DLFFBQVAsSUFBcUM7QUFDakUsU0FBTyxNQUFNaEUsSUFBSSxDQUFDLG9CQUFELEVBQXVCZ0UsUUFBdkIsQ0FBakI7QUFDRCxDQUZNO0FBSUEsTUFBTUMsZUFBZSxHQUFHLE9BQU9oTyxJQUFQLEVBQXFCbUYsS0FBckIsS0FBdUM7QUFDcEUsU0FBTyxNQUFNNEUsSUFBSSxDQUFtQixvQkFBbkIsRUFBeUM7QUFDeEQvSixRQUR3RDtBQUV4RG1GO0FBRndELEdBQXpDLENBQUosQ0FHVnZGLElBSFUsQ0FHSnFLLENBQUQsSUFBT0EsQ0FBQyxDQUFDZ0UsSUFISixDQUFiO0FBSUQsQ0FMTTtBQU9BLE1BQU1DLGlCQUFpQixHQUFHLE9BQU92RSxNQUFQLEtBTTNCO0FBQ0osU0FBTyxNQUFNSSxJQUFJLENBQUMsbUJBQUQsRUFBc0JKLE1BQXRCLENBQWpCO0FBQ0QsQ0FSTTtBQVVBLE1BQU13RSxnQkFBZ0IsR0FBRyxZQUFZO0FBQzFDLFNBQU8sTUFBTXpFLEdBQUcsQ0FDZCw0QkFEYyxDQUFILENBRVg5SixJQUZXLENBRUxxSyxDQUFELElBQU9BLENBQUMsQ0FBQ21FLGFBRkgsQ0FBYjtBQUdELENBSk07QUFNQSxNQUFNQyxhQUFhLEdBQUcsTUFBT0MsUUFBUCxJQUE0QjtBQUN2RCxTQUFPLE1BQU01RSxHQUFHLENBQW9CLGtCQUFwQixFQUF3QztBQUFFNEU7QUFBRixHQUF4QyxDQUFILENBQXlEMU8sSUFBekQsQ0FDVnFLLENBQUQsSUFBT0EsQ0FBQyxDQUFDcEIsS0FERSxDQUFiO0FBR0QsQ0FKTTtBQU1BLE1BQU0wRixhQUFhLEdBQUcsT0FBTzVFLE1BQVAsS0FJdkI7QUFDSixTQUFPLE1BQU1ELEdBQUcsQ0FDZCx5QkFEYyxFQUVkQyxNQUZjLENBQUgsQ0FHWC9KLElBSFcsQ0FHTHFLLENBQUQsSUFBT0EsQ0FBQyxDQUFDdUUsVUFISCxDQUFiO0FBSUQsQ0FUTTtBQVdBLE1BQU1DLFdBQVcsR0FBRyxNQUFPQyxVQUFQLElBQThCO0FBQ3ZELFNBQU8sTUFBTTNFLElBQUksQ0FBQyx1QkFBRCxFQUEwQjtBQUFFMkU7QUFBRixHQUExQixDQUFqQjtBQUNELENBRk07QUFJQSxNQUFNQyxXQUFXLEdBQUcsWUFBWTtBQUNyQyxTQUFPLE1BQU1qRixHQUFHLENBQVcsdUJBQVgsQ0FBaEI7QUFDRCxDQUZNO0FBSUEsTUFBTWtGLDJCQUEyQixHQUFHLE9BQ3pDNU8sSUFEeUMsRUFFekMrRixLQUZ5QyxFQUd6Q1osS0FIeUMsRUFJekMwSixZQUp5QyxLQUt0QztBQUNILFNBQU8sTUFBTTlFLElBQUksQ0FBQyx5QkFBRCxFQUE0QjtBQUMzQy9KLFFBRDJDO0FBRTNDK0YsU0FGMkM7QUFHM0NaLFNBSDJDO0FBSTNDMEo7QUFKMkMsR0FBNUIsQ0FBakI7QUFNRCxDQVpNO0FBY0EsTUFBTUMsd0JBQXdCLEdBQUcsT0FDdEM5TyxJQURzQyxFQUV0QytGLEtBRnNDLEVBR3RDWixLQUhzQyxFQUl0QzBKLFlBSnNDLEtBS25DO0FBQ0gsU0FBTyxNQUFNOUUsSUFBSSxDQUFDLCtCQUFELEVBQWtDO0FBQ2pEL0osUUFEaUQ7QUFFakQrRixTQUZpRDtBQUdqRFosU0FIaUQ7QUFJakQwSjtBQUppRCxHQUFsQyxDQUFqQjtBQU1ELENBWk07QUFjQSxNQUFNRSxzQkFBc0IsR0FBRyxZQUFZO0FBQ2hELFNBQU8sTUFBTWhGLElBQUksQ0FBQyxrQ0FBRCxFQUFxQyxFQUFyQyxDQUFqQjtBQUNELENBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3V1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFTyxNQUFNaEgsUUFBUSxHQUFHLE1BQU07QUFDNUIsUUFBTWlNLE1BQU0sR0FBR0Msc0RBQVMsRUFBeEI7QUFDQSxRQUFNO0FBQUUxSixnQkFBRjtBQUFnQkM7QUFBaEIsTUFBb0MrQixrRUFBYSxFQUF2RDtBQUNBN0gsa0RBQVMsQ0FBQyxNQUFNO0FBQ2QsUUFBSXdQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZSCxNQUFNLENBQUNJLEtBQW5CLEVBQTBCaFAsTUFBMUIsR0FBbUMsQ0FBdkMsRUFBMEM7QUFDeEMsWUFBTTtBQUFFaVA7QUFBRixVQUFZTCxNQUFNLENBQUNJLEtBQXpCOztBQUNBLFVBQUlDLEtBQUosRUFBVztBQUNUN0osdUJBQWUsQ0FBQzZKLEtBQUQsQ0FBZjtBQUNEO0FBQ0Y7QUFDRixHQVBRLEVBT04sQ0FBQ0wsTUFBTSxDQUFDSSxLQUFSLENBUE0sQ0FBVDtBQVFBLFFBQU10TSxTQUFTLEdBQUcsb0NBQWxCO0FBQ0EsU0FBTztBQUFFeUMsZ0JBQUY7QUFBZ0J6QztBQUFoQixHQUFQO0FBQ0QsQ0FiTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1RQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFTyxNQUFNRCxNQUFNLEdBQUcsTUFBTTtBQUMxQixRQUFNbU0sTUFBTSxHQUFHQyxzREFBUyxFQUF4QjtBQUNBLFFBQU07QUFBRW5JLGlCQUFGO0FBQWlCQztBQUFqQixNQUFzQ1Esa0VBQWEsRUFBekQ7QUFDQTdILGtEQUFTLENBQUMsTUFBTTtBQUNkLFFBQUlvSCxhQUFKLGFBQUlBLGFBQUosZUFBSUEsYUFBYSxDQUFFd0ksU0FBbkIsRUFBOEI7QUFDNUI7QUFDRDs7QUFDRCxRQUFJSixNQUFNLENBQUNDLElBQVAsQ0FBWUgsTUFBTSxDQUFDSSxLQUFuQixFQUEwQmhQLE1BQTFCLEdBQW1DLENBQXZDLEVBQTBDO0FBQ3hDLFlBQU07QUFBRWhDLFdBQUcsRUFBRW1SO0FBQVAsVUFBd0JQLE1BQU0sQ0FBQ0ksS0FBckM7O0FBQ0EsVUFBSSxDQUFDRyxZQUFMLEVBQW1CO0FBQ2pCLGNBQU07QUFDSkMsb0JBREk7QUFFSkMsb0JBRkk7QUFHSkMsc0JBSEk7QUFJSkMscUJBSkk7QUFLSkMsa0JBTEk7QUFNSkM7QUFOSSxZQU9GYixNQUFNLENBQUNJLEtBUFg7QUFRQXJJLHdCQUFnQixDQUFDO0FBQ2Z1SSxtQkFBUyxFQUFFRSxVQURJO0FBRWZNLG1CQUFTLEVBQUVMLFVBRkk7QUFHZk0scUJBQVcsRUFBRUwsWUFIRTtBQUlmTSxvQkFBVSxFQUFFTCxXQUpHO0FBS2ZNLGlCQUFPLEVBQUVMLFFBQVEsSUFBSUMsSUFMTjtBQU1mSyxnQkFBTSxFQUFFbEIsTUFBTSxDQUFDbUI7QUFOQSxTQUFELENBQWhCO0FBUUQsT0FqQkQsTUFpQk87QUFDTHBKLHdCQUFnQixDQUFDO0FBQ2Z1SSxtQkFBUyxFQUFFLGVBREk7QUFFZlEsbUJBQVMsRUFBRSxXQUZJO0FBR2ZDLHFCQUFXLEVBQUUsbUJBSEU7QUFJZkMsb0JBQVUsRUFBRVQ7QUFKRyxTQUFELENBQWhCO0FBTUQ7QUFDRjtBQUNGLEdBaENRLEVBZ0NOLENBQUNQLE1BQU0sQ0FBQ0ksS0FBUixDQWhDTSxDQUFUO0FBaUNELENBcENNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNUUDtBQUNBO0FBQ0E7QUFFTyxNQUFNZ0IsWUFBWSxHQUFJakwsS0FBRCxJQUE0QjtBQUN0RCxTQUFPLDZCQUE2QmtMLElBQTdCLENBQWtDbEwsS0FBbEMsQ0FBUDtBQUNELENBRk07QUFJQSxNQUFNbUwsYUFBYSxHQUFJQyxDQUFELElBQWU7QUFDMUMsU0FDRUEsQ0FBQyxJQUNBQSxDQUFDLEdBQUcsQ0FBSixHQUNHLENBQUMsSUFBRCxFQUFPLElBQVAsRUFBYSxJQUFiLEVBQW1CLElBQW5CLEVBQTBCQSxDQUFDLEdBQUcsQ0FBSixJQUFTQSxDQUFDLEdBQUcsRUFBZCxJQUFxQkEsQ0FBQyxHQUFHLEVBQUosR0FBUyxDQUE5QixHQUFrQyxDQUFsQyxHQUFzQ0EsQ0FBQyxHQUFHLEVBQW5FLENBREgsR0FFRyxFQUhILENBREg7QUFNRCxDQVBNO0FBU0EsTUFBTUMsZ0JBQWdCLEdBQUk1RCxJQUFELElBQWdCO0FBQzlDLFNBQU9BLElBQUksQ0FBQzZELGtCQUFMLENBQXdCLE9BQXhCLEVBQWlDO0FBQ3RDQyxRQUFJLEVBQUUsU0FEZ0M7QUFFdENDLFVBQU0sRUFBRSxJQUY4QjtBQUd0Q0MsVUFBTSxFQUFFLFNBSDhCLENBSXRDOztBQUpzQyxHQUFqQyxDQUFQO0FBTUQsQ0FQTTtBQVNBLE1BQU1DLGNBQWMsR0FBSWpFLElBQUQsSUFBZ0I7QUFDNUMsU0FBUSxHQUFFMEQsYUFBYSxDQUFDMUQsSUFBSSxDQUFDa0UsT0FBTCxFQUFELENBQWlCLEVBQXhDO0FBQ0QsQ0FGTTtBQUlBLE1BQU1DLFVBQVUsR0FBSW5FLElBQUQsSUFBZ0I7QUFDeEMsU0FBT0EsSUFBSSxDQUFDb0Usa0JBQUwsQ0FBd0IsU0FBeEIsRUFBbUM7QUFBRUMsV0FBTyxFQUFFO0FBQVgsR0FBbkMsQ0FBUDtBQUNELENBRk07QUFJQSxNQUFNQyxZQUFZLEdBQUl0RSxJQUFELElBQWdCO0FBQzFDLFNBQU9BLElBQUksQ0FBQ3VFLGNBQUwsQ0FBb0IsU0FBcEIsRUFBK0I7QUFBRUMsU0FBSyxFQUFFO0FBQVQsR0FBL0IsQ0FBUDtBQUNELENBRk07QUFJQSxNQUFNQyxpQkFBaUIsR0FBSXRMLEtBQUQsSUFDL0JBLEtBQUssQ0FBQ3VMLE9BQU4sQ0FBYyxNQUFkLEVBQXNCLEVBQXRCLEVBQTBCQSxPQUExQixDQUFrQyx1QkFBbEMsRUFBMkQsWUFBM0QsQ0FESztBQUdBLE1BQU1DLFVBQVUsR0FBSXhSLENBQUQsSUFDeEIsQ0FBQ0EsQ0FBQyxDQUFDeVIsTUFBRixDQUFTLENBQVQsRUFBWUMsV0FBWixLQUE0QjFSLENBQUMsQ0FBQ0csS0FBRixDQUFRLENBQVIsQ0FBN0IsRUFBeUN3UixJQUF6QyxFQURLO0FBR0EsTUFBTUMsdUJBQXVCLEdBQUcsTUFDckMsSUFBSWxMLElBQUosR0FDR2dLLGtCQURILENBQ3NCLE9BRHRCLEVBQytCO0FBQUVtQixjQUFZLEVBQUU7QUFBaEIsQ0FEL0IsRUFFR0MsS0FGSCxDQUVTLEdBRlQsRUFFYyxDQUZkLENBREs7QUFLQSxNQUFNQyxlQUFlLEdBQUcsTUFDN0JDLElBQUksQ0FBQ0MsY0FBTCxHQUFzQkMsZUFBdEIsR0FBd0NDLFFBRG5DO0FBR0EsTUFBTXJGLGtCQUFrQixHQUFJRCxJQUFELElBQXdCO0FBQ3hELFFBQU11RixPQUFPLEdBQUcxTCxJQUFJLENBQUMyTCxHQUFMLENBQVN4RixJQUFJLENBQUN5RixXQUFMLEVBQVQsRUFBNkJ6RixJQUFJLENBQUMwRixRQUFMLEVBQTdCLEVBQThDMUYsSUFBSSxDQUFDMkYsVUFBTCxFQUE5QyxDQUFoQjtBQUNBLFNBQU8sSUFBSTlMLElBQUosQ0FBUzBMLE9BQVQsRUFBa0JLLFdBQWxCLEVBQVA7QUFDRCxDQUhNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcERQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBSUEsTUFBTUMsTUFBTSxHQUFHQyx3REFBWSxDQUFDO0FBQzFCQyxPQUFLLEVBQUUzSyxPQUFPLENBQUNDLEdBQVIsQ0FBWTJLLG1CQURPO0FBRTFCQyxhQUFXLEVBQUU3SyxPQUFPLENBQUNDLEdBQVIsQ0FBWTZLO0FBRkMsQ0FBRCxDQUEzQjs7QUFLQSxNQUFNQyxTQUEwQixHQUFJNVUsS0FBRCxJQUFXO0FBQzVDLHNCQUNFLDhEQUFDLHdFQUFEO0FBQWlCLFFBQUksRUFBRUEsS0FBdkI7QUFBQSw0QkFDRTtBQUFJLGVBQVMsRUFBQyxtQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUlFO0FBQUssZUFBUyxFQUFDLHlDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBUUUsOERBQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUkYsZUFTRTtBQUFLLGVBQVMsRUFBQyxxQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBaEJEOztBQWtCTyxlQUFlNlUsY0FBZixHQUFnQztBQUN0QyxRQUFNQyxHQUFHLEdBQUcsTUFBTVIsTUFBTSxDQUFDUyxVQUFQLENBQWtCO0FBQUVDLGdCQUFZLEVBQUUsS0FBaEI7QUFBdUJDLFNBQUssRUFBRTtBQUE5QixHQUFsQixDQUFsQjtBQUVBLFFBQU07QUFBRUM7QUFBRixNQUFZLE1BQU1aLE1BQU0sQ0FBQ1MsVUFBUCxDQUFrQjtBQUN2Q0MsZ0JBQVksRUFBRSxNQUR5QjtBQUV2QyxtQkFBZTtBQUZ3QixHQUFsQixDQUF4QjtBQUlDLFNBQU87QUFDTGhWLFNBQUssRUFBRTtBQUNMaUIsU0FBRyxFQUFFNlQsR0FBRyxDQUFDSSxLQURKO0FBRUw3USxVQUFJLEVBQUU2USxLQUFLLENBQUMsQ0FBRDtBQUZOLEtBREY7QUFLTEMsY0FBVSxFQUFFO0FBTFAsR0FBUDtBQU9EO0FBRUQsK0RBQWVQLFNBQWYsRTs7Ozs7Ozs7Ozs7QUNqRGE7O0FBQUEsSUFBSVEsc0JBQXNCLEdBQUNDLG1CQUFPLENBQUMsdUlBQUQsQ0FBbEM7O0FBQW1GQyxrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsZUFBQSxHQUFnQkMsS0FBaEI7O0FBQXNCLElBQUlDLDhCQUE4QixHQUFDSixzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyxxSkFBRCxDQUFSLENBQXpEOztBQUEwSCxJQUFJSSxTQUFTLEdBQUNMLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLDJHQUFELENBQVIsQ0FBcEM7O0FBQWdGLElBQUlLLE1BQU0sR0FBQ04sc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBUixDQUFqQzs7QUFBb0QsSUFBSU0sS0FBSyxHQUFDUCxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyx3REFBRCxDQUFSLENBQWhDOztBQUFxRSxJQUFJTyxPQUFPLEdBQUNQLG1CQUFPLENBQUMsb0VBQUQsQ0FBbkI7O0FBQXFELElBQUlRLFlBQVksR0FBQ1IsbUJBQU8sQ0FBQyw4RUFBRCxDQUF4Qjs7QUFBK0QsSUFBSVMsZ0JBQWdCLEdBQUNULG1CQUFPLENBQUMsZ0ZBQUQsQ0FBNUI7O0FBQW1ELFVBQStCO0FBQUM7QUFBQ1UsUUFBTSxDQUFDQyxxQkFBUCxHQUE2QixJQUE3QjtBQUFtQzs7QUFBQSxNQUFNQyxvQkFBb0IsR0FBQyxDQUFDLE1BQUQsRUFBUSxPQUFSLEVBQWdCbFQsU0FBaEIsQ0FBM0I7QUFBc0QsTUFBTW1ULE9BQU8sR0FBQyxJQUFJQyxHQUFKLENBQVEsQ0FBQyxDQUFDLE9BQUQsRUFBU0MsV0FBVCxDQUFELEVBQXVCLENBQUMsWUFBRCxFQUFjQyxnQkFBZCxDQUF2QixFQUF1RCxDQUFDLFFBQUQsRUFBVUMsWUFBVixDQUF2RCxFQUErRSxDQUFDLFNBQUQsRUFBV0MsYUFBWCxDQUEvRSxDQUFSLENBQWQ7QUFBaUksTUFBTUMsbUJBQW1CLEdBQUMsQ0FBQyxNQUFELEVBQVEsT0FBUixFQUFnQixXQUFoQixFQUE0QixZQUE1QixFQUF5Q3pULFNBQXpDLENBQTFCOztBQUE4RSxTQUFTMFQsZUFBVCxDQUF5QkMsR0FBekIsRUFBNkI7QUFBQyxTQUFPQSxHQUFHLENBQUNDLE9BQUosS0FBYzVULFNBQXJCO0FBQWdDOztBQUFBLFNBQVM2VCxpQkFBVCxDQUEyQkYsR0FBM0IsRUFBK0I7QUFBQyxTQUFPQSxHQUFHLENBQUNBLEdBQUosS0FBVTNULFNBQWpCO0FBQTRCOztBQUFBLFNBQVM4VCxjQUFULENBQXdCSCxHQUF4QixFQUE0QjtBQUFDLFNBQU8sT0FBT0EsR0FBUCxLQUFhLFFBQWIsS0FBd0JELGVBQWUsQ0FBQ0MsR0FBRCxDQUFmLElBQXNCRSxpQkFBaUIsQ0FBQ0YsR0FBRCxDQUEvRCxDQUFQO0FBQThFOztBQUFBLE1BQUs7QUFBQ0ksYUFBVyxFQUFDQyxpQkFBYjtBQUErQkMsWUFBVSxFQUFDQyxnQkFBMUM7QUFBMkRDLFFBQU0sRUFBQ0MsWUFBbEU7QUFBK0VDLE1BQUksRUFBQ0MsVUFBcEY7QUFBK0ZDLFNBQU8sRUFBQ0M7QUFBdkcsSUFBc0gxTixzSkFBQSxJQUErQmdNLFlBQVksQ0FBQzJCLGtCQUF2SyxDLENBQTBMOztBQUNoMkMsTUFBTUMsUUFBUSxHQUFDLENBQUMsR0FBR1YsaUJBQUosRUFBc0IsR0FBR0UsZ0JBQXpCLENBQWY7QUFBMERGLGlCQUFpQixDQUFDaEwsSUFBbEIsQ0FBdUIsQ0FBQ0MsQ0FBRCxFQUFHQyxDQUFILEtBQU9ELENBQUMsR0FBQ0MsQ0FBaEM7QUFBbUN3TCxRQUFRLENBQUMxTCxJQUFULENBQWMsQ0FBQ0MsQ0FBRCxFQUFHQyxDQUFILEtBQU9ELENBQUMsR0FBQ0MsQ0FBdkI7O0FBQTBCLFNBQVN5TCxTQUFULENBQW1CcFMsS0FBbkIsRUFBeUJxUyxNQUF6QixFQUFnQ0MsS0FBaEMsRUFBc0M7QUFBQyxNQUFHQSxLQUFLLEtBQUdELE1BQU0sS0FBRyxNQUFULElBQWlCQSxNQUFNLEtBQUcsWUFBN0IsQ0FBUixFQUFtRDtBQUFDO0FBQ2xOLFVBQU1FLGVBQWUsR0FBQyxvQkFBdEI7QUFBMkMsVUFBTUMsWUFBWSxHQUFDLEVBQW5COztBQUFzQixTQUFJLElBQUlDLEtBQVIsRUFBY0EsS0FBSyxHQUFDRixlQUFlLENBQUNHLElBQWhCLENBQXFCSixLQUFyQixDQUFwQixFQUFnREcsS0FBaEQsRUFBc0Q7QUFBQ0Qsa0JBQVksQ0FBQ0csSUFBYixDQUFrQkMsUUFBUSxDQUFDSCxLQUFLLENBQUMsQ0FBRCxDQUFOLENBQTFCO0FBQXVDOztBQUFBLFFBQUdELFlBQVksQ0FBQzdWLE1BQWhCLEVBQXVCO0FBQUMsWUFBTWtXLGFBQWEsR0FBQ0MsSUFBSSxDQUFDQyxHQUFMLENBQVMsR0FBR1AsWUFBWixJQUEwQixJQUE5QztBQUFtRCxhQUFNO0FBQUNRLGNBQU0sRUFBQ2IsUUFBUSxDQUFDYyxNQUFULENBQWdCM1csQ0FBQyxJQUFFQSxDQUFDLElBQUVtVixpQkFBaUIsQ0FBQyxDQUFELENBQWpCLEdBQXFCb0IsYUFBM0MsQ0FBUjtBQUFrRUssWUFBSSxFQUFDO0FBQXZFLE9BQU47QUFBbUY7O0FBQUEsV0FBTTtBQUFDRixZQUFNLEVBQUNiLFFBQVI7QUFBaUJlLFVBQUksRUFBQztBQUF0QixLQUFOO0FBQWtDOztBQUFBLE1BQUcsT0FBT2xULEtBQVAsS0FBZSxRQUFmLElBQXlCcVMsTUFBTSxLQUFHLE1BQWxDLElBQTBDQSxNQUFNLEtBQUcsWUFBdEQsRUFBbUU7QUFBQyxXQUFNO0FBQUNXLFlBQU0sRUFBQ3ZCLGlCQUFSO0FBQTBCeUIsVUFBSSxFQUFDO0FBQS9CLEtBQU47QUFBMkM7O0FBQUEsUUFBTUYsTUFBTSxHQUFDLENBQUMsR0FBRyxJQUFJRyxHQUFKLEVBQVE7QUFDdmU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFDblQsS0FBRCxFQUFPQSxLQUFLLEdBQUM7QUFBQztBQUFkLElBQStCM0QsR0FBL0IsQ0FBbUMrVyxDQUFDLElBQUVqQixRQUFRLENBQUNrQixJQUFULENBQWNDLENBQUMsSUFBRUEsQ0FBQyxJQUFFRixDQUFwQixLQUF3QmpCLFFBQVEsQ0FBQ0EsUUFBUSxDQUFDeFYsTUFBVCxHQUFnQixDQUFqQixDQUF0RSxDQVIrZCxDQUFKLENBQWI7QUFRalgsU0FBTTtBQUFDcVcsVUFBRDtBQUFRRSxRQUFJLEVBQUM7QUFBYixHQUFOO0FBQXlCOztBQUFBLFNBQVNLLGdCQUFULENBQTBCO0FBQUNuQyxLQUFEO0FBQUtvQyxhQUFMO0FBQWlCbkIsUUFBakI7QUFBd0JyUyxPQUF4QjtBQUE4QnlULFNBQTlCO0FBQXNDbkIsT0FBdEM7QUFBNENWO0FBQTVDLENBQTFCLEVBQThFO0FBQUMsTUFBRzRCLFdBQUgsRUFBZTtBQUFDLFdBQU07QUFBQ3BDLFNBQUQ7QUFBS3NDLFlBQU0sRUFBQ2pXLFNBQVo7QUFBc0I2VSxXQUFLLEVBQUM3VTtBQUE1QixLQUFOO0FBQThDOztBQUFBLFFBQUs7QUFBQ3VWLFVBQUQ7QUFBUUU7QUFBUixNQUFjZCxTQUFTLENBQUNwUyxLQUFELEVBQU9xUyxNQUFQLEVBQWNDLEtBQWQsQ0FBNUI7QUFBaUQsUUFBTXFCLElBQUksR0FBQ1gsTUFBTSxDQUFDclcsTUFBUCxHQUFjLENBQXpCO0FBQTJCLFNBQU07QUFBQzJWLFNBQUssRUFBQyxDQUFDQSxLQUFELElBQVFZLElBQUksS0FBRyxHQUFmLEdBQW1CLE9BQW5CLEdBQTJCWixLQUFsQztBQUF3Q29CLFVBQU0sRUFBQ1YsTUFBTSxDQUFDM1csR0FBUCxDQUFXLENBQUMrVyxDQUFELEVBQUdRLENBQUgsS0FBUSxHQUFFaEMsTUFBTSxDQUFDO0FBQUNSLFNBQUQ7QUFBS3FDLGFBQUw7QUFBYXpULFdBQUssRUFBQ29UO0FBQW5CLEtBQUQsQ0FBd0IsSUFBR0YsSUFBSSxLQUFHLEdBQVAsR0FBV0UsQ0FBWCxHQUFhUSxDQUFDLEdBQUMsQ0FBRSxHQUFFVixJQUFLLEVBQTlFLEVBQWlGeFcsSUFBakYsQ0FBc0YsSUFBdEYsQ0FBL0M7QUFBMkk7QUFDaGU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBMFUsT0FBRyxFQUFDUSxNQUFNLENBQUM7QUFBQ1IsU0FBRDtBQUFLcUMsYUFBTDtBQUFhelQsV0FBSyxFQUFDZ1QsTUFBTSxDQUFDVyxJQUFEO0FBQXpCLEtBQUQ7QUFOMlUsR0FBTjtBQU1oUzs7QUFBQSxTQUFTRSxNQUFULENBQWdCQyxDQUFoQixFQUFrQjtBQUFDLE1BQUcsT0FBT0EsQ0FBUCxLQUFXLFFBQWQsRUFBdUI7QUFBQyxXQUFPQSxDQUFQO0FBQVU7O0FBQUEsTUFBRyxPQUFPQSxDQUFQLEtBQVcsUUFBZCxFQUF1QjtBQUFDLFdBQU9sQixRQUFRLENBQUNrQixDQUFELEVBQUcsRUFBSCxDQUFmO0FBQXVCOztBQUFBLFNBQU9yVyxTQUFQO0FBQWtCOztBQUFBLFNBQVNzVyxrQkFBVCxDQUE0QkMsV0FBNUIsRUFBd0M7QUFBQyxRQUFNQyxJQUFJLEdBQUNyRCxPQUFPLENBQUMzSyxHQUFSLENBQVk0TCxZQUFaLENBQVg7O0FBQXFDLE1BQUdvQyxJQUFILEVBQVE7QUFBQyxXQUFPQSxJQUFJLENBQUMsQ0FBQyxHQUFFOUQsU0FBUyxDQUFDa0IsT0FBYixFQUFzQjtBQUFDNkMsVUFBSSxFQUFDbkM7QUFBTixLQUF0QixFQUF3Q2lDLFdBQXhDLENBQUQsQ0FBWDtBQUFtRTs7QUFBQSxRQUFNLElBQUlwUCxLQUFKLENBQVcseURBQXdEMkwsWUFBWSxDQUFDNEQsYUFBYixDQUEyQnpYLElBQTNCLENBQWdDLElBQWhDLENBQXNDLGVBQWNtVixZQUFhLEVBQXBJLENBQU47QUFBOEksQyxDQUFBO0FBQzdjOzs7QUFDQSxTQUFTdUMsaUJBQVQsQ0FBMkJDLEdBQTNCLEVBQStCQyxXQUEvQixFQUEyQztBQUFDLE1BQUdBLFdBQVcsS0FBRyxNQUFkLElBQXNCRCxHQUF6QixFQUE2QjtBQUFDLFVBQU1FLFVBQVUsR0FBQyxNQUFJO0FBQUMsVUFBRyxDQUFDRixHQUFHLENBQUNqRCxHQUFKLENBQVFvRCxVQUFSLENBQW1CLE9BQW5CLENBQUosRUFBZ0M7QUFBQyxjQUFNbEIsQ0FBQyxHQUFDLFlBQVdlLEdBQVgsR0FBZUEsR0FBRyxDQUFDSSxNQUFKLEVBQWYsR0FBNEJDLE9BQU8sQ0FBQ0MsT0FBUixFQUFwQztBQUFzRHJCLFNBQUMsQ0FBQ3NCLEtBQUYsQ0FBUSxNQUFJLENBQUUsQ0FBZCxFQUFnQnpZLElBQWhCLENBQXFCLE1BQUk7QUFBQ2tZLGFBQUcsQ0FBQ3ZULEtBQUosQ0FBVW1TLE1BQVYsR0FBaUIsTUFBakI7QUFBd0JvQixhQUFHLENBQUN2VCxLQUFKLENBQVUrVCxjQUFWLEdBQXlCLE1BQXpCO0FBQWdDUixhQUFHLENBQUN2VCxLQUFKLENBQVVnVSxlQUFWLEdBQTBCLE1BQTFCO0FBQWtDLFNBQXBIO0FBQXVIO0FBQUMsS0FBck87O0FBQXNPLFFBQUdULEdBQUcsQ0FBQ1UsUUFBUCxFQUFnQjtBQUFDO0FBQ2pVO0FBQ0E7QUFDQVIsZ0JBQVU7QUFBSSxLQUhrUyxNQUc5UjtBQUFDRixTQUFHLENBQUNXLE1BQUosR0FBV1QsVUFBWDtBQUF1QjtBQUFDO0FBQUM7O0FBQUEsU0FBU3RFLEtBQVQsQ0FBZWdGLElBQWYsRUFBb0I7QUFBQyxNQUFHO0FBQUM3RCxPQUFEO0FBQUtrQixTQUFMO0FBQVdrQixlQUFXLEdBQUMsS0FBdkI7QUFBNkIwQixZQUFRLEdBQUMsS0FBdEM7QUFBNENDLFdBQTVDO0FBQW9EcGEsYUFBcEQ7QUFBOEQwWSxXQUE5RDtBQUFzRXpULFNBQXRFO0FBQTRFb1YsVUFBNUU7QUFBbUZDLGFBQW5GO0FBQTZGQyxrQkFBN0Y7QUFBNEcxRCxVQUFNLEdBQUNtQyxrQkFBbkg7QUFBc0lPLGVBQVcsR0FBQyxPQUFsSjtBQUEwSmlCO0FBQTFKLE1BQXVLTixJQUExSztBQUFBLE1BQStLTyxHQUFHLEdBQUMsQ0FBQyxHQUFFdEYsOEJBQThCLENBQUNtQixPQUFsQyxFQUEyQzRELElBQTNDLEVBQWdELENBQUMsS0FBRCxFQUFPLE9BQVAsRUFBZSxhQUFmLEVBQTZCLFVBQTdCLEVBQXdDLFNBQXhDLEVBQWtELFdBQWxELEVBQThELFNBQTlELEVBQXdFLE9BQXhFLEVBQWdGLFFBQWhGLEVBQXlGLFdBQXpGLEVBQXFHLGdCQUFyRyxFQUFzSCxRQUF0SCxFQUErSCxhQUEvSCxFQUE2SSxhQUE3SSxDQUFoRCxDQUFuTDtBQUFnWSxNQUFJUSxJQUFJLEdBQUNELEdBQVQ7QUFBYSxNQUFJbkQsTUFBTSxHQUFDQyxLQUFLLEdBQUMsWUFBRCxHQUFjLFdBQTlCOztBQUEwQyxNQUFHLFlBQVdtRCxJQUFkLEVBQW1CO0FBQUM7QUFDNWdCLFFBQUdBLElBQUksQ0FBQ3BELE1BQVIsRUFBZUEsTUFBTSxHQUFDb0QsSUFBSSxDQUFDcEQsTUFBWixDQUQ0ZixDQUN6ZTs7QUFDbEMsV0FBT29ELElBQUksQ0FBQyxRQUFELENBQVg7QUFBdUI7O0FBQUEsTUFBSUMsU0FBUyxHQUFDLEVBQWQ7O0FBQWlCLE1BQUduRSxjQUFjLENBQUNILEdBQUQsQ0FBakIsRUFBdUI7QUFBQyxVQUFNdUUsZUFBZSxHQUFDeEUsZUFBZSxDQUFDQyxHQUFELENBQWYsR0FBcUJBLEdBQUcsQ0FBQ0MsT0FBekIsR0FBaUNELEdBQXZEOztBQUEyRCxRQUFHLENBQUN1RSxlQUFlLENBQUN2RSxHQUFwQixFQUF3QjtBQUFDLFlBQU0sSUFBSXhNLEtBQUosQ0FBVyw4SUFBNkljLElBQUksQ0FBQ0MsU0FBTCxDQUFlZ1EsZUFBZixDQUFnQyxFQUF4TCxDQUFOO0FBQWtNOztBQUFBSixlQUFXLEdBQUNBLFdBQVcsSUFBRUksZUFBZSxDQUFDSixXQUF6QztBQUFxREcsYUFBUyxHQUFDQyxlQUFlLENBQUN2RSxHQUExQjs7QUFBOEIsUUFBRyxDQUFDaUIsTUFBRCxJQUFTQSxNQUFNLEtBQUcsTUFBckIsRUFBNEI7QUFBQytDLFlBQU0sR0FBQ0EsTUFBTSxJQUFFTyxlQUFlLENBQUNQLE1BQS9CO0FBQXNDcFYsV0FBSyxHQUFDQSxLQUFLLElBQUUyVixlQUFlLENBQUMzVixLQUE3Qjs7QUFBbUMsVUFBRyxDQUFDMlYsZUFBZSxDQUFDUCxNQUFqQixJQUF5QixDQUFDTyxlQUFlLENBQUMzVixLQUE3QyxFQUFtRDtBQUFDLGNBQU0sSUFBSTRFLEtBQUosQ0FBVywySkFBMEpjLElBQUksQ0FBQ0MsU0FBTCxDQUFlZ1EsZUFBZixDQUFnQyxFQUFyTSxDQUFOO0FBQStNO0FBQUM7QUFBQzs7QUFBQXZFLEtBQUcsR0FBQyxPQUFPQSxHQUFQLEtBQWEsUUFBYixHQUFzQkEsR0FBdEIsR0FBMEJzRSxTQUE5QjtBQUF3QyxRQUFNRSxRQUFRLEdBQUMvQixNQUFNLENBQUM3VCxLQUFELENBQXJCO0FBQTZCLFFBQU02VixTQUFTLEdBQUNoQyxNQUFNLENBQUN1QixNQUFELENBQXRCO0FBQStCLFFBQU1VLFVBQVUsR0FBQ2pDLE1BQU0sQ0FBQ0osT0FBRCxDQUF2Qjs7QUFBaUMsWUFBdUM7QUFBQyxRQUFHLENBQUNyQyxHQUFKLEVBQVE7QUFBQyxZQUFNLElBQUl4TSxLQUFKLENBQVcsMEhBQXlIYyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUFDM0YsYUFBRDtBQUFPb1YsY0FBUDtBQUFjM0I7QUFBZCxPQUFmLENBQXVDLEVBQTNLLENBQU47QUFBcUw7O0FBQUEsUUFBRyxDQUFDdkMsbUJBQW1CLENBQUM2RSxRQUFwQixDQUE2QjFELE1BQTdCLENBQUosRUFBeUM7QUFBQyxZQUFNLElBQUl6TixLQUFKLENBQVcsbUJBQWtCd00sR0FBSSw4Q0FBNkNpQixNQUFPLHNCQUFxQm5CLG1CQUFtQixDQUFDN1UsR0FBcEIsQ0FBd0IyWixNQUF4QixFQUFnQ3RaLElBQWhDLENBQXFDLEdBQXJDLENBQTBDLEdBQXBKLENBQU47QUFBK0o7O0FBQUEsUUFBRyxDQUFDaVUsb0JBQW9CLENBQUNvRixRQUFyQixDQUE4QlosT0FBOUIsQ0FBSixFQUEyQztBQUFDLFlBQU0sSUFBSXZRLEtBQUosQ0FBVyxtQkFBa0J3TSxHQUFJLCtDQUE4QytELE9BQVEsc0JBQXFCeEUsb0JBQW9CLENBQUN0VSxHQUFyQixDQUF5QjJaLE1BQXpCLEVBQWlDdFosSUFBakMsQ0FBc0MsR0FBdEMsQ0FBMkMsR0FBdkosQ0FBTjtBQUFrSzs7QUFBQSxRQUFHd1ksUUFBUSxJQUFFQyxPQUFPLEtBQUcsTUFBdkIsRUFBOEI7QUFBQyxZQUFNLElBQUl2USxLQUFKLENBQVcsbUJBQWtCd00sR0FBSSxpRkFBakMsQ0FBTjtBQUEwSDs7QUFBQSxRQUFHa0QsV0FBVyxLQUFHLE1BQWpCLEVBQXdCO0FBQUMsVUFBRyxDQUFDc0IsUUFBUSxJQUFFLENBQVgsS0FBZUMsU0FBUyxJQUFFLENBQTFCLElBQTZCLElBQWhDLEVBQXFDO0FBQUNoWCxlQUFPLENBQUNvWCxJQUFSLENBQWMsbUJBQWtCN0UsR0FBSSxzR0FBcEM7QUFBNEk7O0FBQUEsVUFBRyxDQUFDbUUsV0FBSixFQUFnQjtBQUFDLGNBQU1XLGNBQWMsR0FBQyxDQUFDLE1BQUQsRUFBUSxLQUFSLEVBQWMsTUFBZCxDQUFyQixDQUFELENBQTRDOztBQUN0N0QsY0FBTSxJQUFJdFIsS0FBSixDQUFXLG1CQUFrQndNLEdBQUk7QUFDdkM7QUFDQTtBQUNBLG1HQUFtRzhFLGNBQWMsQ0FBQ3haLElBQWYsQ0FBb0IsR0FBcEIsQ0FBeUI7QUFDNUg7QUFDQSxnRkFMTSxDQUFOO0FBS21GO0FBQUM7QUFBQzs7QUFBQSxNQUFJeVosTUFBTSxHQUFDLENBQUNqQixRQUFELEtBQVlDLE9BQU8sS0FBRyxNQUFWLElBQWtCLE9BQU9BLE9BQVAsS0FBaUIsV0FBL0MsQ0FBWDs7QUFBdUUsTUFBRy9ELEdBQUcsSUFBRUEsR0FBRyxDQUFDb0QsVUFBSixDQUFlLE9BQWYsQ0FBUixFQUFnQztBQUFDO0FBQzdMaEIsZUFBVyxHQUFDLElBQVo7QUFBaUIyQyxVQUFNLEdBQUMsS0FBUDtBQUFjOztBQUFBLFFBQUssQ0FBQ0MsTUFBRCxFQUFRQyxhQUFSLElBQXVCLENBQUMsR0FBRTdGLGdCQUFnQixDQUFDOEYsZUFBcEIsRUFBcUM7QUFBQ0MsY0FBVSxFQUFDLE9BQVo7QUFBb0J2YixZQUFRLEVBQUMsQ0FBQ21iO0FBQTlCLEdBQXJDLENBQTVCO0FBQXdHLFFBQU1LLFNBQVMsR0FBQyxDQUFDTCxNQUFELElBQVNFLGFBQXpCO0FBQXVDLE1BQUlJLFlBQUo7QUFBaUIsTUFBSUMsVUFBSjtBQUFlLE1BQUlDLFFBQUo7QUFBYSxNQUFJQyxRQUFRLEdBQUMsQ0FBQyxHQUFFekcsU0FBUyxDQUFDa0IsT0FBYixFQUFzQjtBQUFDd0YsWUFBUSxFQUFDLFVBQVY7QUFBcUJ0VyxPQUFHLEVBQUMsQ0FBekI7QUFBMkJ1VyxRQUFJLEVBQUMsQ0FBaEM7QUFBa0N0VyxVQUFNLEVBQUMsQ0FBekM7QUFBMkNqQixTQUFLLEVBQUMsQ0FBakQ7QUFBbUR3WCxhQUFTLEVBQUMsWUFBN0Q7QUFBMEVDLFdBQU8sRUFBQyxDQUFsRjtBQUFvRkMsVUFBTSxFQUFDLE1BQTNGO0FBQWtHQyxVQUFNLEVBQUMsTUFBekc7QUFBZ0hDLFdBQU8sRUFBQyxPQUF4SDtBQUFnSW5YLFNBQUssRUFBQyxDQUF0STtBQUF3SW9WLFVBQU0sRUFBQyxDQUEvSTtBQUFpSmdDLFlBQVEsRUFBQyxNQUExSjtBQUFpS0MsWUFBUSxFQUFDLE1BQTFLO0FBQWlMQyxhQUFTLEVBQUMsTUFBM0w7QUFBa01DLGFBQVMsRUFBQyxNQUE1TTtBQUFtTmxDLGFBQW5OO0FBQTZOQztBQUE3TixHQUF0QixFQUFtUWhCLFdBQVcsS0FBRyxNQUFkLEdBQXFCO0FBQUNyQixVQUFNLEVBQUMsWUFBUjtBQUFxQjRCLGtCQUFjLEVBQUMsT0FBcEM7QUFBNENDLG1CQUFlLEVBQUUsUUFBT1MsV0FBWTtBQUFoRixHQUFyQixHQUEwRzlYLFNBQTdXLENBQWI7O0FBQXFZLE1BQUcsT0FBT21ZLFFBQVAsS0FBa0IsV0FBbEIsSUFBK0IsT0FBT0MsU0FBUCxLQUFtQixXQUFsRCxJQUErRHhELE1BQU0sS0FBRyxNQUEzRSxFQUFrRjtBQUFDO0FBQ25yQixVQUFNbUYsUUFBUSxHQUFDM0IsU0FBUyxHQUFDRCxRQUF6QjtBQUFrQyxVQUFNNkIsVUFBVSxHQUFDQyxLQUFLLENBQUNGLFFBQUQsQ0FBTCxHQUFnQixNQUFoQixHQUF3QixHQUFFQSxRQUFRLEdBQUMsR0FBSSxHQUF4RDs7QUFBMkQsUUFBR25GLE1BQU0sS0FBRyxZQUFaLEVBQXlCO0FBQUM7QUFDdkhvRSxrQkFBWSxHQUFDO0FBQUNVLGVBQU8sRUFBQyxPQUFUO0FBQWlCUSxnQkFBUSxFQUFDLFFBQTFCO0FBQW1DZCxnQkFBUSxFQUFDLFVBQTVDO0FBQXVERSxpQkFBUyxFQUFDLFlBQWpFO0FBQThFRyxjQUFNLEVBQUM7QUFBckYsT0FBYjtBQUFxR1IsZ0JBQVUsR0FBQztBQUFDUyxlQUFPLEVBQUMsT0FBVDtBQUFpQkosaUJBQVMsRUFBQyxZQUEzQjtBQUF3Q1U7QUFBeEMsT0FBWDtBQUFnRSxLQUR4RSxNQUM2RSxJQUFHcEYsTUFBTSxLQUFHLFdBQVosRUFBd0I7QUFBQztBQUNuTW9FLGtCQUFZLEdBQUM7QUFBQ1UsZUFBTyxFQUFDLGNBQVQ7QUFBd0JFLGdCQUFRLEVBQUMsTUFBakM7QUFBd0NNLGdCQUFRLEVBQUMsUUFBakQ7QUFBMERkLGdCQUFRLEVBQUMsVUFBbkU7QUFBOEVFLGlCQUFTLEVBQUMsWUFBeEY7QUFBcUdHLGNBQU0sRUFBQztBQUE1RyxPQUFiO0FBQTRIUixnQkFBVSxHQUFDO0FBQUNLLGlCQUFTLEVBQUMsWUFBWDtBQUF3QkksZUFBTyxFQUFDLE9BQWhDO0FBQXdDRSxnQkFBUSxFQUFDO0FBQWpELE9BQVg7QUFBb0VWLGNBQVEsR0FBRSxlQUFjZixRQUFTLGFBQVlDLFNBQVUsc0RBQXZEO0FBQThHLEtBRHBJLE1BQ3lJLElBQUd4RCxNQUFNLEtBQUcsT0FBWixFQUFvQjtBQUFDO0FBQ3hVb0Usa0JBQVksR0FBQztBQUFDa0IsZ0JBQVEsRUFBQyxRQUFWO0FBQW1CWixpQkFBUyxFQUFDLFlBQTdCO0FBQTBDSSxlQUFPLEVBQUMsY0FBbEQ7QUFBaUVOLGdCQUFRLEVBQUMsVUFBMUU7QUFBcUY3VyxhQUFLLEVBQUM0VixRQUEzRjtBQUFvR1IsY0FBTSxFQUFDUztBQUEzRyxPQUFiO0FBQW9JO0FBQUMsR0FKMmQsTUFJdGQsSUFBRyxPQUFPRCxRQUFQLEtBQWtCLFdBQWxCLElBQStCLE9BQU9DLFNBQVAsS0FBbUIsV0FBbEQsSUFBK0R4RCxNQUFNLEtBQUcsTUFBM0UsRUFBa0Y7QUFBQztBQUM3Tm9FLGdCQUFZLEdBQUM7QUFBQ1UsYUFBTyxFQUFDLE9BQVQ7QUFBaUJRLGNBQVEsRUFBQyxRQUExQjtBQUFtQ2QsY0FBUSxFQUFDLFVBQTVDO0FBQXVEdFcsU0FBRyxFQUFDLENBQTNEO0FBQTZEdVcsVUFBSSxFQUFDLENBQWxFO0FBQW9FdFcsWUFBTSxFQUFDLENBQTNFO0FBQTZFakIsV0FBSyxFQUFDLENBQW5GO0FBQXFGd1gsZUFBUyxFQUFDLFlBQS9GO0FBQTRHRyxZQUFNLEVBQUM7QUFBbkgsS0FBYjtBQUFvSSxHQURNLE1BQ0Y7QUFBQztBQUN6SSxjQUF1QztBQUFDLFlBQU0sSUFBSXRTLEtBQUosQ0FBVyxtQkFBa0J3TSxHQUFJLHlFQUFqQyxDQUFOO0FBQWtIO0FBQUM7O0FBQUEsTUFBSXdHLGFBQWEsR0FBQztBQUFDeEcsT0FBRyxFQUFDLGdGQUFMO0FBQXNGc0MsVUFBTSxFQUFDalcsU0FBN0Y7QUFBdUc2VSxTQUFLLEVBQUM3VTtBQUE3RyxHQUFsQjs7QUFBMEksTUFBRytZLFNBQUgsRUFBYTtBQUFDb0IsaUJBQWEsR0FBQ3JFLGdCQUFnQixDQUFDO0FBQUNuQyxTQUFEO0FBQUtvQyxpQkFBTDtBQUFpQm5CLFlBQWpCO0FBQXdCclMsV0FBSyxFQUFDNFYsUUFBOUI7QUFBdUNuQyxhQUFPLEVBQUNxQyxVQUEvQztBQUEwRHhELFdBQTFEO0FBQWdFVjtBQUFoRSxLQUFELENBQTlCO0FBQXlHOztBQUFBLFNBQU0sYUFBYXhCLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZXdHLGFBQWYsQ0FBNkIsS0FBN0IsRUFBbUM7QUFBQy9XLFNBQUssRUFBQzJWO0FBQVAsR0FBbkMsRUFBd0RDLFVBQVUsR0FBQyxhQUFhdEcsTUFBTSxDQUFDaUIsT0FBUCxDQUFld0csYUFBZixDQUE2QixLQUE3QixFQUFtQztBQUFDL1csU0FBSyxFQUFDNFY7QUFBUCxHQUFuQyxFQUFzREMsUUFBUSxHQUFDLGFBQWF2RyxNQUFNLENBQUNpQixPQUFQLENBQWV3RyxhQUFmLENBQTZCLEtBQTdCLEVBQW1DO0FBQUMvVyxTQUFLLEVBQUM7QUFBQ3VXLGNBQVEsRUFBQyxNQUFWO0FBQWlCRixhQUFPLEVBQUMsT0FBekI7QUFBaUNELFlBQU0sRUFBQyxDQUF4QztBQUEwQ0QsWUFBTSxFQUFDLE1BQWpEO0FBQXdERCxhQUFPLEVBQUM7QUFBaEUsS0FBUDtBQUEwRWMsT0FBRyxFQUFDLEVBQTlFO0FBQWlGLG1CQUFjLElBQS9GO0FBQW9HQyxRQUFJLEVBQUMsY0FBekc7QUFBd0gzRyxPQUFHLEVBQUUsNkJBQTRCLENBQUMsR0FBRWQsT0FBTyxDQUFDMEgsUUFBWCxFQUFxQnJCLFFBQXJCLENBQStCO0FBQXhMLEdBQW5DLENBQWQsR0FBNk8sSUFBM1MsQ0FBZCxHQUErVCxJQUFqWSxFQUFzWSxDQUFDSCxTQUFELElBQVksYUFBYXBHLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZXdHLGFBQWYsQ0FBNkIsVUFBN0IsRUFBd0MsSUFBeEMsRUFBNkMsYUFBYXpILE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZXdHLGFBQWYsQ0FBNkIsS0FBN0IsRUFBbUNwTSxNQUFNLENBQUN3TSxNQUFQLENBQWMsRUFBZCxFQUFpQnhDLElBQWpCLEVBQXNCbEMsZ0JBQWdCLENBQUM7QUFBQ25DLE9BQUQ7QUFBS29DLGVBQUw7QUFBaUJuQixVQUFqQjtBQUF3QnJTLFNBQUssRUFBQzRWLFFBQTlCO0FBQXVDbkMsV0FBTyxFQUFDcUMsVUFBL0M7QUFBMER4RCxTQUExRDtBQUFnRVY7QUFBaEUsR0FBRCxDQUF0QyxFQUFnSDtBQUFDUixPQUFHLEVBQUNBLEdBQUw7QUFBUzhHLFlBQVEsRUFBQyxPQUFsQjtBQUEwQjVGLFNBQUssRUFBQ0EsS0FBaEM7QUFBc0N4UixTQUFLLEVBQUM4VixRQUE1QztBQUFxRDdiLGFBQVMsRUFBQ0E7QUFBL0QsR0FBaEgsQ0FBbkMsQ0FBMUQsQ0FBL1osRUFBeXJCLGFBQWFxVixNQUFNLENBQUNpQixPQUFQLENBQWV3RyxhQUFmLENBQTZCLEtBQTdCLEVBQW1DcE0sTUFBTSxDQUFDd00sTUFBUCxDQUFjLEVBQWQsRUFBaUJ4QyxJQUFqQixFQUFzQm1DLGFBQXRCLEVBQW9DO0FBQUNNLFlBQVEsRUFBQyxPQUFWO0FBQWtCbmQsYUFBUyxFQUFDQSxTQUE1QjtBQUFzQ0osT0FBRyxFQUFDd2QsT0FBTyxJQUFFO0FBQUMvQixZQUFNLENBQUMrQixPQUFELENBQU47QUFBZ0IvRCx1QkFBaUIsQ0FBQytELE9BQUQsRUFBUzdELFdBQVQsQ0FBakI7QUFBd0MsS0FBNUc7QUFBNkd4VCxTQUFLLEVBQUM4VjtBQUFuSCxHQUFwQyxDQUFuQyxDQUF0c0IsRUFBNDRCMUIsUUFBUTtBQUFDO0FBQWM7QUFDbDFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E5RSxRQUFNLENBQUNpQixPQUFQLENBQWV3RyxhQUFmLENBQTZCeEgsS0FBSyxDQUFDZ0IsT0FBbkMsRUFBMkMsSUFBM0MsRUFBZ0QsYUFBYWpCLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZXdHLGFBQWYsQ0FBNkIsTUFBN0IsRUFBb0M7QUFBQ08sT0FBRyxFQUFDLFlBQVVSLGFBQWEsQ0FBQ3hHLEdBQXhCLEdBQTRCd0csYUFBYSxDQUFDbEUsTUFBMUMsR0FBaURrRSxhQUFhLENBQUN0RixLQUFwRTtBQUEwRStGLE9BQUcsRUFBQyxTQUE5RTtBQUF3RkMsTUFBRSxFQUFDLE9BQTNGO0FBQW1HamIsUUFBSSxFQUFDdWEsYUFBYSxDQUFDbEUsTUFBZCxHQUFxQmpXLFNBQXJCLEdBQStCbWEsYUFBYSxDQUFDeEcsR0FBckosQ0FBd0o7QUFBeEo7QUFDaEdtSCxlQUFXLEVBQUNYLGFBQWEsQ0FBQ2xFLE1BRHNFLENBQ2hFO0FBRGdFO0FBRWhHOEUsY0FBVSxFQUFDWixhQUFhLENBQUN0RjtBQUZ1RSxHQUFwQyxDQUE3RCxDQUxtMEMsR0FPaHlDLElBUDRZLENBQW5CO0FBT2xYLEMsQ0FBQTs7O0FBQzFDLFNBQVNtRyxZQUFULENBQXNCckgsR0FBdEIsRUFBMEI7QUFBQyxTQUFPQSxHQUFHLENBQUMsQ0FBRCxDQUFILEtBQVMsR0FBVCxHQUFhQSxHQUFHLENBQUMzVSxLQUFKLENBQVUsQ0FBVixDQUFiLEdBQTBCMlUsR0FBakM7QUFBc0M7O0FBQUEsU0FBU04sV0FBVCxDQUFxQjtBQUFDb0QsTUFBRDtBQUFNOUMsS0FBTjtBQUFVcFIsT0FBVjtBQUFnQnlUO0FBQWhCLENBQXJCLEVBQThDO0FBQUM7QUFDaEgsUUFBTXZOLE1BQU0sR0FBQyxDQUFDLGFBQUQsRUFBZSxTQUFmLEVBQXlCLE9BQUtsRyxLQUE5QixDQUFiO0FBQWtELE1BQUkwWSxZQUFZLEdBQUMsRUFBakI7O0FBQW9CLE1BQUdqRixPQUFILEVBQVc7QUFBQ3ZOLFVBQU0sQ0FBQ3lNLElBQVAsQ0FBWSxPQUFLYyxPQUFqQjtBQUEyQjs7QUFBQSxNQUFHdk4sTUFBTSxDQUFDdkosTUFBVixFQUFpQjtBQUFDK2IsZ0JBQVksR0FBQyxNQUFJeFMsTUFBTSxDQUFDeEosSUFBUCxDQUFZLEdBQVosQ0FBakI7QUFBbUM7O0FBQUEsU0FBTyxHQUFFd1gsSUFBSyxHQUFFdUUsWUFBWSxDQUFDckgsR0FBRCxDQUFNLEdBQUVzSCxZQUFhLEVBQWpEO0FBQW9EOztBQUFBLFNBQVMxSCxZQUFULENBQXNCO0FBQUNrRCxNQUFEO0FBQU05QyxLQUFOO0FBQVVwUjtBQUFWLENBQXRCLEVBQXVDO0FBQUMsU0FBTyxHQUFFa1UsSUFBSyxHQUFFdUUsWUFBWSxDQUFDckgsR0FBRCxDQUFNLFlBQVdwUixLQUFNLEVBQW5EO0FBQXNEOztBQUFBLFNBQVMrUSxnQkFBVCxDQUEwQjtBQUFDbUQsTUFBRDtBQUFNOUMsS0FBTjtBQUFVcFIsT0FBVjtBQUFnQnlUO0FBQWhCLENBQTFCLEVBQW1EO0FBQUM7QUFDeFcsUUFBTXZOLE1BQU0sR0FBQyxDQUFDLFFBQUQsRUFBVSxTQUFWLEVBQW9CLE9BQUtsRyxLQUF6QixFQUErQixRQUFNeVQsT0FBTyxJQUFFLE1BQWYsQ0FBL0IsQ0FBYjtBQUFvRSxNQUFJaUYsWUFBWSxHQUFDeFMsTUFBTSxDQUFDeEosSUFBUCxDQUFZLEdBQVosSUFBaUIsR0FBbEM7QUFBc0MsU0FBTyxHQUFFd1gsSUFBSyxHQUFFd0UsWUFBYSxHQUFFRCxZQUFZLENBQUNySCxHQUFELENBQU0sRUFBakQ7QUFBb0Q7O0FBQUEsU0FBU0gsYUFBVCxDQUF1QjtBQUFDaUQsTUFBRDtBQUFNOUMsS0FBTjtBQUFVcFIsT0FBVjtBQUFnQnlUO0FBQWhCLENBQXZCLEVBQWdEO0FBQUMsWUFBdUM7QUFBQyxVQUFNa0YsYUFBYSxHQUFDLEVBQXBCLENBQUQsQ0FBd0I7O0FBQzlRLFFBQUcsQ0FBQ3ZILEdBQUosRUFBUXVILGFBQWEsQ0FBQ2hHLElBQWQsQ0FBbUIsS0FBbkI7QUFBMEIsUUFBRyxDQUFDM1MsS0FBSixFQUFVMlksYUFBYSxDQUFDaEcsSUFBZCxDQUFtQixPQUFuQjs7QUFBNEIsUUFBR2dHLGFBQWEsQ0FBQ2hjLE1BQWQsR0FBcUIsQ0FBeEIsRUFBMEI7QUFBQyxZQUFNLElBQUlpSSxLQUFKLENBQVcsb0NBQW1DK1QsYUFBYSxDQUFDamMsSUFBZCxDQUFtQixJQUFuQixDQUF5QixnR0FBK0ZnSixJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUFDeUwsV0FBRDtBQUFLcFIsYUFBTDtBQUFXeVQ7QUFBWCxPQUFmLENBQW9DLEVBQTFNLENBQU47QUFBb047O0FBQUEsUUFBR3JDLEdBQUcsQ0FBQ29ELFVBQUosQ0FBZSxJQUFmLENBQUgsRUFBd0I7QUFBQyxZQUFNLElBQUk1UCxLQUFKLENBQVcsd0JBQXVCd00sR0FBSSwwR0FBdEMsQ0FBTjtBQUF3Sjs7QUFBQSxRQUFHLENBQUNBLEdBQUcsQ0FBQ29ELFVBQUosQ0FBZSxHQUFmLENBQUQsSUFBc0J2QyxhQUF6QixFQUF1QztBQUFDLFVBQUkyRyxTQUFKOztBQUFjLFVBQUc7QUFBQ0EsaUJBQVMsR0FBQyxJQUFJQyxHQUFKLENBQVF6SCxHQUFSLENBQVY7QUFBd0IsT0FBNUIsQ0FBNEIsT0FBTTBILEdBQU4sRUFBVTtBQUFDamEsZUFBTyxDQUFDc0UsS0FBUixDQUFjMlYsR0FBZDtBQUFtQixjQUFNLElBQUlsVSxLQUFKLENBQVcsd0JBQXVCd00sR0FBSSxpSUFBdEMsQ0FBTjtBQUErSzs7QUFBQSxVQUFHLENBQUNhLGFBQWEsQ0FBQzhELFFBQWQsQ0FBdUI2QyxTQUFTLENBQUNHLFFBQWpDLENBQUosRUFBK0M7QUFBQyxjQUFNLElBQUluVSxLQUFKLENBQVcscUJBQW9Cd00sR0FBSSxrQ0FBaUN3SCxTQUFTLENBQUNHLFFBQVMsK0RBQTdFLEdBQTZJLDhFQUF2SixDQUFOO0FBQTZPO0FBQUM7QUFBQzs7QUFBQSxTQUFPLEdBQUU3RSxJQUFLLFFBQU84RSxrQkFBa0IsQ0FBQzVILEdBQUQsQ0FBTSxNQUFLcFIsS0FBTSxNQUFLeVQsT0FBTyxJQUFFLEVBQUcsRUFBekU7QUFBNEUsQzs7Ozs7Ozs7Ozs7QUMvQ3JtQzs7QUFBQSxJQUFJd0YsdUJBQXVCLEdBQUNsSixtQkFBTyxDQUFDLHlJQUFELENBQW5DOztBQUFxRkMsa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLGVBQUEsR0FBZ0IsS0FBSyxDQUFyQjs7QUFBdUIsSUFBSUksTUFBTSxHQUFDNkksdUJBQXVCLENBQUNsSixtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBbEM7O0FBQXFELElBQUltSixPQUFPLEdBQUNuSixtQkFBTyxDQUFDLG9HQUFELENBQW5COztBQUF3RCxJQUFJb0osUUFBUSxHQUFDcEosbUJBQU8sQ0FBQyw0REFBRCxDQUFwQjs7QUFBaUMsSUFBSVMsZ0JBQWdCLEdBQUNULG1CQUFPLENBQUMsZ0ZBQUQsQ0FBNUI7O0FBQW1ELE1BQU1xSixVQUFVLEdBQUMsRUFBakI7O0FBQW9CLFNBQVNDLFFBQVQsQ0FBa0I5TixNQUFsQixFQUF5QmxPLElBQXpCLEVBQThCaWIsRUFBOUIsRUFBaUNnQixPQUFqQyxFQUF5QztBQUFDLE1BQUcsSUFBSCxFQUF3QztBQUFPLE1BQUcsQ0FBQyxDQUFDLEdBQUVKLE9BQU8sQ0FBQ0ssVUFBWCxFQUF1QmxjLElBQXZCLENBQUosRUFBaUMsT0FBakYsQ0FBd0Y7QUFDdmU7QUFDQTtBQUNBOztBQUNBa08sUUFBTSxDQUFDOE4sUUFBUCxDQUFnQmhjLElBQWhCLEVBQXFCaWIsRUFBckIsRUFBd0JnQixPQUF4QixFQUFpQzFFLEtBQWpDLENBQXVDa0UsR0FBRyxJQUFFO0FBQUMsY0FBdUM7QUFBQztBQUNyRixZQUFNQSxHQUFOO0FBQVc7QUFBQyxHQURaO0FBQ2MsUUFBTVUsU0FBUyxHQUFDRixPQUFPLElBQUUsT0FBT0EsT0FBTyxDQUFDRyxNQUFmLEtBQXdCLFdBQWpDLEdBQTZDSCxPQUFPLENBQUNHLE1BQXJELEdBQTREbE8sTUFBTSxJQUFFQSxNQUFNLENBQUNrTyxNQUEzRixDQUxpWSxDQUsvUjs7QUFDaEhMLFlBQVUsQ0FBQy9iLElBQUksR0FBQyxHQUFMLEdBQVNpYixFQUFULElBQWFrQixTQUFTLEdBQUMsTUFBSUEsU0FBTCxHQUFlLEVBQXJDLENBQUQsQ0FBVixHQUFxRCxJQUFyRDtBQUEyRDs7QUFBQSxTQUFTRSxlQUFULENBQXlCQyxLQUF6QixFQUErQjtBQUFDLFFBQUs7QUFBQ0M7QUFBRCxNQUFTRCxLQUFLLENBQUNFLGFBQXBCO0FBQWtDLFNBQU9ELE1BQU0sSUFBRUEsTUFBTSxLQUFHLE9BQWpCLElBQTBCRCxLQUFLLENBQUNHLE9BQWhDLElBQXlDSCxLQUFLLENBQUNJLE9BQS9DLElBQXdESixLQUFLLENBQUNLLFFBQTlELElBQXdFTCxLQUFLLENBQUNNLE1BQTlFLElBQXNGO0FBQzFOTixPQUFLLENBQUNPLFdBQU4sSUFBbUJQLEtBQUssQ0FBQ08sV0FBTixDQUFrQkMsS0FBbEIsS0FBMEIsQ0FEZ0Y7QUFDN0U7O0FBQUEsU0FBU0MsV0FBVCxDQUFxQkMsQ0FBckIsRUFBdUI5TyxNQUF2QixFQUE4QmxPLElBQTlCLEVBQW1DaWIsRUFBbkMsRUFBc0N6SyxPQUF0QyxFQUE4Q3lNLE9BQTlDLEVBQXNEQyxNQUF0RCxFQUE2RGQsTUFBN0QsRUFBb0U7QUFBQyxRQUFLO0FBQUNlO0FBQUQsTUFBV0gsQ0FBQyxDQUFDUixhQUFsQjs7QUFBZ0MsTUFBR1csUUFBUSxLQUFHLEdBQVgsS0FBaUJkLGVBQWUsQ0FBQ1csQ0FBRCxDQUFmLElBQW9CLENBQUMsQ0FBQyxHQUFFbkIsT0FBTyxDQUFDSyxVQUFYLEVBQXVCbGMsSUFBdkIsQ0FBdEMsQ0FBSCxFQUF1RTtBQUFDO0FBQzdOO0FBQVE7O0FBQUFnZCxHQUFDLENBQUNJLGNBQUYsR0FENEcsQ0FDekY7O0FBQzNCLE1BQUdGLE1BQU0sSUFBRSxJQUFSLElBQWNqQyxFQUFFLENBQUNuVSxPQUFILENBQVcsR0FBWCxLQUFpQixDQUFsQyxFQUFvQztBQUFDb1csVUFBTSxHQUFDLEtBQVA7QUFBYyxHQUZpRSxDQUVqRTs7O0FBQ25EaFAsUUFBTSxDQUFDc0MsT0FBTyxHQUFDLFNBQUQsR0FBVyxNQUFuQixDQUFOLENBQWlDeFEsSUFBakMsRUFBc0NpYixFQUF0QyxFQUF5QztBQUFDZ0MsV0FBRDtBQUFTYixVQUFUO0FBQWdCYztBQUFoQixHQUF6QztBQUFtRTs7QUFBQSxTQUFTRyxJQUFULENBQWNoZ0IsS0FBZCxFQUFvQjtBQUFDLFlBQXVDO0FBQUMsYUFBU2lnQixlQUFULENBQXlCQyxJQUF6QixFQUE4QjtBQUFDLGFBQU8sSUFBSWhXLEtBQUosQ0FBVyxnQ0FBK0JnVyxJQUFJLENBQUN4QyxHQUFJLGdCQUFld0MsSUFBSSxDQUFDQyxRQUFTLDZCQUE0QkQsSUFBSSxDQUFDRSxNQUFPLGFBQTlHLElBQTRILFNBQTRCLENBQTVCLEdBQStGLEVBQTNOLENBQVYsQ0FBUDtBQUFrUCxLQUFsUixDQUFrUjs7O0FBQ2paLFVBQU1DLGtCQUFrQixHQUFDO0FBQUMxZCxVQUFJLEVBQUM7QUFBTixLQUF6QjtBQUFxQyxVQUFNMmQsYUFBYSxHQUFDdlAsTUFBTSxDQUFDQyxJQUFQLENBQVlxUCxrQkFBWixDQUFwQjtBQUFvREMsaUJBQWEsQ0FBQ0MsT0FBZCxDQUFzQjdDLEdBQUcsSUFBRTtBQUFDLFVBQUdBLEdBQUcsS0FBRyxNQUFULEVBQWdCO0FBQUMsWUFBRzFkLEtBQUssQ0FBQzBkLEdBQUQsQ0FBTCxJQUFZLElBQVosSUFBa0IsT0FBTzFkLEtBQUssQ0FBQzBkLEdBQUQsQ0FBWixLQUFvQixRQUFwQixJQUE4QixPQUFPMWQsS0FBSyxDQUFDMGQsR0FBRCxDQUFaLEtBQW9CLFFBQXZFLEVBQWdGO0FBQUMsZ0JBQU11QyxlQUFlLENBQUM7QUFBQ3ZDLGVBQUQ7QUFBS3lDLG9CQUFRLEVBQUMsc0JBQWQ7QUFBcUNDLGtCQUFNLEVBQUNwZ0IsS0FBSyxDQUFDMGQsR0FBRCxDQUFMLEtBQWEsSUFBYixHQUFrQixNQUFsQixHQUF5QixPQUFPMWQsS0FBSyxDQUFDMGQsR0FBRDtBQUFqRixXQUFELENBQXJCO0FBQWdIO0FBQUMsT0FBbk4sTUFBdU47QUFBQztBQUM3VTtBQUNBLGNBQU04QyxDQUFDLEdBQUM5QyxHQUFSO0FBQWE7QUFBQyxLQUYyRSxFQURzQyxDQUcvRzs7QUFDaEIsVUFBTStDLGtCQUFrQixHQUFDO0FBQUM3QyxRQUFFLEVBQUMsSUFBSjtBQUFTekssYUFBTyxFQUFDLElBQWpCO0FBQXNCME0sWUFBTSxFQUFDLElBQTdCO0FBQWtDRCxhQUFPLEVBQUMsSUFBMUM7QUFBK0NjLGNBQVEsRUFBQyxJQUF4RDtBQUE2RC9CLGNBQVEsRUFBQyxJQUF0RTtBQUEyRUksWUFBTSxFQUFDO0FBQWxGLEtBQXpCO0FBQWlILFVBQU00QixhQUFhLEdBQUM1UCxNQUFNLENBQUNDLElBQVAsQ0FBWXlQLGtCQUFaLENBQXBCO0FBQW9ERSxpQkFBYSxDQUFDSixPQUFkLENBQXNCN0MsR0FBRyxJQUFFO0FBQUMsWUFBTWtELE9BQU8sR0FBQyxPQUFPNWdCLEtBQUssQ0FBQzBkLEdBQUQsQ0FBMUI7O0FBQWdDLFVBQUdBLEdBQUcsS0FBRyxJQUFULEVBQWM7QUFBQyxZQUFHMWQsS0FBSyxDQUFDMGQsR0FBRCxDQUFMLElBQVlrRCxPQUFPLEtBQUcsUUFBdEIsSUFBZ0NBLE9BQU8sS0FBRyxRQUE3QyxFQUFzRDtBQUFDLGdCQUFNWCxlQUFlLENBQUM7QUFBQ3ZDLGVBQUQ7QUFBS3lDLG9CQUFRLEVBQUMsc0JBQWQ7QUFBcUNDLGtCQUFNLEVBQUNRO0FBQTVDLFdBQUQsQ0FBckI7QUFBNkU7QUFBQyxPQUFwSixNQUF5SixJQUFHbEQsR0FBRyxLQUFHLFFBQVQsRUFBa0I7QUFBQyxZQUFHMWQsS0FBSyxDQUFDMGQsR0FBRCxDQUFMLElBQVlrRCxPQUFPLEtBQUcsUUFBekIsRUFBa0M7QUFBQyxnQkFBTVgsZUFBZSxDQUFDO0FBQUN2QyxlQUFEO0FBQUt5QyxvQkFBUSxFQUFDLFVBQWQ7QUFBeUJDLGtCQUFNLEVBQUNRO0FBQWhDLFdBQUQsQ0FBckI7QUFBaUU7QUFBQyxPQUF4SCxNQUE2SCxJQUFHbEQsR0FBRyxLQUFHLFNBQU4sSUFBaUJBLEdBQUcsS0FBRyxRQUF2QixJQUFpQ0EsR0FBRyxLQUFHLFNBQXZDLElBQWtEQSxHQUFHLEtBQUcsVUFBeEQsSUFBb0VBLEdBQUcsS0FBRyxVQUE3RSxFQUF3RjtBQUFDLFlBQUcxZCxLQUFLLENBQUMwZCxHQUFELENBQUwsSUFBWSxJQUFaLElBQWtCa0QsT0FBTyxLQUFHLFNBQS9CLEVBQXlDO0FBQUMsZ0JBQU1YLGVBQWUsQ0FBQztBQUFDdkMsZUFBRDtBQUFLeUMsb0JBQVEsRUFBQyxXQUFkO0FBQTBCQyxrQkFBTSxFQUFDUTtBQUFqQyxXQUFELENBQXJCO0FBQWtFO0FBQUMsT0FBdE0sTUFBME07QUFBQztBQUNsc0I7QUFDQSxjQUFNSixDQUFDLEdBQUM5QyxHQUFSO0FBQWE7QUFBQyxLQUZ1SixFQUp0QyxDQU0vRztBQUNoQjs7QUFDQSxVQUFNbUQsU0FBUyxHQUFDbkwsTUFBTSxDQUFDaUIsT0FBUCxDQUFlbUssTUFBZixDQUFzQixLQUF0QixDQUFoQjs7QUFBNkMsUUFBRzlnQixLQUFLLENBQUMyZSxRQUFOLElBQWdCLENBQUNrQyxTQUFTLENBQUNFLE9BQTlCLEVBQXNDO0FBQUNGLGVBQVMsQ0FBQ0UsT0FBVixHQUFrQixJQUFsQjtBQUF1QjVjLGFBQU8sQ0FBQ29YLElBQVIsQ0FBYSxzS0FBYjtBQUFzTDtBQUFDOztBQUFBLFFBQU0zQyxDQUFDLEdBQUM1WSxLQUFLLENBQUMyZSxRQUFOLEtBQWlCLEtBQXpCO0FBQStCLFFBQU05TixNQUFNLEdBQUMsQ0FBQyxHQUFFNE4sUUFBUSxDQUFDM04sU0FBWixHQUFiOztBQUFzQyxRQUFLO0FBQUNuTyxRQUFEO0FBQU1pYjtBQUFOLE1BQVVsSSxNQUFNLENBQUNpQixPQUFQLENBQWVxSyxPQUFmLENBQXVCLE1BQUk7QUFBQyxVQUFLLENBQUNDLFlBQUQsRUFBY0MsVUFBZCxJQUEwQixDQUFDLEdBQUUxQyxPQUFPLENBQUMyQyxXQUFYLEVBQXdCdFEsTUFBeEIsRUFBK0I3USxLQUFLLENBQUMyQyxJQUFyQyxFQUEwQyxJQUExQyxDQUEvQjtBQUErRSxXQUFNO0FBQUNBLFVBQUksRUFBQ3NlLFlBQU47QUFBbUJyRCxRQUFFLEVBQUM1ZCxLQUFLLENBQUM0ZCxFQUFOLEdBQVMsQ0FBQyxHQUFFWSxPQUFPLENBQUMyQyxXQUFYLEVBQXdCdFEsTUFBeEIsRUFBK0I3USxLQUFLLENBQUM0ZCxFQUFyQyxDQUFULEdBQWtEc0QsVUFBVSxJQUFFRDtBQUFwRixLQUFOO0FBQXlHLEdBQXBOLEVBQXFOLENBQUNwUSxNQUFELEVBQVE3USxLQUFLLENBQUMyQyxJQUFkLEVBQW1CM0MsS0FBSyxDQUFDNGQsRUFBekIsQ0FBck4sQ0FBZjs7QUFBa1EsTUFBRztBQUFDemQsWUFBRDtBQUFVZ1QsV0FBVjtBQUFrQnlNLFdBQWxCO0FBQTBCQyxVQUExQjtBQUFpQ2Q7QUFBakMsTUFBeUMvZSxLQUE1QyxDQVJsaEIsQ0FRb2tCOztBQUMzcEIsTUFBRyxPQUFPRyxRQUFQLEtBQWtCLFFBQXJCLEVBQThCO0FBQUNBLFlBQVEsR0FBQyxhQUFhdVYsTUFBTSxDQUFDaUIsT0FBUCxDQUFld0csYUFBZixDQUE2QixHQUE3QixFQUFpQyxJQUFqQyxFQUFzQ2hkLFFBQXRDLENBQXRCO0FBQXVFLEdBVGYsQ0FTZTs7O0FBQ3RHLE1BQUlpaEIsS0FBSjs7QUFBVSxZQUF3QztBQUFDLFFBQUc7QUFBQ0EsV0FBSyxHQUFDMUwsTUFBTSxDQUFDMkwsUUFBUCxDQUFnQkMsSUFBaEIsQ0FBcUJuaEIsUUFBckIsQ0FBTjtBQUFzQyxLQUExQyxDQUEwQyxPQUFNaWUsR0FBTixFQUFVO0FBQUMsWUFBTSxJQUFJbFUsS0FBSixDQUFXLDhEQUE2RGxLLEtBQUssQ0FBQzJDLElBQUssNEZBQXpFLElBQXNLLFNBQTRCLENBQTVCLEdBQStGLEVBQXJRLENBQVYsQ0FBTjtBQUEyUjtBQUFDLEdBQTFYLE1BQThYLEVBQXVDOztBQUFBLFFBQU00ZSxRQUFRLEdBQUNILEtBQUssSUFBRSxPQUFPQSxLQUFQLEtBQWUsUUFBdEIsSUFBZ0NBLEtBQUssQ0FBQ25oQixHQUFyRDtBQUF5RCxRQUFLLENBQUN1aEIsa0JBQUQsRUFBb0IxRixTQUFwQixJQUErQixDQUFDLEdBQUVoRyxnQkFBZ0IsQ0FBQzhGLGVBQXBCLEVBQXFDO0FBQUNDLGNBQVUsRUFBQztBQUFaLEdBQXJDLENBQXBDOztBQUErRixRQUFNSCxNQUFNLEdBQUNoRyxNQUFNLENBQUNpQixPQUFQLENBQWU4SyxXQUFmLENBQTJCQyxFQUFFLElBQUU7QUFBQ0Ysc0JBQWtCLENBQUNFLEVBQUQsQ0FBbEI7O0FBQXVCLFFBQUdILFFBQUgsRUFBWTtBQUFDLFVBQUcsT0FBT0EsUUFBUCxLQUFrQixVQUFyQixFQUFnQ0EsUUFBUSxDQUFDRyxFQUFELENBQVIsQ0FBaEMsS0FBa0QsSUFBRyxPQUFPSCxRQUFQLEtBQWtCLFFBQXJCLEVBQThCO0FBQUNBLGdCQUFRLENBQUNSLE9BQVQsR0FBaUJXLEVBQWpCO0FBQXFCO0FBQUM7QUFBQyxHQUE1SyxFQUE2SyxDQUFDSCxRQUFELEVBQVVDLGtCQUFWLENBQTdLLENBQWI7O0FBQXlOLEdBQUMsR0FBRTlMLE1BQU0sQ0FBQ25VLFNBQVYsRUFBcUIsTUFBSTtBQUFDLFVBQU1vZ0IsY0FBYyxHQUFDN0YsU0FBUyxJQUFFbEQsQ0FBWCxJQUFjLENBQUMsR0FBRTRGLE9BQU8sQ0FBQ0ssVUFBWCxFQUF1QmxjLElBQXZCLENBQW5DO0FBQWdFLFVBQU1tYyxTQUFTLEdBQUMsT0FBT0MsTUFBUCxLQUFnQixXQUFoQixHQUE0QkEsTUFBNUIsR0FBbUNsTyxNQUFNLElBQUVBLE1BQU0sQ0FBQ2tPLE1BQWxFO0FBQXlFLFVBQU02QyxZQUFZLEdBQUNsRCxVQUFVLENBQUMvYixJQUFJLEdBQUMsR0FBTCxHQUFTaWIsRUFBVCxJQUFha0IsU0FBUyxHQUFDLE1BQUlBLFNBQUwsR0FBZSxFQUFyQyxDQUFELENBQTdCOztBQUF3RSxRQUFHNkMsY0FBYyxJQUFFLENBQUNDLFlBQXBCLEVBQWlDO0FBQUNqRCxjQUFRLENBQUM5TixNQUFELEVBQVFsTyxJQUFSLEVBQWFpYixFQUFiLEVBQWdCO0FBQUNtQixjQUFNLEVBQUNEO0FBQVIsT0FBaEIsQ0FBUjtBQUE2QztBQUFDLEdBQTNULEVBQTRULENBQUNsQixFQUFELEVBQUlqYixJQUFKLEVBQVNtWixTQUFULEVBQW1CaUQsTUFBbkIsRUFBMEJuRyxDQUExQixFQUE0Qi9ILE1BQTVCLENBQTVUO0FBQWlXLFFBQU1nUixVQUFVLEdBQUM7QUFBQzVoQixPQUFHLEVBQUN5YixNQUFMO0FBQVlvRyxXQUFPLEVBQUNuQyxDQUFDLElBQUU7QUFBQyxVQUFHeUIsS0FBSyxDQUFDcGhCLEtBQU4sSUFBYSxPQUFPb2hCLEtBQUssQ0FBQ3BoQixLQUFOLENBQVk4aEIsT0FBbkIsS0FBNkIsVUFBN0MsRUFBd0Q7QUFBQ1YsYUFBSyxDQUFDcGhCLEtBQU4sQ0FBWThoQixPQUFaLENBQW9CbkMsQ0FBcEI7QUFBd0I7O0FBQUEsVUFBRyxDQUFDQSxDQUFDLENBQUNvQyxnQkFBTixFQUF1QjtBQUFDckMsbUJBQVcsQ0FBQ0MsQ0FBRCxFQUFHOU8sTUFBSCxFQUFVbE8sSUFBVixFQUFlaWIsRUFBZixFQUFrQnpLLE9BQWxCLEVBQTBCeU0sT0FBMUIsRUFBa0NDLE1BQWxDLEVBQXlDZCxNQUF6QyxDQUFYO0FBQTZEO0FBQUM7QUFBL0wsR0FBakI7O0FBQWtOOEMsWUFBVSxDQUFDRyxZQUFYLEdBQXdCckMsQ0FBQyxJQUFFO0FBQUMsUUFBRyxDQUFDLENBQUMsR0FBRW5CLE9BQU8sQ0FBQ0ssVUFBWCxFQUF1QmxjLElBQXZCLENBQUosRUFBaUM7O0FBQU8sUUFBR3llLEtBQUssQ0FBQ3BoQixLQUFOLElBQWEsT0FBT29oQixLQUFLLENBQUNwaEIsS0FBTixDQUFZZ2lCLFlBQW5CLEtBQWtDLFVBQWxELEVBQTZEO0FBQUNaLFdBQUssQ0FBQ3BoQixLQUFOLENBQVlnaUIsWUFBWixDQUF5QnJDLENBQXpCO0FBQTZCOztBQUFBaEIsWUFBUSxDQUFDOU4sTUFBRCxFQUFRbE8sSUFBUixFQUFhaWIsRUFBYixFQUFnQjtBQUFDcEQsY0FBUSxFQUFDO0FBQVYsS0FBaEIsQ0FBUjtBQUEwQyxHQUF6TSxDQVY1dkMsQ0FVczhDO0FBQzdoRDs7O0FBQ0EsTUFBR3hhLEtBQUssQ0FBQzBnQixRQUFOLElBQWdCVSxLQUFLLENBQUNhLElBQU4sS0FBYSxHQUFiLElBQWtCLEVBQUUsVUFBU2IsS0FBSyxDQUFDcGhCLEtBQWpCLENBQXJDLEVBQTZEO0FBQUMsVUFBTThlLFNBQVMsR0FBQyxPQUFPQyxNQUFQLEtBQWdCLFdBQWhCLEdBQTRCQSxNQUE1QixHQUFtQ2xPLE1BQU0sSUFBRUEsTUFBTSxDQUFDa08sTUFBbEUsQ0FBRCxDQUEwRTtBQUN2STs7QUFDQSxVQUFNbUQsWUFBWSxHQUFDclIsTUFBTSxJQUFFQSxNQUFNLENBQUNzUixjQUFmLElBQStCLENBQUMsR0FBRTNELE9BQU8sQ0FBQzRELGVBQVgsRUFBNEJ4RSxFQUE1QixFQUErQmtCLFNBQS9CLEVBQXlDak8sTUFBTSxJQUFFQSxNQUFNLENBQUN3UixPQUF4RCxFQUFnRXhSLE1BQU0sSUFBRUEsTUFBTSxDQUFDeVIsYUFBL0UsQ0FBbEQ7QUFBZ0pULGNBQVUsQ0FBQ2xmLElBQVgsR0FBZ0J1ZixZQUFZLElBQUUsQ0FBQyxHQUFFMUQsT0FBTyxDQUFDK0QsV0FBWCxFQUF3QixDQUFDLEdBQUUvRCxPQUFPLENBQUNnRSxTQUFYLEVBQXNCNUUsRUFBdEIsRUFBeUJrQixTQUF6QixFQUFtQ2pPLE1BQU0sSUFBRUEsTUFBTSxDQUFDNFIsYUFBbEQsQ0FBeEIsQ0FBOUI7QUFBeUg7O0FBQUEsU0FBTSxhQUFhL00sTUFBTSxDQUFDaUIsT0FBUCxDQUFlK0wsWUFBZixDQUE0QnRCLEtBQTVCLEVBQWtDUyxVQUFsQyxDQUFuQjtBQUFrRTs7QUFBQSxJQUFJYyxRQUFRLEdBQUMzQyxJQUFiO0FBQWtCMUssZUFBQSxHQUFnQnFOLFFBQWhCLEM7Ozs7Ozs7Ozs7O0FDeEJoVjs7QUFBQXJOLGtCQUFBLEdBQW1CLElBQW5CO0FBQXdCQSwrQkFBQSxHQUFnQ3NOLHVCQUFoQztBQUF3RHROLGtDQUFBLEdBQW1DLEtBQUssQ0FBeEM7QUFBMEM7QUFDdkk7QUFDQTs7QUFBRyxTQUFTc04sdUJBQVQsQ0FBaUN4TCxJQUFqQyxFQUFzQztBQUFDLFNBQU9BLElBQUksQ0FBQ3lMLFFBQUwsQ0FBYyxHQUFkLEtBQW9CekwsSUFBSSxLQUFHLEdBQTNCLEdBQStCQSxJQUFJLENBQUNyVixLQUFMLENBQVcsQ0FBWCxFQUFhLENBQUMsQ0FBZCxDQUEvQixHQUFnRHFWLElBQXZEO0FBQTZEO0FBQUE7QUFDdkc7QUFDQTtBQUNBOzs7QUFBRyxNQUFNMEwsMEJBQTBCLEdBQUNqWixNQUFBLEdBQWtDdU4sQ0FBbEMsR0FBNkt3TCx1QkFBOU07QUFBc090TixrQ0FBQSxHQUFtQ3dOLDBCQUFuQyxDOzs7Ozs7Ozs7OztBQ0w1Tjs7QUFBQXhOLGtCQUFBLEdBQW1CLElBQW5CO0FBQXdCQSwwQkFBQSxHQUEyQkEsMkJBQUEsR0FBNEIsS0FBSyxDQUE1RDs7QUFBOEQsTUFBTXlOLG1CQUFtQixHQUFDLE9BQU9DLElBQVAsS0FBYyxXQUFkLElBQTJCQSxJQUFJLENBQUNELG1CQUFoQyxJQUFxRCxVQUFTRSxFQUFULEVBQVk7QUFBQyxNQUFJQyxLQUFLLEdBQUM1YSxJQUFJLENBQUM2YSxHQUFMLEVBQVY7QUFBcUIsU0FBT0MsVUFBVSxDQUFDLFlBQVU7QUFBQ0gsTUFBRSxDQUFDO0FBQUNJLGdCQUFVLEVBQUMsS0FBWjtBQUFrQkMsbUJBQWEsRUFBQyxZQUFVO0FBQUMsZUFBT2xMLElBQUksQ0FBQ21MLEdBQUwsQ0FBUyxDQUFULEVBQVcsTUFBSWpiLElBQUksQ0FBQzZhLEdBQUwsS0FBV0QsS0FBZixDQUFYLENBQVA7QUFBMEM7QUFBckYsS0FBRCxDQUFGO0FBQTRGLEdBQXhHLEVBQXlHLENBQXpHLENBQWpCO0FBQThILENBQS9POztBQUFnUDVOLDJCQUFBLEdBQTRCeU4sbUJBQTVCOztBQUFnRCxNQUFNUyxrQkFBa0IsR0FBQyxPQUFPUixJQUFQLEtBQWMsV0FBZCxJQUEyQkEsSUFBSSxDQUFDUSxrQkFBaEMsSUFBb0QsVUFBU2hYLEVBQVQsRUFBWTtBQUFDLFNBQU9pWCxZQUFZLENBQUNqWCxFQUFELENBQW5CO0FBQXlCLENBQW5IOztBQUFvSDhJLDBCQUFBLEdBQTJCa08sa0JBQTNCLEM7Ozs7Ozs7Ozs7O0FDQTFlOztBQUFBLElBQUlwTyxzQkFBc0IsR0FBQ0MsbUJBQU8sQ0FBQyx1SUFBRCxDQUFsQzs7QUFBbUZDLGtCQUFBLEdBQW1CLElBQW5CO0FBQXdCQSxzQkFBQSxHQUF1Qm9PLGNBQXZCO0FBQXNDcE8sb0JBQUEsR0FBcUJxTyxZQUFyQjtBQUFrQ3JPLDhCQUFBLEdBQStCc08sc0JBQS9CO0FBQXNEdE8sZUFBQSxHQUFnQixLQUFLLENBQXJCOztBQUF1QixJQUFJdU8sc0JBQXNCLEdBQUN6TyxzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyw0SEFBRCxDQUFSLENBQWpEOztBQUF3SCxJQUFJeU8sb0JBQW9CLEdBQUN6TyxtQkFBTyxDQUFDLDBGQUFELENBQWhDLEMsQ0FBNEQ7QUFDamM7QUFDQTtBQUNBOzs7QUFDQSxNQUFNME8saUJBQWlCLEdBQUMsSUFBeEI7O0FBQTZCLFNBQVNDLFVBQVQsQ0FBb0J0RyxHQUFwQixFQUF3Qi9iLEdBQXhCLEVBQTRCc2lCLFNBQTVCLEVBQXNDO0FBQUMsTUFBSUMsS0FBSyxHQUFDdmlCLEdBQUcsQ0FBQzRKLEdBQUosQ0FBUW1TLEdBQVIsQ0FBVjs7QUFBdUIsTUFBR3dHLEtBQUgsRUFBUztBQUFDLFFBQUcsWUFBV0EsS0FBZCxFQUFvQjtBQUFDLGFBQU9BLEtBQUssQ0FBQ0MsTUFBYjtBQUFxQjs7QUFBQSxXQUFPbkssT0FBTyxDQUFDQyxPQUFSLENBQWdCaUssS0FBaEIsQ0FBUDtBQUErQjs7QUFBQSxNQUFJRSxRQUFKO0FBQWEsUUFBTUMsSUFBSSxHQUFDLElBQUlySyxPQUFKLENBQVlDLE9BQU8sSUFBRTtBQUFDbUssWUFBUSxHQUFDbkssT0FBVDtBQUFrQixHQUF4QyxDQUFYO0FBQXFEdFksS0FBRyxDQUFDMmlCLEdBQUosQ0FBUTVHLEdBQVIsRUFBWXdHLEtBQUssR0FBQztBQUFDakssV0FBTyxFQUFDbUssUUFBVDtBQUFrQkQsVUFBTSxFQUFDRTtBQUF6QixHQUFsQjtBQUFrRCxTQUFPSixTQUFTLEdBQUM7QUFDblRBLFdBQVMsR0FBR3hpQixJQUFaLENBQWlCOGlCLEtBQUssS0FBR0gsUUFBUSxDQUFDRyxLQUFELENBQVIsRUFBZ0JBLEtBQW5CLENBQXRCLENBRGtULEdBQ2pRRixJQURpUDtBQUMzTzs7QUFBQSxTQUFTRyxXQUFULENBQXFCMWhCLElBQXJCLEVBQTBCO0FBQUMsTUFBRztBQUFDQSxRQUFJLEdBQUMyaEIsUUFBUSxDQUFDdEgsYUFBVCxDQUF1QixNQUF2QixDQUFMO0FBQW9DLFdBQU87QUFDakk7QUFDQSxPQUFDLENBQUN2WixNQUFNLENBQUM4Z0Isb0JBQVQsSUFBK0IsQ0FBQyxDQUFDRCxRQUFRLENBQUNFLFlBQTFDLElBQXdEN2hCLElBQUksQ0FBQzhoQixPQUFMLENBQWFDLFFBQWIsQ0FBc0IsVUFBdEI7QUFGa0U7QUFFOUIsR0FGVixDQUVVLE9BQU1DLE9BQU4sRUFBYztBQUFDLFdBQU8sS0FBUDtBQUFjO0FBQUM7O0FBQUEsTUFBTUMsV0FBVyxHQUFDUCxXQUFXLEVBQTdCOztBQUFnQyxTQUFTUSxjQUFULENBQXdCcmlCLElBQXhCLEVBQTZCaWIsRUFBN0IsRUFBZ0M5YSxJQUFoQyxFQUFxQztBQUFDLFNBQU8sSUFBSWtYLE9BQUosQ0FBWSxDQUFDbEYsR0FBRCxFQUFLbVEsR0FBTCxLQUFXO0FBQUMsUUFBR1IsUUFBUSxDQUFDUyxhQUFULENBQXdCLCtCQUE4QnZpQixJQUFLLElBQTNELENBQUgsRUFBbUU7QUFBQyxhQUFPbVMsR0FBRyxFQUFWO0FBQWM7O0FBQUFoUyxRQUFJLEdBQUMyaEIsUUFBUSxDQUFDdEgsYUFBVCxDQUF1QixNQUF2QixDQUFMLENBQW5GLENBQXVIOztBQUNyVixRQUFHUyxFQUFILEVBQU05YSxJQUFJLENBQUM4YSxFQUFMLEdBQVFBLEVBQVI7QUFBVzlhLFFBQUksQ0FBQzZhLEdBQUwsR0FBVSxVQUFWO0FBQW9CN2EsUUFBSSxDQUFDcWlCLFdBQUwsR0FBaUJ0YixTQUFqQjtBQUFpRC9HLFFBQUksQ0FBQ3dYLE1BQUwsR0FBWXhGLEdBQVo7QUFBZ0JoUyxRQUFJLENBQUNzaUIsT0FBTCxHQUFhSCxHQUFiLENBRHdILENBQ3ZHOztBQUN2SG5pQixRQUFJLENBQUNILElBQUwsR0FBVUEsSUFBVjtBQUFlOGhCLFlBQVEsQ0FBQ1ksSUFBVCxDQUFjQyxXQUFkLENBQTBCeGlCLElBQTFCO0FBQWlDLEdBRnVKLENBQVA7QUFFN0k7O0FBQUEsTUFBTXlpQixnQkFBZ0IsR0FBQ0MsTUFBTSxDQUFDLGtCQUFELENBQTdCLEMsQ0FBa0Q7O0FBQ3JHLFNBQVM5QixjQUFULENBQXdCdEYsR0FBeEIsRUFBNEI7QUFBQyxTQUFPck4sTUFBTSxDQUFDMFUsY0FBUCxDQUFzQnJILEdBQXRCLEVBQTBCbUgsZ0JBQTFCLEVBQTJDLEVBQTNDLENBQVA7QUFBdUQ7O0FBQUEsU0FBUzVCLFlBQVQsQ0FBc0J2RixHQUF0QixFQUEwQjtBQUFDLFNBQU9BLEdBQUcsSUFBRW1ILGdCQUFnQixJQUFJbkgsR0FBaEM7QUFBcUM7O0FBQUEsU0FBU3NILFlBQVQsQ0FBc0JoUCxHQUF0QixFQUEwQmlQLE1BQTFCLEVBQWlDO0FBQUMsU0FBTyxJQUFJM0wsT0FBSixDQUFZLENBQUNDLE9BQUQsRUFBUzJMLE1BQVQsS0FBa0I7QUFBQ0QsVUFBTSxHQUFDbEIsUUFBUSxDQUFDdEgsYUFBVCxDQUF1QixRQUF2QixDQUFQLENBQUQsQ0FBeUM7QUFDcFE7QUFDQTs7QUFDQXdJLFVBQU0sQ0FBQ3JMLE1BQVAsR0FBY0wsT0FBZDs7QUFBc0IwTCxVQUFNLENBQUNQLE9BQVAsR0FBZSxNQUFJUSxNQUFNLENBQUNsQyxjQUFjLENBQUMsSUFBSXhaLEtBQUosQ0FBVywwQkFBeUJ3TSxHQUFJLEVBQXhDLENBQUQsQ0FBZixDQUF6QixDQUhxTSxDQUcvRztBQUM1Rzs7O0FBQ0FpUCxVQUFNLENBQUNSLFdBQVAsR0FBbUJ0YixTQUFuQixDQUwyTixDQUt4SztBQUNuRDs7QUFDQThiLFVBQU0sQ0FBQ2pQLEdBQVAsR0FBV0EsR0FBWDtBQUFlK04sWUFBUSxDQUFDaGEsSUFBVCxDQUFjNmEsV0FBZCxDQUEwQkssTUFBMUI7QUFBbUMsR0FQMkksQ0FBUDtBQU9qSSxDLENBQUE7OztBQUNyRCxTQUFTRSx5QkFBVCxDQUFtQ2pOLENBQW5DLEVBQXFDa04sRUFBckMsRUFBd0MxSCxHQUF4QyxFQUE0QztBQUFDLFNBQU8sSUFBSXBFLE9BQUosQ0FBWSxDQUFDQyxPQUFELEVBQVMyTCxNQUFULEtBQWtCO0FBQUMsUUFBSUcsU0FBUyxHQUFDLEtBQWQ7QUFBb0JuTixLQUFDLENBQUNuWCxJQUFGLENBQU9xSyxDQUFDLElBQUU7QUFBQztBQUNsSGlhLGVBQVMsR0FBQyxJQUFWO0FBQWU5TCxhQUFPLENBQUNuTyxDQUFELENBQVA7QUFBWSxLQUQ0RSxFQUMxRW9PLEtBRDBFLENBQ3BFMEwsTUFEb0U7QUFDNUQsS0FBQyxHQUFFOUIsb0JBQW9CLENBQUNmLG1CQUF4QixFQUE2QyxNQUFJSyxVQUFVLENBQUMsTUFBSTtBQUFDLFVBQUcsQ0FBQzJDLFNBQUosRUFBYztBQUFDSCxjQUFNLENBQUN4SCxHQUFELENBQU47QUFBYTtBQUFDLEtBQW5DLEVBQW9DMEgsRUFBcEMsQ0FBM0Q7QUFBcUcsR0FENUYsQ0FBUDtBQUNzRyxDLENBQUE7QUFDbko7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsU0FBU2xDLHNCQUFULEdBQWlDO0FBQUMsTUFBR1osSUFBSSxDQUFDZ0QsZ0JBQVIsRUFBeUI7QUFBQyxXQUFPaE0sT0FBTyxDQUFDQyxPQUFSLENBQWdCK0ksSUFBSSxDQUFDZ0QsZ0JBQXJCLENBQVA7QUFBK0M7O0FBQUEsUUFBTUMsZUFBZSxHQUFDLElBQUlqTSxPQUFKLENBQVlDLE9BQU8sSUFBRTtBQUFDO0FBQ3ZKLFVBQU1nSixFQUFFLEdBQUNELElBQUksQ0FBQ2tELG1CQUFkOztBQUFrQ2xELFFBQUksQ0FBQ2tELG1CQUFMLEdBQXlCLE1BQUk7QUFBQ2pNLGFBQU8sQ0FBQytJLElBQUksQ0FBQ2dELGdCQUFOLENBQVA7QUFBK0IvQyxRQUFFLElBQUVBLEVBQUUsRUFBTjtBQUFVLEtBQXZFO0FBQXlFLEdBRHNCLENBQXRCO0FBQ0UsU0FBTzRDLHlCQUF5QixDQUFDSSxlQUFELEVBQWlCbEMsaUJBQWpCLEVBQW1DTCxjQUFjLENBQUMsSUFBSXhaLEtBQUosQ0FBVSxzQ0FBVixDQUFELENBQWpELENBQWhDO0FBQXVJOztBQUFBLFNBQVNpYyxnQkFBVCxDQUEwQkMsV0FBMUIsRUFBc0NDLEtBQXRDLEVBQTRDO0FBQUMsWUFBd0M7QUFBQyxXQUFPck0sT0FBTyxDQUFDQyxPQUFSLENBQWdCO0FBQUNxTSxhQUFPLEVBQUMsQ0FBQ0YsV0FBVyxHQUFDLDRCQUFaLEdBQXlDRyxTQUFTLENBQUMsQ0FBQyxHQUFFMUMsc0JBQXNCLENBQUNsTixPQUExQixFQUFtQzBQLEtBQW5DLEVBQXlDLEtBQXpDLENBQUQsQ0FBbkQsQ0FBVDtBQUErRztBQUNoZEcsU0FBRyxFQUFDO0FBRDZWLEtBQWhCLENBQVA7QUFDaFU7O0FBQUEsU0FBTzVDLHNCQUFzQixHQUFHbmlCLElBQXpCLENBQThCZ2xCLFFBQVEsSUFBRTtBQUFDLFFBQUcsRUFBRUosS0FBSyxJQUFJSSxRQUFYLENBQUgsRUFBd0I7QUFBQyxZQUFNL0MsY0FBYyxDQUFDLElBQUl4WixLQUFKLENBQVcsMkJBQTBCbWMsS0FBTSxFQUEzQyxDQUFELENBQXBCO0FBQXFFOztBQUFBLFVBQU1LLFFBQVEsR0FBQ0QsUUFBUSxDQUFDSixLQUFELENBQVIsQ0FBZ0Ixa0IsR0FBaEIsQ0FBb0J1aUIsS0FBSyxJQUFFa0MsV0FBVyxHQUFDLFNBQVosR0FBc0JHLFNBQVMsQ0FBQ3JDLEtBQUQsQ0FBMUQsQ0FBZjtBQUFrRixXQUFNO0FBQUNvQyxhQUFPLEVBQUNJLFFBQVEsQ0FBQ25PLE1BQVQsQ0FBZ0JvTyxDQUFDLElBQUVBLENBQUMsQ0FBQzlELFFBQUYsQ0FBVyxLQUFYLENBQW5CLENBQVQ7QUFBK0MyRCxTQUFHLEVBQUNFLFFBQVEsQ0FBQ25PLE1BQVQsQ0FBZ0JvTyxDQUFDLElBQUVBLENBQUMsQ0FBQzlELFFBQUYsQ0FBVyxNQUFYLENBQW5CO0FBQW5ELEtBQU47QUFBa0csR0FBM1QsQ0FBUDtBQUFxVTs7QUFBQSxTQUFTK0QsaUJBQVQsQ0FBMkJSLFdBQTNCLEVBQXVDO0FBQUMsUUFBTVMsV0FBVyxHQUFDLElBQUkxUSxHQUFKLEVBQWxCO0FBQTRCLFFBQU0yUSxhQUFhLEdBQUMsSUFBSTNRLEdBQUosRUFBcEI7QUFBOEIsUUFBTTRRLFdBQVcsR0FBQyxJQUFJNVEsR0FBSixFQUFsQjtBQUE0QixRQUFNNlEsTUFBTSxHQUFDLElBQUk3USxHQUFKLEVBQWI7O0FBQXVCLFdBQVM4USxrQkFBVCxDQUE0QnZRLEdBQTVCLEVBQWdDO0FBQUMsUUFBSTJOLElBQUksR0FBQ3lDLGFBQWEsQ0FBQ3ZiLEdBQWQsQ0FBa0JtTCxHQUFsQixDQUFUOztBQUFnQyxRQUFHMk4sSUFBSCxFQUFRO0FBQUMsYUFBT0EsSUFBUDtBQUFhLEtBQXZELENBQXVEOzs7QUFDM2pCLFFBQUdJLFFBQVEsQ0FBQ1MsYUFBVCxDQUF3QixnQkFBZXhPLEdBQUksSUFBM0MsQ0FBSCxFQUFtRDtBQUFDLGFBQU9zRCxPQUFPLENBQUNDLE9BQVIsRUFBUDtBQUEwQjs7QUFBQTZNLGlCQUFhLENBQUN4QyxHQUFkLENBQWtCNU4sR0FBbEIsRUFBc0IyTixJQUFJLEdBQUNxQixZQUFZLENBQUNoUCxHQUFELENBQXZDO0FBQThDLFdBQU8yTixJQUFQO0FBQWE7O0FBQUEsV0FBUzZDLGVBQVQsQ0FBeUJ2a0IsSUFBekIsRUFBOEI7QUFBQyxRQUFJMGhCLElBQUksR0FBQzBDLFdBQVcsQ0FBQ3hiLEdBQVosQ0FBZ0I1SSxJQUFoQixDQUFUOztBQUErQixRQUFHMGhCLElBQUgsRUFBUTtBQUFDLGFBQU9BLElBQVA7QUFBYTs7QUFBQTBDLGVBQVcsQ0FBQ3pDLEdBQVosQ0FBZ0IzaEIsSUFBaEIsRUFBcUIwaEIsSUFBSSxHQUFDdFosS0FBSyxDQUFDcEksSUFBRCxDQUFMLENBQVlsQixJQUFaLENBQWlCcVQsR0FBRyxJQUFFO0FBQUMsVUFBRyxDQUFDQSxHQUFHLENBQUMzSixFQUFSLEVBQVc7QUFBQyxjQUFNLElBQUlqQixLQUFKLENBQVcsOEJBQTZCdkgsSUFBSyxFQUE3QyxDQUFOO0FBQXVEOztBQUFBLGFBQU9tUyxHQUFHLENBQUNxUyxJQUFKLEdBQVcxbEIsSUFBWCxDQUFnQjBsQixJQUFJLEtBQUc7QUFBQ3hrQixZQUFJLEVBQUNBLElBQU47QUFBVzJNLGVBQU8sRUFBQzZYO0FBQW5CLE9BQUgsQ0FBcEIsQ0FBUDtBQUEwRCxLQUFwSixFQUFzSmpOLEtBQXRKLENBQTRKa0UsR0FBRyxJQUFFO0FBQUMsWUFBTXNGLGNBQWMsQ0FBQ3RGLEdBQUQsQ0FBcEI7QUFBMkIsS0FBN0wsQ0FBMUI7QUFBME4sV0FBT2lHLElBQVA7QUFBYTs7QUFBQSxTQUFNO0FBQUMrQyxrQkFBYyxDQUFDZixLQUFELEVBQU87QUFBQyxhQUFPckMsVUFBVSxDQUFDcUMsS0FBRCxFQUFPUSxXQUFQLENBQWpCO0FBQXNDLEtBQTdEOztBQUE4RFEsZ0JBQVksQ0FBQ2hCLEtBQUQsRUFBT2lCLE9BQVAsRUFBZTtBQUFDdE4sYUFBTyxDQUFDQyxPQUFSLENBQWdCcU4sT0FBaEIsRUFBeUI3bEIsSUFBekIsQ0FBOEI4bEIsRUFBRSxJQUFFQSxFQUFFLEVBQXBDLEVBQXdDOWxCLElBQXhDLENBQTZDNlQsT0FBTyxLQUFHO0FBQUNrUyxpQkFBUyxFQUFDbFMsT0FBTyxJQUFFQSxPQUFPLENBQUNxQixPQUFqQixJQUEwQnJCLE9BQXJDO0FBQTZDQSxlQUFPLEVBQUNBO0FBQXJELE9BQUgsQ0FBcEQsRUFBc0g4SSxHQUFHLEtBQUc7QUFBQzNWLGFBQUssRUFBQzJWO0FBQVAsT0FBSCxDQUF6SCxFQUEwSTNjLElBQTFJLENBQStJZ21CLEtBQUssSUFBRTtBQUFDLGNBQU1DLEdBQUcsR0FBQ2IsV0FBVyxDQUFDdGIsR0FBWixDQUFnQjhhLEtBQWhCLENBQVY7QUFBaUNRLG1CQUFXLENBQUN2QyxHQUFaLENBQWdCK0IsS0FBaEIsRUFBc0JvQixLQUF0QjtBQUE2QixZQUFHQyxHQUFHLElBQUUsYUFBWUEsR0FBcEIsRUFBd0JBLEdBQUcsQ0FBQ3pOLE9BQUosQ0FBWXdOLEtBQVo7QUFBb0IsT0FBalE7QUFBb1EsS0FBOVY7O0FBQStWRSxhQUFTLENBQUN0QixLQUFELEVBQU8xSCxRQUFQLEVBQWdCO0FBQUMsYUFBT3FGLFVBQVUsQ0FBQ3FDLEtBQUQsRUFBT1csTUFBUCxFQUFjLE1BQUk7QUFBQyxlQUFPbkIseUJBQXlCLENBQUNNLGdCQUFnQixDQUFDQyxXQUFELEVBQWFDLEtBQWIsQ0FBaEIsQ0FBb0M1a0IsSUFBcEMsQ0FBeUMsQ0FBQztBQUFDNmtCLGlCQUFEO0FBQVNFO0FBQVQsU0FBRCxLQUFpQjtBQUFDLGlCQUFPeE0sT0FBTyxDQUFDYyxHQUFSLENBQVksQ0FBQytMLFdBQVcsQ0FBQ2UsR0FBWixDQUFnQnZCLEtBQWhCLElBQXVCLEVBQXZCLEdBQTBCck0sT0FBTyxDQUFDYyxHQUFSLENBQVl3TCxPQUFPLENBQUMza0IsR0FBUixDQUFZc2xCLGtCQUFaLENBQVosQ0FBM0IsRUFBd0VqTixPQUFPLENBQUNjLEdBQVIsQ0FBWTBMLEdBQUcsQ0FBQzdrQixHQUFKLENBQVF1bEIsZUFBUixDQUFaLENBQXhFLENBQVosQ0FBUDtBQUFvSSxTQUEvTCxFQUFpTXpsQixJQUFqTSxDQUFzTXFULEdBQUcsSUFBRTtBQUFDLGlCQUFPLEtBQUtzUyxjQUFMLENBQW9CZixLQUFwQixFQUEyQjVrQixJQUEzQixDQUFnQ29tQixVQUFVLEtBQUc7QUFBQ0Esc0JBQUQ7QUFBWUMsa0JBQU0sRUFBQ2hULEdBQUcsQ0FBQyxDQUFEO0FBQXRCLFdBQUgsQ0FBMUMsQ0FBUDtBQUFrRixTQUE5UixDQUFELEVBQWlTaVAsaUJBQWpTLEVBQW1UTCxjQUFjLENBQUMsSUFBSXhaLEtBQUosQ0FBVyxtQ0FBa0NtYyxLQUFNLEVBQW5ELENBQUQsQ0FBalUsQ0FBekIsQ0FBbVo1a0IsSUFBblosQ0FBd1osQ0FBQztBQUFDb21CLG9CQUFEO0FBQVlDO0FBQVosU0FBRCxLQUF1QjtBQUFDLGdCQUFNaFQsR0FBRyxHQUFDL0QsTUFBTSxDQUFDd00sTUFBUCxDQUFjO0FBQUN1SyxrQkFBTSxFQUFDQTtBQUFSLFdBQWQsRUFBOEJELFVBQTlCLENBQVY7QUFBb0QsaUJBQU0sV0FBVUEsVUFBVixHQUFxQkEsVUFBckIsR0FBZ0MvUyxHQUF0QztBQUEyQyxTQUEvZ0IsRUFBaWhCb0YsS0FBamhCLENBQXVoQmtFLEdBQUcsSUFBRTtBQUFDLGNBQUdPLFFBQUgsRUFBWTtBQUFDO0FBQ3g1QyxrQkFBTVAsR0FBTjtBQUFXOztBQUFBLGlCQUFNO0FBQUMzVixpQkFBSyxFQUFDMlY7QUFBUCxXQUFOO0FBQW1CLFNBRGcxQixDQUFQO0FBQ3QwQixPQURtekIsQ0FBakI7QUFDL3hCLEtBRHNhOztBQUNyYU8sWUFBUSxDQUFDMEgsS0FBRCxFQUFPO0FBQUM7QUFDckQ7QUFDQSxVQUFJMEIsRUFBSjs7QUFBTyxVQUFHQSxFQUFFLEdBQUNDLFNBQVMsQ0FBQ0MsVUFBaEIsRUFBMkI7QUFBQztBQUNuQyxZQUFHRixFQUFFLENBQUNHLFFBQUgsSUFBYSxLQUFLaFcsSUFBTCxDQUFVNlYsRUFBRSxDQUFDSSxhQUFiLENBQWhCLEVBQTRDLE9BQU9uTyxPQUFPLENBQUNDLE9BQVIsRUFBUDtBQUEwQjs7QUFBQSxhQUFPa00sZ0JBQWdCLENBQUNDLFdBQUQsRUFBYUMsS0FBYixDQUFoQixDQUFvQzVrQixJQUFwQyxDQUF5QzJtQixNQUFNLElBQUVwTyxPQUFPLENBQUNjLEdBQVIsQ0FBWWlLLFdBQVcsR0FBQ3FELE1BQU0sQ0FBQzlCLE9BQVAsQ0FBZTNrQixHQUFmLENBQW1CZ2tCLE1BQU0sSUFBRVgsY0FBYyxDQUFDVyxNQUFELEVBQVEsUUFBUixDQUF6QyxDQUFELEdBQTZELEVBQXBGLENBQWpELEVBQTBJbGtCLElBQTFJLENBQStJLE1BQUk7QUFBQyxTQUFDLEdBQUVxaUIsb0JBQW9CLENBQUNmLG1CQUF4QixFQUE2QyxNQUFJLEtBQUs0RSxTQUFMLENBQWV0QixLQUFmLEVBQXFCLElBQXJCLEVBQTJCbk0sS0FBM0IsQ0FBaUMsTUFBSSxDQUFFLENBQXZDLENBQWpEO0FBQTRGLE9BQWhQLEVBQWtQQSxLQUFsUCxFQUF3UDtBQUNyVSxZQUFJLENBQUUsQ0FEdUUsQ0FBUDtBQUM3RDs7QUFMaWMsR0FBTjtBQUt4Yjs7QUFBQSxJQUFJeUksUUFBUSxHQUFDaUUsaUJBQWI7QUFBK0J0UixlQUFBLEdBQWdCcU4sUUFBaEIsQzs7Ozs7Ozs7Ozs7QUNqQzlCOztBQUFBLElBQUlwRSx1QkFBdUIsR0FBQ2xKLG1CQUFPLENBQUMseUlBQUQsQ0FBbkM7O0FBQXFGLElBQUlELHNCQUFzQixHQUFDQyxtQkFBTyxDQUFDLHVJQUFELENBQWxDOztBQUFtRkMsa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLGlCQUFBLEdBQWtCeEUsU0FBbEI7QUFBNEJ3RSxnQ0FBQSxHQUFpQytTLHdCQUFqQztBQUEwRC9TLG9CQUFBLEdBQXFCQSxrQkFBQSxHQUFtQkEsZUFBQSxHQUFnQixLQUFLLENBQTdEOztBQUErRCxJQUFJSSxNQUFNLEdBQUNOLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBakM7O0FBQW9ELElBQUlvSixRQUFRLEdBQUNGLHVCQUF1QixDQUFDbEosbUJBQU8sQ0FBQyxvR0FBRCxDQUFSLENBQXBDOztBQUFrRkMsY0FBQSxHQUFlbUosUUFBUSxDQUFDOUgsT0FBeEI7QUFBZ0NyQixrQkFBQSxHQUFtQm1KLFFBQVEsQ0FBQzZKLFVBQTVCOztBQUF1QyxJQUFJQyxjQUFjLEdBQUNsVCxtQkFBTyxDQUFDLDRFQUFELENBQTFCOztBQUFnRSxJQUFJbVQsV0FBVyxHQUFDcFQsc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsc0VBQUQsQ0FBUixDQUF0Qzs7QUFBaUVDLGtCQUFBLEdBQW1Ca1QsV0FBVyxDQUFDN1IsT0FBL0I7QUFBdUM7O0FBQW1CLE1BQU04UixlQUFlLEdBQUM7QUFBQzVYLFFBQU0sRUFBQyxJQUFSO0FBQWE7QUFDN3dCNlgsZ0JBQWMsRUFBQyxFQURpdkI7O0FBQzl1QkMsT0FBSyxDQUFDMUYsRUFBRCxFQUFJO0FBQUMsUUFBRyxLQUFLcFMsTUFBUixFQUFlLE9BQU9vUyxFQUFFLEVBQVQ7O0FBQVksZUFBK0IsRUFBK0I7QUFBQzs7QUFEMG9CLENBQXRCLEMsQ0FDbG5COztBQUN4SCxNQUFNMkYsaUJBQWlCLEdBQUMsQ0FBQyxVQUFELEVBQVksT0FBWixFQUFvQixPQUFwQixFQUE0QixRQUE1QixFQUFxQyxZQUFyQyxFQUFrRCxZQUFsRCxFQUErRCxVQUEvRCxFQUEwRSxRQUExRSxFQUFtRixTQUFuRixFQUE2RixlQUE3RixFQUE2RyxTQUE3RyxFQUF1SCxXQUF2SCxFQUFtSSxnQkFBbkksQ0FBeEI7QUFBNkssTUFBTUMsWUFBWSxHQUFDLENBQUMsa0JBQUQsRUFBb0IscUJBQXBCLEVBQTBDLHFCQUExQyxFQUFnRSxrQkFBaEUsRUFBbUYsaUJBQW5GLEVBQXFHLG9CQUFyRyxDQUFuQjtBQUE4SSxNQUFNQyxnQkFBZ0IsR0FBQyxDQUFDLE1BQUQsRUFBUSxTQUFSLEVBQWtCLFFBQWxCLEVBQTJCLE1BQTNCLEVBQWtDLFVBQWxDLEVBQTZDLGdCQUE3QyxDQUF2QixDLENBQXNGOztBQUNqWi9YLE1BQU0sQ0FBQzBVLGNBQVAsQ0FBc0JnRCxlQUF0QixFQUFzQyxRQUF0QyxFQUErQztBQUFDbGQsS0FBRyxHQUFFO0FBQUMsV0FBT2tULFFBQVEsQ0FBQzlILE9BQVQsQ0FBaUJvUyxNQUF4QjtBQUFnQzs7QUFBdkMsQ0FBL0M7QUFBeUZILGlCQUFpQixDQUFDckksT0FBbEIsQ0FBMEJ5SSxLQUFLLElBQUU7QUFBQztBQUMzSDtBQUNBO0FBQ0E7QUFDQWpZLFFBQU0sQ0FBQzBVLGNBQVAsQ0FBc0JnRCxlQUF0QixFQUFzQ08sS0FBdEMsRUFBNEM7QUFBQ3pkLE9BQUcsR0FBRTtBQUFDLFlBQU1zRixNQUFNLEdBQUNvWSxTQUFTLEVBQXRCO0FBQXlCLGFBQU9wWSxNQUFNLENBQUNtWSxLQUFELENBQWI7QUFBc0I7O0FBQXRELEdBQTVDO0FBQXNHLENBSmI7QUFJZUYsZ0JBQWdCLENBQUN2SSxPQUFqQixDQUF5QnlJLEtBQUssSUFBRTtBQUFDO0FBQ3pJOztBQUFDUCxpQkFBZSxDQUFDTyxLQUFELENBQWYsR0FBdUIsQ0FBQyxHQUFHOUksSUFBSixLQUFXO0FBQUMsVUFBTXJQLE1BQU0sR0FBQ29ZLFNBQVMsRUFBdEI7QUFBeUIsV0FBT3BZLE1BQU0sQ0FBQ21ZLEtBQUQsQ0FBTixDQUFjLEdBQUc5SSxJQUFqQixDQUFQO0FBQStCLEdBQTNGO0FBQTZGLENBRFU7QUFDUjJJLFlBQVksQ0FBQ3RJLE9BQWIsQ0FBcUJ0QixLQUFLLElBQUU7QUFBQ3dKLGlCQUFlLENBQUNFLEtBQWhCLENBQXNCLE1BQUk7QUFBQ2xLLFlBQVEsQ0FBQzlILE9BQVQsQ0FBaUJvUyxNQUFqQixDQUF3QkcsRUFBeEIsQ0FBMkJqSyxLQUEzQixFQUFpQyxDQUFDLEdBQUdpQixJQUFKLEtBQVc7QUFBQyxZQUFNaUosVUFBVSxHQUFFLEtBQUlsSyxLQUFLLENBQUM1TCxNQUFOLENBQWEsQ0FBYixFQUFnQkMsV0FBaEIsRUFBOEIsR0FBRTJMLEtBQUssQ0FBQ21LLFNBQU4sQ0FBZ0IsQ0FBaEIsQ0FBbUIsRUFBekU7QUFBMkUsWUFBTUMsZ0JBQWdCLEdBQUNaLGVBQXZCOztBQUF1QyxVQUFHWSxnQkFBZ0IsQ0FBQ0YsVUFBRCxDQUFuQixFQUFnQztBQUFDLFlBQUc7QUFBQ0UsMEJBQWdCLENBQUNGLFVBQUQsQ0FBaEIsQ0FBNkIsR0FBR2pKLElBQWhDO0FBQXVDLFNBQTNDLENBQTJDLE9BQU05QixHQUFOLEVBQVU7QUFBQ2phLGlCQUFPLENBQUNzRSxLQUFSLENBQWUsd0NBQXVDMGdCLFVBQVcsRUFBakU7QUFBb0VobEIsaUJBQU8sQ0FBQ3NFLEtBQVIsQ0FBZSxHQUFFMlYsR0FBRyxDQUFDaFUsT0FBUSxLQUFJZ1UsR0FBRyxDQUFDa0wsS0FBTSxFQUEzQztBQUErQztBQUFDO0FBQUMsS0FBM1c7QUFBOFcsR0FBelk7QUFBNFksQ0FBemE7O0FBQTJhLFNBQVNMLFNBQVQsR0FBb0I7QUFBQyxNQUFHLENBQUNSLGVBQWUsQ0FBQzVYLE1BQXBCLEVBQTJCO0FBQUMsVUFBTXpHLE9BQU8sR0FBQyxnQ0FBOEIscUVBQTVDO0FBQWtILFVBQU0sSUFBSUYsS0FBSixDQUFVRSxPQUFWLENBQU47QUFBMEI7O0FBQUEsU0FBT3FlLGVBQWUsQ0FBQzVYLE1BQXZCO0FBQStCLEMsQ0FBQTs7O0FBQ3Z1QixJQUFJOFIsUUFBUSxHQUFDOEYsZUFBYixDLENBQTZCOztBQUM3Qm5ULGVBQUEsR0FBZ0JxTixRQUFoQjs7QUFBeUIsU0FBUzdSLFNBQVQsR0FBb0I7QUFBQyxTQUFPNEUsTUFBTSxDQUFDaUIsT0FBUCxDQUFldE4sVUFBZixDQUEwQmtmLGNBQWMsQ0FBQ2dCLGFBQXpDLENBQVA7QUFBZ0UsQyxDQUFBO0FBQzlHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLE1BQU1DLFlBQVksR0FBQyxDQUFDLEdBQUd0SixJQUFKLEtBQVc7QUFBQ3VJLGlCQUFlLENBQUM1WCxNQUFoQixHQUF1QixJQUFJNE4sUUFBUSxDQUFDOUgsT0FBYixDQUFxQixHQUFHdUosSUFBeEIsQ0FBdkI7QUFBcUR1SSxpQkFBZSxDQUFDQyxjQUFoQixDQUErQm5JLE9BQS9CLENBQXVDMEMsRUFBRSxJQUFFQSxFQUFFLEVBQTdDO0FBQWlEd0YsaUJBQWUsQ0FBQ0MsY0FBaEIsR0FBK0IsRUFBL0I7QUFBa0MsU0FBT0QsZUFBZSxDQUFDNVgsTUFBdkI7QUFBK0IsQ0FBdE0sQyxDQUF1TTs7O0FBQ3ZNeUUsb0JBQUEsR0FBcUJrVSxZQUFyQjs7QUFBa0MsU0FBU25CLHdCQUFULENBQWtDeFgsTUFBbEMsRUFBeUM7QUFBQyxRQUFNMk4sT0FBTyxHQUFDM04sTUFBZDtBQUFxQixRQUFNNFksUUFBUSxHQUFDLEVBQWY7O0FBQWtCLE9BQUksTUFBTUMsUUFBVixJQUFzQmQsaUJBQXRCLEVBQXdDO0FBQUMsUUFBRyxPQUFPcEssT0FBTyxDQUFDa0wsUUFBRCxDQUFkLEtBQTJCLFFBQTlCLEVBQXVDO0FBQUNELGNBQVEsQ0FBQ0MsUUFBRCxDQUFSLEdBQW1CM1ksTUFBTSxDQUFDd00sTUFBUCxDQUFjb00sS0FBSyxDQUFDQyxPQUFOLENBQWNwTCxPQUFPLENBQUNrTCxRQUFELENBQXJCLElBQWlDLEVBQWpDLEdBQW9DLEVBQWxELEVBQXFEbEwsT0FBTyxDQUFDa0wsUUFBRCxDQUE1RCxDQUFuQixDQUFELENBQTRGOztBQUMvUjtBQUFVOztBQUFBRCxZQUFRLENBQUNDLFFBQUQsQ0FBUixHQUFtQmxMLE9BQU8sQ0FBQ2tMLFFBQUQsQ0FBMUI7QUFBc0MsR0FEMkIsQ0FDM0I7OztBQUNoREQsVUFBUSxDQUFDVixNQUFULEdBQWdCdEssUUFBUSxDQUFDOUgsT0FBVCxDQUFpQm9TLE1BQWpDO0FBQXdDRCxrQkFBZ0IsQ0FBQ3ZJLE9BQWpCLENBQXlCeUksS0FBSyxJQUFFO0FBQUNTLFlBQVEsQ0FBQ1QsS0FBRCxDQUFSLEdBQWdCLENBQUMsR0FBRzlJLElBQUosS0FBVztBQUFDLGFBQU8xQixPQUFPLENBQUN3SyxLQUFELENBQVAsQ0FBZSxHQUFHOUksSUFBbEIsQ0FBUDtBQUFnQyxLQUE1RDtBQUE4RCxHQUEvRjtBQUFpRyxTQUFPdUosUUFBUDtBQUFpQixDOzs7Ozs7Ozs7OztBQ25CN0k7O0FBQUFuVSxrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsdUJBQUEsR0FBd0JzRyxlQUF4Qjs7QUFBd0MsSUFBSWxHLE1BQU0sR0FBQ0wsbUJBQU8sQ0FBQyxvQkFBRCxDQUFsQjs7QUFBNEIsSUFBSXlPLG9CQUFvQixHQUFDek8sbUJBQU8sQ0FBQywwRkFBRCxDQUFoQzs7QUFBNEQsTUFBTXdVLHVCQUF1QixHQUFDLE9BQU9DLG9CQUFQLEtBQThCLFdBQTVEOztBQUF3RSxTQUFTbE8sZUFBVCxDQUF5QjtBQUFDQyxZQUFEO0FBQVl2YjtBQUFaLENBQXpCLEVBQStDO0FBQUMsUUFBTXlwQixVQUFVLEdBQUN6cEIsUUFBUSxJQUFFLENBQUN1cEIsdUJBQTVCO0FBQW9ELFFBQU1HLFNBQVMsR0FBQyxDQUFDLEdBQUV0VSxNQUFNLENBQUNvTCxNQUFWLEdBQWhCO0FBQW9DLFFBQUssQ0FBQ21KLE9BQUQsRUFBU0MsVUFBVCxJQUFxQixDQUFDLEdBQUV4VSxNQUFNLENBQUNwVSxRQUFWLEVBQW9CLEtBQXBCLENBQTFCO0FBQXFELFFBQU1vYSxNQUFNLEdBQUMsQ0FBQyxHQUFFaEcsTUFBTSxDQUFDK0wsV0FBVixFQUF1QkMsRUFBRSxJQUFFO0FBQUMsUUFBR3NJLFNBQVMsQ0FBQ2pKLE9BQWIsRUFBcUI7QUFBQ2lKLGVBQVMsQ0FBQ2pKLE9BQVY7QUFBb0JpSixlQUFTLENBQUNqSixPQUFWLEdBQWtCaGUsU0FBbEI7QUFBNkI7O0FBQUEsUUFBR2duQixVQUFVLElBQUVFLE9BQWYsRUFBdUI7O0FBQU8sUUFBR3ZJLEVBQUUsSUFBRUEsRUFBRSxDQUFDeUksT0FBVixFQUFrQjtBQUFDSCxlQUFTLENBQUNqSixPQUFWLEdBQWtCcUosT0FBTyxDQUFDMUksRUFBRCxFQUFJNUYsU0FBUyxJQUFFQSxTQUFTLElBQUVvTyxVQUFVLENBQUNwTyxTQUFELENBQXBDLEVBQWdEO0FBQUNEO0FBQUQsT0FBaEQsQ0FBekI7QUFBd0Y7QUFBQyxHQUE3TyxFQUE4TyxDQUFDa08sVUFBRCxFQUFZbE8sVUFBWixFQUF1Qm9PLE9BQXZCLENBQTlPLENBQWI7QUFBNFIsR0FBQyxHQUFFdlUsTUFBTSxDQUFDblUsU0FBVixFQUFxQixNQUFJO0FBQUMsUUFBRyxDQUFDc29CLHVCQUFKLEVBQTRCO0FBQUMsVUFBRyxDQUFDSSxPQUFKLEVBQVk7QUFBQyxjQUFNSSxZQUFZLEdBQUMsQ0FBQyxHQUFFdkcsb0JBQW9CLENBQUNmLG1CQUF4QixFQUE2QyxNQUFJbUgsVUFBVSxDQUFDLElBQUQsQ0FBM0QsQ0FBbkI7QUFBc0YsZUFBTSxNQUFJLENBQUMsR0FBRXBHLG9CQUFvQixDQUFDTixrQkFBeEIsRUFBNEM2RyxZQUE1QyxDQUFWO0FBQXFFO0FBQUM7QUFBQyxHQUFqTyxFQUFrTyxDQUFDSixPQUFELENBQWxPO0FBQTZPLFNBQU0sQ0FBQ3ZPLE1BQUQsRUFBUXVPLE9BQVIsQ0FBTjtBQUF3Qjs7QUFBQSxTQUFTRyxPQUFULENBQWlCM00sT0FBakIsRUFBeUI2TSxRQUF6QixFQUFrQzFMLE9BQWxDLEVBQTBDO0FBQUMsUUFBSztBQUFDcFMsTUFBRDtBQUFJK2QsWUFBSjtBQUFhQztBQUFiLE1BQXVCQyxjQUFjLENBQUM3TCxPQUFELENBQTFDO0FBQW9ENEwsVUFBUSxDQUFDbEcsR0FBVCxDQUFhN0csT0FBYixFQUFxQjZNLFFBQXJCO0FBQStCQyxVQUFRLENBQUNILE9BQVQsQ0FBaUIzTSxPQUFqQjtBQUEwQixTQUFPLFNBQVN1TSxTQUFULEdBQW9CO0FBQUNRLFlBQVEsQ0FBQ0UsTUFBVCxDQUFnQmpOLE9BQWhCO0FBQXlCOE0sWUFBUSxDQUFDUCxTQUFULENBQW1Cdk0sT0FBbkIsRUFBMUIsQ0FBc0Q7O0FBQ3ByQyxRQUFHK00sUUFBUSxDQUFDRyxJQUFULEtBQWdCLENBQW5CLEVBQXFCO0FBQUNKLGNBQVEsQ0FBQ0ssVUFBVDtBQUFzQkMsZUFBUyxDQUFDSCxNQUFWLENBQWlCbGUsRUFBakI7QUFBc0I7QUFBQyxHQURnaUM7QUFDOWhDOztBQUFBLE1BQU1xZSxTQUFTLEdBQUMsSUFBSTFVLEdBQUosRUFBaEI7O0FBQTBCLFNBQVNzVSxjQUFULENBQXdCN0wsT0FBeEIsRUFBZ0M7QUFBQyxRQUFNcFMsRUFBRSxHQUFDb1MsT0FBTyxDQUFDL0MsVUFBUixJQUFvQixFQUE3QjtBQUFnQyxNQUFJNE4sUUFBUSxHQUFDb0IsU0FBUyxDQUFDdGYsR0FBVixDQUFjaUIsRUFBZCxDQUFiOztBQUErQixNQUFHaWQsUUFBSCxFQUFZO0FBQUMsV0FBT0EsUUFBUDtBQUFpQjs7QUFBQSxRQUFNZSxRQUFRLEdBQUMsSUFBSXJVLEdBQUosRUFBZjtBQUF5QixRQUFNb1UsUUFBUSxHQUFDLElBQUlULG9CQUFKLENBQXlCZ0IsT0FBTyxJQUFFO0FBQUNBLFdBQU8sQ0FBQ3ZLLE9BQVIsQ0FBZ0IyRCxLQUFLLElBQUU7QUFBQyxZQUFNb0csUUFBUSxHQUFDRSxRQUFRLENBQUNqZixHQUFULENBQWEyWSxLQUFLLENBQUNoRixNQUFuQixDQUFmO0FBQTBDLFlBQU1wRCxTQUFTLEdBQUNvSSxLQUFLLENBQUM2RyxjQUFOLElBQXNCN0csS0FBSyxDQUFDOEcsaUJBQU4sR0FBd0IsQ0FBOUQ7O0FBQWdFLFVBQUdWLFFBQVEsSUFBRXhPLFNBQWIsRUFBdUI7QUFBQ3dPLGdCQUFRLENBQUN4TyxTQUFELENBQVI7QUFBcUI7QUFBQyxLQUFoTDtBQUFtTCxHQUF0TixFQUF1TjhDLE9BQXZOLENBQWY7QUFBK09pTSxXQUFTLENBQUN2RyxHQUFWLENBQWM5WCxFQUFkLEVBQWlCaWQsUUFBUSxHQUFDO0FBQUNqZCxNQUFEO0FBQUkrZCxZQUFKO0FBQWFDO0FBQWIsR0FBMUI7QUFBa0QsU0FBT2YsUUFBUDtBQUFpQixDOzs7Ozs7Ozs7OztBQ0QzaEI7O0FBQUEsSUFBSXJVLHNCQUFzQixHQUFDQyxtQkFBTyxDQUFDLHVJQUFELENBQWxDOztBQUFtRkMsa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLGVBQUEsR0FBZ0IyVixVQUFoQjs7QUFBMkIsSUFBSXZWLE1BQU0sR0FBQ04sc0JBQXNCLENBQUNDLG1CQUFPLENBQUMsb0JBQUQsQ0FBUixDQUFqQzs7QUFBb0QsSUFBSW1KLE9BQU8sR0FBQ25KLG1CQUFPLENBQUMsNERBQUQsQ0FBbkI7O0FBQWdDLFNBQVM0VixVQUFULENBQW9CQyxpQkFBcEIsRUFBc0M7QUFBQyxXQUFTQyxpQkFBVCxDQUEyQm5yQixLQUEzQixFQUFpQztBQUFDLFdBQU0sYUFBYTBWLE1BQU0sQ0FBQ2lCLE9BQVAsQ0FBZXdHLGFBQWYsQ0FBNkIrTixpQkFBN0IsRUFBK0NuYSxNQUFNLENBQUN3TSxNQUFQLENBQWM7QUFBQzFNLFlBQU0sRUFBQyxDQUFDLEdBQUUyTixPQUFPLENBQUMxTixTQUFYO0FBQVIsS0FBZCxFQUErQzlRLEtBQS9DLENBQS9DLENBQW5CO0FBQTBIOztBQUFBbXJCLG1CQUFpQixDQUFDQyxlQUFsQixHQUFrQ0YsaUJBQWlCLENBQUNFLGVBQXBELENBQW1FO0FBQW5FO0FBQ3phRCxtQkFBaUIsQ0FBQ0UsbUJBQWxCLEdBQXNDSCxpQkFBaUIsQ0FBQ0csbUJBQXhEOztBQUE0RSxZQUF1QztBQUFDLFVBQU14cEIsSUFBSSxHQUFDcXBCLGlCQUFpQixDQUFDSSxXQUFsQixJQUErQkosaUJBQWlCLENBQUNycEIsSUFBakQsSUFBdUQsU0FBbEU7QUFBNEVzcEIscUJBQWlCLENBQUNHLFdBQWxCLEdBQStCLGNBQWF6cEIsSUFBSyxHQUFqRDtBQUFxRDs7QUFBQSxTQUFPc3BCLGlCQUFQO0FBQTBCLEM7Ozs7Ozs7Ozs7O0FDRG5ROztBQUFBN1Ysa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLDJCQUFBLEdBQTRCaVcsbUJBQTVCOztBQUFnRCxTQUFTQSxtQkFBVCxDQUE2QkMsUUFBN0IsRUFBc0NuSixPQUF0QyxFQUE4QztBQUFDLE1BQUlvSixjQUFKLENBQUQsQ0FBb0I7O0FBQ3ZKLFFBQU1DLGFBQWEsR0FBQ0YsUUFBUSxDQUFDOVgsS0FBVCxDQUFlLEdBQWYsQ0FBcEI7QUFBd0MsR0FBQzJPLE9BQU8sSUFBRSxFQUFWLEVBQWNzSixJQUFkLENBQW1CNU0sTUFBTSxJQUFFO0FBQUMsUUFBRzJNLGFBQWEsQ0FBQyxDQUFELENBQWIsQ0FBaUJFLFdBQWpCLE9BQWlDN00sTUFBTSxDQUFDNk0sV0FBUCxFQUFwQyxFQUF5RDtBQUFDSCxvQkFBYyxHQUFDMU0sTUFBZjtBQUFzQjJNLG1CQUFhLENBQUNHLE1BQWQsQ0FBcUIsQ0FBckIsRUFBdUIsQ0FBdkI7QUFBMEJMLGNBQVEsR0FBQ0UsYUFBYSxDQUFDMXBCLElBQWQsQ0FBbUIsR0FBbkIsS0FBeUIsR0FBbEM7QUFBc0MsYUFBTyxJQUFQO0FBQWE7O0FBQUEsV0FBTyxLQUFQO0FBQWMsR0FBdk07QUFBeU0sU0FBTTtBQUFDd3BCLFlBQUQ7QUFBVUM7QUFBVixHQUFOO0FBQWlDLEM7Ozs7Ozs7Ozs7O0FDRHJROztBQUFBblcsa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLGVBQUEsR0FBZ0J3VyxJQUFoQjtBQUFxQjtBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJRztBQUNIO0FBQ0E7O0FBQ0EsU0FBU0EsSUFBVCxHQUFlO0FBQUMsUUFBTWhSLEdBQUcsR0FBQy9KLE1BQU0sQ0FBQ2diLE1BQVAsQ0FBYyxJQUFkLENBQVY7QUFBOEIsU0FBTTtBQUFDN0MsTUFBRSxDQUFDakgsSUFBRCxFQUFNK0osT0FBTixFQUFjO0FBQUM7QUFBQyxPQUFDbFIsR0FBRyxDQUFDbUgsSUFBRCxDQUFILEtBQVluSCxHQUFHLENBQUNtSCxJQUFELENBQUgsR0FBVSxFQUF0QixDQUFELEVBQTRCaEssSUFBNUIsQ0FBaUMrVCxPQUFqQztBQUEyQyxLQUE5RDs7QUFBK0RDLE9BQUcsQ0FBQ2hLLElBQUQsRUFBTStKLE9BQU4sRUFBYztBQUFDLFVBQUdsUixHQUFHLENBQUNtSCxJQUFELENBQU4sRUFBYTtBQUFDbkgsV0FBRyxDQUFDbUgsSUFBRCxDQUFILENBQVU0SixNQUFWLENBQWlCL1EsR0FBRyxDQUFDbUgsSUFBRCxDQUFILENBQVV4WSxPQUFWLENBQWtCdWlCLE9BQWxCLE1BQTZCLENBQTlDLEVBQWdELENBQWhEO0FBQW9EO0FBQUMsS0FBcEo7O0FBQXFKRSxRQUFJLENBQUNqSyxJQUFELEVBQU0sR0FBR2tLLElBQVQsRUFBYztBQUFDO0FBQzVOO0FBQUMsT0FBQ3JSLEdBQUcsQ0FBQ21ILElBQUQsQ0FBSCxJQUFXLEVBQVosRUFBZ0JsZ0IsS0FBaEIsR0FBd0JKLEdBQXhCLENBQTRCcXFCLE9BQU8sSUFBRTtBQUFDQSxlQUFPLENBQUMsR0FBR0csSUFBSixDQUFQO0FBQWtCLE9BQXhEO0FBQTJEOztBQURSLEdBQU47QUFDaUIsQzs7Ozs7Ozs7Ozs7QUNkbEQ7O0FBQUE3VyxrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsdUJBQUEsR0FBd0I4TSxlQUF4QjtBQUF3QzlNLGlCQUFBLEdBQWtCa04sU0FBbEI7QUFBNEJsTixpQkFBQSxHQUFrQjhXLFNBQWxCO0FBQTRCOVcsbUJBQUEsR0FBb0IrVyxXQUFwQjtBQUFnQy9XLG1CQUFBLEdBQW9CaU4sV0FBcEI7QUFBZ0NqTixtQkFBQSxHQUFvQmdYLFdBQXBCO0FBQWdDaFgsa0JBQUEsR0FBbUJ1SixVQUFuQjtBQUE4QnZKLHFCQUFBLEdBQXNCaVgsYUFBdEI7QUFBb0NqWCxtQkFBQSxHQUFvQjZMLFdBQXBCO0FBQWdDN0wsZUFBQSxHQUFnQixLQUFLLENBQXJCOztBQUF1QixJQUFJa1gsdUJBQXVCLEdBQUNuWCxtQkFBTyxDQUFDLDhHQUFELENBQW5DOztBQUFnRixJQUFJb1gsWUFBWSxHQUFDcFgsbUJBQU8sQ0FBQyxzRkFBRCxDQUF4Qjs7QUFBeUQsSUFBSXFYLG9CQUFvQixHQUFDclgsbUJBQU8sQ0FBQyxpSEFBRCxDQUFoQzs7QUFBdUUsSUFBSXNYLG9CQUFvQixHQUFDdFgsbUJBQU8sQ0FBQyw4R0FBRCxDQUFoQzs7QUFBa0UsSUFBSXVYLEtBQUssR0FBQ3hYLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLGtFQUFELENBQVIsQ0FBaEM7O0FBQXFELElBQUl3WCxNQUFNLEdBQUN4WCxtQkFBTyxDQUFDLG9FQUFELENBQWxCOztBQUErQixJQUFJeVgsVUFBVSxHQUFDelgsbUJBQU8sQ0FBQyxnR0FBRCxDQUF0Qjs7QUFBNkMsSUFBSTBYLGlCQUFpQixHQUFDMVgsbUJBQU8sQ0FBQyxnSEFBRCxDQUE3Qjs7QUFBNEQsSUFBSTJYLFlBQVksR0FBQzNYLG1CQUFPLENBQUMsa0dBQUQsQ0FBeEI7O0FBQWdELElBQUk0WCxnQkFBZ0IsR0FBQzdYLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLHVDQUFELENBQVIsQ0FBM0M7O0FBQWlGLElBQUk2WCxhQUFhLEdBQUM3WCxtQkFBTyxDQUFDLHNHQUFELENBQXpCOztBQUFtRCxJQUFJOFgsV0FBVyxHQUFDOVgsbUJBQU8sQ0FBQyxrR0FBRCxDQUF2Qjs7QUFBK0MsU0FBU0Qsc0JBQVQsQ0FBZ0NnWSxHQUFoQyxFQUFvQztBQUFDLFNBQU9BLEdBQUcsSUFBRUEsR0FBRyxDQUFDQyxVQUFULEdBQW9CRCxHQUFwQixHQUF3QjtBQUFDelcsV0FBTyxFQUFDeVc7QUFBVCxHQUEvQjtBQUE4QyxDLENBQUE7OztBQUNubUMsSUFBSUUsa0JBQUo7O0FBQXVCLElBQUd6akIsS0FBSCxFQUFtQyxFQUFnRjs7QUFBQSxNQUFNMGpCLFFBQVEsR0FBQzFqQixNQUFBLElBQW9DLEVBQW5EOztBQUFzRCxTQUFTMmpCLHNCQUFULEdBQWlDO0FBQUMsU0FBT3pjLE1BQU0sQ0FBQ3dNLE1BQVAsQ0FBYyxJQUFJclQsS0FBSixDQUFVLGlCQUFWLENBQWQsRUFBMkM7QUFBQzZiLGFBQVMsRUFBQztBQUFYLEdBQTNDLENBQVA7QUFBcUU7O0FBQUEsU0FBUzBILGFBQVQsQ0FBdUJyVyxJQUF2QixFQUE0QnNXLE1BQTVCLEVBQW1DO0FBQUMsU0FBT0EsTUFBTSxJQUFFdFcsSUFBSSxDQUFDMEMsVUFBTCxDQUFnQixHQUFoQixDQUFSLEdBQTZCMUMsSUFBSSxLQUFHLEdBQVAsR0FBVyxDQUFDLEdBQUVvVix1QkFBdUIsQ0FBQzFKLDBCQUEzQixFQUF1RDRLLE1BQXZELENBQVgsR0FBMkUsR0FBRUEsTUFBTyxHQUFFQyxlQUFlLENBQUN2VyxJQUFELENBQWYsS0FBd0IsR0FBeEIsR0FBNEJBLElBQUksQ0FBQ2dTLFNBQUwsQ0FBZSxDQUFmLENBQTVCLEdBQThDaFMsSUFBSyxFQUF0SyxHQUF3S0EsSUFBL0s7QUFBcUw7O0FBQUEsU0FBU2dMLGVBQVQsQ0FBeUJoTCxJQUF6QixFQUE4QjJILE1BQTlCLEVBQXFDc0QsT0FBckMsRUFBNkNDLGFBQTdDLEVBQTJEO0FBQUMsTUFBR3pZLEtBQUgsRUFBbUMsRUFBdVY7O0FBQUEsU0FBTyxLQUFQO0FBQWM7O0FBQUEsU0FBUzJZLFNBQVQsQ0FBbUJwTCxJQUFuQixFQUF3QjJILE1BQXhCLEVBQStCMEQsYUFBL0IsRUFBNkM7QUFBQyxNQUFHNVksS0FBSCxFQUFtQyxFQUFnUjs7QUFBQSxTQUFPdU4sSUFBUDtBQUFhOztBQUFBLFNBQVNnVixTQUFULENBQW1CaFYsSUFBbkIsRUFBd0IySCxNQUF4QixFQUErQjtBQUFDLE1BQUdsVixLQUFILEVBQW1DLEVBQWtTOztBQUFBLFNBQU91TixJQUFQO0FBQWE7O0FBQUEsU0FBU3VXLGVBQVQsQ0FBeUJ2VyxJQUF6QixFQUE4QjtBQUFDLFFBQU13VyxVQUFVLEdBQUN4VyxJQUFJLENBQUMzTixPQUFMLENBQWEsR0FBYixDQUFqQjtBQUFtQyxRQUFNb2tCLFNBQVMsR0FBQ3pXLElBQUksQ0FBQzNOLE9BQUwsQ0FBYSxHQUFiLENBQWhCOztBQUFrQyxNQUFHbWtCLFVBQVUsR0FBQyxDQUFDLENBQVosSUFBZUMsU0FBUyxHQUFDLENBQUMsQ0FBN0IsRUFBK0I7QUFBQ3pXLFFBQUksR0FBQ0EsSUFBSSxDQUFDZ1MsU0FBTCxDQUFlLENBQWYsRUFBaUJ3RSxVQUFVLEdBQUMsQ0FBQyxDQUFaLEdBQWNBLFVBQWQsR0FBeUJDLFNBQTFDLENBQUw7QUFBMkQ7O0FBQUEsU0FBT3pXLElBQVA7QUFBYTs7QUFBQSxTQUFTaVYsV0FBVCxDQUFxQmpWLElBQXJCLEVBQTBCO0FBQUNBLE1BQUksR0FBQ3VXLGVBQWUsQ0FBQ3ZXLElBQUQsQ0FBcEI7QUFBMkIsU0FBT0EsSUFBSSxLQUFHbVcsUUFBUCxJQUFpQm5XLElBQUksQ0FBQzBDLFVBQUwsQ0FBZ0J5VCxRQUFRLEdBQUMsR0FBekIsQ0FBeEI7QUFBdUQ7O0FBQUEsU0FBU2hMLFdBQVQsQ0FBcUJuTCxJQUFyQixFQUEwQjtBQUFDO0FBQ3gvRCxTQUFPcVcsYUFBYSxDQUFDclcsSUFBRCxFQUFNbVcsUUFBTixDQUFwQjtBQUFxQzs7QUFBQSxTQUFTakIsV0FBVCxDQUFxQmxWLElBQXJCLEVBQTBCO0FBQUNBLE1BQUksR0FBQ0EsSUFBSSxDQUFDclYsS0FBTCxDQUFXd3JCLFFBQVEsQ0FBQ3RyQixNQUFwQixDQUFMO0FBQWlDLE1BQUcsQ0FBQ21WLElBQUksQ0FBQzBDLFVBQUwsQ0FBZ0IsR0FBaEIsQ0FBSixFQUF5QjFDLElBQUksR0FBRSxJQUFHQSxJQUFLLEVBQWQ7QUFBZ0IsU0FBT0EsSUFBUDtBQUFhO0FBQUE7QUFDdko7QUFDQTs7O0FBQUcsU0FBU3lILFVBQVQsQ0FBb0JyVSxHQUFwQixFQUF3QjtBQUFDO0FBQzVCLE1BQUdBLEdBQUcsQ0FBQ3NQLFVBQUosQ0FBZSxHQUFmLEtBQXFCdFAsR0FBRyxDQUFDc1AsVUFBSixDQUFlLEdBQWYsQ0FBckIsSUFBMEN0UCxHQUFHLENBQUNzUCxVQUFKLENBQWUsR0FBZixDQUE3QyxFQUFpRSxPQUFPLElBQVA7O0FBQVksTUFBRztBQUFDO0FBQ2pGLFVBQU1nVSxjQUFjLEdBQUMsQ0FBQyxHQUFFakIsTUFBTSxDQUFDa0IsaUJBQVYsR0FBckI7QUFBb0QsVUFBTUMsUUFBUSxHQUFDLElBQUk3UCxHQUFKLENBQVEzVCxHQUFSLEVBQVlzakIsY0FBWixDQUFmO0FBQTJDLFdBQU9FLFFBQVEsQ0FBQ0MsTUFBVCxLQUFrQkgsY0FBbEIsSUFBa0N6QixXQUFXLENBQUMyQixRQUFRLENBQUN4QyxRQUFWLENBQXBEO0FBQXlFLEdBRDNGLENBQzJGLE9BQU1oTCxDQUFOLEVBQVE7QUFBQyxXQUFPLEtBQVA7QUFBYztBQUFDOztBQUFBLFNBQVMrTCxhQUFULENBQXVCbEcsS0FBdkIsRUFBNkI2SCxVQUE3QixFQUF3Q2pkLEtBQXhDLEVBQThDO0FBQUMsTUFBSWtkLGlCQUFpQixHQUFDLEVBQXRCO0FBQXlCLFFBQU1DLFlBQVksR0FBQyxDQUFDLEdBQUVqQixXQUFXLENBQUNrQixhQUFmLEVBQThCaEksS0FBOUIsQ0FBbkI7QUFBd0QsUUFBTWlJLGFBQWEsR0FBQ0YsWUFBWSxDQUFDRyxNQUFqQztBQUF3QyxRQUFNQyxjQUFjLEdBQUM7QUFDN1gsR0FBQ04sVUFBVSxLQUFHN0gsS0FBYixHQUFtQixDQUFDLEdBQUU2RyxhQUFhLENBQUN1QixlQUFqQixFQUFrQ0wsWUFBbEMsRUFBZ0RGLFVBQWhELENBQW5CLEdBQStFLEVBQWhGLEtBQXFGO0FBQ3JGO0FBQ0FqZCxPQUh3VztBQUdsV2tkLG1CQUFpQixHQUFDOUgsS0FBbEI7QUFBd0IsUUFBTTdhLE1BQU0sR0FBQ3VGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZc2QsYUFBWixDQUFiOztBQUF3QyxNQUFHLENBQUM5aUIsTUFBTSxDQUFDa2pCLEtBQVAsQ0FBYUMsS0FBSyxJQUFFO0FBQUMsUUFBSXBLLEtBQUssR0FBQ2lLLGNBQWMsQ0FBQ0csS0FBRCxDQUFkLElBQXVCLEVBQWpDO0FBQW9DLFVBQUs7QUFBQ0MsWUFBRDtBQUFRQztBQUFSLFFBQWtCUCxhQUFhLENBQUNLLEtBQUQsQ0FBcEMsQ0FBckMsQ0FBaUY7QUFDL0s7O0FBQ0EsUUFBSUcsUUFBUSxHQUFFLElBQUdGLE1BQU0sR0FBQyxLQUFELEdBQU8sRUFBRyxHQUFFRCxLQUFNLEdBQXpDOztBQUE0QyxRQUFHRSxRQUFILEVBQVk7QUFBQ0MsY0FBUSxHQUFFLEdBQUUsQ0FBQ3ZLLEtBQUQsR0FBTyxHQUFQLEdBQVcsRUFBRyxJQUFHdUssUUFBUyxHQUF0QztBQUEwQzs7QUFBQSxRQUFHRixNQUFNLElBQUUsQ0FBQ2pGLEtBQUssQ0FBQ0MsT0FBTixDQUFjckYsS0FBZCxDQUFaLEVBQWlDQSxLQUFLLEdBQUMsQ0FBQ0EsS0FBRCxDQUFOO0FBQWMsV0FBTSxDQUFDc0ssUUFBUSxJQUFFRixLQUFLLElBQUlILGNBQXBCLE9BQXNDO0FBQzlMTCxxQkFBaUIsR0FBQ0EsaUJBQWlCLENBQUNoYixPQUFsQixDQUEwQjJiLFFBQTFCLEVBQW1DRixNQUFNLEdBQUNySyxLQUFLLENBQUM1aUIsR0FBTixFQUFVO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBb3RCLFdBQU8sSUFBRXpRLGtCQUFrQixDQUFDeVEsT0FBRCxDQUppQyxFQUl0Qi9zQixJQUpzQixDQUlqQixHQUppQixDQUFELEdBSVhzYyxrQkFBa0IsQ0FBQ2lHLEtBQUQsQ0FKaEQsS0FJMEQsR0FMNEUsQ0FBTjtBQUtoRSxHQVBSLENBQUosRUFPYztBQUFDNEoscUJBQWlCLEdBQUMsRUFBbEIsQ0FBRCxDQUFzQjtBQUMxRztBQUNBO0FBQ0M7O0FBQUEsU0FBTTtBQUFDM2lCLFVBQUQ7QUFBUXdqQixVQUFNLEVBQUNiO0FBQWYsR0FBTjtBQUF5Qzs7QUFBQSxTQUFTYyxrQkFBVCxDQUE0QmhlLEtBQTVCLEVBQWtDekYsTUFBbEMsRUFBeUM7QUFBQyxRQUFNMGpCLGFBQWEsR0FBQyxFQUFwQjtBQUF1Qm5lLFFBQU0sQ0FBQ0MsSUFBUCxDQUFZQyxLQUFaLEVBQW1Cc1AsT0FBbkIsQ0FBMkI3QyxHQUFHLElBQUU7QUFBQyxRQUFHLENBQUNsUyxNQUFNLENBQUM2UCxRQUFQLENBQWdCcUMsR0FBaEIsQ0FBSixFQUF5QjtBQUFDd1IsbUJBQWEsQ0FBQ3hSLEdBQUQsQ0FBYixHQUFtQnpNLEtBQUssQ0FBQ3lNLEdBQUQsQ0FBeEI7QUFBK0I7QUFBQyxHQUEzRjtBQUE2RixTQUFPd1IsYUFBUDtBQUFzQjtBQUFBO0FBQzlOO0FBQ0E7QUFDQTs7O0FBQUcsU0FBUy9OLFdBQVQsQ0FBcUJ0USxNQUFyQixFQUE0QmxPLElBQTVCLEVBQWlDd3NCLFNBQWpDLEVBQTJDO0FBQUM7QUFDL0MsTUFBSUMsSUFBSjtBQUFTLFFBQU1DLFdBQVcsR0FBQyxPQUFPMXNCLElBQVAsS0FBYyxRQUFkLEdBQXVCQSxJQUF2QixHQUE0QixDQUFDLEdBQUVrcUIsTUFBTSxDQUFDeUMsb0JBQVYsRUFBZ0Mzc0IsSUFBaEMsQ0FBOUM7O0FBQW9GLE1BQUc7QUFBQ3lzQixRQUFJLEdBQUMsSUFBSWpSLEdBQUosQ0FBUWtSLFdBQVcsQ0FBQ3ZWLFVBQVosQ0FBdUIsR0FBdkIsSUFBNEJqSixNQUFNLENBQUNtQixNQUFuQyxHQUEwQ25CLE1BQU0sQ0FBQzJhLFFBQXpELEVBQWtFLFVBQWxFLENBQUw7QUFBb0YsR0FBeEYsQ0FBd0YsT0FBTWhMLENBQU4sRUFBUTtBQUFDO0FBQzlMNE8sUUFBSSxHQUFDLElBQUlqUixHQUFKLENBQVEsR0FBUixFQUFZLFVBQVosQ0FBTDtBQUE4QixHQUZnQixDQUVoQjs7O0FBQzlCLE1BQUcsQ0FBQ1UsVUFBVSxDQUFDd1EsV0FBRCxDQUFkLEVBQTRCO0FBQUMsV0FBT0YsU0FBUyxHQUFDLENBQUNFLFdBQUQsQ0FBRCxHQUFlQSxXQUEvQjtBQUE0Qzs7QUFBQSxNQUFHO0FBQUMsVUFBTUUsUUFBUSxHQUFDLElBQUlwUixHQUFKLENBQVFrUixXQUFSLEVBQW9CRCxJQUFwQixDQUFmO0FBQXlDRyxZQUFRLENBQUMvRCxRQUFULEdBQWtCLENBQUMsR0FBRWdCLHVCQUF1QixDQUFDMUosMEJBQTNCLEVBQXVEeU0sUUFBUSxDQUFDL0QsUUFBaEUsQ0FBbEI7QUFBNEYsUUFBSWdFLGNBQWMsR0FBQyxFQUFuQjs7QUFBc0IsUUFBRyxDQUFDLEdBQUUxQyxVQUFVLENBQUMyQyxjQUFkLEVBQThCRixRQUFRLENBQUMvRCxRQUF2QyxLQUFrRCtELFFBQVEsQ0FBQ0csWUFBM0QsSUFBeUVQLFNBQTVFLEVBQXNGO0FBQUMsWUFBTWxlLEtBQUssR0FBQyxDQUFDLEdBQUUrYixZQUFZLENBQUMyQyxzQkFBaEIsRUFBd0NKLFFBQVEsQ0FBQ0csWUFBakQsQ0FBWjtBQUEyRSxZQUFLO0FBQUNWLGNBQUQ7QUFBUXhqQjtBQUFSLFVBQWdCK2dCLGFBQWEsQ0FBQ2dELFFBQVEsQ0FBQy9ELFFBQVYsRUFBbUIrRCxRQUFRLENBQUMvRCxRQUE1QixFQUFxQ3ZhLEtBQXJDLENBQWxDOztBQUE4RSxVQUFHK2QsTUFBSCxFQUFVO0FBQUNRLHNCQUFjLEdBQUMsQ0FBQyxHQUFFM0MsTUFBTSxDQUFDeUMsb0JBQVYsRUFBZ0M7QUFBQzlELGtCQUFRLEVBQUN3RCxNQUFWO0FBQWlCWSxjQUFJLEVBQUNMLFFBQVEsQ0FBQ0ssSUFBL0I7QUFBb0MzZSxlQUFLLEVBQUNnZSxrQkFBa0IsQ0FBQ2hlLEtBQUQsRUFBT3pGLE1BQVA7QUFBNUQsU0FBaEMsQ0FBZjtBQUE2SDtBQUFDLEtBQXJoQixDQUFxaEI7OztBQUNqbUIsVUFBTXlWLFlBQVksR0FBQ3NPLFFBQVEsQ0FBQ3RCLE1BQVQsS0FBa0JtQixJQUFJLENBQUNuQixNQUF2QixHQUE4QnNCLFFBQVEsQ0FBQzVzQixJQUFULENBQWNaLEtBQWQsQ0FBb0J3dEIsUUFBUSxDQUFDdEIsTUFBVCxDQUFnQmhzQixNQUFwQyxDQUE5QixHQUEwRXN0QixRQUFRLENBQUM1c0IsSUFBdEc7QUFBMkcsV0FBT3dzQixTQUFTLEdBQUMsQ0FBQ2xPLFlBQUQsRUFBY3VPLGNBQWMsSUFBRXZPLFlBQTlCLENBQUQsR0FBNkNBLFlBQTdEO0FBQTJFLEdBRDdHLENBQzZHLE9BQU1ULENBQU4sRUFBUTtBQUFDLFdBQU8yTyxTQUFTLEdBQUMsQ0FBQ0UsV0FBRCxDQUFELEdBQWVBLFdBQS9CO0FBQTRDO0FBQUM7O0FBQUEsU0FBU1EsV0FBVCxDQUFxQnJsQixHQUFyQixFQUF5QjtBQUFDLFFBQU15akIsTUFBTSxHQUFDLENBQUMsR0FBRXBCLE1BQU0sQ0FBQ2tCLGlCQUFWLEdBQWI7QUFBNEMsU0FBT3ZqQixHQUFHLENBQUNzUCxVQUFKLENBQWVtVSxNQUFmLElBQXVCempCLEdBQUcsQ0FBQzRlLFNBQUosQ0FBYzZFLE1BQU0sQ0FBQ2hzQixNQUFyQixDQUF2QixHQUFvRHVJLEdBQTNEO0FBQWdFOztBQUFBLFNBQVNzbEIsWUFBVCxDQUFzQmpmLE1BQXRCLEVBQTZCckcsR0FBN0IsRUFBaUNvVCxFQUFqQyxFQUFvQztBQUFDO0FBQ3ZaO0FBQ0EsTUFBRyxDQUFDcUQsWUFBRCxFQUFjQyxVQUFkLElBQTBCQyxXQUFXLENBQUN0USxNQUFELEVBQVFyRyxHQUFSLEVBQVksSUFBWixDQUF4QztBQUEwRCxRQUFNeWpCLE1BQU0sR0FBQyxDQUFDLEdBQUVwQixNQUFNLENBQUNrQixpQkFBVixHQUFiO0FBQTRDLFFBQU1nQyxhQUFhLEdBQUM5TyxZQUFZLENBQUNuSCxVQUFiLENBQXdCbVUsTUFBeEIsQ0FBcEI7QUFBb0QsUUFBTStCLFdBQVcsR0FBQzlPLFVBQVUsSUFBRUEsVUFBVSxDQUFDcEgsVUFBWCxDQUFzQm1VLE1BQXRCLENBQTlCO0FBQTREaE4sY0FBWSxHQUFDNE8sV0FBVyxDQUFDNU8sWUFBRCxDQUF4QjtBQUF1Q0MsWUFBVSxHQUFDQSxVQUFVLEdBQUMyTyxXQUFXLENBQUMzTyxVQUFELENBQVosR0FBeUJBLFVBQTlDO0FBQXlELFFBQU0rTyxXQUFXLEdBQUNGLGFBQWEsR0FBQzlPLFlBQUQsR0FBY3NCLFdBQVcsQ0FBQ3RCLFlBQUQsQ0FBeEQ7QUFBdUUsUUFBTWlQLFVBQVUsR0FBQ3RTLEVBQUUsR0FBQ2lTLFdBQVcsQ0FBQzFPLFdBQVcsQ0FBQ3RRLE1BQUQsRUFBUStNLEVBQVIsQ0FBWixDQUFaLEdBQXFDc0QsVUFBVSxJQUFFRCxZQUFwRTtBQUFpRixTQUFNO0FBQUN6VyxPQUFHLEVBQUN5bEIsV0FBTDtBQUFpQnJTLE1BQUUsRUFBQ29TLFdBQVcsR0FBQ0UsVUFBRCxHQUFZM04sV0FBVyxDQUFDMk4sVUFBRDtBQUF0RCxHQUFOO0FBQTJFOztBQUFBLFNBQVNDLG1CQUFULENBQTZCM0UsUUFBN0IsRUFBc0M0RSxLQUF0QyxFQUE0QztBQUFDLFFBQU1DLGFBQWEsR0FBQyxDQUFDLEdBQUU3RCx1QkFBdUIsQ0FBQzVKLHVCQUEzQixFQUFvRCxDQUFDLEdBQUU4SixvQkFBb0IsQ0FBQzRELG1CQUF4QixFQUE2QzlFLFFBQTdDLENBQXBELENBQXBCOztBQUFnSSxNQUFHNkUsYUFBYSxLQUFHLE1BQWhCLElBQXdCQSxhQUFhLEtBQUcsU0FBM0MsRUFBcUQ7QUFBQyxXQUFPN0UsUUFBUDtBQUFpQixHQUF4TSxDQUF3TTs7O0FBQzd3QixNQUFHLENBQUM0RSxLQUFLLENBQUMvVSxRQUFOLENBQWVnVixhQUFmLENBQUosRUFBa0M7QUFBQztBQUNuQ0QsU0FBSyxDQUFDekUsSUFBTixDQUFXdG5CLElBQUksSUFBRTtBQUFDLFVBQUcsQ0FBQyxHQUFFeW9CLFVBQVUsQ0FBQzJDLGNBQWQsRUFBOEJwckIsSUFBOUIsS0FBcUMsQ0FBQyxHQUFFOG9CLFdBQVcsQ0FBQ2tCLGFBQWYsRUFBOEJocUIsSUFBOUIsRUFBb0Nrc0IsRUFBcEMsQ0FBdUNyZSxJQUF2QyxDQUE0Q21lLGFBQTVDLENBQXhDLEVBQW1HO0FBQUM3RSxnQkFBUSxHQUFDbm5CLElBQVQ7QUFBYyxlQUFPLElBQVA7QUFBYTtBQUFDLEtBQWxKO0FBQXFKOztBQUFBLFNBQU0sQ0FBQyxHQUFFbW9CLHVCQUF1QixDQUFDNUosdUJBQTNCLEVBQW9ENEksUUFBcEQsQ0FBTjtBQUFxRTs7QUFBQSxNQUFNZ0YsdUJBQXVCLEdBQUMzbUIsTUFBQSxJQUEwRyxDQUF4STtBQUN0SSxNQUFNNG1CLGtCQUFrQixHQUFDakwsTUFBTSxDQUFDLG9CQUFELENBQS9COztBQUFzRCxTQUFTa0wsVUFBVCxDQUFvQmxtQixHQUFwQixFQUF3Qm1tQixRQUF4QixFQUFpQztBQUFDLFNBQU81bEIsS0FBSyxDQUFDUCxHQUFELEVBQUs7QUFBQztBQUM5TDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBb21CLGVBQVcsRUFBQztBQVhpTCxHQUFMLENBQUwsQ0FXdkpudkIsSUFYdUosQ0FXbEpxVCxHQUFHLElBQUU7QUFBQyxRQUFHLENBQUNBLEdBQUcsQ0FBQzNKLEVBQVIsRUFBVztBQUFDLFVBQUd3bEIsUUFBUSxHQUFDLENBQVQsSUFBWTdiLEdBQUcsQ0FBQ3pKLE1BQUosSUFBWSxHQUEzQixFQUErQjtBQUFDLGVBQU9xbEIsVUFBVSxDQUFDbG1CLEdBQUQsRUFBS21tQixRQUFRLEdBQUMsQ0FBZCxDQUFqQjtBQUFtQzs7QUFBQSxVQUFHN2IsR0FBRyxDQUFDekosTUFBSixLQUFhLEdBQWhCLEVBQW9CO0FBQUMsZUFBT3lKLEdBQUcsQ0FBQzVKLElBQUosR0FBV3pKLElBQVgsQ0FBZ0J5QyxJQUFJLElBQUU7QUFBQyxjQUFHQSxJQUFJLENBQUMyc0IsUUFBUixFQUFpQjtBQUFDLG1CQUFNO0FBQUNBLHNCQUFRLEVBQUNKO0FBQVYsYUFBTjtBQUFxQzs7QUFBQSxnQkFBTSxJQUFJdm1CLEtBQUosQ0FBVyw2QkFBWCxDQUFOO0FBQWdELFNBQTlILENBQVA7QUFBd0k7O0FBQUEsWUFBTSxJQUFJQSxLQUFKLENBQVcsNkJBQVgsQ0FBTjtBQUFnRDs7QUFBQSxXQUFPNEssR0FBRyxDQUFDNUosSUFBSixFQUFQO0FBQW1CLEdBWG5LLENBQVA7QUFXNks7O0FBQUEsU0FBUzRsQixhQUFULENBQXVCQyxRQUF2QixFQUFnQ0MsY0FBaEMsRUFBK0M7QUFBQyxTQUFPTixVQUFVLENBQUNLLFFBQUQsRUFBVUMsY0FBYyxHQUFDLENBQUQsR0FBRyxDQUEzQixDQUFWLENBQXdDOVcsS0FBeEMsQ0FBOENrRSxHQUFHLElBQUU7QUFBQztBQUNwYztBQUNBO0FBQ0EsUUFBRyxDQUFDNFMsY0FBSixFQUFtQjtBQUFDLE9BQUMsR0FBRXZFLFlBQVksQ0FBQy9JLGNBQWhCLEVBQWdDdEYsR0FBaEM7QUFBc0M7O0FBQUEsVUFBTUEsR0FBTjtBQUFXLEdBSDJVLENBQVA7QUFHalU7O0FBQUEsTUFBTTZTLE1BQU4sQ0FBWTtBQUFDO0FBQ3JGO0FBQ0E7QUFBTTtBQUNOO0FBQ0E5bUIsYUFBVyxDQUFDK21CLFNBQUQsRUFBV0MsTUFBWCxFQUFrQkMsR0FBbEIsRUFBc0I7QUFBQ0MsZ0JBQUQ7QUFBY0MsY0FBZDtBQUF5QkMsT0FBekI7QUFBNkJDLFdBQTdCO0FBQXFDQyxhQUFyQztBQUErQ3JULE9BQS9DO0FBQW1Ec1QsZ0JBQW5EO0FBQWdFQyxjQUFoRTtBQUEyRTVTLFVBQTNFO0FBQWtGc0QsV0FBbEY7QUFBMEZJLGlCQUExRjtBQUF3R0gsaUJBQXhHO0FBQXNIc1A7QUFBdEgsR0FBdEIsRUFBdUo7QUFBQyxTQUFLdkwsS0FBTCxHQUFXLEtBQUssQ0FBaEI7QUFBa0IsU0FBS21GLFFBQUwsR0FBYyxLQUFLLENBQW5CO0FBQXFCLFNBQUt2YSxLQUFMLEdBQVcsS0FBSyxDQUFoQjtBQUFrQixTQUFLZSxNQUFMLEdBQVksS0FBSyxDQUFqQjtBQUFtQixTQUFLdWIsUUFBTCxHQUFjLEtBQUssQ0FBbkI7QUFBcUIsU0FBS3NFLFVBQUwsR0FBZ0IsS0FBSyxDQUFyQjtBQUF1QixTQUFLQyxHQUFMLEdBQVMsRUFBVDtBQUFZLFNBQUtDLEdBQUwsR0FBUyxFQUFUO0FBQVksU0FBS0MsR0FBTCxHQUFTLEtBQUssQ0FBZDtBQUFnQixTQUFLQyxHQUFMLEdBQVMsS0FBSyxDQUFkO0FBQWdCLFNBQUtYLFVBQUwsR0FBZ0IsS0FBSyxDQUFyQjtBQUF1QixTQUFLWSxJQUFMLEdBQVUsS0FBSyxDQUFmO0FBQWlCLFNBQUtuSixNQUFMLEdBQVksS0FBSyxDQUFqQjtBQUFtQixTQUFLb0osUUFBTCxHQUFjLEtBQUssQ0FBbkI7QUFBcUIsU0FBS0MsS0FBTCxHQUFXLEtBQUssQ0FBaEI7QUFBa0IsU0FBS1QsVUFBTCxHQUFnQixLQUFLLENBQXJCO0FBQXVCLFNBQUtVLGNBQUwsR0FBb0IsS0FBSyxDQUF6QjtBQUEyQixTQUFLQyxRQUFMLEdBQWMsS0FBSyxDQUFuQjtBQUFxQixTQUFLdlQsTUFBTCxHQUFZLEtBQUssQ0FBakI7QUFBbUIsU0FBS3NELE9BQUwsR0FBYSxLQUFLLENBQWxCO0FBQW9CLFNBQUtJLGFBQUwsR0FBbUIsS0FBSyxDQUF4QjtBQUEwQixTQUFLSCxhQUFMLEdBQW1CLEtBQUssQ0FBeEI7QUFBMEIsU0FBS2lRLE9BQUwsR0FBYSxLQUFLLENBQWxCO0FBQW9CLFNBQUtYLFNBQUwsR0FBZSxLQUFLLENBQXBCO0FBQXNCLFNBQUt6UCxjQUFMLEdBQW9CLEtBQUssQ0FBekI7QUFBMkIsU0FBS3FRLElBQUwsR0FBVSxDQUFWOztBQUFZLFNBQUtDLFVBQUwsR0FBZ0I5UyxDQUFDLElBQUU7QUFBQyxZQUFNMVcsS0FBSyxHQUFDMFcsQ0FBQyxDQUFDMVcsS0FBZDs7QUFBb0IsVUFBRyxDQUFDQSxLQUFKLEVBQVU7QUFBQztBQUMzdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQUs7QUFBQ3VpQixrQkFBRDtBQUFVdmE7QUFBVixZQUFpQixJQUF0QjtBQUEyQixhQUFLeWhCLFdBQUwsQ0FBaUIsY0FBakIsRUFBZ0MsQ0FBQyxHQUFFN0YsTUFBTSxDQUFDeUMsb0JBQVYsRUFBZ0M7QUFBQzlELGtCQUFRLEVBQUNqSixXQUFXLENBQUNpSixRQUFELENBQXJCO0FBQWdDdmE7QUFBaEMsU0FBaEMsQ0FBaEMsRUFBd0csQ0FBQyxHQUFFNGIsTUFBTSxDQUFDOEYsTUFBVixHQUF4RztBQUE2SDtBQUFROztBQUFBLFVBQUcsQ0FBQzFwQixLQUFLLENBQUMycEIsR0FBVixFQUFjO0FBQUM7QUFBUTs7QUFBQSxVQUFJQyxZQUFKO0FBQWlCLFlBQUs7QUFBQ3JvQixXQUFEO0FBQUtvVCxVQUFMO0FBQVFnQixlQUFSO0FBQWdCa1U7QUFBaEIsVUFBcUI3cEIsS0FBMUI7O0FBQWdDLFVBQUdZLEtBQUgsRUFBeUMsRUFFako7O0FBQUEsV0FBSzJvQixJQUFMLEdBQVVNLEdBQVY7QUFBYyxZQUFLO0FBQUN0SDtBQUFELFVBQVcsQ0FBQyxHQUFFdUIsaUJBQWlCLENBQUNnRyxnQkFBckIsRUFBdUN2b0IsR0FBdkMsQ0FBaEIsQ0FYNmlCLENBV2pmO0FBQzFNOztBQUNBLFVBQUcsS0FBSzRuQixLQUFMLElBQVl4VSxFQUFFLEtBQUcsS0FBSzVMLE1BQXRCLElBQThCd1osUUFBUSxLQUFHLEtBQUtBLFFBQWpELEVBQTBEO0FBQUM7QUFBUSxPQWJ3bkIsQ0FheG5CO0FBQ25FOzs7QUFDQSxVQUFHLEtBQUswRyxJQUFMLElBQVcsQ0FBQyxLQUFLQSxJQUFMLENBQVVqcEIsS0FBVixDQUFmLEVBQWdDO0FBQUM7QUFBUTs7QUFBQSxXQUFLK3BCLE1BQUwsQ0FBWSxjQUFaLEVBQTJCeG9CLEdBQTNCLEVBQStCb1QsRUFBL0IsRUFBa0M3TSxNQUFNLENBQUN3TSxNQUFQLENBQWMsRUFBZCxFQUFpQnFCLE9BQWpCLEVBQXlCO0FBQUNnQixlQUFPLEVBQUNoQixPQUFPLENBQUNnQixPQUFSLElBQWlCLEtBQUswUyxRQUEvQjtBQUF3Q3ZULGNBQU0sRUFBQ0gsT0FBTyxDQUFDRyxNQUFSLElBQWdCLEtBQUswRDtBQUFwRSxPQUF6QixDQUFsQyxFQUErSW9RLFlBQS9JO0FBQThKLEtBZmllLENBQXRnQixDQWVzQzs7O0FBQ3hNLFNBQUt4TSxLQUFMLEdBQVcsQ0FBQyxHQUFFbUcsdUJBQXVCLENBQUM1Six1QkFBM0IsRUFBb0RzTyxTQUFwRCxDQUFYLENBaEJrSyxDQWdCeEY7O0FBQzFFLFNBQUtXLFVBQUwsR0FBZ0IsRUFBaEIsQ0FqQmtLLENBaUIvSTtBQUNuQjtBQUNBOztBQUNBLFFBQUdYLFNBQVMsS0FBRyxTQUFmLEVBQXlCO0FBQUMsV0FBS1csVUFBTCxDQUFnQixLQUFLeEwsS0FBckIsSUFBNEI7QUFBQ29MLGlCQUFEO0FBQVd3QixlQUFPLEVBQUMsSUFBbkI7QUFBd0JqekIsYUFBSyxFQUFDcXhCLFlBQTlCO0FBQTJDalQsV0FBM0M7QUFBK0M4VSxlQUFPLEVBQUM3QixZQUFZLElBQUVBLFlBQVksQ0FBQzZCLE9BQWxGO0FBQTBGQyxlQUFPLEVBQUM5QixZQUFZLElBQUVBLFlBQVksQ0FBQzhCO0FBQTdILE9BQTVCO0FBQW1LOztBQUFBLFNBQUt0QixVQUFMLENBQWdCLE9BQWhCLElBQXlCO0FBQUNKLGVBQVMsRUFBQ0YsR0FBWDtBQUFleEssaUJBQVcsRUFBQztBQUFDO0FBQUQ7QUFBM0IsS0FBekIsQ0FwQjNCLENBb0JvSTtBQUN0Uzs7QUFDQSxTQUFLZ0MsTUFBTCxHQUFZa0ksTUFBTSxDQUFDbEksTUFBbkI7QUFBMEIsU0FBS3VJLFVBQUwsR0FBZ0JBLFVBQWhCO0FBQTJCLFNBQUs5RixRQUFMLEdBQWMwRixTQUFkO0FBQXdCLFNBQUtqZ0IsS0FBTCxHQUFXa2dCLE1BQVgsQ0F0QnFGLENBc0JuRTtBQUMvRjs7QUFDQSxVQUFNaUMsaUJBQWlCLEdBQUMsQ0FBQyxHQUFFdEcsVUFBVSxDQUFDMkMsY0FBZCxFQUE4QnlCLFNBQTlCLEtBQTBDbE8sSUFBSSxDQUFDcVEsYUFBTCxDQUFtQkMsVUFBckY7O0FBQWdHLFNBQUt0aEIsTUFBTCxHQUFZb2hCLGlCQUFpQixHQUFDbEMsU0FBRCxHQUFXRSxHQUF4QztBQUE0QyxTQUFLN0QsUUFBTCxHQUFjQSxRQUFkO0FBQXVCLFNBQUt5RSxHQUFMLEdBQVNOLFlBQVQ7QUFBc0IsU0FBS08sR0FBTCxHQUFTLElBQVQ7QUFBYyxTQUFLRSxRQUFMLEdBQWNYLE9BQWQsQ0F4QnJDLENBd0IyRDtBQUM3Tjs7QUFDQSxTQUFLWSxLQUFMLEdBQVcsSUFBWDtBQUFnQixTQUFLVCxVQUFMLEdBQWdCQSxVQUFoQjtBQUEyQixTQUFLWSxPQUFMLEdBQWEsQ0FBQyxFQUFFdlAsSUFBSSxDQUFDcVEsYUFBTCxDQUFtQkUsSUFBbkIsSUFBeUJ2USxJQUFJLENBQUNxUSxhQUFMLENBQW1CRyxHQUE1QyxJQUFpRCxDQUFDSixpQkFBRCxJQUFvQixDQUFDcFEsSUFBSSxDQUFDeFosUUFBTCxDQUFjaXFCLE1BQW5DLElBQTJDLENBQUM1cEIsS0FBL0YsQ0FBZDtBQUE4SSxTQUFLK25CLFNBQUwsR0FBZSxDQUFDLENBQUNBLFNBQWpCO0FBQTJCLFNBQUt6UCxjQUFMLEdBQW9CLEtBQXBCOztBQUEwQixRQUFHdFksS0FBSCxFQUFtQyxFQUEyTDs7QUFBQSxlQUErQixFQU14WDtBQUFDOztBQUFBNnBCLFFBQU0sR0FBRTtBQUFDOXZCLFVBQU0sQ0FBQzRGLFFBQVAsQ0FBZ0JrcUIsTUFBaEI7QUFBMEI7QUFBQTtBQUN2SjtBQUNBOzs7QUFBS0MsTUFBSSxHQUFFO0FBQUMvdkIsVUFBTSxDQUFDZ3dCLE9BQVAsQ0FBZUQsSUFBZjtBQUF1QjtBQUFBO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUFLMWIsTUFBSSxDQUFDek4sR0FBRCxFQUFLb1QsRUFBTCxFQUFRZ0IsT0FBTyxHQUFDLEVBQWhCLEVBQW1CO0FBQUMsUUFBRy9VLEtBQUgsRUFBeUMsRUFHeUQ7O0FBQUE7QUFBQyxLQUFDO0FBQUNXLFNBQUQ7QUFBS29UO0FBQUwsUUFBU2tTLFlBQVksQ0FBQyxJQUFELEVBQU10bEIsR0FBTixFQUFVb1QsRUFBVixDQUF0QjtBQUFxQyxXQUFPLEtBQUtvVixNQUFMLENBQVksV0FBWixFQUF3QnhvQixHQUF4QixFQUE0Qm9ULEVBQTVCLEVBQStCZ0IsT0FBL0IsQ0FBUDtBQUFnRDtBQUFBO0FBQ3JOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUFLekwsU0FBTyxDQUFDM0ksR0FBRCxFQUFLb1QsRUFBTCxFQUFRZ0IsT0FBTyxHQUFDLEVBQWhCLEVBQW1CO0FBQUM7QUFBQyxLQUFDO0FBQUNwVSxTQUFEO0FBQUtvVDtBQUFMLFFBQVNrUyxZQUFZLENBQUMsSUFBRCxFQUFNdGxCLEdBQU4sRUFBVW9ULEVBQVYsQ0FBdEI7QUFBcUMsV0FBTyxLQUFLb1YsTUFBTCxDQUFZLGNBQVosRUFBMkJ4b0IsR0FBM0IsRUFBK0JvVCxFQUEvQixFQUFrQ2dCLE9BQWxDLENBQVA7QUFBbUQ7O0FBQUEsUUFBTW9VLE1BQU4sQ0FBYXpvQixNQUFiLEVBQW9CQyxHQUFwQixFQUF3Qm9ULEVBQXhCLEVBQTJCZ0IsT0FBM0IsRUFBbUNpVSxZQUFuQyxFQUFnRDtBQUFDLFFBQUcsQ0FBQ2hVLFVBQVUsQ0FBQ3JVLEdBQUQsQ0FBZCxFQUFvQjtBQUFDNUcsWUFBTSxDQUFDNEYsUUFBUCxDQUFnQjdHLElBQWhCLEdBQXFCNkgsR0FBckI7QUFBeUIsYUFBTyxLQUFQO0FBQWM7O0FBQUEsVUFBTXFwQixpQkFBaUIsR0FBQ3JwQixHQUFHLEtBQUdvVCxFQUFOLElBQVVnQixPQUFPLENBQUNrVixFQUFsQixJQUFzQmxWLE9BQU8sQ0FBQ21WLGtCQUF0RCxDQUE3RCxDQUFzSTtBQUMvUzs7QUFDQSxRQUFHblYsT0FBTyxDQUFDa1YsRUFBWCxFQUFjO0FBQUMsV0FBS3ZCLE9BQUwsR0FBYSxJQUFiO0FBQW1COztBQUFBLFFBQUl5QixZQUFZLEdBQUNwVixPQUFPLENBQUNHLE1BQVIsS0FBaUIsS0FBS0EsTUFBdkM7O0FBQThDLFFBQUdsVixLQUFILEVBQW1DLHNCQVduRDs7QUFBQSxRQUFHLENBQUMrVSxPQUFPLENBQUNrVixFQUFaLEVBQWU7QUFBQyxXQUFLMUIsS0FBTCxHQUFXLEtBQVg7QUFBa0IsS0FidUUsQ0FhdkU7OztBQUNsRyxRQUFHdkYsTUFBTSxDQUFDb0gsRUFBVixFQUFhO0FBQUNDLGlCQUFXLENBQUNDLElBQVosQ0FBaUIsYUFBakI7QUFBaUM7O0FBQUEsVUFBSztBQUFDdlUsYUFBTyxHQUFDO0FBQVQsUUFBZ0JoQixPQUFyQjtBQUE2QixVQUFNd1YsVUFBVSxHQUFDO0FBQUN4VTtBQUFELEtBQWpCOztBQUEyQixRQUFHLEtBQUt5UyxjQUFSLEVBQXVCO0FBQUMsV0FBS2dDLGtCQUFMLENBQXdCLEtBQUtoQyxjQUE3QixFQUE0QytCLFVBQTVDO0FBQXlEOztBQUFBeFcsTUFBRSxHQUFDMkUsV0FBVyxDQUFDQyxTQUFTLENBQUM2SixXQUFXLENBQUN6TyxFQUFELENBQVgsR0FBZ0IwTyxXQUFXLENBQUMxTyxFQUFELENBQTNCLEdBQWdDQSxFQUFqQyxFQUFvQ2dCLE9BQU8sQ0FBQ0csTUFBNUMsRUFBbUQsS0FBSzBELGFBQXhELENBQVYsQ0FBZDtBQUFnRyxVQUFNNlIsU0FBUyxHQUFDbEksU0FBUyxDQUFDQyxXQUFXLENBQUN6TyxFQUFELENBQVgsR0FBZ0IwTyxXQUFXLENBQUMxTyxFQUFELENBQTNCLEdBQWdDQSxFQUFqQyxFQUFvQyxLQUFLbUIsTUFBekMsQ0FBekI7QUFBMEUsU0FBS3NULGNBQUwsR0FBb0J6VSxFQUFwQixDQWR6TCxDQWNnTjtBQUN6WDtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxRQUFHLENBQUNnQixPQUFPLENBQUNrVixFQUFULElBQWEsS0FBS1MsZUFBTCxDQUFxQkQsU0FBckIsQ0FBaEIsRUFBZ0Q7QUFBQyxXQUFLdGlCLE1BQUwsR0FBWXNpQixTQUFaO0FBQXNCckQsWUFBTSxDQUFDbEksTUFBUCxDQUFjbUQsSUFBZCxDQUFtQixpQkFBbkIsRUFBcUN0TyxFQUFyQyxFQUF3Q3dXLFVBQXhDLEVBQXZCLENBQTJFOztBQUMzSCxXQUFLMUIsV0FBTCxDQUFpQm5vQixNQUFqQixFQUF3QkMsR0FBeEIsRUFBNEJvVCxFQUE1QixFQUErQmdCLE9BQS9CO0FBQXdDLFdBQUs0VixZQUFMLENBQWtCRixTQUFsQjtBQUE2QixXQUFLRyxNQUFMLENBQVksS0FBSzVDLFVBQUwsQ0FBZ0IsS0FBS3hMLEtBQXJCLENBQVosRUFBd0MsSUFBeEM7QUFBOEM0SyxZQUFNLENBQUNsSSxNQUFQLENBQWNtRCxJQUFkLENBQW1CLG9CQUFuQixFQUF3Q3RPLEVBQXhDLEVBQTJDd1csVUFBM0M7QUFBdUQsYUFBTyxJQUFQO0FBQWE7O0FBQUEsUUFBSU0sTUFBTSxHQUFDLENBQUMsR0FBRTNILGlCQUFpQixDQUFDZ0csZ0JBQXJCLEVBQXVDdm9CLEdBQXZDLENBQVg7QUFBdUQsUUFBRztBQUFDZ2hCLGNBQUQ7QUFBVXZhO0FBQVYsUUFBaUJ5akIsTUFBcEIsQ0FwQnJFLENBb0JnRztBQUN6UTtBQUNBOztBQUNBLFFBQUl0RSxLQUFKLEVBQVV1RSxRQUFWOztBQUFtQixRQUFHO0FBQUN2RSxXQUFLLEdBQUMsTUFBTSxLQUFLa0IsVUFBTCxDQUFnQnNELFdBQWhCLEVBQVo7QUFBMEMsT0FBQztBQUFDQyxrQkFBVSxFQUFDRjtBQUFaLFVBQXNCLE1BQUssQ0FBQyxHQUFFbEksWUFBWSxDQUFDN0ksc0JBQWhCLEdBQTVCO0FBQXdFLEtBQXRILENBQXNILE9BQU14RixHQUFOLEVBQVU7QUFBQztBQUNwSjtBQUNBeGEsWUFBTSxDQUFDNEYsUUFBUCxDQUFnQjdHLElBQWhCLEdBQXFCaWIsRUFBckI7QUFBd0IsYUFBTyxLQUFQO0FBQWMsS0F6Qm1JLENBeUJuSTtBQUN0QztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EsUUFBRyxDQUFDLEtBQUtrWCxRQUFMLENBQWNSLFNBQWQsQ0FBRCxJQUEyQixDQUFDTixZQUEvQixFQUE0QztBQUFDenBCLFlBQU0sR0FBQyxjQUFQO0FBQXVCLEtBOUJxRyxDQThCckc7QUFDcEU7OztBQUNBLFFBQUkyVyxVQUFVLEdBQUN0RCxFQUFmLENBaEN5SyxDQWdDdko7QUFDbEI7QUFDQTs7QUFDQTROLFlBQVEsR0FBQ0EsUUFBUSxHQUFDLENBQUMsR0FBRWdCLHVCQUF1QixDQUFDNUosdUJBQTNCLEVBQW9EMEosV0FBVyxDQUFDZCxRQUFELENBQS9ELENBQUQsR0FBNEVBLFFBQTdGOztBQUFzRyxRQUFHcUksaUJBQWlCLElBQUVySSxRQUFRLEtBQUcsU0FBakMsRUFBMkM7QUFBQztBQUFDNU0sYUFBTyxDQUFDbVYsa0JBQVIsR0FBMkIsSUFBM0I7O0FBQWdDLFVBQUdscUIsS0FBSCxFQUF1RCxFQUF2RCxNQUV0RDtBQUFDNnFCLGNBQU0sQ0FBQ2xKLFFBQVAsR0FBZ0IyRSxtQkFBbUIsQ0FBQzNFLFFBQUQsRUFBVTRFLEtBQVYsQ0FBbkM7O0FBQW9ELFlBQUdzRSxNQUFNLENBQUNsSixRQUFQLEtBQWtCQSxRQUFyQixFQUE4QjtBQUFDQSxrQkFBUSxHQUFDa0osTUFBTSxDQUFDbEosUUFBaEI7QUFBeUJrSixnQkFBTSxDQUFDbEosUUFBUCxHQUFnQmpKLFdBQVcsQ0FBQ2lKLFFBQUQsQ0FBM0I7QUFBc0NoaEIsYUFBRyxHQUFDLENBQUMsR0FBRXFpQixNQUFNLENBQUN5QyxvQkFBVixFQUFnQ29GLE1BQWhDLENBQUo7QUFBNkM7QUFBQztBQUFDOztBQUFBLFVBQU1yTyxLQUFLLEdBQUMsQ0FBQyxHQUFFbUcsdUJBQXVCLENBQUM1Six1QkFBM0IsRUFBb0Q0SSxRQUFwRCxDQUFaOztBQUEwRSxRQUFHLENBQUMzTSxVQUFVLENBQUNqQixFQUFELENBQWQsRUFBbUI7QUFBQyxnQkFBdUM7QUFBQyxjQUFNLElBQUkxVCxLQUFKLENBQVcsa0JBQWlCTSxHQUFJLGNBQWFvVCxFQUFHLDJDQUF0QyxHQUFrRixvRkFBNUYsQ0FBTjtBQUF3TDs7QUFBQWhhLFlBQU0sQ0FBQzRGLFFBQVAsQ0FBZ0I3RyxJQUFoQixHQUFxQmliLEVBQXJCO0FBQXdCLGFBQU8sS0FBUDtBQUFjOztBQUFBc0QsY0FBVSxHQUFDa0wsU0FBUyxDQUFDRSxXQUFXLENBQUNwTCxVQUFELENBQVosRUFBeUIsS0FBS25DLE1BQTlCLENBQXBCOztBQUEwRCxRQUFHLENBQUMsR0FBRStOLFVBQVUsQ0FBQzJDLGNBQWQsRUFBOEJwSixLQUE5QixDQUFILEVBQXdDO0FBQUMsWUFBTTBPLFFBQVEsR0FBQyxDQUFDLEdBQUVoSSxpQkFBaUIsQ0FBQ2dHLGdCQUFyQixFQUF1QzdSLFVBQXZDLENBQWY7QUFBa0UsWUFBTWdOLFVBQVUsR0FBQzZHLFFBQVEsQ0FBQ3ZKLFFBQTFCO0FBQW1DLFlBQU13SixVQUFVLEdBQUMsQ0FBQyxHQUFFN0gsV0FBVyxDQUFDa0IsYUFBZixFQUE4QmhJLEtBQTlCLENBQWpCO0FBQXNELFlBQU00TyxVQUFVLEdBQUMsQ0FBQyxHQUFFL0gsYUFBYSxDQUFDdUIsZUFBakIsRUFBa0N1RyxVQUFsQyxFQUE4QzlHLFVBQTlDLENBQWpCO0FBQTJFLFlBQU1nSCxpQkFBaUIsR0FBQzdPLEtBQUssS0FBRzZILFVBQWhDO0FBQTJDLFlBQU1zQixjQUFjLEdBQUMwRixpQkFBaUIsR0FBQzNJLGFBQWEsQ0FBQ2xHLEtBQUQsRUFBTzZILFVBQVAsRUFBa0JqZCxLQUFsQixDQUFkLEdBQXVDLEVBQTdFOztBQUFnRixVQUFHLENBQUNna0IsVUFBRCxJQUFhQyxpQkFBaUIsSUFBRSxDQUFDMUYsY0FBYyxDQUFDUixNQUFuRCxFQUEwRDtBQUFDLGNBQU1tRyxhQUFhLEdBQUNwa0IsTUFBTSxDQUFDQyxJQUFQLENBQVlna0IsVUFBVSxDQUFDekcsTUFBdkIsRUFBK0JoVyxNQUEvQixDQUFzQ29XLEtBQUssSUFBRSxDQUFDMWQsS0FBSyxDQUFDMGQsS0FBRCxDQUFuRCxDQUFwQjs7QUFBZ0YsWUFBR3dHLGFBQWEsQ0FBQ2x6QixNQUFkLEdBQXFCLENBQXhCLEVBQTBCO0FBQUMsb0JBQXVDO0FBQUNrQyxtQkFBTyxDQUFDb1gsSUFBUixDQUFjLEdBQUUyWixpQkFBaUIsR0FBRSxvQkFBRixHQUF1QixpQ0FBaUMsOEJBQTVFLEdBQTJHLGVBQWNDLGFBQWEsQ0FBQ256QixJQUFkLENBQW1CLElBQW5CLENBQXlCLDhCQUEvSjtBQUErTDs7QUFBQSxnQkFBTSxJQUFJa0ksS0FBSixDQUFVLENBQUNnckIsaUJBQWlCLEdBQUUsMEJBQXlCMXFCLEdBQUksb0NBQW1DMnFCLGFBQWEsQ0FBQ256QixJQUFkLENBQW1CLElBQW5CLENBQXlCLGlDQUEzRixHQUE2SCw4QkFBNkJrc0IsVUFBVyw4Q0FBNkM3SCxLQUFNLEtBQTFPLElBQWlQLCtDQUE4QzZPLGlCQUFpQixHQUFDLDJCQUFELEdBQTZCLHNCQUF1QixFQUE5VyxDQUFOO0FBQXdYO0FBQUMsT0FBdHdCLE1BQTJ3QixJQUFHQSxpQkFBSCxFQUFxQjtBQUFDdFgsVUFBRSxHQUFDLENBQUMsR0FBRWlQLE1BQU0sQ0FBQ3lDLG9CQUFWLEVBQWdDdmUsTUFBTSxDQUFDd00sTUFBUCxDQUFjLEVBQWQsRUFBaUJ3WCxRQUFqQixFQUEwQjtBQUFDdkosa0JBQVEsRUFBQ2dFLGNBQWMsQ0FBQ1IsTUFBekI7QUFBZ0MvZCxlQUFLLEVBQUNnZSxrQkFBa0IsQ0FBQ2hlLEtBQUQsRUFBT3VlLGNBQWMsQ0FBQ2hrQixNQUF0QjtBQUF4RCxTQUExQixDQUFoQyxDQUFIO0FBQXVKLE9BQTdLLE1BQWlMO0FBQUM7QUFDcGlFdUYsY0FBTSxDQUFDd00sTUFBUCxDQUFjdE0sS0FBZCxFQUFvQmdrQixVQUFwQjtBQUFpQztBQUFDOztBQUFBaEUsVUFBTSxDQUFDbEksTUFBUCxDQUFjbUQsSUFBZCxDQUFtQixrQkFBbkIsRUFBc0N0TyxFQUF0QyxFQUF5Q3dXLFVBQXpDOztBQUFxRCxRQUFHO0FBQUMsVUFBSWdCLHFCQUFKLEVBQTBCQyxzQkFBMUIsRUFBaURDLGVBQWpEOztBQUFpRSxVQUFJQyxTQUFTLEdBQUMsTUFBTSxLQUFLQyxZQUFMLENBQWtCblAsS0FBbEIsRUFBd0JtRixRQUF4QixFQUFpQ3ZhLEtBQWpDLEVBQXVDMk0sRUFBdkMsRUFBMENzRCxVQUExQyxFQUFxRGtULFVBQXJELENBQXBCO0FBQXFGLFVBQUc7QUFBQzNyQixhQUFEO0FBQU96SSxhQUFQO0FBQWFrekIsZUFBYjtBQUFxQkM7QUFBckIsVUFBOEJvQyxTQUFqQyxDQUF2SixDQUFrTTs7QUFDNVIsVUFBRyxDQUFDckMsT0FBTyxJQUFFQyxPQUFWLEtBQW9CbnpCLEtBQXZCLEVBQTZCO0FBQUMsWUFBR0EsS0FBSyxDQUFDeTFCLFNBQU4sSUFBaUJ6MUIsS0FBSyxDQUFDeTFCLFNBQU4sQ0FBZ0JDLFlBQXBDLEVBQWlEO0FBQUMsZ0JBQU1DLFdBQVcsR0FBQzMxQixLQUFLLENBQUN5MUIsU0FBTixDQUFnQkMsWUFBbEMsQ0FBRCxDQUFnRDtBQUMvSDtBQUNBOztBQUNBLGNBQUdDLFdBQVcsQ0FBQzdiLFVBQVosQ0FBdUIsR0FBdkIsQ0FBSCxFQUErQjtBQUFDLGtCQUFNOGIsVUFBVSxHQUFDLENBQUMsR0FBRTdJLGlCQUFpQixDQUFDZ0csZ0JBQXJCLEVBQXVDNEMsV0FBdkMsQ0FBakI7QUFBcUVDLHNCQUFVLENBQUNwSyxRQUFYLEdBQW9CMkUsbUJBQW1CLENBQUN5RixVQUFVLENBQUNwSyxRQUFaLEVBQXFCNEUsS0FBckIsQ0FBdkM7O0FBQW1FLGdCQUFHQSxLQUFLLENBQUMvVSxRQUFOLENBQWV1YSxVQUFVLENBQUNwSyxRQUExQixDQUFILEVBQXVDO0FBQUMsb0JBQUs7QUFBQ2hoQixtQkFBRyxFQUFDcXJCLE1BQUw7QUFBWWpZLGtCQUFFLEVBQUNrWTtBQUFmLGtCQUFzQmhHLFlBQVksQ0FBQyxJQUFELEVBQU02RixXQUFOLEVBQWtCQSxXQUFsQixDQUF2QztBQUFzRSxxQkFBTyxLQUFLM0MsTUFBTCxDQUFZem9CLE1BQVosRUFBbUJzckIsTUFBbkIsRUFBMEJDLEtBQTFCLEVBQWdDbFgsT0FBaEMsQ0FBUDtBQUFpRDtBQUFDOztBQUFBaGIsZ0JBQU0sQ0FBQzRGLFFBQVAsQ0FBZ0I3RyxJQUFoQixHQUFxQmd6QixXQUFyQjtBQUFpQyxpQkFBTyxJQUFJM2IsT0FBSixDQUFZLE1BQUksQ0FBRSxDQUFsQixDQUFQO0FBQTRCOztBQUFBLGFBQUs0WCxTQUFMLEdBQWUsQ0FBQyxDQUFDNXhCLEtBQUssQ0FBQysxQixXQUF2QixDQUh4VyxDQUcyWTs7QUFDeGEsWUFBRy8xQixLQUFLLENBQUM2d0IsUUFBTixLQUFpQkosa0JBQXBCLEVBQXVDO0FBQUMsY0FBSXVGLGFBQUo7O0FBQWtCLGNBQUc7QUFBQyxrQkFBTSxLQUFLQyxjQUFMLENBQW9CLE1BQXBCLENBQU47QUFBa0NELHlCQUFhLEdBQUMsTUFBZDtBQUFzQixXQUE1RCxDQUE0RCxPQUFNeFYsQ0FBTixFQUFRO0FBQUN3Vix5QkFBYSxHQUFDLFNBQWQ7QUFBeUI7O0FBQUFULG1CQUFTLEdBQUMsTUFBTSxLQUFLQyxZQUFMLENBQWtCUSxhQUFsQixFQUFnQ0EsYUFBaEMsRUFBOEMva0IsS0FBOUMsRUFBb0QyTSxFQUFwRCxFQUF1RHNELFVBQXZELEVBQWtFO0FBQUN0QixtQkFBTyxFQUFDO0FBQVQsV0FBbEUsQ0FBaEI7QUFBb0c7QUFBQzs7QUFBQXFSLFlBQU0sQ0FBQ2xJLE1BQVAsQ0FBY21ELElBQWQsQ0FBbUIscUJBQW5CLEVBQXlDdE8sRUFBekMsRUFBNEN3VyxVQUE1QztBQUF3RCxXQUFLMUIsV0FBTCxDQUFpQm5vQixNQUFqQixFQUF3QkMsR0FBeEIsRUFBNEJvVCxFQUE1QixFQUErQmdCLE9BQS9COztBQUF3QyxnQkFBdUM7QUFBQyxjQUFNc1gsT0FBTyxHQUFDLEtBQUtyRSxVQUFMLENBQWdCLE9BQWhCLEVBQXlCSixTQUF2QztBQUFpRDd0QixjQUFNLENBQUN1eUIsSUFBUCxDQUFZQyxhQUFaLEdBQTBCRixPQUFPLENBQUM5SyxlQUFSLEtBQTBCOEssT0FBTyxDQUFDN0ssbUJBQWxDLElBQXVELENBQUNrSyxTQUFTLENBQUM5RCxTQUFWLENBQW9CckcsZUFBdEc7QUFBdUg7O0FBQUEsVUFBR3hNLE9BQU8sQ0FBQ2tWLEVBQVIsSUFBWXRJLFFBQVEsS0FBRyxTQUF2QixJQUFrQyxDQUFDLENBQUM0SixxQkFBcUIsR0FBQ3BTLElBQUksQ0FBQ3FRLGFBQUwsQ0FBbUJyekIsS0FBMUMsS0FBa0QsSUFBbEQsR0FBdUQsS0FBSyxDQUE1RCxHQUE4RCxDQUFDcTFCLHNCQUFzQixHQUFDRCxxQkFBcUIsQ0FBQ0ssU0FBOUMsS0FBMEQsSUFBMUQsR0FBK0QsS0FBSyxDQUFwRSxHQUFzRUosc0JBQXNCLENBQUNockIsVUFBNUosTUFBMEssR0FBNU0sSUFBaU5ySyxLQUFLLElBQUUsSUFBeE4sSUFBOE5BLEtBQUssQ0FBQ3kxQixTQUF2TyxFQUFpUDtBQUFDO0FBQy94QjtBQUNBejFCLGFBQUssQ0FBQ3kxQixTQUFOLENBQWdCcHJCLFVBQWhCLEdBQTJCLEdBQTNCO0FBQWdDLE9BUDBELENBTzFEOzs7QUFDaEMsWUFBTWdzQixtQkFBbUIsR0FBQ3pYLE9BQU8sQ0FBQ2dCLE9BQVIsSUFBaUIsS0FBS3lHLEtBQUwsS0FBYUEsS0FBeEQ7QUFBOEQsWUFBTWlRLFlBQVksR0FBQyxDQUFDaEIsZUFBZSxHQUFDMVcsT0FBTyxDQUFDaUIsTUFBekIsS0FBa0MsSUFBbEMsR0FBdUN5VixlQUF2QyxHQUF1RCxDQUFDZSxtQkFBM0U7QUFBK0YsWUFBTUUsV0FBVyxHQUFDRCxZQUFZLEdBQUM7QUFBQ2xkLFNBQUMsRUFBQyxDQUFIO0FBQUtvZCxTQUFDLEVBQUM7QUFBUCxPQUFELEdBQVcsSUFBekM7QUFBOEMsWUFBTSxLQUFLbFMsR0FBTCxDQUFTK0IsS0FBVCxFQUFlbUYsUUFBZixFQUF3QnZhLEtBQXhCLEVBQThCcWpCLFNBQTlCLEVBQXdDaUIsU0FBeEMsRUFBa0QxQyxZQUFZLElBQUUsSUFBZCxHQUFtQkEsWUFBbkIsR0FBZ0MwRCxXQUFsRixFQUErRnJjLEtBQS9GLENBQXFHeUYsQ0FBQyxJQUFFO0FBQUMsWUFBR0EsQ0FBQyxDQUFDb0csU0FBTCxFQUFldGQsS0FBSyxHQUFDQSxLQUFLLElBQUVrWCxDQUFiLENBQWYsS0FBbUMsTUFBTUEsQ0FBTjtBQUFTLE9BQXJKLENBQU47O0FBQTZKLFVBQUdsWCxLQUFILEVBQVM7QUFBQ3dvQixjQUFNLENBQUNsSSxNQUFQLENBQWNtRCxJQUFkLENBQW1CLGtCQUFuQixFQUFzQ3pqQixLQUF0QyxFQUE0QzZyQixTQUE1QyxFQUFzREYsVUFBdEQ7QUFBa0UsY0FBTTNyQixLQUFOO0FBQWE7O0FBQUEsVUFBR29CLEtBQUgsRUFBbUMsRUFBNkQ7O0FBQUFvbkIsWUFBTSxDQUFDbEksTUFBUCxDQUFjbUQsSUFBZCxDQUFtQixxQkFBbkIsRUFBeUN0TyxFQUF6QyxFQUE0Q3dXLFVBQTVDO0FBQXdELGFBQU8sSUFBUDtBQUFhLEtBUi9nQixDQVErZ0IsT0FBTWhXLEdBQU4sRUFBVTtBQUFDLFVBQUdBLEdBQUcsQ0FBQzJILFNBQVAsRUFBaUI7QUFBQyxlQUFPLEtBQVA7QUFBYzs7QUFBQSxZQUFNM0gsR0FBTjtBQUFXO0FBQUM7O0FBQUFzVSxhQUFXLENBQUNub0IsTUFBRCxFQUFRQyxHQUFSLEVBQVlvVCxFQUFaLEVBQWVnQixPQUFPLEdBQUMsRUFBdkIsRUFBMEI7QUFBQyxjQUF1QztBQUFDLFVBQUcsT0FBT2hiLE1BQU0sQ0FBQ2d3QixPQUFkLEtBQXdCLFdBQTNCLEVBQXVDO0FBQUN6dkIsZUFBTyxDQUFDc0UsS0FBUixDQUFlLDJDQUFmO0FBQTJEO0FBQVE7O0FBQUEsVUFBRyxPQUFPN0UsTUFBTSxDQUFDZ3dCLE9BQVAsQ0FBZXJwQixNQUFmLENBQVAsS0FBZ0MsV0FBbkMsRUFBK0M7QUFBQ3BHLGVBQU8sQ0FBQ3NFLEtBQVIsQ0FBZSwyQkFBMEI4QixNQUFPLG1CQUFoRDtBQUFvRTtBQUFRO0FBQUM7O0FBQUEsUUFBR0EsTUFBTSxLQUFHLFdBQVQsSUFBc0IsQ0FBQyxHQUFFc2lCLE1BQU0sQ0FBQzhGLE1BQVYsUUFBc0IvVSxFQUEvQyxFQUFrRDtBQUFDLFdBQUswVSxRQUFMLEdBQWMxVCxPQUFPLENBQUNnQixPQUF0QjtBQUE4QmhjLFlBQU0sQ0FBQ2d3QixPQUFQLENBQWVycEIsTUFBZixFQUF1QjtBQUFDQyxXQUFEO0FBQUtvVCxVQUFMO0FBQVFnQixlQUFSO0FBQWdCZ1UsV0FBRyxFQUFDLElBQXBCO0FBQXlCRSxXQUFHLEVBQUMsS0FBS04sSUFBTCxHQUFVam9CLE1BQU0sS0FBRyxXQUFULEdBQXFCLEtBQUtpb0IsSUFBMUIsR0FBK0IsS0FBS0EsSUFBTCxHQUFVO0FBQWhGLE9BQXZCLEVBQTBHO0FBQzlvQztBQUNBO0FBQ0EsUUFIb2lDLEVBR2ppQzVVLEVBSGlpQztBQUc1aEM7QUFBQzs7QUFBQSxRQUFNNlksb0JBQU4sQ0FBMkJyWSxHQUEzQixFQUErQm9OLFFBQS9CLEVBQXdDdmEsS0FBeEMsRUFBOEMyTSxFQUE5QyxFQUFpRHdXLFVBQWpELEVBQTREc0MsYUFBNUQsRUFBMEU7QUFBQyxRQUFHdFksR0FBRyxDQUFDMkgsU0FBUCxFQUFpQjtBQUFDO0FBQ3RHLFlBQU0zSCxHQUFOO0FBQVc7O0FBQUEsUUFBRyxDQUFDLEdBQUVxTyxZQUFZLENBQUM5SSxZQUFoQixFQUE4QnZGLEdBQTlCLEtBQW9Dc1ksYUFBdkMsRUFBcUQ7QUFBQ3pGLFlBQU0sQ0FBQ2xJLE1BQVAsQ0FBY21ELElBQWQsQ0FBbUIsa0JBQW5CLEVBQXNDOU4sR0FBdEMsRUFBMENSLEVBQTFDLEVBQTZDd1csVUFBN0MsRUFBRCxDQUEwRDtBQUMxSDtBQUNBO0FBQ0E7QUFDQTs7QUFDQXh3QixZQUFNLENBQUM0RixRQUFQLENBQWdCN0csSUFBaEIsR0FBcUJpYixFQUFyQixDQUxnRSxDQUt4QztBQUN4Qjs7QUFDQSxZQUFNNFAsc0JBQXNCLEVBQTVCO0FBQWdDOztBQUFBLFFBQUc7QUFBQyxVQUFJaUUsU0FBSjtBQUFjLFVBQUkxSyxXQUFKO0FBQWdCLFVBQUkvbUIsS0FBSjs7QUFBVSxVQUFHLE9BQU95eEIsU0FBUCxLQUFtQixXQUFuQixJQUFnQyxPQUFPMUssV0FBUCxLQUFxQixXQUF4RCxFQUFvRTtBQUFDO0FBQUMsU0FBQztBQUFDMWlCLGNBQUksRUFBQ290QixTQUFOO0FBQWdCMUs7QUFBaEIsWUFBNkIsTUFBTSxLQUFLa1AsY0FBTCxDQUFvQixTQUFwQixDQUFwQztBQUFxRTs7QUFBQSxZQUFNVixTQUFTLEdBQUM7QUFBQ3YxQixhQUFEO0FBQU95eEIsaUJBQVA7QUFBaUIxSyxtQkFBakI7QUFBNkIzSSxXQUE3QjtBQUFpQzNWLGFBQUssRUFBQzJWO0FBQXZDLE9BQWhCOztBQUE0RCxVQUFHLENBQUNtWCxTQUFTLENBQUN2MUIsS0FBZCxFQUFvQjtBQUFDLFlBQUc7QUFBQ3UxQixtQkFBUyxDQUFDdjFCLEtBQVYsR0FBZ0IsTUFBTSxLQUFLb3JCLGVBQUwsQ0FBcUJxRyxTQUFyQixFQUErQjtBQUFDclQsZUFBRDtBQUFLb04sb0JBQUw7QUFBY3ZhO0FBQWQsV0FBL0IsQ0FBdEI7QUFBNEUsU0FBaEYsQ0FBZ0YsT0FBTTBsQixNQUFOLEVBQWE7QUFBQ3h5QixpQkFBTyxDQUFDc0UsS0FBUixDQUFjLHlDQUFkLEVBQXdEa3VCLE1BQXhEO0FBQWdFcEIsbUJBQVMsQ0FBQ3YxQixLQUFWLEdBQWdCLEVBQWhCO0FBQW9CO0FBQUM7O0FBQUEsYUFBT3UxQixTQUFQO0FBQWtCLEtBQTdjLENBQTZjLE9BQU1xQixZQUFOLEVBQW1CO0FBQUMsYUFBTyxLQUFLSCxvQkFBTCxDQUEwQkcsWUFBMUIsRUFBdUNwTCxRQUF2QyxFQUFnRHZhLEtBQWhELEVBQXNEMk0sRUFBdEQsRUFBeUR3VyxVQUF6RCxFQUFvRSxJQUFwRSxDQUFQO0FBQWtGO0FBQUM7O0FBQUEsUUFBTW9CLFlBQU4sQ0FBbUJuUCxLQUFuQixFQUF5Qm1GLFFBQXpCLEVBQWtDdmEsS0FBbEMsRUFBd0MyTSxFQUF4QyxFQUEyQ3NELFVBQTNDLEVBQXNEa1QsVUFBdEQsRUFBaUU7QUFBQyxRQUFHO0FBQUMsWUFBTXlDLGlCQUFpQixHQUFDLEtBQUtoRixVQUFMLENBQWdCeEwsS0FBaEIsQ0FBeEI7O0FBQStDLFVBQUcrTixVQUFVLENBQUN4VSxPQUFYLElBQW9CaVgsaUJBQXBCLElBQXVDLEtBQUt4USxLQUFMLEtBQWFBLEtBQXZELEVBQTZEO0FBQUMsZUFBT3dRLGlCQUFQO0FBQTBCOztBQUFBLFlBQU1DLGVBQWUsR0FBQ0QsaUJBQWlCLElBQUUsYUFBWUEsaUJBQS9CLEdBQWlEOXpCLFNBQWpELEdBQTJEOHpCLGlCQUFqRjtBQUFtRyxZQUFNdEIsU0FBUyxHQUFDdUIsZUFBZSxHQUFDQSxlQUFELEdBQWlCLE1BQU0sS0FBS2IsY0FBTCxDQUFvQjVQLEtBQXBCLEVBQTJCNWtCLElBQTNCLENBQWdDcVQsR0FBRyxLQUFHO0FBQUMyYyxpQkFBUyxFQUFDM2MsR0FBRyxDQUFDelEsSUFBZjtBQUFvQjBpQixtQkFBVyxFQUFDalMsR0FBRyxDQUFDaVMsV0FBcEM7QUFBZ0RtTSxlQUFPLEVBQUNwZSxHQUFHLENBQUNpaUIsR0FBSixDQUFRN0QsT0FBaEU7QUFBd0VDLGVBQU8sRUFBQ3JlLEdBQUcsQ0FBQ2lpQixHQUFKLENBQVE1RDtBQUF4RixPQUFILENBQW5DLENBQXREO0FBQStMLFlBQUs7QUFBQzFCLGlCQUFEO0FBQVd5QixlQUFYO0FBQW1CQztBQUFuQixVQUE0Qm9DLFNBQWpDOztBQUEyQyxnQkFBdUM7QUFBQyxjQUFLO0FBQUN5QjtBQUFELFlBQXFCM2hCLG1CQUFPLENBQUMscUVBQUQsQ0FBakM7O0FBQThDLFlBQUcsQ0FBQzJoQixrQkFBa0IsQ0FBQ3ZGLFNBQUQsQ0FBdEIsRUFBa0M7QUFBQyxnQkFBTSxJQUFJdm5CLEtBQUosQ0FBVyx5REFBd0RzaEIsUUFBUyxHQUE1RSxDQUFOO0FBQXVGO0FBQUM7O0FBQUEsVUFBSXVGLFFBQUo7O0FBQWEsVUFBR21DLE9BQU8sSUFBRUMsT0FBWixFQUFvQjtBQUFDcEMsZ0JBQVEsR0FBQyxLQUFLTyxVQUFMLENBQWdCMkYsV0FBaEIsQ0FBNEIsQ0FBQyxHQUFFcEssTUFBTSxDQUFDeUMsb0JBQVYsRUFBZ0M7QUFBQzlELGtCQUFEO0FBQVV2YTtBQUFWLFNBQWhDLENBQTVCLEVBQThFaVEsVUFBOUUsRUFBeUZnUyxPQUF6RixFQUFpRyxLQUFLblUsTUFBdEcsQ0FBVDtBQUF3SDs7QUFBQSxZQUFNL2UsS0FBSyxHQUFDLE1BQU0sS0FBS2szQixRQUFMLENBQWMsTUFBSWhFLE9BQU8sR0FBQyxLQUFLaUUsY0FBTCxDQUFvQnBHLFFBQXBCLENBQUQsR0FBK0JvQyxPQUFPLEdBQUMsS0FBS2lFLGNBQUwsQ0FBb0JyRyxRQUFwQixDQUFELEdBQStCLEtBQUszRixlQUFMLENBQXFCcUcsU0FBckIsRUFBK0I7QUFDeG1EO0FBQUNqRyxnQkFBRDtBQUFVdmEsYUFBVjtBQUFnQmUsY0FBTSxFQUFDNEwsRUFBdkI7QUFBMEJtQixjQUFNLEVBQUMsS0FBS0EsTUFBdEM7QUFBNkNzRCxlQUFPLEVBQUMsS0FBS0EsT0FBMUQ7QUFBa0VJLHFCQUFhLEVBQUMsS0FBS0E7QUFBckYsT0FEeWtELENBQTlGLENBQWxCO0FBQ24zQzhTLGVBQVMsQ0FBQ3YxQixLQUFWLEdBQWdCQSxLQUFoQjtBQUFzQixXQUFLNnhCLFVBQUwsQ0FBZ0J4TCxLQUFoQixJQUF1QmtQLFNBQXZCO0FBQWlDLGFBQU9BLFNBQVA7QUFBa0IsS0FEdWUsQ0FDdmUsT0FBTW5YLEdBQU4sRUFBVTtBQUFDLGFBQU8sS0FBS3FZLG9CQUFMLENBQTBCclksR0FBMUIsRUFBOEJvTixRQUE5QixFQUF1Q3ZhLEtBQXZDLEVBQTZDMk0sRUFBN0MsRUFBZ0R3VyxVQUFoRCxDQUFQO0FBQW9FO0FBQUM7O0FBQUE5UCxLQUFHLENBQUMrQixLQUFELEVBQU9tRixRQUFQLEVBQWdCdmEsS0FBaEIsRUFBc0IyTSxFQUF0QixFQUF5QjFaLElBQXpCLEVBQThCcXlCLFdBQTlCLEVBQTBDO0FBQUMsU0FBSzVFLFVBQUwsR0FBZ0IsS0FBaEI7QUFBc0IsU0FBS3RMLEtBQUwsR0FBV0EsS0FBWDtBQUFpQixTQUFLbUYsUUFBTCxHQUFjQSxRQUFkO0FBQXVCLFNBQUt2YSxLQUFMLEdBQVdBLEtBQVg7QUFBaUIsU0FBS2UsTUFBTCxHQUFZNEwsRUFBWjtBQUFlLFdBQU8sS0FBSzZXLE1BQUwsQ0FBWXZ3QixJQUFaLEVBQWlCcXlCLFdBQWpCLENBQVA7QUFBc0M7QUFBQTtBQUNqYjtBQUNBO0FBQ0E7OztBQUFLYyxnQkFBYyxDQUFDcFUsRUFBRCxFQUFJO0FBQUMsU0FBS2lQLElBQUwsR0FBVWpQLEVBQVY7QUFBYzs7QUFBQXNSLGlCQUFlLENBQUMzVyxFQUFELEVBQUk7QUFBQyxRQUFHLENBQUMsS0FBSzVMLE1BQVQsRUFBZ0IsT0FBTyxLQUFQO0FBQWEsVUFBSyxDQUFDc2xCLFlBQUQsRUFBY0MsT0FBZCxJQUF1QixLQUFLdmxCLE1BQUwsQ0FBWTBCLEtBQVosQ0FBa0IsR0FBbEIsQ0FBNUI7QUFBbUQsVUFBSyxDQUFDOGpCLFlBQUQsRUFBY0MsT0FBZCxJQUF1QjdaLEVBQUUsQ0FBQ2xLLEtBQUgsQ0FBUyxHQUFULENBQTVCLENBQWpGLENBQTJIOztBQUNwTCxRQUFHK2pCLE9BQU8sSUFBRUgsWUFBWSxLQUFHRSxZQUF4QixJQUFzQ0QsT0FBTyxLQUFHRSxPQUFuRCxFQUEyRDtBQUFDLGFBQU8sSUFBUDtBQUFhLEtBRGhCLENBQ2dCOzs7QUFDekUsUUFBR0gsWUFBWSxLQUFHRSxZQUFsQixFQUErQjtBQUFDLGFBQU8sS0FBUDtBQUFjLEtBRlcsQ0FFWDtBQUM5QztBQUNBO0FBQ0E7OztBQUNBLFdBQU9ELE9BQU8sS0FBR0UsT0FBakI7QUFBMEI7O0FBQUFqRCxjQUFZLENBQUM1VyxFQUFELEVBQUk7QUFBQyxVQUFLLEdBQUVnUyxJQUFGLElBQVFoUyxFQUFFLENBQUNsSyxLQUFILENBQVMsR0FBVCxDQUFiLENBQUQsQ0FBNEI7QUFDdEU7O0FBQ0EsUUFBR2tjLElBQUksS0FBRyxFQUFQLElBQVdBLElBQUksS0FBRyxLQUFyQixFQUEyQjtBQUFDaHNCLFlBQU0sQ0FBQzh6QixRQUFQLENBQWdCLENBQWhCLEVBQWtCLENBQWxCO0FBQXFCO0FBQVEsS0FGZixDQUVlOzs7QUFDekQsVUFBTUMsSUFBSSxHQUFDbFQsUUFBUSxDQUFDbVQsY0FBVCxDQUF3QmhJLElBQXhCLENBQVg7O0FBQXlDLFFBQUcrSCxJQUFILEVBQVE7QUFBQ0EsVUFBSSxDQUFDRSxjQUFMO0FBQXNCO0FBQVEsS0FIdEMsQ0FHc0M7QUFDaEY7OztBQUNBLFVBQU1DLE1BQU0sR0FBQ3JULFFBQVEsQ0FBQ3NULGlCQUFULENBQTJCbkksSUFBM0IsRUFBaUMsQ0FBakMsQ0FBYjs7QUFBaUQsUUFBR2tJLE1BQUgsRUFBVTtBQUFDQSxZQUFNLENBQUNELGNBQVA7QUFBeUI7QUFBQzs7QUFBQS9DLFVBQVEsQ0FBQzlpQixNQUFELEVBQVE7QUFBQyxXQUFPLEtBQUtBLE1BQUwsS0FBY0EsTUFBckI7QUFBNkI7QUFBQTtBQUNwSTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFBSyxRQUFNMk0sUUFBTixDQUFlblUsR0FBZixFQUFtQndILE1BQU0sR0FBQ3hILEdBQTFCLEVBQThCb1UsT0FBTyxHQUFDLEVBQXRDLEVBQXlDO0FBQUMsUUFBSThWLE1BQU0sR0FBQyxDQUFDLEdBQUUzSCxpQkFBaUIsQ0FBQ2dHLGdCQUFyQixFQUF1Q3ZvQixHQUF2QyxDQUFYO0FBQXVELFFBQUc7QUFBQ2doQjtBQUFELFFBQVdrSixNQUFkOztBQUFxQixRQUFHN3FCLEtBQUgsRUFBbUMsRUFBeWY7O0FBQUEsVUFBTXVtQixLQUFLLEdBQUMsTUFBTSxLQUFLa0IsVUFBTCxDQUFnQnNELFdBQWhCLEVBQWxCO0FBQWdELFFBQUkxVCxVQUFVLEdBQUNsUCxNQUFmOztBQUFzQixRQUFHbkksS0FBSCxFQUEyRCxFQUEzRCxNQUU3bUI7QUFBQzZxQixZQUFNLENBQUNsSixRQUFQLEdBQWdCMkUsbUJBQW1CLENBQUN1RSxNQUFNLENBQUNsSixRQUFSLEVBQWlCNEUsS0FBakIsQ0FBbkM7O0FBQTJELFVBQUdzRSxNQUFNLENBQUNsSixRQUFQLEtBQWtCQSxRQUFyQixFQUE4QjtBQUFDQSxnQkFBUSxHQUFDa0osTUFBTSxDQUFDbEosUUFBaEI7QUFBeUJrSixjQUFNLENBQUNsSixRQUFQLEdBQWdCQSxRQUFoQjtBQUF5QmhoQixXQUFHLEdBQUMsQ0FBQyxHQUFFcWlCLE1BQU0sQ0FBQ3lDLG9CQUFWLEVBQWdDb0YsTUFBaEMsQ0FBSjtBQUE2QztBQUFDOztBQUFBLFVBQU1yTyxLQUFLLEdBQUMsQ0FBQyxHQUFFbUcsdUJBQXVCLENBQUM1Six1QkFBM0IsRUFBb0Q0SSxRQUFwRCxDQUFaLENBRjdQLENBRXVVOztBQUNyWCxjQUF1QztBQUFDO0FBQVE7O0FBQUEsVUFBTXhSLE9BQU8sQ0FBQ2MsR0FBUixDQUFZLENBQUMsS0FBS3dXLFVBQUwsQ0FBZ0IwRyxNQUFoQixDQUF1QjNSLEtBQXZCLEVBQThCNWtCLElBQTlCLENBQW1DdzJCLEtBQUssSUFBRTtBQUFDLGFBQU9BLEtBQUssR0FBQyxLQUFLZCxjQUFMLENBQW9CLEtBQUs3RixVQUFMLENBQWdCMkYsV0FBaEIsQ0FBNEJ6c0IsR0FBNUIsRUFBZ0MwVyxVQUFoQyxFQUEyQyxJQUEzQyxFQUFnRCxPQUFPdEMsT0FBTyxDQUFDRyxNQUFmLEtBQXdCLFdBQXhCLEdBQW9DSCxPQUFPLENBQUNHLE1BQTVDLEdBQW1ELEtBQUtBLE1BQXhHLENBQXBCLENBQUQsR0FBc0ksS0FBbEo7QUFBeUosS0FBcE0sQ0FBRCxFQUF1TSxLQUFLdVMsVUFBTCxDQUFnQjFTLE9BQU8sQ0FBQ3BFLFFBQVIsR0FBaUIsVUFBakIsR0FBNEIsVUFBNUMsRUFBd0Q2TCxLQUF4RCxDQUF2TSxDQUFaLENBQU47QUFBMlI7O0FBQUEsUUFBTTRQLGNBQU4sQ0FBcUI1UCxLQUFyQixFQUEyQjtBQUFDLFFBQUlOLFNBQVMsR0FBQyxLQUFkOztBQUFvQixVQUFNbVMsTUFBTSxHQUFDLEtBQUtqRyxHQUFMLEdBQVMsTUFBSTtBQUFDbE0sZUFBUyxHQUFDLElBQVY7QUFBZ0IsS0FBM0M7O0FBQTRDLFVBQU1vUyxlQUFlLEdBQUMsTUFBTSxLQUFLN0csVUFBTCxDQUFnQjhHLFFBQWhCLENBQXlCL1IsS0FBekIsQ0FBNUI7O0FBQTRELFFBQUdOLFNBQUgsRUFBYTtBQUFDLFlBQU10ZCxLQUFLLEdBQUMsSUFBSXlCLEtBQUosQ0FBVyx3Q0FBdUNtYyxLQUFNLEdBQXhELENBQVo7QUFBd0U1ZCxXQUFLLENBQUNzZCxTQUFOLEdBQWdCLElBQWhCO0FBQXFCLFlBQU10ZCxLQUFOO0FBQWE7O0FBQUEsUUFBR3l2QixNQUFNLEtBQUcsS0FBS2pHLEdBQWpCLEVBQXFCO0FBQUMsV0FBS0EsR0FBTCxHQUFTLElBQVQ7QUFBZTs7QUFBQSxXQUFPa0csZUFBUDtBQUF3Qjs7QUFBQWpCLFVBQVEsQ0FBQzNQLEVBQUQsRUFBSTtBQUFDLFFBQUl4QixTQUFTLEdBQUMsS0FBZDs7QUFBb0IsVUFBTW1TLE1BQU0sR0FBQyxNQUFJO0FBQUNuUyxlQUFTLEdBQUMsSUFBVjtBQUFnQixLQUFsQzs7QUFBbUMsU0FBS2tNLEdBQUwsR0FBU2lHLE1BQVQ7QUFBZ0IsV0FBTzNRLEVBQUUsR0FBRzlsQixJQUFMLENBQVV5QyxJQUFJLElBQUU7QUFBQyxVQUFHZzBCLE1BQU0sS0FBRyxLQUFLakcsR0FBakIsRUFBcUI7QUFBQyxhQUFLQSxHQUFMLEdBQVMsSUFBVDtBQUFlOztBQUFBLFVBQUdsTSxTQUFILEVBQWE7QUFBQyxjQUFNM0gsR0FBRyxHQUFDLElBQUlsVSxLQUFKLENBQVUsaUNBQVYsQ0FBVjtBQUF1RGtVLFdBQUcsQ0FBQzJILFNBQUosR0FBYyxJQUFkO0FBQW1CLGNBQU0zSCxHQUFOO0FBQVc7O0FBQUEsYUFBT2xhLElBQVA7QUFBYSxLQUF0SyxDQUFQO0FBQWdMOztBQUFBaXpCLGdCQUFjLENBQUNwRyxRQUFELEVBQVU7QUFBQyxVQUFLO0FBQUNwdUIsVUFBSSxFQUFDMDFCO0FBQU4sUUFBZ0IsSUFBSWxhLEdBQUosQ0FBUTRTLFFBQVIsRUFBaUJudEIsTUFBTSxDQUFDNEYsUUFBUCxDQUFnQjdHLElBQWpDLENBQXJCOztBQUE0RCxRQUFHLEtBQUgsRUFBNEUsRUFBNkM7O0FBQUEsV0FBT211QixhQUFhLENBQUNDLFFBQUQsRUFBVSxLQUFLcUIsS0FBZixDQUFiLENBQW1DM3dCLElBQW5DLENBQXdDeUMsSUFBSSxJQUFFO0FBQUMsV0FBSzR0QixHQUFMLENBQVN1RyxRQUFULElBQW1CbjBCLElBQW5CO0FBQXdCLGFBQU9BLElBQVA7QUFBYSxLQUFwRixDQUFQO0FBQThGOztBQUFBa3pCLGdCQUFjLENBQUNyRyxRQUFELEVBQVU7QUFBQyxVQUFLO0FBQUNwdUIsVUFBSSxFQUFDMjFCO0FBQU4sUUFBbUIsSUFBSW5hLEdBQUosQ0FBUTRTLFFBQVIsRUFBaUJudEIsTUFBTSxDQUFDNEYsUUFBUCxDQUFnQjdHLElBQWpDLENBQXhCOztBQUErRCxRQUFHLEtBQUtvdkIsR0FBTCxDQUFTdUcsV0FBVCxDQUFILEVBQXlCO0FBQUMsYUFBTyxLQUFLdkcsR0FBTCxDQUFTdUcsV0FBVCxDQUFQO0FBQThCOztBQUFBLFdBQU8sS0FBS3ZHLEdBQUwsQ0FBU3VHLFdBQVQsSUFBc0J4SCxhQUFhLENBQUNDLFFBQUQsRUFBVSxLQUFLcUIsS0FBZixDQUFiLENBQW1DM3dCLElBQW5DLENBQXdDeUMsSUFBSSxJQUFFO0FBQUMsYUFBTyxLQUFLNnRCLEdBQUwsQ0FBU3VHLFdBQVQsQ0FBUDtBQUE2QixhQUFPcDBCLElBQVA7QUFBYSxLQUF6RixFQUEyRmdXLEtBQTNGLENBQWlHa0UsR0FBRyxJQUFFO0FBQUMsYUFBTyxLQUFLMlQsR0FBTCxDQUFTdUcsV0FBVCxDQUFQO0FBQTZCLFlBQU1sYSxHQUFOO0FBQVcsS0FBL0ksQ0FBN0I7QUFBK0s7O0FBQUFnTixpQkFBZSxDQUFDcUcsU0FBRCxFQUFXOEcsR0FBWCxFQUFlO0FBQUMsVUFBSztBQUFDOUcsZUFBUyxFQUFDRjtBQUFYLFFBQWdCLEtBQUtNLFVBQUwsQ0FBZ0IsT0FBaEIsQ0FBckI7O0FBQThDLFVBQU0yRyxPQUFPLEdBQUMsS0FBS3JHLFFBQUwsQ0FBY1osR0FBZCxDQUFkOztBQUFpQ2dILE9BQUcsQ0FBQ0MsT0FBSixHQUFZQSxPQUFaO0FBQW9CLFdBQU0sQ0FBQyxHQUFFM0wsTUFBTSxDQUFDNEwsbUJBQVYsRUFBK0JsSCxHQUEvQixFQUFtQztBQUFDaUgsYUFBRDtBQUFTL0csZUFBVDtBQUFtQjVnQixZQUFNLEVBQUMsSUFBMUI7QUFBK0IwbkI7QUFBL0IsS0FBbkMsQ0FBTjtBQUErRTs7QUFBQWxFLG9CQUFrQixDQUFDelcsRUFBRCxFQUFJd1csVUFBSixFQUFlO0FBQUMsUUFBRyxLQUFLbkMsR0FBUixFQUFZO0FBQUNoQixZQUFNLENBQUNsSSxNQUFQLENBQWNtRCxJQUFkLENBQW1CLGtCQUFuQixFQUFzQ3NCLHNCQUFzQixFQUE1RCxFQUErRDVQLEVBQS9ELEVBQWtFd1csVUFBbEU7QUFBOEUsV0FBS25DLEdBQUw7QUFBVyxXQUFLQSxHQUFMLEdBQVMsSUFBVDtBQUFlO0FBQUM7O0FBQUF3QyxRQUFNLENBQUN2d0IsSUFBRCxFQUFNcXlCLFdBQU4sRUFBa0I7QUFBQyxXQUFPLEtBQUt2RSxHQUFMLENBQVM5dEIsSUFBVCxFQUFjLEtBQUsydEIsVUFBTCxDQUFnQixPQUFoQixFQUF5QkosU0FBdkMsRUFBaUQ4RSxXQUFqRCxDQUFQO0FBQXNFOztBQW5JMzNEOztBQW1JNDNEamhCLGVBQUEsR0FBZ0IyYixNQUFoQjtBQUF1QkEsTUFBTSxDQUFDbEksTUFBUCxHQUFjLENBQUMsR0FBRTZELEtBQUssQ0FBQ2pXLE9BQVQsR0FBZCxDOzs7Ozs7Ozs7OztBQ2hMMTlEOztBQUFBckIsa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLGlCQUFBLEdBQWtCb2pCLFNBQWxCOztBQUE0QixJQUFJQyxXQUFXLEdBQUNwYSx1QkFBdUIsQ0FBQ2xKLG1CQUFPLENBQUMsNEZBQUQsQ0FBUixDQUF2Qzs7QUFBa0UsU0FBU3VqQix3QkFBVCxHQUFtQztBQUFDLE1BQUcsT0FBT0MsT0FBUCxLQUFpQixVQUFwQixFQUErQixPQUFPLElBQVA7QUFBWSxNQUFJQyxLQUFLLEdBQUMsSUFBSUQsT0FBSixFQUFWOztBQUF3QkQsMEJBQXdCLEdBQUMsWUFBVTtBQUFDLFdBQU9FLEtBQVA7QUFBYyxHQUFsRDs7QUFBbUQsU0FBT0EsS0FBUDtBQUFjOztBQUFBLFNBQVN2YSx1QkFBVCxDQUFpQzZPLEdBQWpDLEVBQXFDO0FBQUMsTUFBR0EsR0FBRyxJQUFFQSxHQUFHLENBQUNDLFVBQVosRUFBdUI7QUFBQyxXQUFPRCxHQUFQO0FBQVk7O0FBQUEsTUFBR0EsR0FBRyxLQUFHLElBQU4sSUFBWSxPQUFPQSxHQUFQLEtBQWEsUUFBYixJQUF1QixPQUFPQSxHQUFQLEtBQWEsVUFBbkQsRUFBOEQ7QUFBQyxXQUFNO0FBQUN6VyxhQUFPLEVBQUN5VztBQUFULEtBQU47QUFBcUI7O0FBQUEsTUFBSTBMLEtBQUssR0FBQ0Ysd0JBQXdCLEVBQWxDOztBQUFxQyxNQUFHRSxLQUFLLElBQUVBLEtBQUssQ0FBQ2xSLEdBQU4sQ0FBVXdGLEdBQVYsQ0FBVixFQUF5QjtBQUFDLFdBQU8wTCxLQUFLLENBQUN2dEIsR0FBTixDQUFVNmhCLEdBQVYsQ0FBUDtBQUF1Qjs7QUFBQSxNQUFJMkwsTUFBTSxHQUFDLEVBQVg7QUFBYyxNQUFJQyxxQkFBcUIsR0FBQ2pvQixNQUFNLENBQUMwVSxjQUFQLElBQXVCMVUsTUFBTSxDQUFDa29CLHdCQUF4RDs7QUFBaUYsT0FBSSxJQUFJdmIsR0FBUixJQUFlMFAsR0FBZixFQUFtQjtBQUFDLFFBQUdyYyxNQUFNLENBQUNtb0IsU0FBUCxDQUFpQkMsY0FBakIsQ0FBZ0NDLElBQWhDLENBQXFDaE0sR0FBckMsRUFBeUMxUCxHQUF6QyxDQUFILEVBQWlEO0FBQUMsVUFBSTJiLElBQUksR0FBQ0wscUJBQXFCLEdBQUNqb0IsTUFBTSxDQUFDa29CLHdCQUFQLENBQWdDN0wsR0FBaEMsRUFBb0MxUCxHQUFwQyxDQUFELEdBQTBDLElBQXhFOztBQUE2RSxVQUFHMmIsSUFBSSxLQUFHQSxJQUFJLENBQUM5dEIsR0FBTCxJQUFVOHRCLElBQUksQ0FBQy9VLEdBQWxCLENBQVAsRUFBOEI7QUFBQ3ZULGNBQU0sQ0FBQzBVLGNBQVAsQ0FBc0JzVCxNQUF0QixFQUE2QnJiLEdBQTdCLEVBQWlDMmIsSUFBakM7QUFBd0MsT0FBdkUsTUFBMkU7QUFBQ04sY0FBTSxDQUFDcmIsR0FBRCxDQUFOLEdBQVkwUCxHQUFHLENBQUMxUCxHQUFELENBQWY7QUFBc0I7QUFBQztBQUFDOztBQUFBcWIsUUFBTSxDQUFDcGlCLE9BQVAsR0FBZXlXLEdBQWY7O0FBQW1CLE1BQUcwTCxLQUFILEVBQVM7QUFBQ0EsU0FBSyxDQUFDeFUsR0FBTixDQUFVOEksR0FBVixFQUFjMkwsTUFBZDtBQUF1Qjs7QUFBQSxTQUFPQSxNQUFQO0FBQWUsQyxDQUFBO0FBQ3g3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxNQUFNTyxnQkFBZ0IsR0FBQyx3QkFBdkI7O0FBQWdELFNBQVNaLFNBQVQsQ0FBbUJhLE1BQW5CLEVBQTBCO0FBQUMsTUFBRztBQUFDQyxRQUFEO0FBQU1uYjtBQUFOLE1BQWdCa2IsTUFBbkI7QUFBMEIsTUFBSUUsUUFBUSxHQUFDRixNQUFNLENBQUNFLFFBQVAsSUFBaUIsRUFBOUI7QUFBaUMsTUFBSWpPLFFBQVEsR0FBQytOLE1BQU0sQ0FBQy9OLFFBQVAsSUFBaUIsRUFBOUI7QUFBaUMsTUFBSW9FLElBQUksR0FBQzJKLE1BQU0sQ0FBQzNKLElBQVAsSUFBYSxFQUF0QjtBQUF5QixNQUFJM2UsS0FBSyxHQUFDc29CLE1BQU0sQ0FBQ3RvQixLQUFQLElBQWMsRUFBeEI7QUFBMkIsTUFBSXlvQixJQUFJLEdBQUMsS0FBVDtBQUFlRixNQUFJLEdBQUNBLElBQUksR0FBQ2xiLGtCQUFrQixDQUFDa2IsSUFBRCxDQUFsQixDQUF5QnJtQixPQUF6QixDQUFpQyxNQUFqQyxFQUF3QyxHQUF4QyxJQUE2QyxHQUE5QyxHQUFrRCxFQUEzRDs7QUFBOEQsTUFBR29tQixNQUFNLENBQUNHLElBQVYsRUFBZTtBQUFDQSxRQUFJLEdBQUNGLElBQUksR0FBQ0QsTUFBTSxDQUFDRyxJQUFqQjtBQUF1QixHQUF2QyxNQUE0QyxJQUFHcmIsUUFBSCxFQUFZO0FBQUNxYixRQUFJLEdBQUNGLElBQUksSUFBRSxDQUFDbmIsUUFBUSxDQUFDNVUsT0FBVCxDQUFpQixHQUFqQixDQUFELEdBQXdCLElBQUc0VSxRQUFTLEdBQXBDLEdBQXVDQSxRQUF6QyxDQUFUOztBQUE0RCxRQUFHa2IsTUFBTSxDQUFDSSxJQUFWLEVBQWU7QUFBQ0QsVUFBSSxJQUFFLE1BQUlILE1BQU0sQ0FBQ0ksSUFBakI7QUFBdUI7QUFBQzs7QUFBQSxNQUFHMW9CLEtBQUssSUFBRSxPQUFPQSxLQUFQLEtBQWUsUUFBekIsRUFBa0M7QUFBQ0EsU0FBSyxHQUFDcUssTUFBTSxDQUFDcWQsV0FBVyxDQUFDaUIsc0JBQVosQ0FBbUMzb0IsS0FBbkMsQ0FBRCxDQUFaO0FBQXlEOztBQUFBLE1BQUl3aUIsTUFBTSxHQUFDOEYsTUFBTSxDQUFDOUYsTUFBUCxJQUFleGlCLEtBQUssSUFBRyxJQUFHQSxLQUFNLEVBQWhDLElBQW1DLEVBQTlDO0FBQWlELE1BQUd3b0IsUUFBUSxJQUFFQSxRQUFRLENBQUNJLE1BQVQsQ0FBZ0IsQ0FBQyxDQUFqQixNQUFzQixHQUFuQyxFQUF1Q0osUUFBUSxJQUFFLEdBQVY7O0FBQWMsTUFBR0YsTUFBTSxDQUFDTyxPQUFQLElBQWdCLENBQUMsQ0FBQ0wsUUFBRCxJQUFXSCxnQkFBZ0IsQ0FBQ3BuQixJQUFqQixDQUFzQnVuQixRQUF0QixDQUFaLEtBQThDQyxJQUFJLEtBQUcsS0FBeEUsRUFBOEU7QUFBQ0EsUUFBSSxHQUFDLFFBQU1BLElBQUksSUFBRSxFQUFaLENBQUw7QUFBcUIsUUFBR2xPLFFBQVEsSUFBRUEsUUFBUSxDQUFDLENBQUQsQ0FBUixLQUFjLEdBQTNCLEVBQStCQSxRQUFRLEdBQUMsTUFBSUEsUUFBYjtBQUF1QixHQUExSixNQUErSixJQUFHLENBQUNrTyxJQUFKLEVBQVM7QUFBQ0EsUUFBSSxHQUFDLEVBQUw7QUFBUzs7QUFBQSxNQUFHOUosSUFBSSxJQUFFQSxJQUFJLENBQUMsQ0FBRCxDQUFKLEtBQVUsR0FBbkIsRUFBdUJBLElBQUksR0FBQyxNQUFJQSxJQUFUO0FBQWMsTUFBRzZELE1BQU0sSUFBRUEsTUFBTSxDQUFDLENBQUQsQ0FBTixLQUFZLEdBQXZCLEVBQTJCQSxNQUFNLEdBQUMsTUFBSUEsTUFBWDtBQUFrQmpJLFVBQVEsR0FBQ0EsUUFBUSxDQUFDclksT0FBVCxDQUFpQixPQUFqQixFQUF5Qm1MLGtCQUF6QixDQUFUO0FBQXNEbVYsUUFBTSxHQUFDQSxNQUFNLENBQUN0Z0IsT0FBUCxDQUFlLEdBQWYsRUFBbUIsS0FBbkIsQ0FBUDtBQUFpQyxTQUFPLEdBQUVzbUIsUUFBUyxHQUFFQyxJQUFLLEdBQUVsTyxRQUFTLEdBQUVpSSxNQUFPLEdBQUU3RCxJQUFLLEVBQXBEO0FBQXVELEM7Ozs7Ozs7Ozs7O0FDckI1Z0M7O0FBQUF0YSxrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsc0JBQUEsR0FBdUJtYSxjQUF2QixDLENBQXNDOztBQUMzRSxNQUFNc0ssVUFBVSxHQUFDLHNCQUFqQjs7QUFBd0MsU0FBU3RLLGNBQVQsQ0FBd0JwSixLQUF4QixFQUE4QjtBQUFDLFNBQU8wVCxVQUFVLENBQUM3bkIsSUFBWCxDQUFnQm1VLEtBQWhCLENBQVA7QUFBK0IsQzs7Ozs7Ozs7Ozs7QUNEekY7O0FBQUEvUSxrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsd0JBQUEsR0FBeUJ5ZCxnQkFBekI7O0FBQTBDLElBQUlsRyxNQUFNLEdBQUN4WCxtQkFBTyxDQUFDLHVFQUFELENBQWxCOztBQUFrQyxJQUFJMlgsWUFBWSxHQUFDM1gsbUJBQU8sQ0FBQyw0RkFBRCxDQUF4QjtBQUEwQztBQUMzSjtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFBRyxTQUFTMGQsZ0JBQVQsQ0FBMEJ2b0IsR0FBMUIsRUFBOEI0a0IsSUFBOUIsRUFBbUM7QUFBQyxRQUFNNEssVUFBVSxHQUFDLElBQUk3YixHQUFKLENBQVEsUUFBNEIsVUFBNUIsR0FBdUMsQ0FBL0MsQ0FBakI7QUFBZ0csUUFBTThiLFlBQVksR0FBQzdLLElBQUksR0FBQyxJQUFJalIsR0FBSixDQUFRaVIsSUFBUixFQUFhNEssVUFBYixDQUFELEdBQTBCQSxVQUFqRDtBQUE0RCxRQUFLO0FBQUN4TyxZQUFEO0FBQVVrRSxnQkFBVjtBQUF1QitELFVBQXZCO0FBQThCN0QsUUFBOUI7QUFBbUNqdEIsUUFBbkM7QUFBd0NzckI7QUFBeEMsTUFBZ0QsSUFBSTlQLEdBQUosQ0FBUTNULEdBQVIsRUFBWXl2QixZQUFaLENBQXJEOztBQUErRSxNQUFHaE0sTUFBTSxLQUFHK0wsVUFBVSxDQUFDL0wsTUFBdkIsRUFBOEI7QUFBQyxVQUFNLElBQUkvakIsS0FBSixDQUFXLG9EQUFtRE0sR0FBSSxFQUFsRSxDQUFOO0FBQTRFOztBQUFBLFNBQU07QUFBQ2doQixZQUFEO0FBQVV2YSxTQUFLLEVBQUMsQ0FBQyxHQUFFK2IsWUFBWSxDQUFDMkMsc0JBQWhCLEVBQXdDRCxZQUF4QyxDQUFoQjtBQUFzRStELFVBQXRFO0FBQTZFN0QsUUFBN0U7QUFBa0ZqdEIsUUFBSSxFQUFDQSxJQUFJLENBQUNaLEtBQUwsQ0FBV2k0QixVQUFVLENBQUMvTCxNQUFYLENBQWtCaHNCLE1BQTdCO0FBQXZGLEdBQU47QUFBb0ksQzs7Ozs7Ozs7Ozs7QUNMcGY7O0FBQUFxVCxrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsOEJBQUEsR0FBK0JxYSxzQkFBL0I7QUFBc0RyYSw4QkFBQSxHQUErQnNrQixzQkFBL0I7QUFBc0R0a0IsY0FBQSxHQUFlaUksTUFBZjs7QUFBc0IsU0FBU29TLHNCQUFULENBQWdDRCxZQUFoQyxFQUE2QztBQUFDLFFBQU16ZSxLQUFLLEdBQUMsRUFBWjtBQUFleWUsY0FBWSxDQUFDblAsT0FBYixDQUFxQixDQUFDZ0UsS0FBRCxFQUFPN0csR0FBUCxLQUFhO0FBQUMsUUFBRyxPQUFPek0sS0FBSyxDQUFDeU0sR0FBRCxDQUFaLEtBQW9CLFdBQXZCLEVBQW1DO0FBQUN6TSxXQUFLLENBQUN5TSxHQUFELENBQUwsR0FBVzZHLEtBQVg7QUFBa0IsS0FBdEQsTUFBMkQsSUFBR29GLEtBQUssQ0FBQ0MsT0FBTixDQUFjM1ksS0FBSyxDQUFDeU0sR0FBRCxDQUFuQixDQUFILEVBQTZCO0FBQUM7QUFBQ3pNLFdBQUssQ0FBQ3lNLEdBQUQsQ0FBTCxDQUFXekYsSUFBWCxDQUFnQnNNLEtBQWhCO0FBQXdCLEtBQXZELE1BQTJEO0FBQUN0VCxXQUFLLENBQUN5TSxHQUFELENBQUwsR0FBVyxDQUFDek0sS0FBSyxDQUFDeU0sR0FBRCxDQUFOLEVBQVk2RyxLQUFaLENBQVg7QUFBK0I7QUFBQyxHQUExTDtBQUE0TCxTQUFPdFQsS0FBUDtBQUFjOztBQUFBLFNBQVNpcEIsc0JBQVQsQ0FBZ0N2TCxLQUFoQyxFQUFzQztBQUFDLE1BQUcsT0FBT0EsS0FBUCxLQUFlLFFBQWYsSUFBeUIsT0FBT0EsS0FBUCxLQUFlLFFBQWYsSUFBeUIsQ0FBQzNSLEtBQUssQ0FBQzJSLEtBQUQsQ0FBeEQsSUFBaUUsT0FBT0EsS0FBUCxLQUFlLFNBQW5GLEVBQTZGO0FBQUMsV0FBT3JULE1BQU0sQ0FBQ3FULEtBQUQsQ0FBYjtBQUFzQixHQUFwSCxNQUF3SDtBQUFDLFdBQU0sRUFBTjtBQUFVO0FBQUM7O0FBQUEsU0FBU2lMLHNCQUFULENBQWdDTyxRQUFoQyxFQUF5QztBQUFDLFFBQU1uTCxNQUFNLEdBQUMsSUFBSXRqQixlQUFKLEVBQWI7QUFBbUNxRixRQUFNLENBQUMrWixPQUFQLENBQWVxUCxRQUFmLEVBQXlCNVosT0FBekIsQ0FBaUMsQ0FBQyxDQUFDN0MsR0FBRCxFQUFLNkcsS0FBTCxDQUFELEtBQWU7QUFBQyxRQUFHb0YsS0FBSyxDQUFDQyxPQUFOLENBQWNyRixLQUFkLENBQUgsRUFBd0I7QUFBQ0EsV0FBSyxDQUFDaEUsT0FBTixDQUFjNlosSUFBSSxJQUFFcEwsTUFBTSxDQUFDcUwsTUFBUCxDQUFjM2MsR0FBZCxFQUFrQndjLHNCQUFzQixDQUFDRSxJQUFELENBQXhDLENBQXBCO0FBQXNFLEtBQS9GLE1BQW1HO0FBQUNwTCxZQUFNLENBQUMxSyxHQUFQLENBQVc1RyxHQUFYLEVBQWV3YyxzQkFBc0IsQ0FBQzNWLEtBQUQsQ0FBckM7QUFBK0M7QUFBQyxHQUFyTTtBQUF1TSxTQUFPeUssTUFBUDtBQUFlOztBQUFBLFNBQVN6UixNQUFULENBQWdCMkIsTUFBaEIsRUFBdUIsR0FBR29iLGdCQUExQixFQUEyQztBQUFDQSxrQkFBZ0IsQ0FBQy9aLE9BQWpCLENBQXlCbVAsWUFBWSxJQUFFO0FBQUMvRixTQUFLLENBQUM0USxJQUFOLENBQVc3SyxZQUFZLENBQUMxZSxJQUFiLEVBQVgsRUFBZ0N1UCxPQUFoQyxDQUF3QzdDLEdBQUcsSUFBRXdCLE1BQU0sQ0FBQ3dMLE1BQVAsQ0FBY2hOLEdBQWQsQ0FBN0M7QUFBaUVnUyxnQkFBWSxDQUFDblAsT0FBYixDQUFxQixDQUFDZ0UsS0FBRCxFQUFPN0csR0FBUCxLQUFhd0IsTUFBTSxDQUFDbWIsTUFBUCxDQUFjM2MsR0FBZCxFQUFrQjZHLEtBQWxCLENBQWxDO0FBQTZELEdBQXRLO0FBQXdLLFNBQU9yRixNQUFQO0FBQWUsQzs7Ozs7Ozs7Ozs7QUNBbGxDOztBQUFBNUosa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLHVCQUFBLEdBQXdCbVosZUFBeEI7O0FBQXdDLFNBQVNBLGVBQVQsQ0FBeUJ1RyxVQUF6QixFQUFvQztBQUFDLFFBQUs7QUFBQ3pFLE1BQUQ7QUFBSWhDO0FBQUosTUFBWXlHLFVBQWpCO0FBQTRCLFNBQU94SixRQUFRLElBQUU7QUFBQyxVQUFNeUosVUFBVSxHQUFDMUUsRUFBRSxDQUFDdlksSUFBSCxDQUFRd1QsUUFBUixDQUFqQjs7QUFBbUMsUUFBRyxDQUFDeUosVUFBSixFQUFlO0FBQUMsYUFBTyxLQUFQO0FBQWM7O0FBQUEsVUFBTWxiLE1BQU0sR0FBQzRVLEtBQUssSUFBRTtBQUFDLFVBQUc7QUFBQyxlQUFPNkwsa0JBQWtCLENBQUM3TCxLQUFELENBQXpCO0FBQWtDLE9BQXRDLENBQXNDLE9BQU1uTyxDQUFOLEVBQVE7QUFBQyxjQUFNcEMsR0FBRyxHQUFDLElBQUlsVSxLQUFKLENBQVUsd0JBQVYsQ0FBVjtBQUE4Q2tVLFdBQUcsQ0FBQ3RPLElBQUosR0FBUyxlQUFUO0FBQXlCLGNBQU1zTyxHQUFOO0FBQVc7QUFBQyxLQUF2Sjs7QUFBd0osVUFBTTVTLE1BQU0sR0FBQyxFQUFiO0FBQWdCdUYsVUFBTSxDQUFDQyxJQUFQLENBQVl1ZCxNQUFaLEVBQW9CaE8sT0FBcEIsQ0FBNEJrYSxRQUFRLElBQUU7QUFBQyxZQUFNQyxDQUFDLEdBQUNuTSxNQUFNLENBQUNrTSxRQUFELENBQWQ7QUFBeUIsWUFBTUUsQ0FBQyxHQUFDMUYsVUFBVSxDQUFDeUYsQ0FBQyxDQUFDRSxHQUFILENBQWxCOztBQUEwQixVQUFHRCxDQUFDLEtBQUc1M0IsU0FBUCxFQUFpQjtBQUFDeUksY0FBTSxDQUFDaXZCLFFBQUQsQ0FBTixHQUFpQixDQUFDRSxDQUFDLENBQUNseEIsT0FBRixDQUFVLEdBQVYsQ0FBRCxHQUFnQmt4QixDQUFDLENBQUNqbkIsS0FBRixDQUFRLEdBQVIsRUFBYS9SLEdBQWIsQ0FBaUJ1aUIsS0FBSyxJQUFFbkssTUFBTSxDQUFDbUssS0FBRCxDQUE5QixDQUFoQixHQUF1RHdXLENBQUMsQ0FBQzlMLE1BQUYsR0FBUyxDQUFDN1UsTUFBTSxDQUFDNGdCLENBQUQsQ0FBUCxDQUFULEdBQXFCNWdCLE1BQU0sQ0FBQzRnQixDQUFELENBQW5HO0FBQXdHO0FBQUMsS0FBck47QUFBdU4sV0FBT252QixNQUFQO0FBQWUsR0FBamU7QUFBbWUsQzs7Ozs7Ozs7Ozs7QUNBcG1COztBQUFBOEosa0JBQUEsR0FBbUIsSUFBbkI7QUFBd0JBLHFCQUFBLEdBQXNCK1ksYUFBdEIsQyxDQUFvQztBQUN6RTs7QUFDQSxTQUFTd00sV0FBVCxDQUFxQkMsR0FBckIsRUFBeUI7QUFBQyxTQUFPQSxHQUFHLENBQUMzbkIsT0FBSixDQUFZLHNCQUFaLEVBQW1DLE1BQW5DLENBQVA7QUFBbUQ7O0FBQUEsU0FBUzRuQixjQUFULENBQXdCcE0sS0FBeEIsRUFBOEI7QUFBQyxRQUFNRSxRQUFRLEdBQUNGLEtBQUssQ0FBQzdVLFVBQU4sQ0FBaUIsR0FBakIsS0FBdUI2VSxLQUFLLENBQUM5TCxRQUFOLENBQWUsR0FBZixDQUF0Qzs7QUFBMEQsTUFBR2dNLFFBQUgsRUFBWTtBQUFDRixTQUFLLEdBQUNBLEtBQUssQ0FBQzVzQixLQUFOLENBQVksQ0FBWixFQUFjLENBQUMsQ0FBZixDQUFOO0FBQXlCOztBQUFBLFFBQU02c0IsTUFBTSxHQUFDRCxLQUFLLENBQUM3VSxVQUFOLENBQWlCLEtBQWpCLENBQWI7O0FBQXFDLE1BQUc4VSxNQUFILEVBQVU7QUFBQ0QsU0FBSyxHQUFDQSxLQUFLLENBQUM1c0IsS0FBTixDQUFZLENBQVosQ0FBTjtBQUFzQjs7QUFBQSxTQUFNO0FBQUMyYixPQUFHLEVBQUNpUixLQUFMO0FBQVdDLFVBQVg7QUFBa0JDO0FBQWxCLEdBQU47QUFBbUM7O0FBQUEsU0FBU1IsYUFBVCxDQUF1QjJNLGVBQXZCLEVBQXVDO0FBQUMsUUFBTUMsUUFBUSxHQUFDLENBQUNELGVBQWUsQ0FBQzduQixPQUFoQixDQUF3QixLQUF4QixFQUE4QixFQUE5QixLQUFtQyxHQUFwQyxFQUF5Q3BSLEtBQXpDLENBQStDLENBQS9DLEVBQWtEMlIsS0FBbEQsQ0FBd0QsR0FBeEQsQ0FBZjtBQUE0RSxRQUFNNmEsTUFBTSxHQUFDLEVBQWI7QUFBZ0IsTUFBSTJNLFVBQVUsR0FBQyxDQUFmO0FBQWlCLFFBQU1DLGtCQUFrQixHQUFDRixRQUFRLENBQUN0NUIsR0FBVCxDQUFhb3RCLE9BQU8sSUFBRTtBQUFDLFFBQUdBLE9BQU8sQ0FBQ2pWLFVBQVIsQ0FBbUIsR0FBbkIsS0FBeUJpVixPQUFPLENBQUNsTSxRQUFSLENBQWlCLEdBQWpCLENBQTVCLEVBQWtEO0FBQUMsWUFBSztBQUFDbkYsV0FBRDtBQUFLbVIsZ0JBQUw7QUFBY0Q7QUFBZCxVQUFzQm1NLGNBQWMsQ0FBQ2hNLE9BQU8sQ0FBQ2h0QixLQUFSLENBQWMsQ0FBZCxFQUFnQixDQUFDLENBQWpCLENBQUQsQ0FBekM7QUFBK0R3c0IsWUFBTSxDQUFDN1EsR0FBRCxDQUFOLEdBQVk7QUFBQ2tkLFdBQUcsRUFBQ00sVUFBVSxFQUFmO0FBQWtCdE0sY0FBbEI7QUFBeUJDO0FBQXpCLE9BQVo7QUFBK0MsYUFBT0QsTUFBTSxHQUFDQyxRQUFRLEdBQUMsYUFBRCxHQUFlLFFBQXhCLEdBQWlDLFdBQTlDO0FBQTJELEtBQTVOLE1BQWdPO0FBQUMsYUFBTyxJQUFHZ00sV0FBVyxDQUFDOUwsT0FBRCxDQUFVLEVBQS9CO0FBQWtDO0FBQUMsR0FBM1IsRUFBNlIvc0IsSUFBN1IsQ0FBa1MsRUFBbFMsQ0FBekIsQ0FBOUcsQ0FBNmE7QUFDendCOztBQUNBLFlBQStCO0FBQUMsUUFBSW81QixnQkFBZ0IsR0FBQyxFQUFyQjtBQUF3QixRQUFJQyxrQkFBa0IsR0FBQyxDQUF2QixDQUF6QixDQUFrRDs7QUFDakYsVUFBTUMsZUFBZSxHQUFDLE1BQUk7QUFBQyxVQUFJQyxRQUFRLEdBQUMsRUFBYjs7QUFBZ0IsV0FBSSxJQUFJcmlCLENBQUMsR0FBQyxDQUFWLEVBQVlBLENBQUMsR0FBQ21pQixrQkFBZCxFQUFpQ25pQixDQUFDLEVBQWxDLEVBQXFDO0FBQUNxaUIsZ0JBQVEsSUFBRWpnQixNQUFNLENBQUNrZ0IsWUFBUCxDQUFvQkosZ0JBQXBCLENBQVY7QUFBZ0RBLHdCQUFnQjs7QUFBRyxZQUFHQSxnQkFBZ0IsR0FBQyxHQUFwQixFQUF3QjtBQUFDQyw0QkFBa0I7QUFBR0QsMEJBQWdCLEdBQUMsRUFBakI7QUFBcUI7QUFBQzs7QUFBQSxhQUFPRyxRQUFQO0FBQWlCLEtBQXpPOztBQUEwTyxVQUFNRSxTQUFTLEdBQUMsRUFBaEI7QUFBbUIsUUFBSUMsdUJBQXVCLEdBQUNULFFBQVEsQ0FBQ3Q1QixHQUFULENBQWFvdEIsT0FBTyxJQUFFO0FBQUMsVUFBR0EsT0FBTyxDQUFDalYsVUFBUixDQUFtQixHQUFuQixLQUF5QmlWLE9BQU8sQ0FBQ2xNLFFBQVIsQ0FBaUIsR0FBakIsQ0FBNUIsRUFBa0Q7QUFBQyxjQUFLO0FBQUNuRixhQUFEO0FBQUttUixrQkFBTDtBQUFjRDtBQUFkLFlBQXNCbU0sY0FBYyxDQUFDaE0sT0FBTyxDQUFDaHRCLEtBQVIsQ0FBYyxDQUFkLEVBQWdCLENBQUMsQ0FBakIsQ0FBRCxDQUF6QyxDQUFELENBQWdFO0FBQ2xhOztBQUNBLFlBQUk0NUIsVUFBVSxHQUFDamUsR0FBRyxDQUFDdkssT0FBSixDQUFZLEtBQVosRUFBa0IsRUFBbEIsQ0FBZjtBQUFxQyxZQUFJeW9CLFVBQVUsR0FBQyxLQUFmLENBRjZULENBRXhTO0FBQzFEOztBQUNBLFlBQUdELFVBQVUsQ0FBQzE1QixNQUFYLEtBQW9CLENBQXBCLElBQXVCMDVCLFVBQVUsQ0FBQzE1QixNQUFYLEdBQWtCLEVBQTVDLEVBQStDO0FBQUMyNUIsb0JBQVUsR0FBQyxJQUFYO0FBQWlCOztBQUFBLFlBQUcsQ0FBQzVlLEtBQUssQ0FBQzlFLFFBQVEsQ0FBQ3lqQixVQUFVLENBQUM5QixNQUFYLENBQWtCLENBQWxCLEVBQW9CLENBQXBCLENBQUQsQ0FBVCxDQUFULEVBQTRDO0FBQUMrQixvQkFBVSxHQUFDLElBQVg7QUFBaUI7O0FBQUEsWUFBR0EsVUFBSCxFQUFjO0FBQUNELG9CQUFVLEdBQUNMLGVBQWUsRUFBMUI7QUFBOEI7O0FBQUFHLGlCQUFTLENBQUNFLFVBQUQsQ0FBVCxHQUFzQmplLEdBQXRCO0FBQTBCLGVBQU9rUixNQUFNLEdBQUNDLFFBQVEsR0FBRSxVQUFTOE0sVUFBVyxTQUF0QixHQUFnQyxPQUFNQSxVQUFXLE9BQTFELEdBQWtFLE9BQU1BLFVBQVcsVUFBaEc7QUFBMkcsT0FKRCxNQUlLO0FBQUMsZUFBTyxJQUFHZCxXQUFXLENBQUM5TCxPQUFELENBQVUsRUFBL0I7QUFBa0M7QUFBQyxLQUpoRSxFQUlrRS9zQixJQUpsRSxDQUl1RSxFQUp2RSxDQUE1QjtBQUl1RyxXQUFNO0FBQUN1dUIsUUFBRSxFQUFDLElBQUlzTCxNQUFKLENBQVksSUFBR1Ysa0JBQW1CLFNBQWxDLENBQUo7QUFBZ0Q1TSxZQUFoRDtBQUF1RGtOLGVBQXZEO0FBQWlFSyxnQkFBVSxFQUFFLElBQUdKLHVCQUF3QjtBQUF4RyxLQUFOO0FBQXlIOztBQUFBLFNBQU07QUFBQ25MLE1BQUUsRUFBQyxJQUFJc0wsTUFBSixDQUFZLElBQUdWLGtCQUFtQixTQUFsQyxDQUFKO0FBQWdENU07QUFBaEQsR0FBTjtBQUErRCxDOzs7Ozs7Ozs7OztBQ1QvZ0I7O0FBQUFqWixrQkFBQSxHQUFtQixJQUFuQjtBQUF3QkEsZ0JBQUEsR0FBaUJ5bUIsUUFBakI7QUFBMEJ6bUIseUJBQUEsR0FBMEJ5WSxpQkFBMUI7QUFBNEN6WSxjQUFBLEdBQWVxZCxNQUFmO0FBQXNCcmQsc0JBQUEsR0FBdUIwbUIsY0FBdkI7QUFBc0MxbUIsaUJBQUEsR0FBa0IybUIsU0FBbEI7QUFBNEIzbUIsMkJBQUEsR0FBNEJtakIsbUJBQTVCO0FBQWdEbmpCLDRCQUFBLEdBQTZCZ2Esb0JBQTdCO0FBQWtEaGEsVUFBQSxHQUFXQSxVQUFBLEdBQVdBLHFCQUFBLEdBQXNCLEtBQUssQ0FBakQ7O0FBQW1ELElBQUk0bUIsVUFBVSxHQUFDN21CLG1CQUFPLENBQUMsdUdBQUQsQ0FBdEI7QUFBb0Q7QUFDNVk7QUFDQTs7O0FBQUcsU0FBUzBtQixRQUFULENBQWtCeFUsRUFBbEIsRUFBcUI7QUFBQyxNQUFJNFUsSUFBSSxHQUFDLEtBQVQ7QUFBZSxNQUFJbk4sTUFBSjtBQUFXLFNBQU0sQ0FBQyxHQUFHOU8sSUFBSixLQUFXO0FBQUMsUUFBRyxDQUFDaWMsSUFBSixFQUFTO0FBQUNBLFVBQUksR0FBQyxJQUFMO0FBQVVuTixZQUFNLEdBQUN6SCxFQUFFLENBQUMsR0FBR3JILElBQUosQ0FBVDtBQUFvQjs7QUFBQSxXQUFPOE8sTUFBUDtBQUFlLEdBQXpFO0FBQTJFOztBQUFBLFNBQVNqQixpQkFBVCxHQUE0QjtBQUFDLFFBQUs7QUFBQzBMLFlBQUQ7QUFBVXBiLFlBQVY7QUFBbUJzYjtBQUFuQixNQUF5Qi8xQixNQUFNLENBQUM0RixRQUFyQztBQUE4QyxTQUFPLEdBQUVpd0IsUUFBUyxLQUFJcGIsUUFBUyxHQUFFc2IsSUFBSSxHQUFDLE1BQUlBLElBQUwsR0FBVSxFQUFHLEVBQWxEO0FBQXFEOztBQUFBLFNBQVNoSCxNQUFULEdBQWlCO0FBQUMsUUFBSztBQUFDaHdCO0FBQUQsTUFBT2lCLE1BQU0sQ0FBQzRGLFFBQW5CO0FBQTRCLFFBQU15a0IsTUFBTSxHQUFDRixpQkFBaUIsRUFBOUI7QUFBaUMsU0FBT3ByQixJQUFJLENBQUN5bUIsU0FBTCxDQUFlNkUsTUFBTSxDQUFDaHNCLE1BQXRCLENBQVA7QUFBc0M7O0FBQUEsU0FBUys1QixjQUFULENBQXdCdkssU0FBeEIsRUFBa0M7QUFBQyxTQUFPLE9BQU9BLFNBQVAsS0FBbUIsUUFBbkIsR0FBNEJBLFNBQTVCLEdBQXNDQSxTQUFTLENBQUNuRyxXQUFWLElBQXVCbUcsU0FBUyxDQUFDNXZCLElBQWpDLElBQXVDLFNBQXBGO0FBQStGOztBQUFBLFNBQVNvNkIsU0FBVCxDQUFtQm5uQixHQUFuQixFQUF1QjtBQUFDLFNBQU9BLEdBQUcsQ0FBQ3NuQixRQUFKLElBQWN0bkIsR0FBRyxDQUFDdW5CLFdBQXpCO0FBQXNDOztBQUFBLGVBQWU1RCxtQkFBZixDQUFtQ2xILEdBQW5DLEVBQXVDZ0gsR0FBdkMsRUFBMkM7QUFBQyxZQUF1QztBQUFDLFFBQUkrRCxjQUFKOztBQUFtQixRQUFHLENBQUNBLGNBQWMsR0FBQy9LLEdBQUcsQ0FBQzJILFNBQXBCLEtBQWdDLElBQWhDLElBQXNDb0QsY0FBYyxDQUFDbFIsZUFBeEQsRUFBd0U7QUFBQyxZQUFNaGhCLE9BQU8sR0FBRSxJQUFHNHhCLGNBQWMsQ0FBQ3pLLEdBQUQsQ0FBTSw2SkFBdEM7QUFBbU0sWUFBTSxJQUFJcm5CLEtBQUosQ0FBVUUsT0FBVixDQUFOO0FBQTBCO0FBQUMsR0FBblcsQ0FBbVc7OztBQUNqOEIsUUFBTTBLLEdBQUcsR0FBQ3lqQixHQUFHLENBQUN6akIsR0FBSixJQUFTeWpCLEdBQUcsQ0FBQ0EsR0FBSixJQUFTQSxHQUFHLENBQUNBLEdBQUosQ0FBUXpqQixHQUFwQzs7QUFBd0MsTUFBRyxDQUFDeWMsR0FBRyxDQUFDbkcsZUFBUixFQUF3QjtBQUFDLFFBQUdtTixHQUFHLENBQUNBLEdBQUosSUFBU0EsR0FBRyxDQUFDOUcsU0FBaEIsRUFBMEI7QUFBQztBQUM1RixhQUFNO0FBQUNnRSxpQkFBUyxFQUFDLE1BQU1nRCxtQkFBbUIsQ0FBQ0YsR0FBRyxDQUFDOUcsU0FBTCxFQUFlOEcsR0FBRyxDQUFDQSxHQUFuQjtBQUFwQyxPQUFOO0FBQW9FOztBQUFBLFdBQU0sRUFBTjtBQUFVOztBQUFBLFFBQU12NEIsS0FBSyxHQUFDLE1BQU11eEIsR0FBRyxDQUFDbkcsZUFBSixDQUFvQm1OLEdBQXBCLENBQWxCOztBQUEyQyxNQUFHempCLEdBQUcsSUFBRW1uQixTQUFTLENBQUNubkIsR0FBRCxDQUFqQixFQUF1QjtBQUFDLFdBQU85VSxLQUFQO0FBQWM7O0FBQUEsTUFBRyxDQUFDQSxLQUFKLEVBQVU7QUFBQyxVQUFNb0ssT0FBTyxHQUFFLElBQUc0eEIsY0FBYyxDQUFDekssR0FBRCxDQUFNLCtEQUE4RHZ4QixLQUFNLFlBQTFHO0FBQXNILFVBQU0sSUFBSWtLLEtBQUosQ0FBVUUsT0FBVixDQUFOO0FBQTBCOztBQUFBLFlBQXVDO0FBQUMsUUFBRzJHLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZaFIsS0FBWixFQUFtQmlDLE1BQW5CLEtBQTRCLENBQTVCLElBQStCLENBQUNzMkIsR0FBRyxDQUFDQSxHQUF2QyxFQUEyQztBQUFDcDBCLGFBQU8sQ0FBQ29YLElBQVIsQ0FBYyxHQUFFeWdCLGNBQWMsQ0FBQ3pLLEdBQUQsQ0FBTSxpTEFBcEM7QUFBdU47QUFBQzs7QUFBQSxTQUFPdnhCLEtBQVA7QUFBYzs7QUFBQSxNQUFNdThCLGFBQWEsR0FBQyxDQUFDLE1BQUQsRUFBUSxNQUFSLEVBQWUsTUFBZixFQUFzQixVQUF0QixFQUFpQyxNQUFqQyxFQUF3QyxNQUF4QyxFQUErQyxVQUEvQyxFQUEwRCxNQUExRCxFQUFpRSxVQUFqRSxFQUE0RSxPQUE1RSxFQUFvRixRQUFwRixFQUE2RixTQUE3RixDQUFwQjtBQUE0SGpuQixxQkFBQSxHQUFzQmluQixhQUF0Qjs7QUFBb0MsU0FBU2pOLG9CQUFULENBQThCOWtCLEdBQTlCLEVBQWtDO0FBQUMsWUFBd0M7QUFBQyxRQUFHQSxHQUFHLEtBQUcsSUFBTixJQUFZLE9BQU9BLEdBQVAsS0FBYSxRQUE1QixFQUFxQztBQUFDdUcsWUFBTSxDQUFDQyxJQUFQLENBQVl4RyxHQUFaLEVBQWlCK1YsT0FBakIsQ0FBeUI3QyxHQUFHLElBQUU7QUFBQyxZQUFHNmUsYUFBYSxDQUFDOXlCLE9BQWQsQ0FBc0JpVSxHQUF0QixNQUE2QixDQUFDLENBQWpDLEVBQW1DO0FBQUN2WixpQkFBTyxDQUFDb1gsSUFBUixDQUFjLHFEQUFvRG1DLEdBQUksRUFBdEU7QUFBMEU7QUFBQyxPQUE5STtBQUFpSjtBQUFDOztBQUFBLFNBQU0sQ0FBQyxHQUFFd2UsVUFBVSxDQUFDeEQsU0FBZCxFQUF5Qmx1QixHQUF6QixDQUFOO0FBQXFDOztBQUFBLE1BQU1neUIsRUFBRSxHQUFDLE9BQU90SSxXQUFQLEtBQXFCLFdBQTlCO0FBQTBDNWUsVUFBQSxHQUFXa25CLEVBQVg7QUFBYyxNQUFNdkksRUFBRSxHQUFDdUksRUFBRSxJQUFFLE9BQU90SSxXQUFXLENBQUNDLElBQW5CLEtBQTBCLFVBQTlCLElBQTBDLE9BQU9ELFdBQVcsQ0FBQ3VJLE9BQW5CLEtBQTZCLFVBQWhGO0FBQTJGbm5CLFVBQUEsR0FBVzJlLEVBQVgsQzs7Ozs7Ozs7Ozs7QUNKbnNDLGtCQUFrQixNQUFNLHdCQUF3QixrQkFBa0IsMkJBQTJCLHFCQUFxQixnQ0FBZ0MsZ0NBQWdDLG1DQUFtQyw0QkFBNEIsK0JBQStCLG9CQUFvQix5QkFBeUIsVUFBVTtBQUNwVixpRDs7Ozs7Ozs7OztBQ0RBLDRHQUErQzs7Ozs7Ozs7Ozs7QUNBL0MsMEdBQThDOzs7Ozs7Ozs7OztBQ0E5QztBQUNBO0FBQ0EsbUJBQW1CLHNCQUFzQjtBQUN6Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBLDBCOzs7Ozs7Ozs7O0FDbEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsd0M7Ozs7Ozs7Ozs7QUNOQSxjQUFjLG1CQUFPLENBQUMseUdBQStCOztBQUVyRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSx5Qzs7Ozs7Ozs7OztBQ3REQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLGFBQWEsdUJBQXVCO0FBQ3BDO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsK0M7Ozs7Ozs7Ozs7QUNmQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEseUI7Ozs7Ozs7Ozs7O0FDaEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWE7O0FBRWIsSUFBSSxJQUFxQztBQUN6QztBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUEsMkJBQTJCOztBQUUzQjtBQUNBO0FBQ0E7QUFDQSxHQUFHOzs7QUFHSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRDs7QUFFckQ7QUFDQTtBQUNBO0FBQ0EsaURBQWlEOztBQUVqRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNEQUFzRDs7QUFFdEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsdUJBQXVCO0FBQ3ZCLHVCQUF1QjtBQUN2QixlQUFlO0FBQ2Ysa0JBQWtCO0FBQ2xCLGdCQUFnQjtBQUNoQixZQUFZO0FBQ1osWUFBWTtBQUNaLGNBQWM7QUFDZCxnQkFBZ0I7QUFDaEIsa0JBQWtCO0FBQ2xCLGdCQUFnQjtBQUNoQixtQkFBbUI7QUFDbkIsd0JBQXdCO0FBQ3hCLHlCQUF5QjtBQUN6Qix5QkFBeUI7QUFDekIsaUJBQWlCO0FBQ2pCLG9CQUFvQjtBQUNwQixrQkFBa0I7QUFDbEIsY0FBYztBQUNkLGNBQWM7QUFDZCxnQkFBZ0I7QUFDaEIsa0JBQWtCO0FBQ2xCLG9CQUFvQjtBQUNwQixrQkFBa0I7QUFDbEIsMEJBQTBCO0FBQzFCLGNBQWM7QUFDZCxHQUFHO0FBQ0g7Ozs7Ozs7Ozs7OztBQ2pPYTs7QUFFYixJQUFJLEtBQXFDLEVBQUUsRUFFMUM7QUFDRCxFQUFFLG1KQUF5RDtBQUMzRDs7Ozs7Ozs7Ozs7O0FDTkEsa0U7Ozs7Ozs7Ozs7O0FDQUEsK0M7Ozs7Ozs7Ozs7O0FDQUEsd0M7Ozs7Ozs7Ozs7O0FDQUEsd0M7Ozs7Ozs7Ozs7O0FDQUEsdUM7Ozs7Ozs7Ozs7O0FDQUEsK0Q7Ozs7Ozs7Ozs7O0FDQUEseUU7Ozs7Ozs7Ozs7O0FDQUEsaUc7Ozs7Ozs7Ozs7O0FDQUEscUU7Ozs7Ozs7Ozs7O0FDQUEsMEU7Ozs7Ozs7Ozs7O0FDQUEsdUM7Ozs7Ozs7Ozs7O0FDQUEseUM7Ozs7Ozs7Ozs7O0FDQUEsbUM7Ozs7Ozs7Ozs7O0FDQUEsbUQ7Ozs7Ozs7Ozs7QUNBQSxlIiwiZmlsZSI6InBhZ2VzL2luZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBTdHlsZWQgPGJ1dHRvbj4gY29tcG9uZW50IGZvciB0aGUgcGF0aWVudCBmYWNpbmcgcHJvZHVjdFxuICovXG5pbXBvcnQgUmVhY3QsIHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgY3ggZnJvbSBcImNsYXNzbmFtZXNcIjtcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgLy8gVXNlZCB0byBzdHlsZSB0aGUgYnV0dG9uIGRpZmZlcmVudGx5IGJhc2VkIG9uIHdoZXJlIGluIHRoZSBhcHAgaXQgaXNcbiAgYnV0dG9uVHlwZT86IFwiY3RhXCIgfCBcInByaW1hcnlcIiB8IFwic2Vjb25kYXJ5XCIgfCBcImhlYWRlclwiO1xuICAvLyBVc2UgYW4gPGE+IHRhZyBpbnN0ZWFkIG9mIGEgYnV0dG9uXG4gIGFzTGluaz86IGJvb2xlYW47XG4gIC8vIFdoZXRoZXIgdGhlIGJ1dHRvbiBpcyBkaXNhYmxlZFxuICBkaXNhYmxlZD86IGJvb2xlYW47XG4gIC8vIFdoZXRoZXIgdGhlIGJ1dHRvbiBpcyBvdXRsaW5lZCBvciBmaWxsZWQgaW5cbiAgb3V0bGluZT86IGJvb2xlYW47XG4gIC8vIFdpbGwgc2hvdyBhIGxvYWRpbmcgY2lyY2xlIGlmIHRydWVcbiAgcHJvY2Vzc2luZz86IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnV0dG9uQXNCdXR0b25Qcm9wc1xuICBleHRlbmRzIFByb3BzLFxuICBSZWFjdC5CdXR0b25IVE1MQXR0cmlidXRlczxIVE1MQnV0dG9uRWxlbWVudD4ge1xuICAvKipcbiAgICogVGhlIGVsZW1lbnQgdGhhdCBzaG91bGQgYmUgcmVuZGVyZWQgYXMgYSBidXR0b25cbiAgICovXG4gIHRhZz86IFwiYnV0dG9uXCI7XG4gIC8qKlxuICAgKiBUaGUgbmF0aXZlIEhUTUwgYnV0dG9uIHR5cGVcbiAgICovXG4gIHR5cGU/OiBcImJ1dHRvblwiIHwgXCJzdWJtaXRcIiB8IFwicmVzZXRcIjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBCdXR0b25Bc0FuY2hvclByb3BzXG4gIGV4dGVuZHMgUHJvcHMsXG4gIFJlYWN0LkFuY2hvckhUTUxBdHRyaWJ1dGVzPEhUTUxBbmNob3JFbGVtZW50PiB7XG4gIHRhZzogXCJhXCI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnV0dG9uQXNPdGhlclByb3BzXG4gIGV4dGVuZHMgUHJvcHMsXG4gIFJlYWN0LkFuY2hvckhUTUxBdHRyaWJ1dGVzPEhUTUxBbmNob3JFbGVtZW50PiB7XG4gIHRhZzogc3RyaW5nO1xufVxuXG5leHBvcnQgdHlwZSBCdXR0b25Qcm9wcyA9XG4gIHwgQnV0dG9uQXNCdXR0b25Qcm9wc1xuICB8IEJ1dHRvbkFzQW5jaG9yUHJvcHNcbiAgfCBCdXR0b25Bc090aGVyUHJvcHM7XG5cbnR5cGUgUmVmID0gUmVhY3ROb2RlIHwgSFRNTEVsZW1lbnQgfCBzdHJpbmc7XG5jb25zdCBCdXR0b24gPSBSZWFjdC5mb3J3YXJkUmVmPFJlZiwgQnV0dG9uUHJvcHM+KChwcm9wcywgcmVmKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBhc0xpbmssXG4gICAgY2hpbGRyZW4sXG4gICAgYnV0dG9uVHlwZSxcbiAgICBjbGFzc05hbWUsXG4gICAgZGlzYWJsZWQsXG4gICAgaGlkZGVuLFxuICAgIG91dGxpbmUsXG4gICAgcHJvY2Vzc2luZyxcbiAgICAuLi5vdGhlclByb3BzXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgYnV0dG9uQ2xhc3MgPSBjeChcbiAgICBcIml0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTNcIixcbiAgICBcInJvdW5kZWQgb3V0bGluZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZVwiLFxuICAgIHtcbiAgICAgIGZsZXg6ICFoaWRkZW4sXG4gICAgICBoaWRkZW46IGhpZGRlbixcbiAgICAgIGRpc2FibGVkOiBkaXNhYmxlZCxcbiAgICAgIC8vIFwiYmctcmVkLTQwMFwiOiAhYnV0dG9uVHlwZSxcbiAgICB9LFxuICAgICFvdXRsaW5lXG4gICAgICA/IHtcbiAgICAgICAgXCJ0ZXh0LXdoaXRlIHNoYWRvdyBiZy1kYXJrR3JheSBob3ZlcjpiZy1kYXJrR3JheS04MDAgYWN0aXZlOmJnLWRhcmtHcmF5LTgwMFwiOlxuICAgICAgICAgICFkaXNhYmxlZCAmJiBidXR0b25UeXBlID09PSBcImN0YVwiLFxuICAgICAgICBcInRleHQtd2hpdGUgc2hhZG93IGJnLWNvcmFsIGhvdmVyOmJnLWNvcmFsLTUwMCBhY3RpdmU6YmctY29yYWwtNTAwXCI6XG4gICAgICAgICAgKCFkaXNhYmxlZCAmJiBidXR0b25UeXBlID09PSBcInByaW1hcnlcIikgfHwgIWJ1dHRvblR5cGUsXG4gICAgICAgIFwidGV4dC1kYXJrR3JheSBiZy10cmFuc3BhcmVudCB0ZXh0LWRhcmtHcmF5IGJvcmRlciBib3JkZXItc29saWQgYm9yZGVyLWRhcmtHcmF5IGhvdmVyOmJnLWRhcmtHcmF5IGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC1mdWxsXCI6XG4gICAgICAgICAgYnV0dG9uVHlwZSA9PT0gXCJoZWFkZXJcIixcbiAgICAgICAgXCJiZy1ncmF5LTMwMCBob3ZlcjpiZy1ncmF5LTMwMFwiOiBkaXNhYmxlZCxcbiAgICAgIH1cbiAgICAgIDoge1xuICAgICAgICBcImJvcmRlciBib3JkZXItY29yYWwgdGV4dC1jb3JhbCBob3ZlcjpiZy1jb3JhbCBob3Zlcjp0ZXh0LXdoaXRlXCI6XG4gICAgICAgICAgdHJ1ZSxcbiAgICAgIH0sXG5cbiAgICBjbGFzc05hbWVcbiAgKTtcbiAgaWYgKGFzTGluaykge1xuICAgIHJldHVybiAoXG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICA8YSBjbGFzc05hbWU9e2J1dHRvbkNsYXNzfSB7Li4ub3RoZXJQcm9wc30+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvYT5cbiAgICApO1xuICB9XG4gIHJldHVybiAoXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIDxidXR0b24gY2xhc3NOYW1lPXtidXR0b25DbGFzc30gZGlzYWJsZWQ9e2Rpc2FibGVkfSB7Li4ub3RoZXJQcm9wc30+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgICB7cHJvY2Vzc2luZyA/IChcbiAgICAgICAgPHN2Z1xuICAgICAgICAgIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiBtbC0yIGgtNSB3LTUgdGV4dC13aGl0ZVwiXG4gICAgICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgICAgICA+XG4gICAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwib3BhY2l0eS0yNVwiXG4gICAgICAgICAgICBjeD1cIjEyXCJcbiAgICAgICAgICAgIGN5PVwiMTJcIlxuICAgICAgICAgICAgcj1cIjEwXCJcbiAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICBzdHJva2VXaWR0aD1cIjRcIlxuICAgICAgICAgID48L2NpcmNsZT5cbiAgICAgICAgICA8cGF0aFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwib3BhY2l0eS03NVwiXG4gICAgICAgICAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgIGQ9XCJNNCAxMmE4IDggMCAwMTgtOFYwQzUuMzczIDAgMCA1LjM3MyAwIDEyaDR6bTIgNS4yOTFBNy45NjIgNy45NjIgMCAwMTQgMTJIMGMwIDMuMDQyIDEuMTM1IDUuODI0IDMgNy45MzhsMy0yLjY0N3pcIlxuICAgICAgICAgID48L3BhdGg+XG4gICAgICAgIDwvc3ZnPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9idXR0b24+XG4gICk7XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgQnV0dG9uO1xuIiwiLyoqXG4gKiBDYWxsIHRvIGFjdGlvbiBidXR0b24gZm9yIGxhbmRpbmcgcGFnZVxuICovXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBjeCBmcm9tIFwiY2xhc3NuYW1lc1wiO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmNvbnN0IENUQUJ1dHRvbjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2xhc3NOYW1lLCBjaGlsZHJlbiB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPExpbmsgaHJlZj1cIi9vbmJvYXJkaW5nL2ludHJvL3N0YXJ0XCI+XG4gICAgICA8YVxuICAgICAgICBocmVmPVwiI1wiXG4gICAgICAgIGNsYXNzTmFtZT17Y3goXG4gICAgICAgICAgXCJmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWNlbnRlciByb3VuZGVkLWZ1bGwgYmctdGVhbCBob3ZlcjpiZy10ZWFsLTQwMCB1cHBlcmNhc2UgdGV4dC13aGl0ZSB0ZXh0LXNtIGZvbnQtYm9sZCBwLTJcIixcbiAgICAgICAgICBjbGFzc05hbWVcbiAgICAgICAgKX1cbiAgICAgID5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWwtYXV0b1wiPntjaGlsZHJlbn08L3NwYW4+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtYXV0byByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2Vhc2hlbGwgcC0yXCI+XG4gICAgICAgICAgPHN2Z1xuICAgICAgICAgICAgd2lkdGg9XCIyMFwiXG4gICAgICAgICAgICBoZWlnaHQ9XCIyMFwiXG4gICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDIwIDIwXCJcbiAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgIGQ9XCJNOS43ODAwOSAwLjk4MjY2Nkw4LjYwMzIxIDIuMTU5NTVMMTUuOTQ0NyA5LjUyOTA2TDAuNDQ1MzEyIDkuNDQ1VjExLjEyNjNMMTUuOTcyNyAxMS4yMTAzTDguNzcxMzMgMTguMzgzN0w5Ljk0ODIyIDE5LjU4ODZMMTkuMTY3MSAxMC4zNjk3TDkuNzgwMDkgMC45ODI2NjZaXCJcbiAgICAgICAgICAgICAgZmlsbD1cIiMzNzQxNDZcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2E+XG4gICAgPC9MaW5rPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQ1RBQnV0dG9uO1xuIiwiLyoqXG4gKiBTaG93cyBudW1iZXJzIHRvIGNhbGwvZGlhbCBpbiBjYXNlIG9mIGFuIGVtZXJnZW5jeSBmb3IgbGFuZGluZ1xuICovXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgRW1lcmdlbmN5QmFyOiBSZWFjdC5GQzxQcm9wcz4gPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNwYWNlLXktOCBtZDpncmlkLWNvbHMtMiBtZDpzcGFjZS15LTBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleFwiPlxuICAgICAgICA8aW1nIHNyYz1cIi9pbWFnZXMvZGlzdHJlc3Muc3ZnXCIgY2xhc3NOYW1lPVwiXCIgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC00IG1heC13LXhzXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBtYi02XCI+NzQxLTc0MTwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICBJZiB5b3UmYXBvcztyZSBpbiBlbW90aW9uYWwgZGlzdHJlc3MsIHRleHQgSE9NRSB0byBjb25uZWN0IHdpdGggYVxuICAgICAgICAgICAgY291bnNlbG9yIGltbWVkaWF0ZWx5LlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XG4gICAgICAgIDxpbWcgc3JjPVwiL2ltYWdlcy9lbWVyZ2VuY3kuc3ZnXCIgY2xhc3NOYW1lPVwiXCIgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC00IG1heC13LXhzXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBtYi02XCI+OTExPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIElmIHlvdSZhcG9zO3JlIGhhdmluZyBhIG1lZGljYWwgb3IgbWVudGFsIGhlYWx0aCBlbWVyZ2VuY3ksIGNhbGwgOTExXG4gICAgICAgICAgICBvciBnbyB0byB5b3VyIGxvY2FsIEVSLlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgRW1lcmdlbmN5QmFyO1xuIiwiLyoqXG4gKiBDb21wb25lbnQgdXNlZCB0byBkaXNwbGF5IEZBUSBvbiBsYW5kaW5nIHBhZ2UgYW5kIEZBUSBwYWdlLlxuICogRHluYW1pY2FsbHkgcHVsbHMgbGlzdCBvZiBzdGF0ZXMgb3BlcmF0ZWQgaW4gZnJvbSBiYWNrZW5kXG4gKi9cblxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XG5pbXBvcnQgeyBkb2N1bWVudFRvUmVhY3RDb21wb25lbnRzIH0gZnJvbSAnQGNvbnRlbnRmdWwvcmljaC10ZXh0LXJlYWN0LXJlbmRlcmVyJztcbmltcG9ydCBGQVFJdGVtIGZyb20gXCIuL0ZBUUl0ZW1cIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIi4uL2NvcmUvQnV0dG9uXCI7XG5pbXBvcnQgeyBVU1N0YXRlIH0gZnJvbSBcIi4uLy4uLy4uL3NlcnZlci9zcmMvdXRpbHMvc3RhdGVzXCI7XG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGdldFN0YXRlcyB9IGZyb20gXCIuLi8uLi9saWIvYXBpXCI7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIHRpdGxlPzogc3RyaW5nO1xuICBzaG93QnV0dG9uPzogYm9vbGVhbjtcbn1cblxuY29uc3QgRkFROiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBmYXEsIHRpdGxlLCBzaG93QnV0dG9uID0gdHJ1ZSB9KSA9PiB7XG4gIGNvbnN0IFtzdGF0ZXMsIHNldFN0YXRlc10gPSB1c2VTdGF0ZTxBcnJheTxVU1N0YXRlPj4oW10pO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGdldFN0YXRlcygpLnRoZW4oc2V0U3RhdGVzKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IHN0YXRlTGlzdCA9IHN0YXRlcy5tYXAoKHMpID0+IHMubmFtZSk7XG4gIGNvbnN0IHN0YXRlRW5kaW5nID1cbiAgICBzdGF0ZUxpc3Quc2xpY2UoMCwgLTEpLmpvaW4oXCIsIFwiKSArXG4gICAgXCIgYW5kIFwiICtcbiAgICBzdGF0ZUxpc3Rbc3RhdGVMaXN0Lmxlbmd0aCAtIDFdO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIj5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBtZDp0ZXh0LTR4bCB0ZXh0LWNlbnRlciBtZDp0ZXh0LWxlZnQgbWItMTZcIj5cbiAgICAgICAge3RpdGxlID8gdGl0bGUgOiBcIkZBUXNcIn1cbiAgICAgIDwvaDE+XG4gICAgICA8dWwgY2xhc3NOYW1lPVwidy1mdWxsIHNwYWNlLXktOFwiPlxuICAgICAgICB7IGZhcS5tYXAoKHtmaWVsZHN9LCBpbmRleCk9PntcbiAgICAgICAgICByZXR1cm4oXG4gICAgICAgICAgICA8RkFRSXRlbSB0aXRsZT17ZmllbGRzLnF1ZXN0aW9ufT5cbiAgICAgICAgICAgICAge2RvY3VtZW50VG9SZWFjdENvbXBvbmVudHMoZmllbGRzLmZhcWFuc3dlcil9XG4gICAgICAgICAgICA8L0ZBUUl0ZW0+ICBcbiAgICAgICAgICApXG4gICAgICAgIH0pfVxuICAgICAgICB7LyogPEZBUUl0ZW0gdGl0bGU9XCJXaGF0IGlzIExpbmE/XCI+XG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBMaW5hIGFsbG93cyBwYXRpZW50cyB0byBzZWUgbGljZW5zZWQgcHN5Y2hpYXRyeSBwcm9mZXNzaW9uYWxzIHZpYSBhblxuICAgICAgICAgICAgb25saW5lIHZpZGVvIGNvbnN1bHRhdGlvbi7CoFdlIGVuYWJsZSBncmVhdGVyIGFjY2VzcyB0byBoaWdoIHF1YWxpdHksXG4gICAgICAgICAgICBjb252ZW5pZW50LCBhbmQgYWZmb3JkYWJsZSBwc3ljaGlhdHJpYyBjYXJlLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9GQVFJdGVtPlxuICAgICAgICA8RkFRSXRlbSB0aXRsZT1cIldoYXQgaXMgdGhlIGNvc3Q/XCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiIFwiPlxuICAgICAgICAgICAgWW91ciBmaXJzdCBtb250aCBpcyBqdXN0ICQ1LiBXaXRob3V0IGluc3VyYW5jZSwgbWVtYmVyc2hpcCBpcyAkOTUgYVxuICAgICAgICAgICAgbW9udGguIFRoaXMgaW5jbHVkZXMgdmlzaXRzIHdpdGggeW91ciBwcm92aWRlci4gWW91ciBpbnN1cmFuY2UgbWF5XG4gICAgICAgICAgICBjb3ZlciBzb21lIG9mIHRoZSBjb3N0cyBvZiB5b3VyIG1lZGljYXRpb24uXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L0ZBUUl0ZW0+XG4gICAgICAgIDxGQVFJdGVtIHRpdGxlPVwiSG93IGRvZXMgdGhpcyB3b3JrP1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzcGFjZS15LTQgIFwiPlxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgIDEpIENvbXBsZXRlIG91ciBicmllZiBhc3Nlc3NtZW50IG9ubGluZSBzbyB3ZSBjYW4gbGVhcm4gYWJvdXQgeW91clxuICAgICAgICAgICAgICBtZWRpY2FsIGhpc3RvcnkuIEJhc2VkIG9uIHRoaXMsIHdlIHdpbGwgYXNzZXNzIHdoZXRoZXIgd2UgY2FuIGhlbHBcbiAgICAgICAgICAgICAgeW91LlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgIDIpIElmIHlvdSBhcmUgYSBmaXQgZm9yIG91ciBwcmFjdGljZSwgeW91IHdpbGwgYmUgYWJsZSB0byBzY2hlZHVsZVxuICAgICAgICAgICAgICBhbiBvbmxpbmUgdmlzaXQuIFBsZWFzZSBub3RlIHRoYXQgd2UgYXJlIGhhcHB5IHRvIHRha2UgcGF0aWVudHNcbiAgICAgICAgICAgICAgZXZlbiBpZiB0aGV5IGhhdmUgbm90IGJlZW4gdHJlYXRlZCBwcmV2aW91c2x5LlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgIDMpIEJlZm9yZSB5b3VyIHJlc2VydmF0aW9uIGlzIGNvbmZpcm1lZCwgeW91IHdpbGwgbmVlZCB1cGxvYWRcbiAgICAgICAgICAgICAgaW1hZ2VzIG9mIGdvdmVybm1lbnQtaXNzdWVkIHBob3RvIElEIGFzIHdlbGwgYXMgZmlsbCBvdXQgZnVydGhlclxuICAgICAgICAgICAgICBpbnRha2UgaW5mb3JtYXRpb24uXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgNCkgQSB2aXNpdCB3aXRoIExpbmEgaXMgbXVjaCBsaWtlIGEgcmVndWxhciBkb2N0b3IgdmlzaXQsIGV4Y2VwdFxuICAgICAgICAgICAgICB0aGF0IGl0IGlzIGNvbmR1Y3RlZCBkaWdpdGFsbHkuIFdlIHRha2UgY3liZXItc2VjdXJpdHkgc2VyaW91c2x5O1xuICAgICAgICAgICAgICBhbGwgdmlzaXRzIGFyZSBkb25lIHZpYSBhIHNlY3VyZSwgSElQQUEtY29tcGxpYW50IHZpZGVvY2hhdC4gVGhlXG4gICAgICAgICAgICAgIGZpcnN0IHZpc2l0IGlzIGFuIG9ubGluZSB2aXNpdCB3aXRoIGEgbWVudGFsIGhlYWx0aCBleHBlcnQuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8cD5cbiAgICAgICAgICAgICAgV2UgZG8gbm90IGN1dCBjb3JuZXJzIG9yIHNraXAgYW55IGltcG9ydGFudCBhc3BlY3RzIG9mIGEgZnVsbFxuICAgICAgICAgICAgICBwc3ljaGlhdHJpYyBldmFsdWF0aW9uOyB5b3VyIHByb3ZpZGVyIHdpbGwgcGVyZm9ybSBhIGZ1bGxcbiAgICAgICAgICAgICAgcHN5Y2hpYXRyaWMgZXZhbHVhdGlvbi4gT3VyIHByb3ZpZGVycyBvbmx5IHByZXNjcmliZSBtZWRpY2F0aW9uIGlmXG4gICAgICAgICAgICAgIGl0IGlzIGFwcHJvcHJpYXRlIGZvciB5b3VyIHNpdHVhdGlvbi5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9GQVFJdGVtPlxuICAgICAgICA8RkFRSXRlbSB0aXRsZT1cIldoYXQgc3RhdGVzIGRvIHlvdSBvcGVyYXRlIGluP1wiPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgV2UgY3VycmVudGx5IG9wZXJhdGUgaW4ge3N0YXRlRW5kaW5nfS4gV2UmYXBvcztyZSBhbHdheXMgdHJ5aW5nIHRvXG4gICAgICAgICAgICBoZWxwIGFzIG1hbnkgcGVvcGxlIGFzIHBvc3NpYmxlLiBJZiB5b3VyIHN0YXRlIGlzIG5vdCBsaXN0ZWQgaGVyZSxcbiAgICAgICAgICAgIHBsZWFzZSBjb21wbGV0ZSBvdXIgb25saW5lIGFzc2Vzc21lbnQgYW5kIHdlJmFwb3M7bGwgcHJpb3JpdGl6ZSB5b3VcbiAgICAgICAgICAgIG9uIG91ciB3YWl0bGlzdC4gV2UgcmVxdWlyZSBwcm9vZiBvZiByZXNpZGVuY3kgdXBvbiBib29raW5nIGFuXG4gICAgICAgICAgICBhcHBvaW50bWVudCAoYSBkcml2ZXImYXBvcztzIGxpY2Vuc2Ugd29ya3MpLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9GQVFJdGVtPlxuICAgICAgICA8RkFRSXRlbSB0aXRsZT1cIkRvIHlvdSBhY2NlcHQgaW5zdXJhbmNlP1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxuICAgICAgICAgICAgVGhlIHNob3J0IGFuc3dlciBpcyB5ZXMuIPCfmYMgSGVyZSZhcG9zO3MgdGhlIGxvbmdlciBhbnN3ZXI6XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiXCI+XG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+VmlzaXRzPC9oND5cbiAgICAgICAgICAgIExpbmEgaXMgYW4gb3V0LW9mLW5ldHdvcmsgcHJvdmlkZXIgd2l0aCBpbnN1cmFuY2UgY29tcGFuaWVzIGZvclxuICAgICAgICAgICAgdmlzaXRzLiBBbiA8Yj5vdXQtb2YtbmV0d29yazwvYj4gY2xhaW0gbWVhbnMgdGhhdCB5b3VyIGhlYWx0aFxuICAgICAgICAgICAgaW5zdXJhbmNlIGNvbXBhbnkgY2FuIHJlaW1idXJzZSB5b3UgZm9yIG1vbmV5IHNwZW50IG9uIGhlYWx0aGNhcmVcbiAgICAgICAgICAgIHRoYXQgaXMgZnJvbSBhIHByb3ZpZGVyIG5vdCBub3JtYWxseSBjb3ZlcmVkIGluIHlvdXJcbiAgICAgICAgICAgIGluc3VyYW5jZSZhcG9zO3MgbmV0d29yay4gTGluYSBwcm92aWRlcyB5b3Ugd2l0aCBhIHN1cGVyYmlsbCB0b1xuICAgICAgICAgICAgc3VibWl0IHRvIHlvdXIgaW5zdXJhbmNlIHRvIGNvdmVyIHZpc2l0IGZlZXMuXG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwibXQtNCBmb250LWJvbGRcIj5NZWRpY2F0aW9uPC9oND5cbiAgICAgICAgICAgIFlvdSBjYW4gdXNlIHlvdXIgaW5zdXJhbmNlIHRvIHBheSBmb3IgbWVkaWNhdGlvbiBhdCB5b3VyIGxvY2FsXG4gICAgICAgICAgICBwaGFybWFjeS4gSWYgeW91IHdhbnQgeW91ciBwcmVzY3JpcHRpb24gc2hpcHBlZCwgd2UgY2hhcmdlICQxNSBmb3JcbiAgICAgICAgICAgIGFsbCBtZWRpY2F0aW9uLCB3aXRoIHNoaXBwaW5nIGluY2x1ZGVkIGZvciBmcmVlLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9GQVFJdGVtPlxuICAgICAgICA8RkFRSXRlbSB0aXRsZT1cIkRvZXMgTGluYSBzaGlwIG1lZGljYXRpb25zP1wiPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgWWVzLCBMaW5hIHBhcnRuZXJzIHdpdGggbWFpbCBvcmRlciBwaGFybWFjaWVzIHRvIGRlbGl2ZXIgbWVkaWNhdGlvbnNcbiAgICAgICAgICAgIGF0IHRoZSBsb3dlc3QgY29zdCBwb3NzaWJsZSB0byBvdXIgbWVtYmVycy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNFwiPlxuICAgICAgICAgICAgT3VyIHBhcnRuZXIgcGhhcm1hY3kgaXMgUmlkZ2V3YXkgUGhhcm1hY3kuXG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIENvbnRhY3QgSW5mb3JtYXRpb246XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIFJpZGdld2F5IFBoYXJtYWN5LCBDbG9zZWQgRG9vclxuICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAyODI0IEh3eSA5MyBOPGJyIC8+XG4gICAgICAgICAgICBWaWN0b3IsIE1UIDU5ODc1LTAwMDBcbiAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgTmFtZSBvZiBQSUM6IEtsaW50b24gSy4gQ3VydGlzXG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIFByb2Zlc3Npb25hbCBEZWdyZWUgb2YgUElDOiBSZWdpc3RlcmVkIFBoYXJtYWNpc3RcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvRkFRSXRlbT5cbiAgICAgICAgPEZBUUl0ZW0gdGl0bGU9XCJBcmUgeW91IEhJUEFBIGNvbXBsaWFudD9cIj5cbiAgICAgICAgICA8cD5cbiAgICAgICAgICAgIFdlIHRha2UgYWxsIHNlY3VyaXR5IGFuZCBwcml2YWN5IGlzc3VlcyB2ZXJ5IHNlcmlvdXNseS4gVGhlIExpbmFcbiAgICAgICAgICAgIHBsYXRmb3JtIGlzIGZ1bGx5IEhJUEFBIGNvbXBsaWFudC4gQWxsIHBhdGllbnQgZGF0YSBhbmQgbWVzc2FnZXMgYXJlXG4gICAgICAgICAgICBzdHJpY3RseSBjb25maWRlbnRpYWwuIFBsZWFzZSBzZWUgb3Vye1wiIFwifVxuICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9wcml2YWN5LXBvbGljeVwiPlxuICAgICAgICAgICAgICA8YSBjbGFzc05hbWU9XCJ1bmRlcmxpbmUgaG92ZXI6bm8tdW5kZXJsaW5lXCIgaHJlZj1cIiNcIj5cbiAgICAgICAgICAgICAgICBQcml2YWN5IFBvbGljeVxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8L0xpbms+e1wiIFwifVxuICAgICAgICAgICAgZm9yIG1vcmUgaW5mb3JtYXRpb24uXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L0ZBUUl0ZW0+XG4gICAgICAgIDxGQVFJdGVtIHRpdGxlPVwiV2hhdCBxdWFsaWZpY2F0aW9ucyBkbyB5b3VyIHByb3ZpZGVycyBoYXZlP1wiPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgQWxsIG9mIG91ciBwcm92aWRlcnMgYXJlIGxpY2Vuc2VkIHRvIHByYWN0aWNlIG1lZGljaW5lIGluIHRoZSBVbml0ZWRcbiAgICAgICAgICAgIFN0YXRlcyBhbmQgYXJlIGJvYXJkLWNlcnRpZmllZCBpbiB2YXJpb3VzIGFyZWFzIG9mIHNwZWNpYWx0eSBzdWNoIGFzXG4gICAgICAgICAgICBwc3ljaGlhdHJ5IGFuZCBmYW1pbHkgbWVkaWNpbmUuXG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgT3VyIG51cnNlIHByYWN0aXRpb25lcnMgYW5kIHBoeXNpY2lhbuKAmXMgYXNzaXN0YW50cyBhcmUgYWxzbyBhbGxcbiAgICAgICAgICAgIGxpY2Vuc2VkIG9yIGNlcnRpZmllZCBpbiB0aGUgc3RhdGVzIGluIHdoaWNoIHRoZXkgcHJvdmlkZSBwYXRpZW50XG4gICAgICAgICAgICBjYXJlLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9GQVFJdGVtPlxuICAgICAgICA8RkFRSXRlbSB0aXRsZT1cIkNhbiBJIHBpY2sgbXkgcHJvdmlkZXI/XCI+XG4gICAgICAgICAgWWVzISBXZSB0aGluayBpdCZhcG9zO3MgaW1wb3J0YW50IHlvdSBmaW5kIGEgcHJvdmlkZXIgdGhhdCB5b3UgY2FuXG4gICAgICAgICAgZmVlbCBjb21mb3J0YWJsZSBzcGVha2luZyB3aXRoLiBJdCZhcG9zO3MgaW1wb3J0YW50IHRvXG4gICAgICAgICAgJnF1b3Q7Y2xpY2smcXVvdDsgd2l0aCB5b3VyIHByb3ZpZGVyLlxuICAgICAgICA8L0ZBUUl0ZW0+XG4gICAgICAgIDxGQVFJdGVtIHRpdGxlPVwiQXJlIHRoZXJlIGNvbmRpdGlvbnMgdGhhdCB5b3UgZG9u4oCZdCBjb3Zlcj9cIj5cbiAgICAgICAgICBBdCB0aGlzIHRpbWUsIHdlIGNhbm5vdCB0cmVhdCBhZGRpY3Rpb24sIGJpcG9sYXIgZGlzb3JkZXIgb3JcbiAgICAgICAgICBzY2hpem9waHJlbmlhLlxuICAgICAgICA8L0ZBUUl0ZW0+XG4gICAgICAgIDxGQVFJdGVtIHRpdGxlPVwiQ2FuIEkgc2VlIG15IHByb3ZpZGVyIGluLXBlcnNvbj9cIj5cbiAgICAgICAgICBBdCB0aGlzIHRpbWUsIHdlIGFyZSBvbmxpbmUtb25seS5cbiAgICAgICAgPC9GQVFJdGVtPlxuICAgICAgICA8RkFRSXRlbSB0aXRsZT1cIldoYXQgaXMgaW5jbHVkZWQgaW4gbXkgc3Vic2NyaXB0aW9uPyBIb3cgb2Z0ZW4gY2FuIEkgc2VlIG15IHByb3ZpZGVyP1wiPlxuICAgICAgICAgIFlvdXIgc3Vic2NyaXB0aW9uIGluY2x1ZGVzIHVubGltaXRlZCB2aXNpdHMgdG8geW91ciBwcm92aWRlcixcbiAgICAgICAgICB1bmxpbWl0ZWQgbWVzc2FnaW5nIHdpdGggeW91ciBwcm92aWRlciBhbmQgY2FyZSB0ZWFtLiBZb3VyIGluc3VyYW5jZVxuICAgICAgICAgIG1heSBjb3ZlciBzb21lIG9mIHRoZSBjb3N0cyBvZiB5b3VyIG1lZGljYXRpb24uXG4gICAgICAgIDwvRkFRSXRlbT5cbiAgICAgICAgPEZBUUl0ZW0gdGl0bGU9XCJXaGF0IGlzIHlvdXIgcmVzY2hlZHVsaW5nIHBvbGljeT9cIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCIgXCI+XG4gICAgICAgICAgICBQbGVhc2UgZ2l2ZSB1cyA0OCBob3VycyBub3RpY2UgZm9yIGFueSBjYW5jZWxsYXRpb25zIG9yIHJlc2NoZWR1bGVzLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9GQVFJdGVtPlxuICAgICAgICA8RkFRSXRlbSB0aXRsZT1cIldoYXQgaGFwcGVucyBpZiBJIGFtIGxhdGUgdG8gbXkgYXBwb2ludG1lbnQ/XCI+XG4gICAgICAgICAgSWYgeW91IGFyZSBsYXRlIHRvIHlvdXIgYXBwb2ludG1lbnQgYnkgbW9yZSB0aGFuIDE1IG1pbnV0ZXMsIHdlIHdpbGxcbiAgICAgICAgICB3aWxsIGNvdW50IHRoaXMgYXMgYW4gYXBwb2ludG1lbnQgY2FuY2VsbGF0aW9uLlxuICAgICAgICA8L0ZBUUl0ZW0+ICovfVxuICAgICAgPC91bD5cbiAgICAgIHtzaG93QnV0dG9uID8gKFxuICAgICAgICA8TGluayBocmVmPVwiL2ZhcVwiPlxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIGFzTGluaz17dHJ1ZX1cbiAgICAgICAgICAgIGhyZWY9XCIjXCJcbiAgICAgICAgICAgIGJ1dHRvblR5cGU9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtOCB3LWZ1bGwgbWQ6dy1tYXggdGV4dC1jZW50ZXIgYm9yZGVyIGJvcmRlci1kYXJrR3JheSBib3JkZXItMSBob3ZlcjpiZy1kYXJrR3JheSBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBHZXQgYW5zd2VycyB0byBvdGhlciBxdWVzdGlvbnNcbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBGQVE7XG4iLCIvKipcbiAqIEluZGl2aWR1YWwgcXVlc3Rpb24vYW5zd2VyIGluIHRoZSBGQVFcbiAqL1xuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBUcmFuc2l0aW9uIH0gZnJvbSBcIkBoZWFkbGVzc3VpL3JlYWN0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgRkFRSXRlbTogUmVhY3QuRkM8eyB0aXRsZTogc3RyaW5nIH0+ID0gKHsgdGl0bGUsIGNoaWxkcmVuIH0pID0+IHtcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICByZXR1cm4gKFxuICAgIDxsaSBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZGFya0dyYXkgcGItMiBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgIDxidXR0b25cbiAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIHRleHQtbGVmdCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKCFvcGVuKX1cbiAgICAgID5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWxpZ2h0XCI+e3RpdGxlfTwvc3Bhbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC1hdXRvXCI+XG4gICAgICAgICAge29wZW4gPyAoXG4gICAgICAgICAgICA8c3ZnXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNiBoLTZcIlxuICAgICAgICAgICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsxfVxuICAgICAgICAgICAgICAgIGQ9XCJNMjAgMTJINFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPHN2Z1xuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTYgaC02XCJcbiAgICAgICAgICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17MX1cbiAgICAgICAgICAgICAgICBkPVwiTTEyIDZ2Nm0wIDB2Nm0wLTZoNm0tNiAwSDZcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2J1dHRvbj5cbiAgICAgIDxUcmFuc2l0aW9uXG4gICAgICAgIHNob3c9e29wZW59XG4gICAgICAgIGNsYXNzTmFtZT1cInB5LTRcIlxuICAgICAgICBlbnRlcj1cInRyYW5zaXRpb24gZWFzZS1vdXQgZHVyYXRpb24tMjAwXCJcbiAgICAgICAgZW50ZXJGcm9tPVwidHJhbnNmb3JtIG9wYWNpdHktMCBzY2FsZS05NVwiXG4gICAgICAgIGVudGVyVG89XCJ0cmFuc2Zvcm0gb3BhY2l0eS0xMDAgc2NhbGUtMTAwXCJcbiAgICAgICAgbGVhdmU9XCJ0cmFuc2l0aW9uIGVhc2UtaW4gZHVyYXRpb24tNzVcIlxuICAgICAgICBsZWF2ZUZyb209XCJ0cmFuc2Zvcm0gb3BhY2l0eS0xMDAgc2NhbGUtMTAwXCJcbiAgICAgICAgbGVhdmVUbz1cInRyYW5zZm9ybSBvcGFjaXR5LTAgc2NhbGUtOTVcIlxuICAgICAgPlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8L1RyYW5zaXRpb24+XG4gICAgPC9saT5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEZBUUl0ZW07XG4iLCIvKipcbiAqIEZvb3RlciBmb3IgbGFuZGluZyBwYWdlXG4gKi9cbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcbmltcG9ydCBSZWFjdCwgeyBGQywgSFRNTFByb3BzIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgTGVnaXRzY3JpcHRTZWFsIGZyb20gXCIuL0xlZ2l0c2NyaXB0U2VhbFwiO1xuaW1wb3J0IExvZ28gZnJvbSBcIi4vTG9nb1wiO1xuXG5pbXBvcnQgRmFjZWJvb2sgZnJvbSBcIi4uL3N2Zy9Tb2NpYWxNZWRpYS9GYWNlYm9va1wiO1xuaW1wb3J0IEluc3RhZ3JhbSBmcm9tIFwiLi4vc3ZnL1NvY2lhbE1lZGlhL0luc3RhZ3JhbVwiO1xuaW1wb3J0IExpbmtlZEluIGZyb20gXCIuLi9zdmcvU29jaWFsTWVkaWEvTGlua2VkSW5cIjtcblxudHlwZSBTb2NpYWxNZWRpYUxpbmtQcm9wcyA9IHtcbiAgaHJlZjogc3RyaW5nO1xufTtcblxuY29uc3QgU29jaWFsTWVkaWFMaW5rOiBGQzxTb2NpYWxNZWRpYUxpbmtQcm9wcz4gPSAoeyBocmVmLCBjaGlsZHJlbiB9KSA9PiAoXG4gIDxhIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJ3LTZcIiBocmVmPXtocmVmfT5cbiAgICB7Y2hpbGRyZW59XG4gIDwvYT5cbik7XG5cbnR5cGUgRm9vdGVySXRlbVByb3BzID0gSFRNTFByb3BzPEhUTUxBbmNob3JFbGVtZW50PiAmIHtcbiAgaHJlZjogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIGV4dGVybmFsPzogYm9vbGVhbjtcbn07XG5cbmNvbnN0IEZvb3Rlckl0ZW06IEZDPEZvb3Rlckl0ZW1Qcm9wcz4gPSAoe1xuICBocmVmLFxuICBjaGlsZHJlbixcbiAgZXh0ZXJuYWwgPSBmYWxzZSxcbiAgLi4ucHJvcHNcbn0pID0+IHtcbiAgY29uc3QgbGluayA9IChcbiAgICA8YVxuICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWN1cnJlbnQgaG92ZXI6Ym9yZGVyLW5vbmVcIlxuICAgICAgaHJlZj17ZXh0ZXJuYWwgPyBocmVmIDogdW5kZWZpbmVkfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2E+XG4gICk7XG5cbiAgcmV0dXJuIDxsaT57ZXh0ZXJuYWwgPyBsaW5rIDogPExpbmsgaHJlZj17aHJlZn0+e2xpbmt9PC9MaW5rPn08L2xpPjtcbn07XG5cbmNvbnN0IEZvb3RlciA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Zm9vdGVyXG4gICAgICBpZD1cImZvb3RlclwiXG4gICAgICBjbGFzc05hbWU9XCJweC02IHB5LTEyIG1kOnB5LTI4IGZsZXgganVzdGlmeS1jZW50ZXIgYmctc2Vhc2hlbGxcIlxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyIGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxMb2dvIC8+XG4gICAgICAgICAgPExlZ2l0c2NyaXB0U2VhbCAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IG1kOm10LTAgcC00IG1kOnAtMCBncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInRleHQtc20gbWItNCBsZzptYi04IGZsZXggZmxleC1jb2wgZ2FwLXktMVwiPlxuICAgICAgICAgICAgPEZvb3Rlckl0ZW0gaHJlZj1cIi90ZXJtcy1vZi1zZXJ2aWNlXCI+VGVybXMgb2YgU2VydmljZTwvRm9vdGVySXRlbT5cbiAgICAgICAgICAgIDxGb290ZXJJdGVtIGhyZWY9XCIvcHJpdmFjeS1wb2xpY3lcIj5Qcml2YWN5IFBvbGljeTwvRm9vdGVySXRlbT5cbiAgICAgICAgICAgIDxGb290ZXJJdGVtIGhyZWY9XCJtYWlsdG86cHJlc3NAaGVsbG9saW5hLmNvbVwiIGV4dGVybmFsPlxuICAgICAgICAgICAgICBQcmVzcyBJbnF1aXJpZXNcbiAgICAgICAgICAgIDwvRm9vdGVySXRlbT5cbiAgICAgICAgICAgIDxGb290ZXJJdGVtXG4gICAgICAgICAgICAgIGhyZWY9XCJodHRwczovL2JvYXJkcy5ncmVlbmhvdXNlLmlvL2xpbmFcIlxuICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICBleHRlcm5hbFxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBDYXJlZXJzXG4gICAgICAgICAgICA8L0Zvb3Rlckl0ZW0+XG4gICAgICAgICAgICA8Rm9vdGVySXRlbSBocmVmPVwiL3JlZmVyLWZyaWVuZFwiPlJlZmVyIGEgRnJpZW5kPC9Gb290ZXJJdGVtPlxuICAgICAgICAgICAgPEZvb3Rlckl0ZW0gaHJlZj1cIi9ibG9nXCI+QmxvZzwvRm9vdGVySXRlbT5cbiAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHRleHQtc20gZ2FwLXktMVwiPlxuICAgICAgICAgICAgPEZvb3Rlckl0ZW0gaHJlZj1cIm1haWx0bzpzdXBwb3J0QGhlbGxvbGluYS5jb21cIiBleHRlcm5hbD5cbiAgICAgICAgICAgICAgc3VwcG9ydEBoZWxsb2xpbmEuY29tXG4gICAgICAgICAgICA8L0Zvb3Rlckl0ZW0+XG4gICAgICAgICAgICA8Rm9vdGVySXRlbSBocmVmPVwiL2ZhcVwiPkZBUTwvRm9vdGVySXRlbT5cbiAgICAgICAgICAgIDxsaT45YW0tNXBtIEVTVCwgTS1GPC9saT5cbiAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IHB0LTMgZ2FwLXgtM1wiPlxuICAgICAgICAgICAgICA8U29jaWFsTWVkaWFMaW5rIGhyZWY9XCJodHRwczovL3d3dy5pbnN0YWdyYW0uY29tL2xpbmFtZW50YWxoZWFsdGgvP2hsPWVuXCI+XG4gICAgICAgICAgICAgICAgPEluc3RhZ3JhbSAvPlxuICAgICAgICAgICAgICA8L1NvY2lhbE1lZGlhTGluaz5cbiAgICAgICAgICAgICAgPFNvY2lhbE1lZGlhTGluayBocmVmPVwiaHR0cHM6Ly93d3cubGlua2VkaW4uY29tL2NvbXBhbnkvaGVsbG9saW5hL1wiPlxuICAgICAgICAgICAgICAgIDxMaW5rZWRJbiAvPlxuICAgICAgICAgICAgICA8L1NvY2lhbE1lZGlhTGluaz5cbiAgICAgICAgICAgICAgPFNvY2lhbE1lZGlhTGluayBocmVmPVwiaHR0cHM6Ly93d3cuZmFjZWJvb2suY29tL3Blb3BsZS9MaW5hLzEwMDA2ODA3NzI5MTM5NS9cIj5cbiAgICAgICAgICAgICAgICA8RmFjZWJvb2sgLz5cbiAgICAgICAgICAgICAgPC9Tb2NpYWxNZWRpYUxpbms+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBtdC04XCI+XG4gICAgICAgICAgICAmY29weTsgMjAyMSBMaW5hLCBhIEImYW1wO0cgSW5ub3ZhdGlvbnMgY29tcGFueS4gQWxsIHJpZ2h0c1xuICAgICAgICAgICAgcmVzZXJ2ZWQuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZm9vdGVyPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgRm9vdGVyO1xuIiwiLyoqXG4gKiBIZWFkZXIgZm9yIGxhbmRpbmcgcGFnZVxuICovXG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuXG5pbXBvcnQgY3ggZnJvbSBcImNsYXNzbmFtZXNcIjtcbmltcG9ydCB7IFRyYW5zaXRpb24gfSBmcm9tIFwiQGhlYWRsZXNzdWkvcmVhY3RcIjtcbmltcG9ydCBMb2dvIGZyb20gXCIuL0xvZ29cIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIi4uL2NvcmUvQnV0dG9uXCI7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIHN0YXJ0Q29sb3I/OiBzdHJpbmc7XG4gIHN0YXJ0T2ZmZXI/OiBzdHJpbmc7XG4gIGhpZGVNZW51PzogYm9vbGVhbjtcbn1cblxuY29uc3QgSGVhZGVyOiBSZWFjdC5GQzxQcm9wcz4gPSAoe1xuICB0aXRsZSxcbiAgc3RhcnRPZmZlcixcbiAgc3RhcnRDb2xvcixcbiAgaGlkZU1lbnUsXG59KSA9PiB7XG4gIGNvbnN0IFtzaG93T2ZmZXIsIHNldFNob3dPZmZlcl0gPSB1c2VTdGF0ZSghIXN0YXJ0T2ZmZXIpO1xuICBjb25zdCBbc2hvd1NpZGViYXIsIHNldFNob3dTaWRlYmFyXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2lzVG9wLCBzZXRJc1RvcF0gPSB1c2VTdGF0ZSh0cnVlKTtcblxuICBjb25zdCBvblNjcm9sbCA9ICgpID0+IHtcbiAgICBzZXRJc1RvcCh3aW5kb3cucGFnZVlPZmZzZXQgPCAzMik7XG4gIH07XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJzY3JvbGxcIiwgb25TY3JvbGwpO1xuICAgIHJldHVybiAoKSA9PiB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBvblNjcm9sbCk7XG4gIH0sIFtdKTtcblxuICBjb25zdCB0b2dnbGVDbG9zZSA9ICgpID0+IHNldFNob3dTaWRlYmFyKGZhbHNlKTtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPEhlYWQ+XG4gICAgICAgIDx0aXRsZT57dGl0bGV9PC90aXRsZT5cbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxuICAgICAgPC9IZWFkPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9e2N4KFxuICAgICAgICAgIFwidy1mdWxsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZpeGVkIHRvcC0wIGxlZnQtMCB6LTUwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTUwMFwiLFxuICAgICAgICAgIHsgXCJzaGFkb3ctbWRcIjogIWlzVG9wIH0sXG4gICAgICAgICAgaXNUb3AgPyBzdGFydENvbG9yIHx8IFwiYmctc2Vhc2hlbGxcIiA6IFwiYmctd2hpdGVcIlxuICAgICAgICApfVxuICAgICAgPlxuICAgICAgICB7c2hvd09mZmVyID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiei01MCB0LTAgYmctZGFya0dyYXkgdGV4dC13aGl0ZSBoLTggdy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8TGluayBocmVmPVwiL29uYm9hcmRpbmcvaW50cm8vc3RhcnRcIj5cbiAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJ1bmRlcmxpbmUgaG92ZXI6bm8tdW5kZXJsaW5lIG14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICB7c3RhcnRPZmZlcn1cbiAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPGRpdiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93T2ZmZXIoZmFsc2UpfSBjbGFzc05hbWU9XCJtci0yXCI+XG4gICAgICAgICAgICAgIDxzdmdcbiAgICAgICAgICAgICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTYgdy02XCJcbiAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17MX1cbiAgICAgICAgICAgICAgICAgIGQ9XCJNMTAgMTRsMi0ybTAgMGwyLTJtLTIgMmwtMi0ybTIgMmwyIDJtNy0yYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBjb250YWluZXIgaXRlbXMtY2VudGVyIHB4LTYgbWQ6cHgtMCBweS00XCI+XG4gICAgICAgICAgPExpbmsgaHJlZj1cIi9cIj5cbiAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPExvZ28gLz5cbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIHsvKiA8c3Bhbj5MaW5hPC9zcGFuPiAqL31cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2N4KFwibWwtYXV0byBtZDpoaWRkZW5cIiwgaGlkZU1lbnUgPyBcImhpZGRlblwiIDogXCJcIil9PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93U2lkZWJhcih0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgcHktMiBweC0zIHRleHQtY29yYWwgcm91bmRlZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxzdmdcbiAgICAgICAgICAgICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTYgdy02IHRleHQtZGFya0dyYXlcIlxuICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcbiAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHBhdGhcbiAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxuICAgICAgICAgICAgICAgICAgZD1cIk01LjEyMSAxNy44MDRBMTMuOTM3IDEzLjkzNyAwIDAxMTIgMTZjMi41IDAgNC44NDcuNjU1IDYuODc5IDEuODA0TTE1IDEwYTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHptNiAyYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9zdmc+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJsZzpoaWRkZW5cIj5cbiAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9vbmJvYXJkaW5nL2ludHJvL3N0YXJ0XCI+XG4gICAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwicHJpbWFyeS1idXR0b24tYmx1ZSB0ZXh0LXNtIHctXCIgaHJlZj1cIiNcIj5cbiAgICAgICAgICAgICAgICAgIEdldCBTdGFydGVkXG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2Rpdj4gKi99XG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImhpZGRlbiBsZzpmbGV4IGxnOml0ZW1zLWNlbnRlciBsZzp3LWF1dG8gbGc6c3BhY2UteC04IG1sLWF1dG8gbXItNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbGc6ZmxleFwiPlxuICAgICAgICAgICAgICA8TGluayBocmVmPVwiL2xvZ2luXCI+XG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgaHJlZj1cIiNcIlxuICAgICAgICAgICAgICAgICAgYXNMaW5rXG4gICAgICAgICAgICAgICAgICBidXR0b25UeXBlPVwic2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZGFya0dyYXkgaG92ZXI6dW5kZXJsaW5lXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBMb2cgSW5cbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICA8TGluayBocmVmPVwiL29uYm9hcmRpbmcvaW50cm8vc3RhcnRcIj5cbiAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICBidXR0b25UeXBlPVwiaGVhZGVyXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTIgdXBwZXJjYXNlIHRleHQtc20gcHgtNFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgR2V0IFN0YXJ0ZWRcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC91bD5cbiAgICAgICAgPC9uYXY+XG4gICAgICAgIHsvKiA8aHIgY2xhc3NOYW1lPVwiYm9yZGVyLTEgc29saWQgYm9yZGVyLWdyYXktMjAwIG14LTEwXCIgLz4gKi99XG4gICAgICA8L2Rpdj5cblxuICAgICAgPFRyYW5zaXRpb24gc2hvdz17c2hvd1NpZGViYXJ9PlxuICAgICAgICA8VHJhbnNpdGlvbi5DaGlsZFxuICAgICAgICAgIGVudGVyPVwidHJhbnNpdGlvbi1vcGFjaXR5IGVhc2UtbGluZWFyIGR1cmF0aW9uLTEwMFwiXG4gICAgICAgICAgZW50ZXJGcm9tPVwib3BhY2l0eS0wXCJcbiAgICAgICAgICBlbnRlclRvPVwib3BhY2l0eS0xMDBcIlxuICAgICAgICAgIGxlYXZlPVwidHJhbnNpdGlvbi1vcGFjaXR5IGVhc2UtbGluZWFyIGR1cmF0aW9uLTEwMFwiXG4gICAgICAgICAgbGVhdmVGcm9tPVwib3BhY2l0eS0xMDBcIlxuICAgICAgICAgIGxlYXZlVG89XCJvcGFjaXR5LTBcIlxuICAgICAgICA+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibHVlR3JheS04MDAgb3BhY2l0eS0yNVwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93U2lkZWJhcihmYWxzZSl9XG4gICAgICAgICAgPjwvZGl2PlxuICAgICAgICA8L1RyYW5zaXRpb24uQ2hpbGQ+XG4gICAgICAgIDxUcmFuc2l0aW9uLkNoaWxkXG4gICAgICAgICAgZW50ZXI9XCJ0cmFuc2l0aW9uLWFsbCBlYXNlLWxpbmVhciBkdXJhdGlvbi0zMDBcIlxuICAgICAgICAgIGVudGVyRnJvbT1cIi1tbC02NFwiXG4gICAgICAgICAgZW50ZXJUbz1cIm1sLTBcIlxuICAgICAgICAgIGxlYXZlPVwidHJhbnNpdGlvbi1hbGwgZWFzZS1saW5lYXIgZHVyYXRpb24tNTBcIlxuICAgICAgICAgIGxlYXZlVG89XCItbWwtNjRcIlxuICAgICAgICA+XG4gICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJweS0zIHB4LTYgYm9yZGVyLXIgdG9wLTAgdy05NiBiZy13aGl0ZSBmaXhlZCBoLWZ1bGwgb3ZlcmZsb3ctYXV0byB6LTUwIFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi04IFwiPlxuICAgICAgICAgICAgICA8TGluayBocmVmPVwiL1wiPlxuICAgICAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cIlwiPlxuICAgICAgICAgICAgICAgICAgPExvZ28gLz5cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93U2lkZWJhcihmYWxzZSl9IGNsYXNzTmFtZT1cIm1sLWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8c3ZnXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTYgdy02IGN1cnNvci1wb2ludGVyIGhvdmVyOnRleHQtYmx1ZUdyYXktNTAwXCJcbiAgICAgICAgICAgICAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxwYXRoXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxuICAgICAgICAgICAgICAgICAgICBkPVwiTTYgMThMMTggNk02IDZsMTIgMTJcIlxuICAgICAgICAgICAgICAgICAgPjwvcGF0aD5cbiAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJoaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwibWItMVwiPlxuICAgICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgcC00IHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgICBocmVmPVwiLyNnZXRfdHJlYXRtZW50XCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlQ2xvc2V9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEdldCBUcmVhdG1lbnRcbiAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJtYi0xXCI+XG4gICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBwLTQgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9XCIvI2NhcmVfcHJvY2Vzc1wiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZUNsb3NlfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBDYXJlIFByb2Nlc3NcbiAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJtYi0xXCI+XG4gICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBwLTQgdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9XCIvI3ByaWNpbmdcIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVDbG9zZX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgUHJpY2luZ1xuICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cIm1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHAtNCB0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgICAgaHJlZj1cIi8jZmFxXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17dG9nZ2xlQ2xvc2V9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEZBUVxuICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC02IGJvcmRlci10IGJvcmRlci1ibHVlR3JheS0xMDBcIj5cbiAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiL29uYm9hcmRpbmcvaW50cm8vc3RhcnRcIj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b24gYXNMaW5rPkdldCBTdGFydGVkPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvbG9naW5cIj5cbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgICAgYXNMaW5rXG4gICAgICAgICAgICAgICAgICAgIGJ1dHRvblR5cGU9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNvcmFsIG10LTIgYm9yZGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgTG9nIEluXG4gICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9uYXY+XG4gICAgICAgIDwvVHJhbnNpdGlvbi5DaGlsZD5cbiAgICAgIDwvVHJhbnNpdGlvbj5cbiAgICAgIHtzaG93T2ZmZXIgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMTYgYmctc2Vhc2hlbGxcIj48L2Rpdj5cbiAgICAgICkgOiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOCBiZy1zZWFzaGVsbFwiPjwvZGl2PlxuICAgICAgKX1cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtjeChzaG93T2ZmZXIgPyBcIm10LThcIiA6IHVuZGVmaW5lZCl9PjwvZGl2PlxuICAgIDwvPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyO1xuIiwiLyoqXG4gKiBXcmFwcGVyIGNvbXBvbmVudCB1c2VkIHRvIHByb3ZpZGUgdGVtcGxhdGUgZm9yIHRoZSBsYW5kaW5nIHBhZ2UuXG4gKiBVc2UgdGhpcyB0byBjcmVhdGUgbXVsdGlwbGUgdmFyaWF0aW9ucyBvZiB0aGUgbGFuZGluZyBwYWdlIHdpdGhcbiAqIHRoZSBzYW1lIHN0cnVjdHVyZS5cbiAqL1xuaW1wb3J0IHsgTmV4dFBhZ2UgfSBmcm9tIFwibmV4dFwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlT2ZmZXIgfSBmcm9tIFwiLi4vLi4vbGliL2hvb2tzL29mZmVyXCI7XG5pbXBvcnQgeyB1c2VVdG0gfSBmcm9tIFwiLi4vLi4vbGliL2hvb2tzL3V0bVwiO1xuaW1wb3J0IEVtZXJnZW5jeUJhciBmcm9tIFwiLi9FbWVyZ2VuY3lCYXJcIjtcbmltcG9ydCBGQVEgZnJvbSBcIi4vRkFRXCI7XG5pbXBvcnQgRm9vdGVyIGZyb20gXCIuL0Zvb3RlclwiO1xuaW1wb3J0IEhlYWRlciBmcm9tIFwiLi9IZWFkZXJcIjtcbmltcG9ydCBNZWRpY2FsVGVhbSBmcm9tIFwiLi9NZWRpY2FsVGVhbVwiO1xuaW1wb3J0IE5ld0NhcmVQcm9jZXNzIGZyb20gXCIuL05ld0NhcmVQcm9jZXNzXCI7XG5pbXBvcnQgUHJpY2luZyBmcm9tIFwiLi9QcmljaW5nXCI7XG5pbXBvcnQgU2VjdGlvbiBmcm9tIFwiLi9TZWN0aW9uXCI7XG5pbXBvcnQgVGVzdGltb25pYWxzIGZyb20gXCIuL1Rlc3RpbW9uaWFsc1wiO1xuaW1wb3J0IFdoYXRXZVRyZWF0IGZyb20gXCIuL1doYXRXZVRyZWF0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgTGFuZGluZ1RlbXBsYXRlOiBOZXh0UGFnZTxQcm9wcz4gPSAoeyBkYXRhLCBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnNvbGUubG9nKCdBbGwgZGF0YScsIGRhdGEpXG4gIGNvbnN0IHsgZmFxLCBwYWdlIH0gPSBkYXRhXG4gIGNvbnN0IHsgZmllbGRzIH0gPSBwYWdlXG4gIGNvbnN0IHtcbiAgICBjYXJlUHJvY2Vzc0hlYWRpbmcsXG4gICAgY2FyZVByb2Nlc3MsXG4gICAgdGVzdGltb25pYWxzSGVhZGluZyxcbiAgICB0ZXN0aW1vbmlhbHNcbiAgfSA9IGZpZWxkc1xuICBjb25zb2xlLmxvZygnVGl0bHRlJywgY2FyZVByb2Nlc3NIZWFkaW5nKVxuICB1c2VVdG0oKTtcbiAgY29uc3QgeyBvZmZlclRleHQgfSA9IHVzZU9mZmVyKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuICAgICAgPEhlYWRlciB0aXRsZT1cIkxpbmFcIiBzdGFydE9mZmVyPXtvZmZlclRleHR9IC8+XG4gICAgICA8U2VjdGlvbiBpZD1cImRlc2NcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGJnLXNlYXNoZWxsIHJlbGF0aXZlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyIGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICA8ZGl2PntjaGlsZHJlbn08L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG10LTggbWQ6bXQtMFwiPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBzcmM9XCIvaW1hZ2VzL2N0YWJnLnN2Z1wiXG4gICAgICAgICAgICAgIHdpZHRoPVwiNDAwXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtYXV0b1wiXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHJpZ2h0OiBcIjRweFwiIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICB3aWR0aD1cIjM0MFwiXG4gICAgICAgICAgICAgIHNyYz1cIi9pbWFnZXMvaGVyb19pbWFnZV9zbWFsbC5wbmdcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoZXJvaW1hZ2Ugcm91bmRlZC1mdWxsIGFic29sdXRlIHRvcC0wXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuICAgICAgPFNlY3Rpb24gaWQ9XCJjYXJlX3Byb2Nlc3NcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgICAgPE5ld0NhcmVQcm9jZXNzIGhlYWRpbmc9e2NhcmVQcm9jZXNzSGVhZGluZ30gZGF0YT17Y2FyZVByb2Nlc3N9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICA8U2VjdGlvbiBpZD1cInRlc3RpbW9uaWFsc1wiIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgYmctc2Vhc2hlbGxcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICA8VGVzdGltb25pYWxzIGhlYWRpbmc9e3Rlc3RpbW9uaWFsc0hlYWRpbmd9IGRhdGE9e3Rlc3RpbW9uaWFsc30gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1NlY3Rpb24+XG5cbiAgICAgIDxTZWN0aW9uIGlkPVwid2hhdF93ZV90cmVhdFwiIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgYmctc2Vhc2hlbGxcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICA8V2hhdFdlVHJlYXQgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1NlY3Rpb24+XG5cbiAgICAgIDxTZWN0aW9uIGlkPVwibWVkaWNhbF90ZWFtXCI+XG4gICAgICAgIDxNZWRpY2FsVGVhbSAvPlxuICAgICAgPC9TZWN0aW9uPlxuXG4gICAgICA8U2VjdGlvbiBpZD1cInByaWNpbmdcIiBjbGFzc05hbWU9XCJiZy1zZWFzaGVsbFwiIG5vUGFkZGluZz5cbiAgICAgICAgPFByaWNpbmcgLz5cbiAgICAgIDwvU2VjdGlvbj5cblxuICAgICAgPFNlY3Rpb24gaWQ9XCJmYXFcIiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgICAgPEZBUSBmYXE9e2ZhcX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1NlY3Rpb24+XG4gICAgICA8U2VjdGlvblxuICAgICAgICBpZD1cImVtZXJnZW5jeVwiXG4gICAgICAgIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIlxuICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwicmdiYSgyNDQsIDIxOCwgMjEzLCAwLjYpXCIgfX1cbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICA8RW1lcmdlbmN5QmFyIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TZWN0aW9uPlxuICAgICAgPEZvb3RlciAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTGFuZGluZ1RlbXBsYXRlO1xuIiwiLyoqXG4gKiBEaXNwbGF5cyB0aGUgbGVnaXQgc2NyaXB0IHNlYWwgd2l0aCBhbiA8aW1nPlxuICovXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgTGVnaXRzY3JpcHRTZWFsOiBSZWFjdC5GQzxQcm9wcz4gPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGFcbiAgICAgIGhyZWY9XCJodHRwczovL2xlZ2l0c2NyaXB0LmNvbS9waGFybWFjeS9oZWxsb2xpbmEuY29tXCJcbiAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICB0aXRsZT1cIlZlcmlmeSBMZWdpdFNjcmlwdCBBcHByb3ZhbFwiXG4gICAgICByZWw9XCJub3JlZmVycmVyXCJcbiAgICA+XG4gICAgICA8aW1nXG4gICAgICAgIHNyYz1cImh0dHBzOi8vc3RhdGljLmxlZ2l0c2NyaXB0LmNvbS9zZWFscy8xMDc2ODY5Mi5wbmdcIlxuICAgICAgICBhbHQ9XCJMZWdpdFNjcmlwdCBhcHByb3ZlZFwiXG4gICAgICAgIHdpZHRoPVwiMTQwXCJcbiAgICAgICAgaGVpZ2h0PVwiMTAwXCJcbiAgICAgIC8+XG4gICAgPC9hPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTGVnaXRzY3JpcHRTZWFsO1xuIiwiLyoqXG4gKiBMaW5hIGxvZ28gYXMgYW4gU1ZHXG4gKi9cblxuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5pbnRlcmZhY2UgUHJvcHMgeyB9XG5cbmNvbnN0IExvZ286IFJlYWN0LkZDPFByb3BzPiA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8c3ZnXG4gICAgICB3aWR0aD1cIjk2XCJcbiAgICAgIGhlaWdodD1cIjI0XCJcbiAgICAgIHZpZXdCb3g9XCI1IDAgNTAgMTdcIlxuICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgPlxuICAgICAgPGNpcmNsZVxuICAgICAgICByPVwiNS40OTY3MVwiXG4gICAgICAgIHRyYW5zZm9ybT1cIm1hdHJpeCgtMSAwIDAgMSA4LjAyMjM0IDUuNzk5MjMpXCJcbiAgICAgICAgZmlsbD1cIiNGRjg3N0FcIlxuICAgICAgLz5cbiAgICAgIDxjaXJjbGVcbiAgICAgICAgcj1cIjIuNTI1NTFcIlxuICAgICAgICB0cmFuc2Zvcm09XCJtYXRyaXgoLTEgMCAwIDEgMi41MjU3NSAxNC4zNDUzKVwiXG4gICAgICAgIGZpbGw9XCIjRkY4NzdBXCJcbiAgICAgIC8+XG4gICAgICA8cGF0aCBkPVwiTTE4LjQ1ODUgMFYxNS42NTgySDIwLjMxNjJWMEgxOC40NTg1WlwiIGZpbGw9XCIjMzc0MTQ2XCIgLz5cbiAgICAgIDxwYXRoXG4gICAgICAgIGQ9XCJNMjMuNjQzNSA0LjUxMTY4VjE1LjY1ODJIMjUuNTAxM1Y0LjUxMTY4SDIzLjY0MzVaTTIzLjE3OTEgMS40MTU0M0MyMy4xNzkxIDIuMTg5NDkgMjMuNzc2MiAyLjc4NjYyIDI0LjU3MjQgMi43ODY2MkMyNS4zNjg2IDIuNzg2NjIgMjUuOTY1NyAyLjE4OTQ5IDI1Ljk2NTcgMS40MTU0M0MyNS45NjU3IDAuNjE5MjUgMjUuMzY4NiAwIDI0LjU3MjQgMEMyMy43NzYyIDAgMjMuMTc5MSAwLjYxOTI1IDIzLjE3OTEgMS40MTU0M1pcIlxuICAgICAgICBmaWxsPVwiIzM3NDE0NlwiXG4gICAgICAvPlxuICAgICAgPHBhdGhcbiAgICAgICAgZD1cIk0zNy42MjkyIDcuODA2OTdDMzcuNjI5MiA1LjU5NTM2IDM2LjM5MDYgNC4zMzQ3NSAzNC4zNTYgNC4zMzQ3NUMzMi44MDc4IDQuMzM0NzUgMzEuNDgwOSA1LjEzMDkzIDMwLjY2MjYgNi41Njg0N1Y0LjUxMTY4SDI4LjgwNDhWMTUuNjU4MkgzMC42NjI2VjEwLjk5MTdDMzAuNjYyNiA3Ljg5NTQzIDMyLjE4ODYgNi4wMTU1NyAzMy44NDczIDYuMDE1NTdDMzUuMDg1OCA2LjAxNTU3IDM1Ljc3MTQgNi43Njc1MSAzNS43NzE0IDguMjkzNTJWMTUuNjU4MkgzNy42MjkyVjcuODA2OTdaXCJcbiAgICAgICAgZmlsbD1cIiMzNzQxNDZcIlxuICAgICAgLz5cbiAgICAgIDxwYXRoXG4gICAgICAgIGQ9XCJNNDIuNDM3MyAxMi40NTEzQzQyLjQzNzMgMTEuMTkwNyA0My40OTg5IDEwLjQ4MyA0NS40MDA5IDEwLjQ4M0g0Ny4zOTEzVjEwLjc0ODRDNDcuMzkxMyAxMy4yNjk2IDQ1LjcxMDUgMTQuMTU0MyA0NC4yNzMgMTQuMTU0M0M0My4xMDA4IDE0LjE1NDMgNDIuNDM3MyAxMy41MTI5IDQyLjQzNzMgMTIuNDUxM1pNNDkuMjQ5MSA4LjUzNjhDNDkuMjQ5MSA1LjU3MzI1IDQ3LjQxMzQgNC4zMzQ3NSA0NC45NTg2IDQuMzM0NzVDNDIuODU3NSA0LjMzNDc1IDQxLjMwOTQgNS41MDY5IDQwLjk5OTggNy4zODY3Nkw0Mi42MzY0IDcuNzYyNzRDNDIuODc5NiA2LjY1NjkzIDQzLjgwODUgNi4wMTU1NyA0NC45NTg2IDYuMDE1NTdDNDYuMzA3NiA2LjAxNTU3IDQ3LjM5MTMgNi41OTA1OSA0Ny4zOTEzIDguMzE1NjRWOC44MDIxOUg0NS41Nzc4QzQyLjUyNTggOC44MDIxOSA0MC41MzUzIDEwLjA2MjggNDAuNTM1MyAxMi40NTEzQzQwLjUzNTMgMTQuODM5OSA0Mi4xMjc3IDE1LjgzNTEgNDMuOTg1NCAxNS44MzUxQzQ1LjY0NDIgMTUuODM1MSA0Ni43NzIxIDE1LjEwNTMgNDcuNDc5OCAxNC4wODc5TDQ3Ljc4OTQgMTUuNjU4Mkg0OS4yNDkxVjguNTM2OFpcIlxuICAgICAgICBmaWxsPVwiIzM3NDE0NlwiXG4gICAgICAvPlxuICAgIDwvc3ZnPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgTG9nbztcbiIsIi8qKlxuICogQ29tcG9uZW50IGRpc3BsYXlpbmcgRHIuIFBhdGVsIGFuZCBEci4gUGF0aWxcbiAqIFRPRE86IENhbiBpbmNsdWRlIG1vcmUgcGVvcGxlICsgYSBsaW5rIHRvIGV2ZXJ5b25lXG4gKi9cbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuaW50ZXJmYWNlIFByb3BzIHsgfVxuXG5jb25zdCBQcmFjdGl0aW9uZXJDYXJkOiBSZWFjdC5GQzx7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgaW1hZ2VVcmw6IHN0cmluZztcbn0+ID0gKHsgdGl0bGUsIG5hbWUsIGltYWdlVXJsLCBjaGlsZHJlbiB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgc29saWQgc2hhZG93LWxnIHJvdW5kZWQtbGcgcC04IG1heC13LW1kIG1kOm1heC13LWxnXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWItNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTYgdy0xNiBtci00XCI+XG4gICAgICAgICAgPGltZyBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYm9yZGVyIGItMlwiIHNyYz17aW1hZ2VVcmx9IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14bFwiPntuYW1lfTwvaDM+XG4gICAgICAgICAgPGg2IGNsYXNzTmFtZT1cInRleHQtYmx1ZS00MDBcIj57dGl0bGV9PC9oNj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIlwiPntjaGlsZHJlbn08L3A+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5jb25zdCBNZWRpY2FsVGVhbTogUmVhY3QuRkM8UHJvcHM+ID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIG1kOnRleHQtNHhsIHRleHQtY2VudGVyIG1iLThcIj5cbiAgICAgICAgICBZb3VyIG1lZGljYWwgdGVhbVxuICAgICAgICA8L2gyPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktY2VudGVyIHNwYWNlLXktOCBtZDpzcGFjZS15LTAgbWQ6c3BhY2UteC04XCI+XG4gICAgICAgIDxQcmFjdGl0aW9uZXJDYXJkXG4gICAgICAgICAgbmFtZT1cIkRyLiBWaWxhcyBKLiBQYXRpbFwiXG4gICAgICAgICAgdGl0bGU9XCJNRFwiXG4gICAgICAgICAgaW1hZ2VVcmw9XCIvaW1hZ2VzL3Byb3ZpZGVycy9kcl9wYXRpbC5qcGdcIlxuICAgICAgICA+XG4gICAgICAgICAgRHIuIFBhdGlsIGhhcyAzMiB5ZWFycyBvZiBleHBlcmllbmNlIHRyZWF0aW5nIGFueGlldHksIGRlcHJlc3Npb24sXG4gICAgICAgICAgQURIRCwgYW5kIG90aGVyIHBzeWNoaWF0cmljIGNvbmRpdGlvbnMuIEhlIGlzIDxpPnF1YWRydXBsZTwvaT4gYm9hcmRcbiAgICAgICAgICBjZXJ0aWZpZWQgYnkgdGhlIEFtZXJpY2FuIEJvYXJkIG9mIFBzeWNoaWF0cnkgaW4gYWR1bHQsIGdlcmlhdHJpYywgYW5kXG4gICAgICAgICAgYWRkaWN0aW9uIHBzeWNoaWF0cnkgYWxvbmcgd2l0aCBoaXMgc3BlY2lhbGl6YXRpb24gaW4gY2hpbGRcbiAgICAgICAgICBwc3ljaGlhdHJ5LiBIZSBzZXJ2ZWQgYXMgY2hpZWYgb2YgcHN5Y2hpYXRyeSBmb3IgT3N3ZW8gSG9zcGl0YWwgZm9yIDEzXG4gICAgICAgICAgeWVhcnMuXG4gICAgICAgIDwvUHJhY3RpdGlvbmVyQ2FyZD5cbiAgICAgICAgPFByYWN0aXRpb25lckNhcmRcbiAgICAgICAgICBuYW1lPVwiRHIuIEthcnRpayBQYXRlbFwiXG4gICAgICAgICAgdGl0bGU9XCJNRFwiXG4gICAgICAgICAgaW1hZ2VVcmw9XCIvaW1hZ2VzL3Byb3ZpZGVycy9wYXRlbC5qcGdcIlxuICAgICAgICA+XG4gICAgICAgICAgRHIuIFBhdGVsIGhhcyA5IHllYXJzIG9mIGV4cGVyaWVuY2UgaW4gaGVhbHRoY2FyZSBhbmQgaXNcbiAgICAgICAgICBib2FyZC1jZXJ0aWZpZWQgaW4gSW50ZXJuYWwgTWVkaWNpbmUuIEhpcyBleHBlcmllbmNlIGVuY29tcGFzc2VzXG4gICAgICAgICAgaW5wYXRpZW50LCBhbWJ1bGF0b3J5LCBhbmQgdGVsZWhlYWx0aCBwYXRpZW50IGNhcmUuIEhlIGhhcyB3b3JrZWQgb25cbiAgICAgICAgICBwcm9qZWN0cyBzcGFubmluZyBhY3Jvc3MgcHJvY2VzcyBpbXByb3ZlbWVudCwgcXVhbGl0eSBpbXByb3ZlbWVudCwgYW5kXG4gICAgICAgICAgb3BlcmF0aW9ucyB0byBoZWxwIGltcHJvdmUgcGF0aWVudCBjYXJlLlxuICAgICAgICA8L1ByYWN0aXRpb25lckNhcmQ+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IE1lZGljYWxUZWFtO1xuIiwiLyoqXG4gKiBTaG93cyB0aGUgc3RlcHMgZm9yIHRoZSBjYXJlIHByb2Nlc3MuIFwibmV3XCIgcHJlZml4IGlzXG4gKiBhIHJlbGljIG9mIHdoZW4gd2UgaGFkIHR3byBvcHRpb25zXG4gKi9cbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuaW50ZXJmYWNlIFByb3BzIHsgfVxuXG5jb25zdCBTdGVwTnVtYmVyOiBSZWFjdC5GQyA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNlbnRlclwiPlxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1jb3JhbC0zMDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyICB3LTE0IGgtMTQgbWQ6dy0xNiBtZDpoLTE2IGJnLXNlYXNoZWxsIHJvdW5kZWQtZnVsbCB0ZXh0LWNvcmFsIHRleHQteGwgZm9udC1ib2xkXCI+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvc3Bhbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmNvbnN0IExpbmU6IFJlYWN0LkZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2VudGVyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWNvcmFsIGgtMTJcIiBzdHlsZT17eyB3aWR0aDogXCIycHhcIiB9fT48L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmNvbnN0IE5ld0NhcmVQcm9jZXNzOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBoZWFkaW5nLCBkYXRhIH0pID0+IHtcbiAgY29uc29sZS5sb2coJ0hlYWRpbmcgaW5zaWRlJywgZGF0YSlcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTJcIj5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBtZDp0ZXh0LTR4bCB0ZXh0LWNlbnRlciBtZDp0ZXh0LWxlZnQgbWItOFwiPlxuICAgICAgICB7aGVhZGluZyA/IGhlYWRpbmcgOiAnT3VyIGNhcmUgcHJvY2Vzcyd9XG4gICAgICA8L2gxPlxuICAgICAgPGRpdj5cbiAgICAgICAgey8qIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LTJ4bCBtYi04XCI+R2V0dGluZyBTdGFydGVkPC9oMj4gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAteS0yIG1kOmdhcC15LTQgZ2FwLXgtMSBtYi0yMCBtZDptYi0wXCI+XG5cbiAgICAgICAgICB7IGRhdGEgJiYgZGF0YS5tYXAoKHtmaWVsZHN9LCBpbmRleCk9PntcbiAgICAgICAgICAgIHJldHVybihcbiAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPFN0ZXBOdW1iZXI+e2luZGV4KzF9e2RhdGEubGVuZ3RofTwvU3RlcE51bWJlcj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTIgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e2ZpZWxkcy5jYXJlUHJvY2Vzc05hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbVwiPntmaWVsZHMuY2FyZVByb2Nlc3NEZXNjcmlwdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAge2RhdGEubGVuZ3RoICE9IGluZGV4KzEgJiYgPExpbmUgLz59XG4gICAgICAgICAgICAgICAgPGRpdiAvPlxuICAgICAgICAgICAgICA8Lz4gXG4gICAgICAgICAgICApIFxuICAgICAgICAgIH0pfVxuICAgICAgICAgIHsvKiA8U3RlcE51bWJlcj4xPC9TdGVwTnVtYmVyPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTEyIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPkZyZWUgQXNzZXNzbWVudDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc21cIj5JdCBvbmx5IHRha2VzIDUgbWludXRlcy48L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPExpbmUgLz5cbiAgICAgICAgICA8ZGl2IC8+XG5cbiAgICAgICAgICA8U3RlcE51bWJlcj4yPC9TdGVwTnVtYmVyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xMiBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5BcHBvaW50bWVudDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc21cIj5cbiAgICAgICAgICAgICAgTWVldCB3aXRoIGEgY2xpbmljaWFuIGZyb20gdGhlIGNvbWZvcnQgb2YgeW91ciBob21lLlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxMaW5lIC8+XG4gICAgICAgICAgPGRpdiAvPlxuXG4gICAgICAgICAgPFN0ZXBOdW1iZXI+MzwvU3RlcE51bWJlcj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTIgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIFwiPlByZXNjcmlwdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc21cIj5cbiAgICAgICAgICAgICAgRlJFRSBtZWRpY2F0aW9uIGFuZCBkZWxpdmVyeSBpbiAyLTMgYnVzaW5lc3MgZGF5cy5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8TGluZSAvPlxuICAgICAgICAgIDxkaXYgLz5cblxuICAgICAgICAgIDxTdGVwTnVtYmVyPjQ8L1N0ZXBOdW1iZXI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTEyIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBcIj5SZWd1bGFyIENoZWNrLWluczwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc21cIj5cbiAgICAgICAgICAgICAgR2V0IHJlZmlsbHMsIGNoZWNrIGluIHdpdGggeW91ciBwcm92aWRlciwgYW5kIHRyYWNrIHlvdXIgcHJvZ3Jlc3NcbiAgICAgICAgICAgICAgLSBhbGwgYXQgeW91ciBvd24gcGFjZS5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IC8+ICovfVxuXG5cbiAgICAgICAgICA8ZGl2IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIG14LTRcIj5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBtZDp0ZXh0LTR4bCB0ZXh0LWNlbnRlciBtZDp0ZXh0LWxlZnRcIj5cbiAgICAgICAgICBPdXIgY2FyZSBwcm9jZXNzXG4gICAgICAgIDwvaDE+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6LW10LTggZ3JpZCBncmlkLWNvbHMtMiBzcGFjZS15LTE2XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciAgaXRlbXMtY2VudGVyIHB4LTRcIj5cbiAgICAgICAgICA8aW1nIHNyYz1cIi9pbWFnZXMvYXNzZXNzbWVudC5zdmdcIiBjbGFzc05hbWU9XCJtci00IG10LTEyXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXcteHNcIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBtYi00XCI+UGVyc29uYWxpemVkIEFzc2Vzc21lbnRzPC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9wYWNpdHktNzBcIj5cbiAgICAgICAgICAgIEluIDEwIG1pbnV0ZXMsIHdlJmFwb3M7bGwgZ2V0IHRvIGtub3cgeW91IGFuZCBzdWdnZXN0IGEgcHJvdmlkZXJcbiAgICAgICAgICAgIHRoYXQgZml0cyB5b3VyIHVuaXF1ZSBuZWVkcy5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB4LTRcIj5cbiAgICAgICAgICA8aW1nIHNyYz1cIi9pbWFnZXMvYXBwb2ludG1lbnQuc3ZnXCIgY2xhc3NOYW1lPVwibXItNFwiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LXhzXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgbWItNFwiPkNvbnZlbmllbnQgQXBwb2ludG1lbnRzPC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9wYWNpdHktNzBcIj5cbiAgICAgICAgICAgIE1lZXQgd2l0aCBhIGNsaW5pY2lhbiBmcm9tIHRoZSBjb21mb3J0IG9mIHlvdXIgaG9tZS5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB4LTRcIj5cbiAgICAgICAgICA8aW1nIHNyYz1cIi9pbWFnZXMvcHJlc2NyaXB0aW9uLnN2Z1wiIGNsYXNzTmFtZT1cIm1yLTRcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy14c1wiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIG1iLTRcIj5GcmVlIERlbGl2ZXJ5PC9oMz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9wYWNpdHktNzBcIj5cbiAgICAgICAgICAgIEZSRUUgbWVkaWNpbmUgZGVsaXZlcnkgaW4gMi0zIGJ1c2luZXNzIGRheXMuXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBOZXdDYXJlUHJvY2VzcztcbiIsIi8qKlxuICogQ29tcG9uZW50IHRvIGRpc3BsYXkgcHJpY2luZyBvbiB0aGUgbGFuZGluZyBwYWdlXG4gKi9cbmltcG9ydCBJbWFnZSBmcm9tIFwibmV4dC9pbWFnZVwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IENUQUJ1dHRvbiBmcm9tIFwiLi9DVEFCdXR0b25cIjtcblxuaW50ZXJmYWNlIFByb3BzIHsgfVxuXG5jb25zdCBDaGVja21hcmsgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgd2lkdGg9XCIxNlwiXG4gICAgICBoZWlnaHQ9XCIxNFwiXG4gICAgICB2aWV3Qm94PVwiMCAwIDE2IDE0XCJcbiAgICAgIGZpbGw9XCJub25lXCJcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgY2xhc3NOYW1lPVwibWwtNCBtZDptbC0wIG1yLTQgZmxleC1zaHJpbmstMFwiXG4gICAgPlxuICAgICAgPHBhdGhcbiAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgZD1cIk02Ljg0Nzk5IDEzLjE5NjhMMTUuNjkyNCAxLjUxODM1TDE0LjA2MjcgMC4yODQxOEw2LjQ0NTU1IDEwLjM0MjFMMS45Mzg4NSA3LjEzNjI0TDAuNzUzOTA2IDguODAxOTZMNi44NDc5OSAxMy4xOTY4WlwiXG4gICAgICAgIGZpbGw9XCIjMzc0MTQ2XCJcbiAgICAgIC8+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuXG5jb25zdCBQcmljaW5nOiBSZWFjdC5GQzxQcm9wcz4gPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOnB5LTEyXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6aGlkZGVuIHotMTAgYWJzb2x1dGUgdC0wIGgtZnVsbCB3LWZ1bGwgYmctYmxhY2sgb3BhY2l0eS0zMFwiIC8+XG4gICAgICAgIDxoMVxuICAgICAgICAgIGNsYXNzTmFtZT1cInotMzAgYmxvY2sgbWQ6aGlkZGVuIGFic29sdXRlIHQtMCBoLWZ1bGwgdy1mdWxsIHRleHQtY2VudGVyIHRleHQtd2hpdGUgdGV4dC0zeGwgbWQ6dGV4dC00eGwgbWItMTJcIlxuICAgICAgICAgIHN0eWxlPXt7IHRvcDogXCI0NSVcIiwgYm90dG9tOiBcIjUwJVwiIH19XG4gICAgICAgID5cbiAgICAgICAgICBJdCZhcG9zO3MgdGltZSB0byBiZSB5b3Vyc2VsZiBhZ2Fpbi5cbiAgICAgICAgPC9oMT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTk2IG1kOmhpZGRlblwiPlxuICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaW1hZ2VzL3ByaWNpbmdfaW1hZ2VfMy5qcGVnXCIgbGF5b3V0PVwiZmlsbFwiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTQgbWQ6cHgtMTAgcHktMTIgbWQ6cHktNCBtZDptYXgtdy14bCBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIG14LWF1dG9cIj5cbiAgICAgICAgey8qIDxoMSBjbGFzc05hbWU9XCJoaWRkZW4gbGc6YmxvY2sgdGV4dC0zeGwgbWQ6dGV4dC00eGwgbWItOFwiPlxuICAgICAgICAgIEFmZm9yZGFibGUgcGxhbnMgdG8gaGVscCB5b3UgZmVlbCBiZXR0ZXJcbiAgICAgICAgPC9oMT4gKi99XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LTN4bCBtZDp0ZXh0LTR4bCBtYi04XCI+XG4gICAgICAgICAgQWZmb3JkYWJsZSBwbGFucyB0byBoZWxwIHlvdSBmZWVsIGJldHRlclxuICAgICAgICA8L2gxPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIHRleHQtY2VudGVyIG1iLTIgZm9udC1ib2xkXCI+XG4gICAgICAgICAgU3RhcnRpbmcgYXMgbG93IGFzIDxzPiQ5NTwvcz4gJDUgZm9yIHlvdXIgZmlyc3QgbW9udGguXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtc20gbWItMTBcIj5cbiAgICAgICAgICBKdXN0ICQ5NSBhIG1vbnRoIGFmdGVyIHRoYXQuXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDx1bCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC15LTIgbWItOCB3LWZ1bGwgbXgtYXV0byBtZDp3LTQvNVwiPlxuICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgPENoZWNrbWFyayAvPlxuICAgICAgICAgICAgVW5saW1pdGVkIHZpZGVvIGNvbnN1bHRhdGlvbnMgd2l0aCB5b3VyIHByb3ZpZGVyXG4gICAgICAgICAgPC9saT5cbiAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxDaGVja21hcmsgLz5cbiAgICAgICAgICAgIFVubGltaXRlZCBtZXNzYWdpbmcgd2l0aCB5b3VyIHByb3ZpZGVyXG4gICAgICAgICAgPC9saT5cbiAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxDaGVja21hcmsgLz5cbiAgICAgICAgICAgIEZyZWUgbWVkaWNhdGlvbiBkZWxpdmVyeSB0byB5b3VyIGRvb3JcbiAgICAgICAgICA8L2xpPlxuICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgPENoZWNrbWFyayAvPlxuICAgICAgICAgICAgUmVndWxhciBwcm9ncmVzcyB0cmFja2luZ1xuICAgICAgICAgIDwvbGk+XG4gICAgICAgIDwvdWw+XG4gICAgICAgIDxDVEFCdXR0b24gY2xhc3NOYW1lPVwidy03MiBtZDp3LWZ1bGwgbXgtYXV0b1wiPlxuICAgICAgICAgIFN0YXJ0IGZyZWUgYXNzZXNzbWVudFxuICAgICAgICA8L0NUQUJ1dHRvbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIEluc3VyYW5jZSBhY2NlcHRlZCwgYnV0IG5vdCBuZWVkZWQuXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICBFYXN5IG91dCBvZiBuZXR3b3JrIGNsYWltcy4gSFNBL0ZTQSBlbGlnaWJsZS4gTWVkaWNhdGlvbnMgZWxpZ2libGUgZm9yXG4gICAgICAgICAgaW5zdXJhbmNlIGNvdmVyYWdlIGFyZSBiaWxsZWQgc2VwYXJhdGVseS5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFByaWNpbmc7XG4iLCIvKipcbiAqIFVzZWQgdG8gZGVub2F0ZSBhIHNlY3Rpb24gb24gdGhlIGxhbmRpbmcgcGFnZVxuICovXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgY3ggZnJvbSBcImNsYXNzbmFtZXNcIjtcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgLy8gaWQgdGFnIGZvciB0aGUgc2VjdGlvblxuICBpZD86IHN0cmluZztcbiAgLy8gYW55IENTUyBjbGFzc2VzIHRvIGFwcGx5LCBpZiBhcHBsaWNhYmxlXG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgLy8gd2hldGhlciB0byByZW1vdmUgcGFkZGluZ1xuICBub1BhZGRpbmc/OiBib29sZWFuO1xuICAvLyBvcHRpb25hbCBDU1MgcHJvcGVydGllc1xuICBzdHlsZT86IFJlYWN0LkNTU1Byb3BlcnRpZXM7XG59XG5cbmNvbnN0IFNlY3Rpb246IFJlYWN0LkZDPFByb3BzPiA9ICh7XG4gIGNoaWxkcmVuLFxuICBjbGFzc05hbWUsXG4gIG5vUGFkZGluZyxcbiAgLi4ub3RoZXJQcm9wc1xufSkgPT4ge1xuICBjb25zdCBjb21iaW5lZENsYXNzID0gY3goIW5vUGFkZGluZyA/IFwicHktMTIgbWQ6cHktMjggcHgtNlwiIDogXCJcIiwgY2xhc3NOYW1lKTtcbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9e2NvbWJpbmVkQ2xhc3N9IHsuLi5vdGhlclByb3BzfT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTZWN0aW9uO1xuIiwiLyoqXG4gKiBTVkcgZGlzcGxheWluZyA1IHBvaW50ZWQgc3RhcnMgb24gdGhlIGxhbmRpbmcgcGFnZVxuICovXG5cbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuaW50ZXJmYWNlIFByb3BzIHsgfVxuXG5jb25zdCBTaGFycFN0YXJzOiBSZWFjdC5GQzxQcm9wcz4gPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPHN2Z1xuICAgICAgd2lkdGg9XCIxMjhcIlxuICAgICAgaGVpZ2h0PVwiMjFcIlxuICAgICAgdmlld0JveD1cIjAgMCAxMjggMjFcIlxuICAgICAgZmlsbD1cIm5vbmVcIlxuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgPlxuICAgICAgPHBhdGhcbiAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgZD1cIk0xMS4xODkyIDAuNzE5NzkxQzExLjA5OTQgMC43MjQxNTIgMTEuMDEzMSAwLjc1NTY5OCAxMC45NDE2IDAuODEwMjY3QzEwLjg3MDIgMC44NjQ4MzUgMTAuODE3IDAuOTM5ODQ0IDEwLjc4OTEgMS4wMjUzM0w4LjU2MzI2IDcuNzAzNjhIMS40MzQ2NUMxLjM0MTQyIDcuNzAzOTggMS4yNTA2NSA3LjczMzY2IDEuMTc1MjUgNy43ODg1MUMxLjA5OTg2IDcuODQzMzYgMS4wNDM2NyA3LjkyMDU3IDEuMDE0NjcgOC4wMDkxOUMwLjk4NTY3MSA4LjA5NzgxIDAuOTg1MzQgOC4xOTMzMSAxLjAxMzcyIDguMjgyMTJDMS4wNDIxMSA4LjM3MDk0IDEuMDk3NzYgOC40NDg1NCAxLjE3Mjc4IDguNTAzOTFMNi45NjI5NiAxMi43Mzc5TDQuNzM3MDkgMTkuNjQ5QzQuNzA4MTIgMTkuNzM4MiA0LjcwODE3IDE5LjgzNDMgNC43MzcyNSAxOS45MjM1QzQuNzY2MzIgMjAuMDEyNyA0LjgyMjkyIDIwLjA5MDQgNC44OTg5MSAyMC4xNDUzQzQuOTc0OSAyMC4yMDAzIDUuMDY2MzUgMjAuMjI5OCA1LjE2MDE0IDIwLjIyOTVDNS4yNTM5MiAyMC4yMjkyIDUuMzQ1MiAyMC4xOTkyIDUuNDIwODUgMjAuMTQzN0wxMS4yMTEgMTUuOTA5OEwxNy4wMDEyIDIwLjE0MzdDMTcuMDc2OSAyMC4xOTkyIDE3LjE2ODIgMjAuMjI5MiAxNy4yNjE5IDIwLjIyOTVDMTcuMzU1NyAyMC4yMjk4IDE3LjQ0NzIgMjAuMjAwMyAxNy41MjMyIDIwLjE0NTNDMTcuNTk5MiAyMC4wOTA0IDE3LjY1NTggMjAuMDEyNyAxNy42ODQ4IDE5LjkyMzVDMTcuNzEzOSAxOS44MzQzIDE3LjcxNCAxOS43MzgyIDE3LjY4NSAxOS42NDlMMTUuNDU5MSAxMi43Mzc5TDIxLjI0OTMgOC41MDM5MUMyMS4zMjQzIDguNDQ4NTQgMjEuMzggOC4zNzA5NCAyMS40MDgzIDguMjgyMTJDMjEuNDM2NyA4LjE5MzMxIDIxLjQzNjQgOC4wOTc4MSAyMS40MDc0IDguMDA5MTlDMjEuMzc4NCA3LjkyMDU3IDIxLjMyMjIgNy44NDMzNiAyMS4yNDY4IDcuNzg4NTFDMjEuMTcxNCA3LjczMzY2IDIxLjA4MDcgNy43MDM5OCAyMC45ODc0IDcuNzAzNjhIMTMuODU4OEwxMS42MzI5IDEuMDI1MzNDMTEuNjAyOCAwLjkzMjc0NSAxMS41NDMgMC44NTI2NiAxMS40NjI4IDAuNzk3NDM4QzExLjM4MjYgMC43NDIyMTYgMTEuMjg2NSAwLjcxNDkzMiAxMS4xODkyIDAuNzE5NzkxWlwiXG4gICAgICAgIGZpbGw9XCIjMzc0MTQ2XCJcbiAgICAgIC8+XG4gICAgICA8cGF0aFxuICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxuICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxuICAgICAgICBkPVwiTTY0LjE5MTIgMC43MTk3OTFDNjQuMTAxNCAwLjcyNDE1MiA2NC4wMTUgMC43NTU2OTggNjMuOTQzNiAwLjgxMDI2N0M2My44NzIxIDAuODY0ODM1IDYzLjgxODkgMC45Mzk4NDQgNjMuNzkxMSAxLjAyNTMzTDYxLjU2NTIgNy43MDM2OEg1NC40MzY2QzU0LjM0MzQgNy43MDM5OCA1NC4yNTI2IDcuNzMzNjYgNTQuMTc3MiA3Ljc4ODUxQzU0LjEwMTggNy44NDMzNiA1NC4wNDU2IDcuOTIwNTcgNTQuMDE2NiA4LjAwOTE5QzUzLjk4NzYgOC4wOTc4MSA1My45ODczIDguMTkzMzEgNTQuMDE1NyA4LjI4MjEyQzU0LjA0NDEgOC4zNzA5NCA1NC4wOTk3IDguNDQ4NTQgNTQuMTc0NyA4LjUwMzkxTDU5Ljk2NDkgMTIuNzM3OUw1Ny43MzkgMTkuNjQ5QzU3LjcxMDEgMTkuNzM4MiA1Ny43MTAxIDE5LjgzNDMgNTcuNzM5MiAxOS45MjM1QzU3Ljc2ODMgMjAuMDEyNyA1Ny44MjQ5IDIwLjA5MDQgNTcuOTAwOSAyMC4xNDUzQzU3Ljk3NjggMjAuMjAwMyA1OC4wNjgzIDIwLjIyOTggNTguMTYyMSAyMC4yMjk1QzU4LjI1NTkgMjAuMjI5MiA1OC4zNDcyIDIwLjE5OTIgNTguNDIyOCAyMC4xNDM3TDY0LjIxMyAxNS45MDk4TDcwLjAwMzIgMjAuMTQzN0M3MC4wNzg4IDIwLjE5OTIgNzAuMTcwMSAyMC4yMjkyIDcwLjI2MzkgMjAuMjI5NUM3MC4zNTc3IDIwLjIyOTggNzAuNDQ5MSAyMC4yMDAzIDcwLjUyNTEgMjAuMTQ1M0M3MC42MDExIDIwLjA5MDQgNzAuNjU3NyAyMC4wMTI3IDcwLjY4NjggMTkuOTIzNUM3MC43MTU5IDE5LjgzNDMgNzAuNzE1OSAxOS43MzgyIDcwLjY4NjkgMTkuNjQ5TDY4LjQ2MTEgMTIuNzM3OUw3NC4yNTEzIDguNTAzOTFDNzQuMzI2MyA4LjQ0ODU0IDc0LjM4MTkgOC4zNzA5NCA3NC40MTAzIDguMjgyMTJDNzQuNDM4NyA4LjE5MzMxIDc0LjQzODQgOC4wOTc4MSA3NC40MDk0IDguMDA5MTlDNzQuMzgwNCA3LjkyMDU3IDc0LjMyNDIgNy44NDMzNiA3NC4yNDg4IDcuNzg4NTFDNzQuMTczNCA3LjczMzY2IDc0LjA4MjYgNy43MDM5OCA3My45ODk0IDcuNzAzNjhINjYuODYwOEw2NC42MzQ5IDEuMDI1MzNDNjQuNjA0NyAwLjkzMjc0NSA2NC41NDQ5IDAuODUyNjYgNjQuNDY0NyAwLjc5NzQzOEM2NC4zODQ2IDAuNzQyMjE2IDY0LjI4ODQgMC43MTQ5MzIgNjQuMTkxMiAwLjcxOTc5MVpcIlxuICAgICAgICBmaWxsPVwiIzM3NDE0NlwiXG4gICAgICAvPlxuICAgICAgPHBhdGhcbiAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgZD1cIk0zNy42OTAyIDAuNzE5NzkxQzM3LjYwMDQgMC43MjQxNTIgMzcuNTE0IDAuNzU1Njk4IDM3LjQ0MjYgMC44MTAyNjdDMzcuMzcxMSAwLjg2NDgzNSAzNy4zMTggMC45Mzk4NDQgMzcuMjkwMSAxLjAyNTMzTDM1LjA2NDIgNy43MDM2OEgyNy45MzU2QzI3Ljg0MjQgNy43MDM5OCAyNy43NTE2IDcuNzMzNjYgMjcuNjc2MiA3Ljc4ODUxQzI3LjYwMDggNy44NDMzNiAyNy41NDQ2IDcuOTIwNTcgMjcuNTE1NiA4LjAwOTE5QzI3LjQ4NjYgOC4wOTc4MSAyNy40ODYzIDguMTkzMzEgMjcuNTE0NyA4LjI4MjEyQzI3LjU0MzEgOC4zNzA5NCAyNy41OTg3IDguNDQ4NTQgMjcuNjczOCA4LjUwMzkxTDMzLjQ2MzkgMTIuNzM3OUwzMS4yMzgxIDE5LjY0OUMzMS4yMDkxIDE5LjczODIgMzEuMjA5MSAxOS44MzQzIDMxLjIzODIgMTkuOTIzNUMzMS4yNjczIDIwLjAxMjcgMzEuMzIzOSAyMC4wOTA0IDMxLjM5OTkgMjAuMTQ1M0MzMS40NzU5IDIwLjIwMDMgMzEuNTY3MyAyMC4yMjk4IDMxLjY2MTEgMjAuMjI5NUMzMS43NTQ5IDIwLjIyOTIgMzEuODQ2MiAyMC4xOTkyIDMxLjkyMTggMjAuMTQzN0wzNy43MTIgMTUuOTA5OEw0My41MDIyIDIwLjE0MzdDNDMuNTc3OSAyMC4xOTkyIDQzLjY2OTEgMjAuMjI5MiA0My43NjI5IDIwLjIyOTVDNDMuODU2NyAyMC4yMjk4IDQzLjk0ODIgMjAuMjAwMyA0NC4wMjQxIDIwLjE0NTNDNDQuMTAwMSAyMC4wOTA0IDQ0LjE1NjcgMjAuMDEyNyA0NC4xODU4IDE5LjkyMzVDNDQuMjE0OSAxOS44MzQzIDQ0LjIxNDkgMTkuNzM4MiA0NC4xODYgMTkuNjQ5TDQxLjk2MDEgMTIuNzM3OUw0Ny43NTAzIDguNTAzOTFDNDcuODI1MyA4LjQ0ODU0IDQ3Ljg4MDkgOC4zNzA5NCA0Ny45MDkzIDguMjgyMTJDNDcuOTM3NyA4LjE5MzMxIDQ3LjkzNzQgOC4wOTc4MSA0Ny45MDg0IDguMDA5MTlDNDcuODc5NCA3LjkyMDU3IDQ3LjgyMzIgNy44NDMzNiA0Ny43NDc4IDcuNzg4NTFDNDcuNjcyNCA3LjczMzY2IDQ3LjU4MTYgNy43MDM5OCA0Ny40ODg0IDcuNzAzNjhINDAuMzU5OEwzOC4xMzM5IDEuMDI1MzNDMzguMTAzOCAwLjkzMjc0NSAzOC4wNDQgMC44NTI2NiAzNy45NjM4IDAuNzk3NDM4QzM3Ljg4MzYgMC43NDIyMTYgMzcuNzg3NCAwLjcxNDkzMiAzNy42OTAyIDAuNzE5NzkxWlwiXG4gICAgICAgIGZpbGw9XCIjMzc0MTQ2XCJcbiAgICAgIC8+XG4gICAgICA8cGF0aFxuICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxuICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxuICAgICAgICBkPVwiTTkwLjY5MjYgMC43MTk3OTFDOTAuNjAyOCAwLjcyNDE1MiA5MC41MTY1IDAuNzU1Njk4IDkwLjQ0NSAwLjgxMDI2N0M5MC4zNzM2IDAuODY0ODM1IDkwLjMyMDQgMC45Mzk4NDQgOTAuMjkyNiAxLjAyNTMzTDg4LjA2NjcgNy43MDM2OEg4MC45MzgxQzgwLjg0NDggNy43MDM5OCA4MC43NTQxIDcuNzMzNjYgODAuNjc4NyA3Ljc4ODUxQzgwLjYwMzMgNy44NDMzNiA4MC41NDcxIDcuOTIwNTcgODAuNTE4MSA4LjAwOTE5QzgwLjQ4OTEgOC4wOTc4MSA4MC40ODg4IDguMTkzMzEgODAuNTE3MSA4LjI4MjEyQzgwLjU0NTUgOC4zNzA5NCA4MC42MDEyIDguNDQ4NTQgODAuNjc2MiA4LjUwMzkxTDg2LjQ2NjQgMTIuNzM3OUw4NC4yNDA1IDE5LjY0OUM4NC4yMTE1IDE5LjczODIgODQuMjExNiAxOS44MzQzIDg0LjI0MDcgMTkuOTIzNUM4NC4yNjk3IDIwLjAxMjcgODQuMzI2MyAyMC4wOTA0IDg0LjQwMjMgMjAuMTQ1M0M4NC40NzgzIDIwLjIwMDMgODQuNTY5OCAyMC4yMjk4IDg0LjY2MzYgMjAuMjI5NUM4NC43NTczIDIwLjIyOTIgODQuODQ4NiAyMC4xOTkyIDg0LjkyNDMgMjAuMTQzN0w5MC43MTQ1IDE1LjkwOThMOTYuNTA0NiAyMC4xNDM3Qzk2LjU4MDMgMjAuMTk5MiA5Ni42NzE2IDIwLjIyOTIgOTYuNzY1NCAyMC4yMjk1Qzk2Ljg1OTEgMjAuMjI5OCA5Ni45NTA2IDIwLjIwMDMgOTcuMDI2NiAyMC4xNDUzQzk3LjEwMjYgMjAuMDkwNCA5Ny4xNTkyIDIwLjAxMjcgOTcuMTg4MiAxOS45MjM1Qzk3LjIxNzMgMTkuODM0MyA5Ny4yMTc0IDE5LjczODIgOTcuMTg4NCAxOS42NDlMOTQuOTYyNSAxMi43Mzc5TDEwMC43NTMgOC41MDM5MUMxMDAuODI4IDguNDQ4NTQgMTAwLjg4MyA4LjM3MDk0IDEwMC45MTIgOC4yODIxMkMxMDAuOTQgOC4xOTMzMSAxMDAuOTQgOC4wOTc4MSAxMDAuOTExIDguMDA5MTlDMTAwLjg4MiA3LjkyMDU3IDEwMC44MjYgNy44NDMzNiAxMDAuNzUgNy43ODg1MUMxMDAuNjc1IDcuNzMzNjYgMTAwLjU4NCA3LjcwMzk4IDEwMC40OTEgNy43MDM2OEg5My4zNjIyTDkxLjEzNjQgMS4wMjUzM0M5MS4xMDYyIDAuOTMyNzQ1IDkxLjA0NjQgMC44NTI2NiA5MC45NjYyIDAuNzk3NDM4QzkwLjg4NiAwLjc0MjIxNiA5MC43ODk5IDAuNzE0OTMyIDkwLjY5MjYgMC43MTk3OTFaXCJcbiAgICAgICAgZmlsbD1cIiMzNzQxNDZcIlxuICAgICAgLz5cbiAgICAgIDxwYXRoXG4gICAgICAgIGZpbGxSdWxlPVwiZXZlbm9kZFwiXG4gICAgICAgIGNsaXBSdWxlPVwiZXZlbm9kZFwiXG4gICAgICAgIGQ9XCJNMTE3LjE5NCAwLjcxOTc5MUMxMTcuMTA0IDAuNzI0MTUyIDExNy4wMTcgMC43NTU2OTggMTE2Ljk0NiAwLjgxMDI2N0MxMTYuODc1IDAuODY0ODM1IDExNi44MjEgMC45Mzk4NDQgMTE2Ljc5NCAxLjAyNTMzTDExNC41NjggNy43MDM2OEgxMDcuNDM5QzEwNy4zNDYgNy43MDM5OCAxMDcuMjU1IDcuNzMzNjYgMTA3LjE4IDcuNzg4NTFDMTA3LjEwNCA3Ljg0MzM2IDEwNy4wNDggNy45MjA1NyAxMDcuMDE5IDguMDA5MTlDMTA2Ljk5IDguMDk3ODEgMTA2Ljk5IDguMTkzMzEgMTA3LjAxOCA4LjI4MjEyQzEwNy4wNDcgOC4zNzA5NCAxMDcuMTAyIDguNDQ4NTQgMTA3LjE3NyA4LjUwMzkxTDExMi45NjcgMTIuNzM3OUwxMTAuNzQxIDE5LjY0OUMxMTAuNzEzIDE5LjczODIgMTEwLjcxMyAxOS44MzQzIDExMC43NDIgMTkuOTIzNUMxMTAuNzcxIDIwLjAxMjcgMTEwLjgyNyAyMC4wOTA0IDExMC45MDMgMjAuMTQ1M0MxMTAuOTc5IDIwLjIwMDMgMTExLjA3MSAyMC4yMjk4IDExMS4xNjUgMjAuMjI5NUMxMTEuMjU4IDIwLjIyOTIgMTExLjM1IDIwLjE5OTIgMTExLjQyNSAyMC4xNDM3TDExNy4yMTUgMTUuOTA5OEwxMjMuMDA2IDIwLjE0MzdDMTIzLjA4MSAyMC4xOTkyIDEyMy4xNzMgMjAuMjI5MiAxMjMuMjY2IDIwLjIyOTVDMTIzLjM2IDIwLjIyOTggMTIzLjQ1MiAyMC4yMDAzIDEyMy41MjggMjAuMTQ1M0MxMjMuNjA0IDIwLjA5MDQgMTIzLjY2IDIwLjAxMjcgMTIzLjY4OSAxOS45MjM1QzEyMy43MTggMTkuODM0MyAxMjMuNzE4IDE5LjczODIgMTIzLjY4OSAxOS42NDlMMTIxLjQ2NCAxMi43Mzc5TDEyNy4yNTQgOC41MDM5MUMxMjcuMzI5IDguNDQ4NTQgMTI3LjM4NCA4LjM3MDk0IDEyNy40MTMgOC4yODIxMkMxMjcuNDQxIDguMTkzMzEgMTI3LjQ0MSA4LjA5NzgxIDEyNy40MTIgOC4wMDkxOUMxMjcuMzgzIDcuOTIwNTcgMTI3LjMyNyA3Ljg0MzM2IDEyNy4yNTEgNy43ODg1MUMxMjcuMTc2IDcuNzMzNjYgMTI3LjA4NSA3LjcwMzk4IDEyNi45OTIgNy43MDM2OEgxMTkuODYzTDExNy42MzcgMS4wMjUzM0MxMTcuNjA3IDAuOTMyNzQ1IDExNy41NDcgMC44NTI2NiAxMTcuNDY3IDAuNzk3NDM4QzExNy4zODcgMC43NDIyMTYgMTE3LjI5MSAwLjcxNDkzMiAxMTcuMTk0IDAuNzE5NzkxWlwiXG4gICAgICAgIGZpbGw9XCIjMzc0MTQ2XCJcbiAgICAgIC8+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTaGFycFN0YXJzO1xuIiwiLyoqXG4gKiBTaG93cyB0ZXN0aW1vbmlhbHMgb24gdGhlIGxhbmRpbmcgcGFnZVxuICovXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgU2hhcnBTdGFycyBmcm9tIFwiLi9TaGFycFN0YXJzXCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgVGVzdGltb25pYWw6IFJlYWN0LkZDPHsgdGl0bGU6IHN0cmluZzsgc3R5bGU6IFJlYWN0LkNTU1Byb3BlcnRpZXMgfT4gPSAoe1xuICB0aXRsZSxcbiAgY2hpbGRyZW4sXG4gIHN0eWxlLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cInAtOCBtYXgtdy1zbSBtYi00IHctZnVsbCBtZDp3LTk2IGZsZXgtc2hyaW5rLTBcIlxuICAgICAgc3R5bGU9e3N0eWxlfVxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgbWItOFwiPnt0aXRsZX08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkIG1iLThcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgICA8U2hhcnBTdGFycyAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuY29uc3QgdGVzdGltb25pYWxzID0gW1xuICA8VGVzdGltb25pYWxcbiAgICBrZXk9XCJ0ZXN0aW1vbmlhbC0yXCJcbiAgICB0aXRsZT1cIlBhdGllbnQgZnJvbSBNaWFtaVwiXG4gICAgc3R5bGU9e3tcbiAgICAgIGJhY2tncm91bmRDb2xvcjogXCJyZ2JhKDc3LCAxODgsIDE5NSwgMC4xKVwiLFxuICAgIH19XG4gID5cbiAgICBNeSBwcm92aWRlciB3YXMga2luZCBhbmQgY29uc2lkZXJhdGUuIEhlIGFza2VkIG1lIGEgbG90IG9mIHF1ZXN0aW9ucyB0byBnZXRcbiAgICB0byB0aGUgcm9vdCBvZiBteSBmZWVsaW5ncy4gVGhlIG1lZGljYXRpb24gc2hpcG1lbnQgd2FzIGFsc28gc3VwZXJcbiAgICBjb252ZW5pZW50IGZvciBtZS4gSSZhcG9zO20gc28gZ2xhZCBJIHdhcyBhYmxlIHRvIHF1aWNrbHkgYm9vayBhblxuICAgIGFwcG9pbnRtZW50IHdpdGggTGluYS5cbiAgPC9UZXN0aW1vbmlhbD4sXG4gIDxUZXN0aW1vbmlhbFxuICAgIGtleT1cInRlc3RpbW9uaWFsLTNcIlxuICAgIHRpdGxlPVwiUGF0aWVudCBmcm9tIFBlbnNhY29sYVwiXG4gICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBcInJnYmEoMjU1LCAyMTcsIDIwOCwgMC43KVwiIH19XG4gID5cbiAgICBJIHdhcyBhYmxlIHRvIGJvb2sgYW4gYXBwb2ludG1lbnQgd2l0aCBEci4gUCB3aXRoaW4gYSBkYXkuIEhlIHdhc1xuICAgIHVuZGVyc3RhbmRpbmcsIHN0cmFpZ2h0Zm9yd2FyZCwgYW5kIGNhcmluZy4gSGUgYW5zd2VyZWQgYWxsIG15IHF1ZXN0aW9ucyBhbmRcbiAgICBtYWRlIG1lIGZlZWwgY29uZmlkZW50IGFib3V0IG15IHRyZWF0bWVudC4gSXQmYXBvcztzIGJlZW4gYSBncmVhdCBleHBlcmllbmNlXG4gICAgc28gZmFyLlxuICA8L1Rlc3RpbW9uaWFsPixcbiAgPFRlc3RpbW9uaWFsXG4gICAga2V5PVwidGVzdGltb25pYWwtMVwiXG4gICAgdGl0bGU9XCJQYXRpZW50IGZyb20gVGFtcGEgQmF5XCJcbiAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwicmdiYSg3NywgMTg4LCAxOTUsIDAuMSlcIiB9fVxuICA+XG4gICAgVGVsZWhlYWx0aCBpcyBzbyBpbXBvcnRhbnQsIGl0IGVuYWJsZXMgcGVvcGxlIHRvIGdldCBjYXJlIHdpdGggYW4gYWN0dWFsXG4gICAgcGVyc29uIG92ZXIgdmlkZW8uIFNvbWV0aW1lcyB3ZSBjYW4mYXBvczt0IHBoeXNpY2FsbHkgZ2V0IHRvIGEgZG9jdG9yJmFwb3M7c1xuICAgIG9mZmljZSwgYnV0IG5vdyBMaW5hIG9mZmVycyBzb21ldGhpbmcgZm9yIGV2ZXJ5b25lIHdobyBjYW4mYXBvczt0IGRvXG4gICAgaW4tcGVyc29uLiBUaGFua3MgZm9yIGNyZWF0aW5nIHRoaXMgcGxhdGZvcm0hXG4gIDwvVGVzdGltb25pYWw+LFxuXTtcblxuY29uc3QgVGVzdGltb25pYWxzOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBoZWFkaW5nLCBkYXRhIH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3dcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6dy0xLzNcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIG1kOnRleHQtNHhsIHRleHQtY2VudGVyIG1kOnRleHQtbGVmdCBtYi04XCI+XG4gICAgICAgICAgICB7aGVhZGluZyA/IGhlYWRpbmcgOiAnTGlmZSBjaGFuZ2luZyByZXN1bHRzIGZyb20gcmVhbCBtZW1iZXJzJ30gICAgICAgICAgXG4gICAgICAgIDwvaDI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgbWQ6anVzdGlmeS1zdGFydCBtZDpmbGV4LXJvdyBvdmVyZmxvdy1hdXRvIG1kOnNwYWNlLXgtNFwiPlxuICAgICAgICB7dGVzdGltb25pYWxzfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBUZXN0aW1vbmlhbHM7XG4iLCIvKipcbiAqIFNob3dzIGxpc3Qgb2YgY29uZGl0aW9ucyB0cmVhdGVkLlxuICogdW51c2VkP1xuICovXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgQ2hlY2ttYXJrID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxzdmdcbiAgICAgIHdpZHRoPVwiMTZcIlxuICAgICAgaGVpZ2h0PVwiMTRcIlxuICAgICAgdmlld0JveD1cIjAgMCAxNiAxNFwiXG4gICAgICBmaWxsPVwibm9uZVwiXG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIGNsYXNzTmFtZT1cIm1sLTQgbWQ6bWwtMCBtci00IGZsZXgtc2hyaW5rLTAgdGV4dC1kYXJrR3JheVwiXG4gICAgPlxuICAgICAgPHBhdGhcbiAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcbiAgICAgICAgZD1cIk02Ljg0Nzk5IDEzLjE5NjhMMTUuNjkyNCAxLjUxODM1TDE0LjA2MjcgMC4yODQxOEw2LjQ0NTU1IDEwLjM0MjFMMS45Mzg4NSA3LjEzNjI0TDAuNzUzOTA2IDguODAxOTZMNi44NDc5OSAxMy4xOTY4WlwiXG4gICAgICAgIGZpbGw9XCIjMzc0MTQ2XCJcbiAgICAgIC8+XG4gICAgPC9zdmc+XG4gICk7XG59O1xuXG5jb25zdCBUcmVhdG1lbnRJdGVtOiBSZWFjdC5GQyA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgIDxDaGVja21hcmsgLz5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2xpPlxuICApO1xufTtcblxuY29uc3QgV2hhdFdlVHJlYXQ6IFJlYWN0LkZDPFByb3BzPiA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3dcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS8zXCI+XG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBtZDp0ZXh0LTR4bCB0ZXh0LWNlbnRlciBtZDp0ZXh0LWxlZnQgbWItOFwiPlxuICAgICAgICAgIEFueGlldHkgYW5kIGRlcHJlc3Npb24gY29tZSBpbiBtYW55IGZvcm1zXG4gICAgICAgIDwvaDE+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWQ6dGV4dC1sZWZ0XCI+XG4gICAgICAgICAgVGhhdCZhcG9zO3Mgd2h5IHdlIHNwZWNpYWxpemUgaW4gdHJlYXRpbmcgdGhlIGZ1bGwgc3BlY3RydW0gb2YgcmVsYXRlZFxuICAgICAgICAgIGNvbmRpdGlvbnMgd2l0aCBwZXJzb25hbGl6ZWQgdHJlYXRtZW50IHBsYW5zIHRoYXQgYXJlIHJpZ2h0IGZvciB5b3UuXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8dWwgY2xhc3NOYW1lPVwibXQtOCBtZDptdC0wIGdyaWQgZ3JpZC1jb2xzLTIgbXgtYXV0byBnYXAteC00IGdhcC15LTQgdGV4dC1zbSBtZDp0ZXh0LW1kXCI+XG4gICAgICAgIDxUcmVhdG1lbnRJdGVtPk1ham9yIGRlcHJlc3NpdmUgZGlzb3JkZXI8L1RyZWF0bWVudEl0ZW0+XG4gICAgICAgIDxUcmVhdG1lbnRJdGVtPkdlbmVyYWxpemVkIGFueGlldHkgZGlzb3JkZXI8L1RyZWF0bWVudEl0ZW0+XG4gICAgICAgIDxUcmVhdG1lbnRJdGVtPkluc29tbmlhPC9UcmVhdG1lbnRJdGVtPlxuICAgICAgICA8VHJlYXRtZW50SXRlbT5QYW5pYyBEaXNvcmRlcjwvVHJlYXRtZW50SXRlbT5cbiAgICAgICAgPFRyZWF0bWVudEl0ZW0+QWN1dGUgU3RyZXNzIERpc29yZGVyPC9UcmVhdG1lbnRJdGVtPlxuICAgICAgICA8VHJlYXRtZW50SXRlbT5Qb3N0cGFydHVtIGRlcHJlc3Npb248L1RyZWF0bWVudEl0ZW0+XG4gICAgICAgIDxUcmVhdG1lbnRJdGVtPlNvY2lhbCBhbnhpZXR5PC9UcmVhdG1lbnRJdGVtPlxuICAgICAgICA8VHJlYXRtZW50SXRlbT5QaG9iaWE8L1RyZWF0bWVudEl0ZW0+XG4gICAgICAgIDxUcmVhdG1lbnRJdGVtPlBvc3QgVHJhdW1hdGljIFN0cmVzcyBEaXNvcmRlciAoUFRTRCk8L1RyZWF0bWVudEl0ZW0+XG4gICAgICAgIDxUcmVhdG1lbnRJdGVtPlNlYXNvbmFsIEFmZmVjdGl2ZSBEaXNvcmRlciAoU0FEKTwvVHJlYXRtZW50SXRlbT5cbiAgICAgICAgPFRyZWF0bWVudEl0ZW0+UHJlbWVuc3RydWFsIER5c3Bob3JpYyBEaXNvcmRlciAoUE1ERCk8L1RyZWF0bWVudEl0ZW0+XG4gICAgICAgIDxUcmVhdG1lbnRJdGVtPk9ic2Vzc2l2ZSBDb21wdWxzaXZlIERpc29yZGVyIChPQ0QpPC9UcmVhdG1lbnRJdGVtPlxuICAgICAgPC91bD5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFdoYXRXZVRyZWF0O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5jb25zdCBGYWNlYm9vayA9ICgpID0+IChcbiAgPHN2Z1xuICAgIHZpZXdCb3g9XCIwIDAgNTEyIDUxMlwiXG4gICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcbiAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxuICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgIHN0cm9rZU1pdGVybGltaXQ9XCIyXCJcbiAgPlxuICAgIDxwYXRoXG4gICAgICBkPVwiTTUxMiAyNTcuNTU1YzAtMTQxLjM4NS0xMTQuNjE1LTI1Ni0yNTYtMjU2UzAgMTE2LjE3IDAgMjU3LjU1NWMwIDEyNy43NzcgOTMuNjE2IDIzMy42ODUgMjE2IDI1Mi44OXYtMTc4Ljg5aC02NXYtNzRoNjV2LTU2LjRjMC02NC4xNiAzOC4yMTktOTkuNiA5Ni42OTUtOTkuNiAyOC4wMDkgMCA1Ny4zMDUgNSA1Ny4zMDUgNXY2M2gtMzIuMjgxYy0zMS44MDEgMC00MS43MTkgMTkuNzMzLTQxLjcxOSAzOS45Nzh2NDguMDIyaDcxbC0xMS4zNSA3NEgyOTZ2MTc4Ljg5YzEyMi4zODUtMTkuMjA1IDIxNi0xMjUuMTEzIDIxNi0yNTIuODl6XCJcbiAgICAgIGZpbGxSdWxlPVwibm9uemVyb1wiXG4gICAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcbiAgICAvPlxuICA8L3N2Zz5cbik7XG5cbmV4cG9ydCBkZWZhdWx0IEZhY2Vib29rO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5jb25zdCBJbnN0YWdyYW0gPSAoKSA9PiAoXG4gIDxzdmdcbiAgICB2aWV3Qm94PVwiMCAwIDYwMCA2MDBcIlxuICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgIGZpbGxSdWxlPVwiZXZlbm9kZFwiXG4gICAgY2xpcFJ1bGU9XCJldmVub2RkXCJcbiAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcbiAgICBzdHJva2VNaXRlcmxpbWl0PVwiMlwiXG4gID5cbiAgICA8ZyBmaWxsUnVsZT1cIm5vbnplcm9cIj5cbiAgICAgIDxwYXRoXG4gICAgICAgIGQ9XCJNMzAwIDQ0Yy02OS41MjYgMC03OC4yNDQuMjk1LTEwNS41NDkgMS41NC0yNy4yNDggMS4yNDQtNDUuODU4IDUuNTcxLTYyLjE0MiAxMS45LTE2LjgzNCA2LjU0Mi0zMS4xMSAxNS4yOTYtNDUuMzQyIDI5LjUyOC0xNC4yMzIgMTQuMjMxLTIyLjk4NiAyOC41MDgtMjkuNTI4IDQ1LjM0Mi02LjMyOSAxNi4yODMtMTAuNjU2IDM0Ljg5My0xMS45IDYyLjE0MUM0NC4yOTUgMjIxLjc1NiA0NCAyMzAuNDc0IDQ0IDMwMGMwIDY5LjUyNC4yOTQgNzguMjQyIDEuNTQgMTA1LjU0NyAxLjI0MyAyNy4yNDggNS41NyA0NS44NTggMTEuOSA2Mi4xNDEgNi41NDEgMTYuODM0IDE1LjI5NSAzMS4xMSAyOS41MjcgNDUuMzQ0IDE0LjIzMSAxNC4yMzEgMjguNTA4IDIyLjk4NSA0NS4zNDIgMjkuNTI3IDE2LjI4NCA2LjMyOCAzNC44OTQgMTAuNjU2IDYyLjE0MiAxMS44OTkgMjcuMzA1IDEuMjQ1IDM2LjAyMyAxLjU0IDEwNS41NDkgMS41NCA2OS41MjQgMCA3OC4yNDItLjI5NSAxMDUuNTQ3LTEuNTQgMjcuMjQ4LTEuMjQzIDQ1Ljg1OC01LjU3MSA2Mi4xNDEtMTEuODk5IDE2LjgzNC02LjU0MiAzMS4xMS0xNS4yOTYgNDUuMzQ0LTI5LjUyNyAxNC4yMzEtMTQuMjMzIDIyLjk4NS0yOC41MSAyOS41MjctNDUuMzQ0IDYuMzI4LTE2LjI4MyAxMC42NTYtMzQuODkzIDExLjg5OS02Mi4xNCAxLjI0NS0yNy4zMDYgMS41NC0zNi4wMjQgMS41NC0xMDUuNTQ4IDAtNjkuNTI2LS4yOTUtNzguMjQ0LTEuNTQtMTA1LjU0OS0xLjI0My0yNy4yNDgtNS41NzEtNDUuODU4LTExLjg5OS02Mi4xNDEtNi41NDItMTYuODM0LTE1LjI5Ni0zMS4xMS0yOS41MjctNDUuMzQyLTE0LjIzMy0xNC4yMzItMjguNTEtMjIuOTg2LTQ1LjM0NC0yOS41MjgtMTYuMjgzLTYuMzI5LTM0Ljg5My0xMC42NTYtNjIuMTQtMTEuOUMzNzguMjQxIDQ0LjI5NiAzNjkuNTIzIDQ0IDMwMCA0NHptMCA0Ni4xMjdjNjguMzU0IDAgNzYuNDUuMjYgMTAzLjQ0NSAxLjQ5MiAyNC45NiAxLjEzOSAzOC41MTQgNS4zMSA0Ny41MzUgOC44MTQgMTEuOTUgNC42NDQgMjAuNDc3IDEwLjE5MiAyOS40MzUgMTkuMTUgOC45NTkgOC45NTggMTQuNTA2IDE3LjQ4NyAxOS4xNSAyOS40MzUgMy41MDYgOS4wMiA3LjY3NiAyMi41NzYgOC44MTUgNDcuNTM1IDEuMjMxIDI2Ljk5NSAxLjQ5MiAzNS4wOTIgMS40OTIgMTAzLjQ0NyAwIDY4LjM1NC0uMjYgNzYuNDUtMS40OTIgMTAzLjQ0NS0xLjEzOSAyNC45Ni01LjMxIDM4LjUxNC04LjgxNSA0Ny41MzUtNC42NDQgMTEuOTUtMTAuMTkxIDIwLjQ3Ny0xOS4xNSAyOS40MzUtOC45NTggOC45NTktMTcuNDg2IDE0LjUwNi0yOS40MzUgMTkuMTUtOS4wMiAzLjUwNi0yMi41NzYgNy42NzYtNDcuNTM1IDguODE0LTI2Ljk5IDEuMjMyLTM1LjA4NiAxLjQ5My0xMDMuNDQ1IDEuNDkzLTY4LjM2IDAtNzYuNDU1LS4yNi0xMDMuNDQ3LTEuNDkzLTI0Ljk2LTEuMTM4LTM4LjUxNC01LjMwOC00Ny41MzUtOC44MTQtMTEuOTUtNC42NDQtMjAuNDc3LTEwLjE5MS0yOS40MzYtMTkuMTUtOC45NTgtOC45NTgtMTQuNTA2LTE3LjQ4Ni0xOS4xNDktMjkuNDM1LTMuNTA2LTkuMDItNy42NzYtMjIuNTc2LTguODE1LTQ3LjUzNS0xLjIzMi0yNi45OTQtMS40OTItMzUuMDkxLTEuNDkyLTEwMy40NDUgMC02OC4zNTUuMjYtNzYuNDUyIDEuNDkyLTEwMy40NDcgMS4xMzktMjQuOTYgNS4zMS0zOC41MTQgOC44MTUtNDcuNTM1IDQuNjQzLTExLjk0OCAxMC4xOTEtMjAuNDc3IDE5LjE1LTI5LjQzNSA4Ljk1OC04Ljk1OCAxNy40ODYtMTQuNTA2IDI5LjQzNS0xOS4xNSA5LjAyLTMuNTA1IDIyLjU3Ni03LjY3NSA0Ny41MzUtOC44MTQgMjYuOTk1LTEuMjMyIDM1LjA5Mi0xLjQ5MiAxMDMuNDQ3LTEuNDkyelwiXG4gICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgLz5cbiAgICAgIDxwYXRoXG4gICAgICAgIGQ9XCJNMzAwIDM4NS4zMzJjLTQ3LjEzIDAtODUuMzM0LTM4LjIwNS04NS4zMzQtODUuMzMyIDAtNDcuMTMgMzguMjA1LTg1LjMzNCA4NS4zMzQtODUuMzM0IDQ3LjEyNyAwIDg1LjMzMiAzOC4yMDUgODUuMzMyIDg1LjMzNCAwIDQ3LjEyNy0zOC4yMDUgODUuMzMyLTg1LjMzMiA4NS4zMzJ6bTAtMjE2Ljc5MmMtNzIuNjA0IDAtMTMxLjQ2IDU4Ljg1Ni0xMzEuNDYgMTMxLjQ2IDAgNzIuNjAyIDU4Ljg1NiAxMzEuNDU4IDEzMS40NiAxMzEuNDU4IDcyLjYwMiAwIDEzMS40NTgtNTguODU2IDEzMS40NTgtMTMxLjQ1OCAwLTcyLjYwNC01OC44NTYtMTMxLjQ2LTEzMS40NTgtMTMxLjQ2ek00NjcuMzcyIDE2My4zNDZjMCAxNi45NjctMTMuNzU0IDMwLjcyLTMwLjcyIDMwLjcycy0zMC43Mi0xMy43NTMtMzAuNzItMzAuNzJjMC0xNi45NjYgMTMuNzU0LTMwLjcxOSAzMC43Mi0zMC43MTlzMzAuNzIgMTMuNzUzIDMwLjcyIDMwLjcyelwiXG4gICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxuICAgICAgLz5cbiAgICA8L2c+XG4gIDwvc3ZnPlxuKTtcblxuZXhwb3J0IGRlZmF1bHQgSW5zdGFncmFtO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5jb25zdCBMaW5rZWRJbiA9ICgpID0+IChcbiAgPHN2Z1xuICAgIHZpZXdCb3g9XCIwIDAgNTEyIDUxMlwiXG4gICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXG4gICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcbiAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxuICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxuICAgIHN0cm9rZU1pdGVybGltaXQ9XCIyXCJcbiAgPlxuICAgIDxwYXRoXG4gICAgICBkPVwiTTQ3My4zMDUtMS4zNTNjMjAuODggMCAzNy44ODUgMTYuNTMzIDM3Ljg4NSAzNi45MjZ2NDM4LjI1MWMwIDIwLjM5My0xNy4wMDUgMzYuOTU0LTM3Ljg4NSAzNi45NTRIMzYuODQ2Yy0yMC44MzkgMC0zNy43NzMtMTYuNTYxLTM3Ljc3My0zNi45NTRWMzUuNTczYzAtMjAuMzkzIDE2LjkzNC0zNi45MjYgMzcuNzczLTM2LjkyNmg0MzYuNDU5em0tMzcuODI5IDQzNi4zODlWMzAxLjAwMmMwLTY1LjgyMi0xNC4yMTItMTE2LjQyNy05MS4xMi0xMTYuNDI3LTM2Ljk1NSAwLTYxLjczOSAyMC4yNjMtNzEuODY3IDM5LjQ3NmgtMS4wNFYxOTAuNjRoLTcyLjgxMXYyNDQuMzk2aDc1Ljg2NlYzMTQuMTU4YzAtMzEuODgzIDYuMDMxLTYyLjc3MyA0NS41NTQtNjIuNzczIDM4Ljk4MSAwIDM5LjQ2OCAzNi40NjEgMzkuNDY4IDY0LjgwMnYxMTguODQ5aDc1Ljk1ek0xNTAuOTg3IDE5MC42NEg3NC45NTN2MjQ0LjM5Nmg3Ni4wMzRWMTkwLjY0ek0xMTIuOTkgNjkuMTUxYy0yNC4zOTUgMC00NC4wNjYgMTkuNzM1LTQ0LjA2NiA0NC4wNDcgMCAyNC4zMTggMTkuNjcxIDQ0LjA1MiA0NC4wNjYgNDQuMDUyIDI0LjI5OSAwIDQ0LjAyNi0xOS43MzQgNDQuMDI2LTQ0LjA1MiAwLTI0LjMxMi0xOS43MjctNDQuMDQ3LTQ0LjAyNi00NC4wNDd6XCJcbiAgICAgIGZpbGxSdWxlPVwibm9uemVyb1wiXG4gICAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcbiAgICAvPlxuICA8L3N2Zz5cbik7XG5cbmV4cG9ydCBkZWZhdWx0IExpbmtlZEluO1xuIiwiLyoqXG4gKiBUaGUgcHJpbWFyeSBjb250ZXh0IHVzZWQgaW4gb3VyIGZyb250ZW5kLCB3aGljaCBpcyBkb25lIGR1cmluZyBvbmJvYXJkaW5nLlxuICogT25jZSBhIHVzZXIgc2lnbnMgdXAgd2UgY2FuIHJlbHkgbW9yZSBvbiBzZXJ2ZXIgc3RhdGUuXG4gKi9cbmltcG9ydCB7XG4gIERpc2NvdW50Q29kZSxcbiAgUXVlc3Rpb25SZXNwb25zZSxcbiAgVXNlclJlZmVycmVyVHlwZSxcbn0gZnJvbSBcIkBoZWFsdGhnZW50L3NlcnZlci9zcmMvbGliL2FwaV90eXBlc1wiO1xuaW1wb3J0IFJlYWN0LCB7XG4gIGNyZWF0ZUNvbnRleHQsXG4gIERpc3BhdGNoLFxuICBTZXRTdGF0ZUFjdGlvbixcbiAgdXNlQ29udGV4dCxcbiAgdXNlU3RhdGUsXG59IGZyb20gXCJyZWFjdFwiO1xuXG4vLyBUaGlzIHNob3VsZCBiZSBzd2l0Y2hlZCB0byB1c2VSZWR1Y2VyIG9yIHJlY29pbC5qcyBhdCB0aGlzIHBvaW50XG5cbmludGVyZmFjZSBPbmJvYXJkaW5nQ29udGV4dCB7XG4gIC8vIFRoZSB0aW1lIHNsb3QgdGhlIHVzZXIgc2VsZWN0ZWQgZm9yIHRoZWlyIGluaXRpYWwgYXBwb2ludG1lbnRcbiAgc2VsZWN0ZWRUaW1lU2xvdDogc3RyaW5nO1xuICBzZXRTZWxlY3RlZFRpbWVTbG90OiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PjtcbiAgLy8gVXNlcidzIGVtYWlsXG4gIGVtYWlsOiBzdHJpbmc7XG4gIHNldEVtYWlsOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PjtcbiAgLy8gVXNlcidzIHBob25lIG51bWJlclxuICBwaG9uZTogc3RyaW5nO1xuICBzZXRQaG9uZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nPj47XG4gIC8vIFRoZSBzdGF0ZSB0aGUgdXNlciBsaXZlcyBpbi4gVXNlZCB0byBkZXRlcm1pbmUgZWxpZ2liaWxpdHlcbiAgcmVzaWRlbmNlU3RhdGU6IHN0cmluZztcbiAgc2V0UmVzaWRlbmNlU3RhdGU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xuICAvLyBUaGUgaW50YWtlIGlkIHJldHVybmVkIGJ5IHRoZSBzZXJ2ZXIgb25jZSB0aGUgdXNlciBmaWxscyBvdXQgdGhlIHF1aXpcbiAgaW50YWtlSWQ6IHN0cmluZztcbiAgc2V0SW50YWtlSWQ6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xuICAvLyBVc2VyJ3MgZmlyc3QgbmFtZVxuICBmaXJzdE5hbWU6IHN0cmluZztcbiAgc2V0Rmlyc3ROYW1lOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PjtcbiAgLy8gVXNlcidzIGxhc3QgbmFtZVxuICBsYXN0TmFtZTogc3RyaW5nO1xuICBzZXRMYXN0TmFtZTogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nPj47XG4gIC8vIFVzZXIncyB6aXAgY29kZVxuICB6aXBDb2RlOiBzdHJpbmc7XG4gIHNldFppcENvZGU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xuICAvLyBUaGUgY3VycmVudCBxdWVzdGlvbiBpbmRleCB3aXRoaW4gdGhlIHF1aXpcbiAgY3VycmVudFF1ZXN0aW9uSWR4OiBudW1iZXI7XG4gIHNldEN1cnJlbnRRdWVzdGlvbklkeDogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248bnVtYmVyPj47XG4gIC8vIFVzZXIncyBkYXRlIG9mIGJpcnRoXG4gIGJpcnRoZGF0ZTogRGF0ZTtcbiAgc2V0QmlydGhkYXRlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxEYXRlPj47XG4gIC8vIEEgbm90aWZpY2F0aW9uIHRvIGJlIGRpc3BsYXllZCB0byB0aGUgdXNlciBkdXJpbmcgb25ib2FyZGluZywgaWYgYW55XG4gIG5vdGlmaWNhdGlvbj86IHN0cmluZztcbiAgc2V0Tm90aWZpY2F0aW9uOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PjtcbiAgLy8gQW4gZXJyb3IgdG8gYmUgZGlzcGxheWVkIHRvIHRoZSB1c2VyIGR1cmluZyBvbmJvYXJkaW5nLCBpZiBhbnlcbiAgZXJyb3I/OiBzdHJpbmc7XG4gIHNldEVycm9yOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+PjtcbiAgLy8gVXNlcidzIHJlc3BvbnNlcyB0byB0aGUgcXVpelxuICBhbnN3ZXJzOiBBcnJheTxRdWVzdGlvblJlc3BvbnNlPjtcbiAgc2V0QW5zd2VyczogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248QXJyYXk8UXVlc3Rpb25SZXNwb25zZT4+Pjtcbn1cblxuaW50ZXJmYWNlIEJvb2tpbmdDb250ZXh0IHtcbiAgLy8gU2VydmVyIHRpbWVzbG90IElEXG4gIHNsb3RJZDogc3RyaW5nO1xuICAvLyBhcHBvaW50bWVudCB0aW1lc3RhbXBcbiAgc2xvdERhdGU6IERhdGU7XG59XG5cbmludGVyZmFjZSBDb250ZXh0VHlwZSB7XG4gIG9uYm9hcmRpbmc6IE9uYm9hcmRpbmdDb250ZXh0O1xuICBib29raW5nOiBCb29raW5nQ29udGV4dDtcbiAgc2V0Qm9va2luZ0NvbnRleHQ6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPEJvb2tpbmdDb250ZXh0Pj47XG4gIGRpc2NvdW50Q29kZT86IERpc2NvdW50Q29kZTtcbiAgc2V0RGlzY291bnRDb2RlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxEaXNjb3VudENvZGUgfCB1bmRlZmluZWQ+PjtcbiAgaW5pdGlhbFBhcmFtcz86IFVzZXJSZWZlcnJlclR5cGU7XG4gIHNldEluaXRpYWxQYXJhbXM6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPFVzZXJSZWZlcnJlclR5cGUgfCB1bmRlZmluZWQ+Pjtcbn1cblxuLy8gQHRzLWlnbm9yZVxuY29uc3QgQXBwQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8Q29udGV4dFR5cGU+KHt9KTtcblxuZXhwb3J0IGNvbnN0IEFwcENvbnRleHRQcm92aWRlcjogUmVhY3QuRkM8e30+ID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuICBjb25zdCBbc2VsZWN0ZWRUaW1lU2xvdCwgc2V0U2VsZWN0ZWRUaW1lU2xvdF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Jlc2lkZW5jZVN0YXRlLCBzZXRSZXNpZGVuY2VTdGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Rpc2NvdW50Q29kZSwgc2V0RGlzY291bnRDb2RlXSA9IHVzZVN0YXRlPERpc2NvdW50Q29kZSB8IHVuZGVmaW5lZD4oKTtcbiAgY29uc3QgW2ludGFrZUlkLCBzZXRJbnRha2VJZF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2ZpcnN0TmFtZSwgc2V0Rmlyc3ROYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbbGFzdE5hbWUsIHNldExhc3ROYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbcGhvbmUsIHNldFBob25lXSA9IHVzZVN0YXRlKFwiXCIpO1xuICBjb25zdCBbemlwQ29kZSwgc2V0WmlwQ29kZV0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2N1cnJlbnRRdWVzdGlvbklkeCwgc2V0Q3VycmVudFF1ZXN0aW9uSWR4XSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbYW5zd2Vycywgc2V0QW5zd2Vyc10gPSB1c2VTdGF0ZTxBcnJheTxRdWVzdGlvblJlc3BvbnNlPj4oW10pO1xuICBjb25zdCBbYmlydGhkYXRlLCBzZXRCaXJ0aGRhdGVdID0gdXNlU3RhdGU8RGF0ZT4obmV3IERhdGUoKSk7XG4gIGNvbnN0IFtub3RpZmljYXRpb24sIHNldE5vdGlmaWNhdGlvbl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW2luaXRpYWxQYXJhbXMsIHNldEluaXRpYWxQYXJhbXNdID0gdXNlU3RhdGU8VXNlclJlZmVycmVyVHlwZT4oKTtcblxuICBjb25zdCBbYm9va2luZ0NvbnRleHQsIHNldEJvb2tpbmdDb250ZXh0XSA9IHVzZVN0YXRlPEJvb2tpbmdDb250ZXh0Pih7XG4gICAgc2xvdElkOiBcIlwiLFxuICAgIHNsb3REYXRlOiBuZXcgRGF0ZSgpLFxuICB9KTtcblxuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBvbmJvYXJkaW5nOiB7XG4gICAgICBzZWxlY3RlZFRpbWVTbG90LFxuICAgICAgc2V0U2VsZWN0ZWRUaW1lU2xvdCxcbiAgICAgIGVtYWlsLFxuICAgICAgc2V0RW1haWwsXG4gICAgICByZXNpZGVuY2VTdGF0ZSxcbiAgICAgIHNldFJlc2lkZW5jZVN0YXRlLFxuICAgICAgaW50YWtlSWQsXG4gICAgICBzZXRJbnRha2VJZCxcbiAgICAgIGZpcnN0TmFtZSxcbiAgICAgIHNldEZpcnN0TmFtZSxcbiAgICAgIGxhc3ROYW1lLFxuICAgICAgc2V0TGFzdE5hbWUsXG4gICAgICBwaG9uZSxcbiAgICAgIHNldFBob25lLFxuICAgICAgemlwQ29kZSxcbiAgICAgIHNldFppcENvZGUsXG4gICAgICBjdXJyZW50UXVlc3Rpb25JZHgsXG4gICAgICBzZXRDdXJyZW50UXVlc3Rpb25JZHgsXG4gICAgICBhbnN3ZXJzLFxuICAgICAgc2V0QW5zd2VycyxcbiAgICAgIGJpcnRoZGF0ZSxcbiAgICAgIHNldEJpcnRoZGF0ZSxcbiAgICAgIG5vdGlmaWNhdGlvbixcbiAgICAgIHNldE5vdGlmaWNhdGlvbixcbiAgICAgIGVycm9yLFxuICAgICAgc2V0RXJyb3IsXG4gICAgfSxcbiAgICBib29raW5nOiBib29raW5nQ29udGV4dCxcbiAgICBzZXRCb29raW5nQ29udGV4dDogc2V0Qm9va2luZ0NvbnRleHQsXG4gICAgZGlzY291bnRDb2RlLFxuICAgIHNldERpc2NvdW50Q29kZSxcbiAgICBpbml0aWFsUGFyYW1zLFxuICAgIHNldEluaXRpYWxQYXJhbXMsXG4gIH07XG4gIHJldHVybiA8QXBwQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17c3RhdGV9PntjaGlsZHJlbn08L0FwcENvbnRleHQuUHJvdmlkZXI+O1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUFwcENvbnRleHQoKSB7XG4gIHJldHVybiB1c2VDb250ZXh0PENvbnRleHRUeXBlPihBcHBDb250ZXh0KTtcbn1cbiIsIi8qKlxuICogQWxsIEFQSSBjYWxscyB1dGlsaXplZCBieSB0aGUgcGF0aWVudCBmYWNpbmcgcHJvZHVjdC5cbiAqL1xuaW1wb3J0IHtcbiAgQWRkcmVzcyxcbiAgQXBwb2ludG1lbnQsXG4gIEF2YWlsYWJpbGl0eVJlc3BvbnNlLFxuICBUaHJlYWQsXG4gIFVzZXJQcm9maWxlLFxuICBVc2VyUmVnaXN0cmF0aW9uLFxuICBJbnRha2VFdmFsdWF0aW9uUmVzcG9uc2UsXG4gIE9uYm9hcmRpbmdTdGF0dXMsXG4gIEluYm94LFxuICBRdWVzdGlvblJlc3BvbnNlLFxuICBDcmVhdGVUaHJlYWRQYXJhbXMsXG4gIFBhdGllbnRSZWZlcnJhbCxcbiAgUHJlc2NyaXB0aW9uLFxuICBQaGFybWFjeSxcbiAgUHJvZ3Jlc3NDaGFydCxcbn0gZnJvbSBcIkBoZWFsdGhnZW50L3NlcnZlci9zcmMvbGliL2FwaV90eXBlc1wiO1xuaW1wb3J0IENvb2tpZXMgZnJvbSBcImpzLWNvb2tpZVwiO1xuaW1wb3J0IHsgVVNTdGF0ZSB9IGZyb20gXCIuLi8uLi9zZXJ2ZXIvc3JjL3V0aWxzL3N0YXRlc1wiO1xuaW1wb3J0IHtub3JtYWxpemVEYXRlVG9VVEN9IGZyb20gXCIuL3V0aWxcIjtcblxuY29uc3QgZ2V0VXJsID0gKGVuZHBvaW50OiBzdHJpbmcpID0+IHtcbiAgaWYgKHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluZGV4T2YoXCJodHRwczovL2hnc3RhZ2luZy5uZ3Jvay5pb1wiKSA+IC0xKSB7XG4gICAgcmV0dXJuIGBodHRwczovL2hnYXBpLm5ncm9rLmlvJHtlbmRwb2ludH1gO1xuICB9XG4gIGNvbnN0IGJhc2VVcmwgPVxuICAgIGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYmFzZV91cmxcIikgfHwgcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfSEdfQkFTRV9BUElfVVJMO1xuICByZXR1cm4gYCR7YmFzZVVybH0ke2VuZHBvaW50fWA7XG59O1xuXG5jb25zdCBBVVRIX1RPS0VOX0tFWSA9IFwiYXV0aF90b2tlblwiO1xuXG5jbGFzcyBBcGlFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgc3RhdHVzQ29kZSE6IG51bWJlcjtcblxuICBjb25zdHJ1Y3RvcihtZXNzYWdlOiBzdHJpbmcsIHN0YXR1c0NvZGU6IG51bWJlcikge1xuICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgIHRoaXMuc3RhdHVzQ29kZSA9IHN0YXR1c0NvZGU7XG4gIH1cbn1cblxuY29uc3QgYXBpRmV0Y2ggPSBhc3luYyA8VD4oXG4gIG1ldGhvZDogc3RyaW5nLFxuICB1cmw6IHN0cmluZyxcbiAgYm9keT86IE9iamVjdFxuKTogUHJvbWlzZTxUPiA9PiB7XG4gIGNvbnN0IHRva2VuID0gQ29va2llcy5nZXQoQVVUSF9UT0tFTl9LRVkpO1xuICBjb25zdCBoZWFkZXJzOiBIZWFkZXJzSW5pdCA9IHsgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfTtcbiAgaWYgKHRva2VuKSB7XG4gICAgaGVhZGVycy5BdXRob3JpemF0aW9uID0gYEJlYXJlciAke3Rva2VufWA7XG4gIH1cbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChnZXRVcmwodXJsKSwge1xuICAgIGhlYWRlcnMsXG4gICAgbWV0aG9kLFxuICAgIGJvZHk6IGJvZHkgPyBKU09OLnN0cmluZ2lmeShib2R5KSA6IHVuZGVmaW5lZCxcbiAgfSk7XG4gIGNvbnN0IGpzb24gPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICB0aHJvdyBuZXcgQXBpRXJyb3IoanNvbi5lcnJvciB8fCByZXNwb25zZS5zdGF0dXNUZXh0LCByZXNwb25zZS5zdGF0dXMpO1xuICB9XG4gIHJldHVybiBqc29uIGFzIFByb21pc2U8VD47XG59O1xuXG5jb25zdCBmaWxlVXBsb2FkID0gYXN5bmMgPFQ+KHVybDogc3RyaW5nLCBib2R5OiBGb3JtRGF0YSk6IFByb21pc2U8VD4gPT4ge1xuICBjb25zdCB0b2tlbiA9IENvb2tpZXMuZ2V0KEFVVEhfVE9LRU5fS0VZKTtcbiAgY29uc3QgaGVhZGVycyA9IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfTtcbiAgY29uc3QgbWV0aG9kID0gXCJQT1NUXCI7XG5cbiAgcmV0dXJuIGZldGNoKGdldFVybCh1cmwpLCB7XG4gICAgaGVhZGVycyxcbiAgICBtZXRob2QsXG4gICAgYm9keSxcbiAgfSkudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocmVzcG9uc2Uuc3RhdHVzVGV4dCk7XG4gICAgfVxuICAgIHJldHVybiByZXNwb25zZS5qc29uKCkgYXMgUHJvbWlzZTxUPjtcbiAgfSk7XG59O1xuXG5jb25zdCBnZXQgPSBhc3luYyA8VD4oXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHBhcmFtcz86IFJlY29yZDxzdHJpbmcsIHVua25vd24+XG4pOiBQcm9taXNlPFQ+ID0+IHtcbiAgLy8gQHRzLWlnbm9yZVxuICBjb25zdCBwYXJhbVN0cmluZyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMocGFyYW1zKS50b1N0cmluZygpO1xuICBjb25zdCB1cmwgPSBwYXJhbVN0cmluZy5sZW5ndGggPiAwID8gYCR7ZW5kcG9pbnR9PyR7cGFyYW1TdHJpbmd9YCA6IGVuZHBvaW50O1xuICByZXR1cm4gYXdhaXQgYXBpRmV0Y2goXCJHRVRcIiwgdXJsLCB1bmRlZmluZWQpO1xufTtcblxuY29uc3QgcG9zdCA9IGFzeW5jIDxUPih1cmw6IHN0cmluZywgcmVxdWVzdDogT2JqZWN0KTogUHJvbWlzZTxUPiA9PiB7XG4gIHJldHVybiBhd2FpdCBhcGlGZXRjaChcIlBPU1RcIiwgdXJsLCByZXF1ZXN0KTtcbn07XG5cbmV4cG9ydCBjb25zdCBnZXRTdGF0ZXMgPSBhc3luYyAoKSA9PiB7XG4gIHJldHVybiBhd2FpdCBnZXQ8eyBzdGF0ZXM6IEFycmF5PFVTU3RhdGU+IH0+KFwiL2FwaS9zdGF0ZXNcIilcbiAgICAudGhlbigocikgPT4gci5zdGF0ZXMpXG4gICAgLnRoZW4oKHN0YXRlcykgPT4gc3RhdGVzLnNvcnQoKGEsIGIpID0+IGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSkpKTtcbn07XG5cbmV4cG9ydCBjb25zdCByZWdpc3RlciA9IGFzeW5jIChcbiAgcmVnaXN0cmF0aW9uOiBVc2VyUmVnaXN0cmF0aW9uXG4pOiBQcm9taXNlPHN0cmluZz4gPT4ge1xuICBjb25zdCB7IGNvbnNlbnQsIC4uLmJvZHkgfSA9IHJlZ2lzdHJhdGlvbjtcbiAgcmV0dXJuIGF3YWl0IHBvc3Q8eyB0b2tlbjogc3RyaW5nIH0+KFwiL2FwaS9zaWdudXBcIiwgcmVnaXN0cmF0aW9uKS50aGVuKFxuICAgIChyKSA9PiByLnRva2VuXG4gICk7XG59O1xuXG5leHBvcnQgY29uc3Qgc3VibWl0UXVpeiA9IGFzeW5jIChxdWl6OiBBcnJheTxRdWVzdGlvblJlc3BvbnNlPikgPT4ge1xuICByZXR1cm4gYXdhaXQgcG9zdDx7IGlkOiBzdHJpbmcgfT4oXCIvYXBpL3N1Ym1pdF9xdWl6XCIsIHtcbiAgICBhbnN3ZXJzOiBxdWl6LFxuICB9KS50aGVuKChyKSA9PiByLmlkKTtcbn07XG5cbmV4cG9ydCBjb25zdCBzdWJtaXRDaGVja2luID0gYXN5bmMgKHJlc3BvbnNlczogQXJyYXk8UXVlc3Rpb25SZXNwb25zZT4pID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3BhdGllbnQvc3VibWl0X2NoZWNraW5cIiwgeyByZXNwb25zZXMgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0UHJvZ3Jlc3NIaXN0b3J5ID0gYXN5bmMgKGhpc3RvcnlUeXBlOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IGdldDxQcm9ncmVzc0NoYXJ0PihcIi9hcGkvcGF0aWVudC9wcm9ncmVzc19oaXN0b3J5XCIsIHtcbiAgICBoaXN0b3J5VHlwZSxcbiAgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgY2hlY2tTdGF0ZSA9IGFzeW5jIChzdGF0ZTogc3RyaW5nKSA9PiB7XG4gIHJldHVybiBhd2FpdCBwb3N0PHsgYXZhaWxhYmxlOiBib29sZWFuIH0+KFwiL2FwaS9wYXRpZW50L2NoZWNrX3N0YXRlXCIsIHtcbiAgICBzdGF0ZSxcbiAgfSkudGhlbigocikgPT4gci5hdmFpbGFibGUpO1xufTtcblxuZXhwb3J0IGNvbnN0IGNoZWNrWmlwID0gYXN5bmMgKHppcDogc3RyaW5nKSA9PiB7XG4gIHJldHVybiBhd2FpdCBnZXQ8eyBhdmFpbGFibGU6IGJvb2xlYW4gfT4oXCIvYXBpL2NoZWNrX3ppcFwiLCB7XG4gICAgemlwLFxuICB9KS50aGVuKChyKSA9PiByLmF2YWlsYWJsZSk7XG59O1xuXG5leHBvcnQgY29uc3Qgam9pbldhaXRsaXN0ID0gYXN5bmMgKGVtYWlsOiBzdHJpbmcsIHN0YXRlOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL2pvaW5fd2FpdGxpc3RcIiwgeyBlbWFpbCwgc3RhdGUgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0QXZhaWxhYmlsaXR5ID0gYXN5bmMgKCkgPT4ge1xuICByZXR1cm4gYXdhaXQgZ2V0PEF2YWlsYWJpbGl0eVJlc3BvbnNlPihcIi9hcGkvcGF0aWVudC9hdmFpbGFiaWxpdHlcIik7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0U3RyaXBlQ2xpZW50U2VjcmV0ID0gYXN5bmMgKHByb21vdGlvbkNvZGU/OiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IGdldDx7IGNsaWVudFNlY3JldDogc3RyaW5nIH0+KFwiL2FwaS9wYXRpZW50L3BheW1lbnRfc2V0dXBcIiwge1xuICAgIHByb21vdGlvbkNvZGUsXG4gIH0pLnRoZW4oKHIpID0+IHIuY2xpZW50U2VjcmV0KTtcbn07XG5cbmV4cG9ydCBjb25zdCBjb25maXJtUGF5bWVudCA9IGFzeW5jIChwYXltZW50SW50ZW50SWQ6IHN0cmluZykgPT4ge1xuICByZXR1cm4gYXdhaXQgcG9zdChcIi9hcGkvcGF0aWVudC9jb25maXJtX3BheW1lbnRcIiwge1xuICAgIHBheW1lbnRJbnRlbnRJZCxcbiAgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgdXBkYXRlUGF5bWVudE1ldGhvZCA9IGFzeW5jIChwYXltZW50TWV0aG9kSWQ6IHN0cmluZykgPT4ge1xuICByZXR1cm4gYXdhaXQgcG9zdChcIi9hcGkvcGF0aWVudC91cGRhdGVfcGF5bWVudF9tZXRob2RcIiwgeyBwYXltZW50TWV0aG9kSWQgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgbG9naW4gPSBhc3luYyAoXG4gIGVtYWlsOiBzdHJpbmcsXG4gIHBhc3N3b3JkOiBzdHJpbmdcbik6IFByb21pc2U8c3RyaW5nPiA9PiB7XG4gIHJldHVybiBhd2FpdCBwb3N0PHsgdG9rZW46IHN0cmluZyB9PihcIi9hcGkvbG9naW5cIiwgeyBlbWFpbCwgcGFzc3dvcmQgfSkudGhlbihcbiAgICAocikgPT4gci50b2tlblxuICApO1xufTtcblxuZXhwb3J0IGNvbnN0IHN1cGVydXNlciA9IGFzeW5jIChwYXNzd29yZDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+ID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3Q8eyB0b2tlbjogc3RyaW5nIH0+KFwiL2FwaS9zdXBlcnVzZXJcIiwgeyBwYXNzd29yZCB9KS50aGVuKFxuICAgIChyKSA9PiByLnRva2VuXG4gICk7XG59O1xuXG5leHBvcnQgY29uc3QgbG9naW5BcyA9IGFzeW5jIChlbWFpbDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+ID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3Q8eyB0b2tlbjogc3RyaW5nIH0+KFwiL2FwaS9sb2dpbl9hc1wiLCB7IGVtYWlsIH0pLnRoZW4oXG4gICAgKHIpID0+IHIudG9rZW5cbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCBib29rQXBwb2ludG1lbnQgPSBhc3luYyAoc2xvdElkOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3BhdGllbnQvc2NoZWR1bGVfYXBwb2ludG1lbnRcIiwge1xuICAgIHNsb3RJZCxcbiAgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0VXBjb21pbmdBcHBvaW50bWVudCA9IGFzeW5jICgpID0+IHtcbiAgcmV0dXJuIGF3YWl0IGdldDx7IGFwcG9pbnRtZW50PzogQXBwb2ludG1lbnQgfT4oXG4gICAgXCIvYXBpL3BhdGllbnQvdXBjb21pbmdfYXBwb2ludG1lbnRcIlxuICApO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldFByZXZpb3VzQXBwb2ludG1lbnRzID0gYXN5bmMgKCkgPT4ge1xuICByZXR1cm4gYXdhaXQgZ2V0PHsgcHJldmlvdXNBcHBvaW50bWVudHM6IEFycmF5PEFwcG9pbnRtZW50PiB9PihcbiAgICBcIi9hcGkvcGF0aWVudC9wcmV2aW91c19hcHBvaW50bWVudHNcIlxuICApLnRoZW4oKHIpID0+IHIucHJldmlvdXNBcHBvaW50bWVudHMpO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldFByb2ZpbGUgPSBhc3luYyAoKSA9PiB7XG4gIHJldHVybiBhd2FpdCBnZXQ8VXNlclByb2ZpbGU+KFwiL2FwaS9wYXRpZW50L21lXCIpO1xufTtcblxuZXhwb3J0IGNvbnN0IHVwZGF0ZUVtYWlsID0gYXN5bmMgKGVtYWlsOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3BhdGllbnQvdXBkYXRlX2VtYWlsXCIsIHsgZW1haWwgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgdXBkYXRlQWRkcmVzcyA9IGFzeW5jIChhZGRyZXNzOiBBZGRyZXNzLCBpc09uYm9hcmRpbmcgPSBmYWxzZSkgPT4ge1xuICByZXR1cm4gYXdhaXQgcG9zdChcIi9hcGkvcGF0aWVudC91cGRhdGVfYWRkcmVzc1wiLCB7XG4gICAgLi4uYWRkcmVzcyxcbiAgICBpc09uYm9hcmRpbmcsXG4gIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IHVwZGF0ZVBob25lID0gYXN5bmMgKHBob25lOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3BhdGllbnQvdXBkYXRlX3Bob25lXCIsIHsgcGhvbmUgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgdXBkYXRlRG9iID0gYXN5bmMgKGRhdGU6IERhdGUpID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3BhdGllbnQvdXBkYXRlX2JpcnRoZGF0ZVwiLCB7XG4gICAgYmlydGhkYXRlOiBub3JtYWxpemVEYXRlVG9VVEMoZGF0ZSksXG4gIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IHVwZGF0ZUVtZXJnZW5jeUNvbnRhY3QgPSBhc3luYyAoXG4gIHBhcmFtczogUmVjb3JkPHN0cmluZywgdW5rbm93bj5cbikgPT4ge1xuICByZXR1cm4gYXdhaXQgcG9zdDx7IHN1Y2Nlc3M6IGJvb2xlYW4gfT4oXG4gICAgXCIvYXBpL3BhdGllbnQvZW1lcmdlbmN5X2NvbnRhY3RcIixcbiAgICBwYXJhbXNcbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCBmb3Jnb3RQYXNzd29yZCA9IGFzeW5jIChlbWFpbDogc3RyaW5nKSA9PiB7XG4gIHJldHVybiBhd2FpdCBwb3N0KFwiL2FwaS9mb3Jnb3RfcGFzc3dvcmRcIiwgeyBlbWFpbCB9KTtcbn07XG5cbmV4cG9ydCBjb25zdCByZXNldFBhc3N3b3JkID0gYXN5bmMgKHRva2VuOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3Jlc2V0X3Bhc3N3b3JkXCIsIHsgdG9rZW4sIHBhc3N3b3JkIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IGNoZWNrSW50YWtlID0gYXN5bmMgKGludGFrZUlkOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IGdldDxJbnRha2VFdmFsdWF0aW9uUmVzcG9uc2U+KFxuICAgIGAvYXBpL2NoZWNrX2ludGFrZT9pZD0ke2ludGFrZUlkfWBcbiAgKTtcbn07XG5cbmV4cG9ydCBjb25zdCBnZXRPbmJvYXJkaW5nU3RhdHVzID0gYXN5bmMgKCkgPT4ge1xuICByZXR1cm4gYXdhaXQgZ2V0PE9uYm9hcmRpbmdTdGF0dXM+KFwiL2FwaS9wYXRpZW50L3N0YXR1c1wiKTtcbn07XG5cbmV4cG9ydCBjb25zdCB2ZXJpZnlJZCA9IGFzeW5jIChpbnF1aXJ5SWQ6IHN0cmluZykgPT4ge1xuICByZXR1cm4gYXdhaXQgcG9zdChcIi9hcGkvcGF0aWVudC92ZXJpZnlfaWRcIiwgeyBpbnF1aXJ5SWQgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgY3JlYXRlTmV3VGhyZWFkID0gYXN5bmMgKHBhcmFtczogQ3JlYXRlVGhyZWFkUGFyYW1zKSA9PiB7XG4gIHJldHVybiBhd2FpdCBwb3N0KFwiL2FwaS9jcmVhdGVfdGhyZWFkXCIsIHBhcmFtcyk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0VGhyZWFkID0gYXN5bmMgKHRocmVhZElkOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGdldDxUaHJlYWQ+KGAvYXBpL3RocmVhZC8ke3RocmVhZElkfWApO1xufTtcblxuZXhwb3J0IGNvbnN0IHBvc3RNZXNzYWdlID0gYXN5bmMgKHRocmVhZElkOiBzdHJpbmcsIGNvbnRlbnQ6IHN0cmluZykgPT4ge1xuICByZXR1cm4gcG9zdChgL2FwaS90aHJlYWQvJHt0aHJlYWRJZH1gLCB7IGNvbnRlbnQgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0SW5ib3ggPSBhc3luYyAoKSA9PiB7XG4gIHJldHVybiBnZXQ8SW5ib3g+KFwiL2FwaS9tZXNzYWdlc1wiKTtcbn07XG5cbmV4cG9ydCBjb25zdCBnZXRVbnJlYWRNZXNzYWdlQ291bnQgPSBhc3luYyAoKSA9PiB7XG4gIHJldHVybiBnZXQ8eyB1bnJlYWRNZXNzYWdlczogbnVtYmVyIH0+KFwiL2FwaS9tZXNzYWdlcy91bnJlYWRcIikudGhlbihcbiAgICAocikgPT4gci51bnJlYWRNZXNzYWdlc1xuICApO1xufTtcblxuZXhwb3J0IGNvbnN0IHN1Ym1pdE1lZGljYWxJbnRha2UgPSBhc3luYyAoYW5zd2VyczogT2JqZWN0KSA9PiB7XG4gIHJldHVybiBhd2FpdCBwb3N0PHsgaWQ6IHN0cmluZyB9PihcIi9hcGkvcGF0aWVudC91cGRhdGVfaW50YWtlXCIsIHsgYW5zd2VycyB9KTtcbn07XG5cbmV4cG9ydCBjb25zdCBzdWJtaXRSZWZlcnJhbCA9IGFzeW5jIChyZWZlcnJhbDogUGF0aWVudFJlZmVycmFsKSA9PiB7XG4gIHJldHVybiBhd2FpdCBwb3N0KFwiL2FwaS9yZWZlcl9wYXRpZW50XCIsIHJlZmVycmFsKTtcbn07XG5cbmV4cG9ydCBjb25zdCBnZXRSZWZlcnJhbENvZGUgPSBhc3luYyAobmFtZTogc3RyaW5nLCBlbWFpbDogc3RyaW5nKSA9PiB7XG4gIHJldHVybiBhd2FpdCBwb3N0PHsgY29kZTogc3RyaW5nIH0+KFwiL2FwaS9yZWZlcnJhbF9jb2RlXCIsIHtcbiAgICBuYW1lLFxuICAgIGVtYWlsLFxuICB9KS50aGVuKChyKSA9PiByLmNvZGUpO1xufTtcblxuZXhwb3J0IGNvbnN0IHN1Ym1pdFN0YXJ0SW50YWtlID0gYXN5bmMgKHBhcmFtczoge1xuICBlbWFpbD86IHN0cmluZztcbiAgcGhvbmU6IHN0cmluZztcbiAgZmlyc3ROYW1lOiBzdHJpbmc7XG4gIGxhc3ROYW1lOiBzdHJpbmc7XG4gIGludGFrZUlkOiBzdHJpbmc7XG59KSA9PiB7XG4gIHJldHVybiBhd2FpdCBwb3N0KFwiL2FwaS9zdGFydF9pbnRha2VcIiwgcGFyYW1zKTtcbn07XG5cbmV4cG9ydCBjb25zdCBnZXRQcmVzY3JpcHRpb25zID0gYXN5bmMgKCkgPT4ge1xuICByZXR1cm4gYXdhaXQgZ2V0PHsgcHJlc2NyaXB0aW9uczogQXJyYXk8UHJlc2NyaXB0aW9uPiB9PihcbiAgICBcIi9hcGkvcGF0aWVudC9wcmVzY3JpcHRpb25zXCJcbiAgKS50aGVuKChyKSA9PiByLnByZXNjcmlwdGlvbnMpO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldFZpZGVvVG9rZW4gPSBhc3luYyAoaWRlbnRpdHk6IHN0cmluZykgPT4ge1xuICByZXR1cm4gYXdhaXQgZ2V0PHsgdG9rZW46IHN0cmluZyB9PihcIi9hcGkvdmlkZW8vdG9rZW5cIiwgeyBpZGVudGl0eSB9KS50aGVuKFxuICAgIChyKSA9PiByLnRva2VuXG4gICk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0UGhhcm1hY2llcyA9IGFzeW5jIChwYXJhbXM6IHtcbiAgemlwPzogc3RyaW5nO1xuICBsYXQ/OiBudW1iZXI7XG4gIGxvbj86IG51bWJlcjtcbn0pID0+IHtcbiAgcmV0dXJuIGF3YWl0IGdldDx7IHBoYXJtYWNpZXM6IEFycmF5PFBoYXJtYWN5PiB9PihcbiAgICBcIi9hcGkvcGF0aWVudC9waGFybWFjaWVzXCIsXG4gICAgcGFyYW1zXG4gICkudGhlbigocikgPT4gci5waGFybWFjaWVzKTtcbn07XG5cbmV4cG9ydCBjb25zdCBzZXRQaGFybWFjeSA9IGFzeW5jIChwaGFybWFjeUlkOiBzdHJpbmcpID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3BhdGllbnQvcGhhcm1hY3lcIiwgeyBwaGFybWFjeUlkIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldFBoYXJtYWN5ID0gYXN5bmMgKCkgPT4ge1xuICByZXR1cm4gYXdhaXQgZ2V0PFBoYXJtYWN5PihcIi9hcGkvcGF0aWVudC9waGFybWFjeVwiKTtcbn07XG5cbmV4cG9ydCBjb25zdCBhZGRQcmltYXJ5Q2FyZVBoeXNpY2lhbkluZm8gPSBhc3luYyAoXG4gIG5hbWU6IHN0cmluZyxcbiAgcGhvbmU6IHN0cmluZyxcbiAgZW1haWw6IHN0cmluZyxcbiAgYWxsb3dTaGFyaW5nOiBib29sZWFuXG4pID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3BhdGllbnQvdXBkYXRlX3BjcFwiLCB7XG4gICAgbmFtZSxcbiAgICBwaG9uZSxcbiAgICBlbWFpbCxcbiAgICBhbGxvd1NoYXJpbmcsXG4gIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IGFkZEV4dGVybmFsVGhlcmFwaXN0SW5mbyA9IGFzeW5jIChcbiAgbmFtZTogc3RyaW5nLFxuICBwaG9uZTogc3RyaW5nLFxuICBlbWFpbDogc3RyaW5nLFxuICBhbGxvd1NoYXJpbmc6IGJvb2xlYW5cbikgPT4ge1xuICByZXR1cm4gYXdhaXQgcG9zdChcIi9hcGkvcGF0aWVudC91cGRhdGVfdGhlcmFwaXN0XCIsIHtcbiAgICBuYW1lLFxuICAgIHBob25lLFxuICAgIGVtYWlsLFxuICAgIGFsbG93U2hhcmluZyxcbiAgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgbWFya09uYm9hcmRpbmdDb21wbGV0ZSA9IGFzeW5jICgpID0+IHtcbiAgcmV0dXJuIGF3YWl0IHBvc3QoXCIvYXBpL3BhdGllbnQvb25ib2FyZGluZ19jb21wbGV0ZVwiLCB7fSk7XG59O1xuIiwiLyoqXG4gKiBSZWFjdCBob29rIHVzZWQgdG8gc2V0IGEgZGlzY291bnQgY29kZSBpbiB0aGUgYXBwbGljYXRpb24gY29udGV4dFxuICogYmFzZWQgb24gdGhlIGN1cnJlbnQgcGFnZSBVUkwuXG4gKi9cbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgRGlzY291bnRDb2RlIH0gZnJvbSBcIi4uLy4uLy4uL3NlcnZlci9zcmMvbGliL2FwaV90eXBlc1wiO1xuaW1wb3J0IHsgdXNlQXBwQ29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0L0FwcENvbnRleHRcIjtcblxuZXhwb3J0IGNvbnN0IHVzZU9mZmVyID0gKCkgPT4ge1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgY29uc3QgeyBkaXNjb3VudENvZGUsIHNldERpc2NvdW50Q29kZSB9ID0gdXNlQXBwQ29udGV4dCgpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChPYmplY3Qua2V5cyhyb3V0ZXIucXVlcnkpLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IHsgb2ZmZXIgfSA9IHJvdXRlci5xdWVyeTtcbiAgICAgIGlmIChvZmZlcikge1xuICAgICAgICBzZXREaXNjb3VudENvZGUob2ZmZXIgYXMgRGlzY291bnRDb2RlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFtyb3V0ZXIucXVlcnldKTtcbiAgY29uc3Qgb2ZmZXJUZXh0ID0gXCJTdGFydCB5b3VyIGZpcnN0IG1vbnRoIGZvciBqdXN0ICQ1XCI7XG4gIHJldHVybiB7IGRpc2NvdW50Q29kZSwgb2ZmZXJUZXh0IH07XG59O1xuIiwiLyoqXG4gKiBSZWFjdCBob29rIHVzZWQgdG8gc2V0IFVUTSBwYXJhbWV0ZXJzIGluIHRoZSBhcHBsaWNhdGlvbiBjb250ZXh0XG4gKiBiYXNlZCBvbiB0aGUgY3VycmVudCBwYWdlIFVSTC4gVXNlZCB0byB0cmFjayBjb252ZXJzaW9ucyAvIGV2ZW50XG4gKiBhdHRyaWJ1dGlvbiBvbiB0aGUgc2VydmVyLlxuICovXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlQXBwQ29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0L0FwcENvbnRleHRcIjtcblxuZXhwb3J0IGNvbnN0IHVzZVV0bSA9ICgpID0+IHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG4gIGNvbnN0IHsgaW5pdGlhbFBhcmFtcywgc2V0SW5pdGlhbFBhcmFtcyB9ID0gdXNlQXBwQ29udGV4dCgpO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpbml0aWFsUGFyYW1zPy51dG1Tb3VyY2UpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKE9iamVjdC5rZXlzKHJvdXRlci5xdWVyeSkubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgeyByZWY6IHJlZmVycmFsQ29kZSB9ID0gcm91dGVyLnF1ZXJ5O1xuICAgICAgaWYgKCFyZWZlcnJhbENvZGUpIHtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIHV0bV9zb3VyY2UsXG4gICAgICAgICAgdXRtX21lZGl1bSxcbiAgICAgICAgICB1dG1fY2FtcGFpZ24sXG4gICAgICAgICAgdXRtX2NvbnRlbnQsXG4gICAgICAgICAgdXRtX3Rlcm0sXG4gICAgICAgICAgdGVybSxcbiAgICAgICAgfSA9IHJvdXRlci5xdWVyeTtcbiAgICAgICAgc2V0SW5pdGlhbFBhcmFtcyh7XG4gICAgICAgICAgdXRtU291cmNlOiB1dG1fc291cmNlLFxuICAgICAgICAgIHV0bU1lZGl1bTogdXRtX21lZGl1bSxcbiAgICAgICAgICB1dG1DYW1wYWlnbjogdXRtX2NhbXBhaWduLFxuICAgICAgICAgIHV0bUNvbnRlbnQ6IHV0bV9jb250ZW50LFxuICAgICAgICAgIHV0bVRlcm06IHV0bV90ZXJtIHx8IHRlcm0sXG4gICAgICAgICAgcmF3VXJsOiByb3V0ZXIuYXNQYXRoLFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldEluaXRpYWxQYXJhbXMoe1xuICAgICAgICAgIHV0bVNvdXJjZTogXCJ1c2VyX3JlZmVycmFsXCIsXG4gICAgICAgICAgdXRtTWVkaXVtOiBcImNvcHlfbGlua1wiLFxuICAgICAgICAgIHV0bUNhbXBhaWduOiBcInJlZmVyX2ZyaWVuZF9wYWdlXCIsXG4gICAgICAgICAgdXRtQ29udGVudDogcmVmZXJyYWxDb2RlLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFtyb3V0ZXIucXVlcnldKTtcbn07XG4iLCIvKipcbiAqIHNpbXBsZSB1dGlsaXR5IGZ1bmN0aW9uc1xuICovXG5cbmV4cG9ydCBjb25zdCBlbWFpbElzVmFsaWQgPSAoZW1haWw6IHN0cmluZyk6IGJvb2xlYW4gPT4ge1xuICByZXR1cm4gL15bXlxcc0BdK0BbXlxcc0BdK1xcLlteXFxzQF0rJC8udGVzdChlbWFpbCk7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0T3JkaW5hbE51bSA9IChuOiBudW1iZXIpID0+IHtcbiAgcmV0dXJuIChcbiAgICBuICtcbiAgICAobiA+IDBcbiAgICAgID8gW1widGhcIiwgXCJzdFwiLCBcIm5kXCIsIFwicmRcIl1bKG4gPiAzICYmIG4gPCAyMSkgfHwgbiAlIDEwID4gMyA/IDAgOiBuICUgMTBdXG4gICAgICA6IFwiXCIpXG4gICk7XG59O1xuXG5leHBvcnQgY29uc3QgZGF0ZVRvVGltZVN0cmluZyA9IChkYXRlOiBEYXRlKSA9PiB7XG4gIHJldHVybiBkYXRlLnRvTG9jYWxlVGltZVN0cmluZyhcImVuLVVTXCIsIHtcbiAgICBob3VyOiBcIm51bWVyaWNcIixcbiAgICBob3VyMTI6IHRydWUsXG4gICAgbWludXRlOiBcIm51bWVyaWNcIixcbiAgICAvLyB0aW1lWm9uZU5hbWU6IEludGwuRGF0ZVRpbWVGb3JtYXQoKS5yZXNvbHZlZE9wdGlvbnMoKS50aW1lWm9uZSxcbiAgfSk7XG59O1xuXG5leHBvcnQgY29uc3QgZGF5V2l0aE9yZGluYWwgPSAoZGF0ZTogRGF0ZSkgPT4ge1xuICByZXR1cm4gYCR7Z2V0T3JkaW5hbE51bShkYXRlLmdldERhdGUoKSl9YDtcbn07XG5cbmV4cG9ydCBjb25zdCBnZXREYXlOYW1lID0gKGRhdGU6IERhdGUpID0+IHtcbiAgcmV0dXJuIGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZGVmYXVsdFwiLCB7IHdlZWtkYXk6IFwibG9uZ1wiIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldE1vbnRoTmFtZSA9IChkYXRlOiBEYXRlKSA9PiB7XG4gIHJldHVybiBkYXRlLnRvTG9jYWxlU3RyaW5nKFwiZGVmYXVsdFwiLCB7IG1vbnRoOiBcImxvbmdcIiB9KTtcbn07XG5cbmV4cG9ydCBjb25zdCBmb3JtYXRQaG9uZU51bWJlciA9IChwaG9uZTogc3RyaW5nKSA9PlxuICBwaG9uZS5yZXBsYWNlKC9cXEQrL2csIFwiXCIpLnJlcGxhY2UoLyhcXGR7M30pKFxcZHszfSkoXFxkezR9KS8sIFwiKCQxKSAkMi0kM1wiKTtcblxuZXhwb3J0IGNvbnN0IGNhcGl0YWxpemUgPSAoczogc3RyaW5nKSA9PlxuICAocy5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHMuc2xpY2UoMSkpLnRyaW0oKTtcblxuZXhwb3J0IGNvbnN0IGdldFRpbWV6b25lQWJicmV2aWF0aW9uID0gKCkgPT5cbiAgbmV3IERhdGUoKVxuICAgIC50b0xvY2FsZVRpbWVTdHJpbmcoXCJlbi11c1wiLCB7IHRpbWVab25lTmFtZTogXCJzaG9ydFwiIH0pXG4gICAgLnNwbGl0KFwiIFwiKVsyXTtcblxuZXhwb3J0IGNvbnN0IGdldFRpbWV6b25lTmFtZSA9ICgpID0+XG4gIEludGwuRGF0ZVRpbWVGb3JtYXQoKS5yZXNvbHZlZE9wdGlvbnMoKS50aW1lWm9uZTtcblxuZXhwb3J0IGNvbnN0IG5vcm1hbGl6ZURhdGVUb1VUQyA9IChkYXRlOiBEYXRlKTogc3RyaW5nID0+IHtcbiAgY29uc3QgdXRjRGF0ZSA9IERhdGUuVVRDKGRhdGUuZ2V0RnVsbFllYXIoKSwgZGF0ZS5nZXRNb250aCgpLCBkYXRlLmdldFVUQ0RhdGUoKSk7XG4gIHJldHVybiBuZXcgRGF0ZSh1dGNEYXRlKS50b0lTT1N0cmluZygpO1xufTtcbiIsIi8qKlxuICogTGFuZGluZyBwYWdlXG4gKi9cbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBDVEFCdXR0b24gZnJvbSBcIi4uL2NvbXBvbmVudHMvbGFuZGluZy9DVEFCdXR0b25cIjtcbmltcG9ydCB7IGNyZWF0ZUNsaWVudCB9IGZyb20gJ2NvbnRlbnRmdWwnXG5pbXBvcnQgTGFuZGluZ1RlbXBsYXRlIGZyb20gXCIuLi9jb21wb25lbnRzL2xhbmRpbmcvTGFuZGluZ1RlbXBsYXRlXCI7XG5cbmludGVyZmFjZSBQcm9wcyB7IH1cblxuY29uc3QgY2xpZW50ID0gY3JlYXRlQ2xpZW50KHtcbiAgc3BhY2U6IHByb2Nlc3MuZW52LkNPTlRFTlRGVUxfU1BBQ0VfSUQsXG4gIGFjY2Vzc1Rva2VuOiBwcm9jZXNzLmVudi5DT05URU5URlVMX0FDQ0VTU19LRVksXG59KVxuXG5jb25zdCBIb21lSW5kZXg6IFJlYWN0LkZDPFByb3BzPiA9IChwcm9wcykgPT4ge1xuICByZXR1cm4gKFxuICAgIDxMYW5kaW5nVGVtcGxhdGUgZGF0YT17cHJvcHN9PlxuICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIG1kOnRleHQtNHhsIG1iLTQgbWQ6bWItOFwiPlxuICAgICAgICBNZW50YWwgaGVhbHRoY2FyZSB3aXRob3V0IHRoZSB3YWl0LiBGaW5hbGx5LlxuICAgICAgPC9oMT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1saWdodCBsZWFkaW5nLXJlbGF4ZWQgbWItNCBtZDptYi04XCI+XG4gICAgICAgIE9ubGluZSBwc3ljaGlhdHJ5IGFuZCBtZWRpY2F0aW9uIGZvciBkZXByZXNzaW9uIGFuZCBhbnhpZXR5LiBQcmVzY3JpYmVkXG4gICAgICAgIHJlc3BvbnNpYmx5LCBwcm92aWRlZCBhZmZvcmRhYmx5LCB3aXRoIHN1cHBvcnQgZnJvbSBhIHRlYW0gb2YgcHJvdmlkZXJzLlxuICAgICAgPC9kaXY+XG4gICAgICA8Q1RBQnV0dG9uPlN0YXJ0IGZyZWUgYXNzZXNzbWVudDwvQ1RBQnV0dG9uPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIG10LTIgdGV4dC1jZW50ZXIgZm9udC1saWdodFwiPlxuICAgICAgICBCb29rIG9ubGluZSBpbiAxMCBtaW51dGVzLlxuICAgICAgPC9kaXY+XG4gICAgPC9MYW5kaW5nVGVtcGxhdGU+XG4gICk7XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U3RhdGljUHJvcHMoKSB7XG4gY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmdldEVudHJpZXMoeyBjb250ZW50X3R5cGU6IFwiZmFxXCIsIG9yZGVyOiAnc3lzLmNyZWF0ZWRBdCcgfSlcblxuIGNvbnN0IHsgaXRlbXMgfSA9IGF3YWl0IGNsaWVudC5nZXRFbnRyaWVzKHtcbiAgICBjb250ZW50X3R5cGU6ICdob21lJyxcbiAgICAnZmllbGRzLnNsdWcnOiAnaG9tZSdcbiAgfSlcbiAgcmV0dXJuIHtcbiAgICBwcm9wczoge1xuICAgICAgZmFxOiByZXMuaXRlbXMsXG4gICAgICBwYWdlOiBpdGVtc1swXVxuICAgIH0sXG4gICAgcmV2YWxpZGF0ZTogMVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IEhvbWVJbmRleDtcbiIsIlwidXNlIHN0cmljdFwiO3ZhciBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0PXJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlRGVmYXVsdFwiKTtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLmRlZmF1bHQ9SW1hZ2U7dmFyIF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlMj1faW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2VcIikpO3ZhciBfZXh0ZW5kczI9X2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9leHRlbmRzXCIpKTt2YXIgX3JlYWN0PV9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcInJlYWN0XCIpKTt2YXIgX2hlYWQ9X2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vbmV4dC1zZXJ2ZXIvbGliL2hlYWRcIikpO3ZhciBfdG9CYXNlPXJlcXVpcmUoXCIuLi9uZXh0LXNlcnZlci9saWIvdG8tYmFzZS02NFwiKTt2YXIgX2ltYWdlQ29uZmlnPXJlcXVpcmUoXCIuLi9uZXh0LXNlcnZlci9zZXJ2ZXIvaW1hZ2UtY29uZmlnXCIpO3ZhciBfdXNlSW50ZXJzZWN0aW9uPXJlcXVpcmUoXCIuL3VzZS1pbnRlcnNlY3Rpb25cIik7aWYodHlwZW9mIHdpbmRvdz09PSd1bmRlZmluZWQnKXs7Z2xvYmFsLl9fTkVYVF9JTUFHRV9JTVBPUlRFRD10cnVlO31jb25zdCBWQUxJRF9MT0FESU5HX1ZBTFVFUz1bJ2xhenknLCdlYWdlcicsdW5kZWZpbmVkXTtjb25zdCBsb2FkZXJzPW5ldyBNYXAoW1snaW1naXgnLGltZ2l4TG9hZGVyXSxbJ2Nsb3VkaW5hcnknLGNsb3VkaW5hcnlMb2FkZXJdLFsnYWthbWFpJyxha2FtYWlMb2FkZXJdLFsnZGVmYXVsdCcsZGVmYXVsdExvYWRlcl1dKTtjb25zdCBWQUxJRF9MQVlPVVRfVkFMVUVTPVsnZmlsbCcsJ2ZpeGVkJywnaW50cmluc2ljJywncmVzcG9uc2l2ZScsdW5kZWZpbmVkXTtmdW5jdGlvbiBpc1N0YXRpY1JlcXVpcmUoc3JjKXtyZXR1cm4gc3JjLmRlZmF1bHQhPT11bmRlZmluZWQ7fWZ1bmN0aW9uIGlzU3RhdGljSW1hZ2VEYXRhKHNyYyl7cmV0dXJuIHNyYy5zcmMhPT11bmRlZmluZWQ7fWZ1bmN0aW9uIGlzU3RhdGljSW1wb3J0KHNyYyl7cmV0dXJuIHR5cGVvZiBzcmM9PT0nb2JqZWN0JyYmKGlzU3RhdGljUmVxdWlyZShzcmMpfHxpc1N0YXRpY0ltYWdlRGF0YShzcmMpKTt9Y29uc3R7ZGV2aWNlU2l6ZXM6Y29uZmlnRGV2aWNlU2l6ZXMsaW1hZ2VTaXplczpjb25maWdJbWFnZVNpemVzLGxvYWRlcjpjb25maWdMb2FkZXIscGF0aDpjb25maWdQYXRoLGRvbWFpbnM6Y29uZmlnRG9tYWluc309cHJvY2Vzcy5lbnYuX19ORVhUX0lNQUdFX09QVFN8fF9pbWFnZUNvbmZpZy5pbWFnZUNvbmZpZ0RlZmF1bHQ7Ly8gc29ydCBzbWFsbGVzdCB0byBsYXJnZXN0XG5jb25zdCBhbGxTaXplcz1bLi4uY29uZmlnRGV2aWNlU2l6ZXMsLi4uY29uZmlnSW1hZ2VTaXplc107Y29uZmlnRGV2aWNlU2l6ZXMuc29ydCgoYSxiKT0+YS1iKTthbGxTaXplcy5zb3J0KChhLGIpPT5hLWIpO2Z1bmN0aW9uIGdldFdpZHRocyh3aWR0aCxsYXlvdXQsc2l6ZXMpe2lmKHNpemVzJiYobGF5b3V0PT09J2ZpbGwnfHxsYXlvdXQ9PT0ncmVzcG9uc2l2ZScpKXsvLyBGaW5kIGFsbCB0aGUgXCJ2d1wiIHBlcmNlbnQgc2l6ZXMgdXNlZCBpbiB0aGUgc2l6ZXMgcHJvcFxuY29uc3Qgdmlld3BvcnRXaWR0aFJlPS8oXnxcXHMpKDE/XFxkP1xcZCl2dy9nO2NvbnN0IHBlcmNlbnRTaXplcz1bXTtmb3IobGV0IG1hdGNoO21hdGNoPXZpZXdwb3J0V2lkdGhSZS5leGVjKHNpemVzKTttYXRjaCl7cGVyY2VudFNpemVzLnB1c2gocGFyc2VJbnQobWF0Y2hbMl0pKTt9aWYocGVyY2VudFNpemVzLmxlbmd0aCl7Y29uc3Qgc21hbGxlc3RSYXRpbz1NYXRoLm1pbiguLi5wZXJjZW50U2l6ZXMpKjAuMDE7cmV0dXJue3dpZHRoczphbGxTaXplcy5maWx0ZXIocz0+cz49Y29uZmlnRGV2aWNlU2l6ZXNbMF0qc21hbGxlc3RSYXRpbyksa2luZDondyd9O31yZXR1cm57d2lkdGhzOmFsbFNpemVzLGtpbmQ6J3cnfTt9aWYodHlwZW9mIHdpZHRoIT09J251bWJlcid8fGxheW91dD09PSdmaWxsJ3x8bGF5b3V0PT09J3Jlc3BvbnNpdmUnKXtyZXR1cm57d2lkdGhzOmNvbmZpZ0RldmljZVNpemVzLGtpbmQ6J3cnfTt9Y29uc3Qgd2lkdGhzPVsuLi5uZXcgU2V0KC8vID4gVGhpcyBtZWFucyB0aGF0IG1vc3QgT0xFRCBzY3JlZW5zIHRoYXQgc2F5IHRoZXkgYXJlIDN4IHJlc29sdXRpb24sXG4vLyA+IGFyZSBhY3R1YWxseSAzeCBpbiB0aGUgZ3JlZW4gY29sb3IsIGJ1dCBvbmx5IDEuNXggaW4gdGhlIHJlZCBhbmRcbi8vID4gYmx1ZSBjb2xvcnMuIFNob3dpbmcgYSAzeCByZXNvbHV0aW9uIGltYWdlIGluIHRoZSBhcHAgdnMgYSAyeFxuLy8gPiByZXNvbHV0aW9uIGltYWdlIHdpbGwgYmUgdmlzdWFsbHkgdGhlIHNhbWUsIHRob3VnaCB0aGUgM3ggaW1hZ2Vcbi8vID4gdGFrZXMgc2lnbmlmaWNhbnRseSBtb3JlIGRhdGEuIEV2ZW4gdHJ1ZSAzeCByZXNvbHV0aW9uIHNjcmVlbnMgYXJlXG4vLyA+IHdhc3RlZnVsIGFzIHRoZSBodW1hbiBleWUgY2Fubm90IHNlZSB0aGF0IGxldmVsIG9mIGRldGFpbCB3aXRob3V0XG4vLyA+IHNvbWV0aGluZyBsaWtlIGEgbWFnbmlmeWluZyBnbGFzcy5cbi8vIGh0dHBzOi8vYmxvZy50d2l0dGVyLmNvbS9lbmdpbmVlcmluZy9lbl91cy90b3BpY3MvaW5mcmFzdHJ1Y3R1cmUvMjAxOS9jYXBwaW5nLWltYWdlLWZpZGVsaXR5LW9uLXVsdHJhLWhpZ2gtcmVzb2x1dGlvbi1kZXZpY2VzLmh0bWxcblt3aWR0aCx3aWR0aCoyLyosIHdpZHRoICogMyovXS5tYXAodz0+YWxsU2l6ZXMuZmluZChwPT5wPj13KXx8YWxsU2l6ZXNbYWxsU2l6ZXMubGVuZ3RoLTFdKSldO3JldHVybnt3aWR0aHMsa2luZDoneCd9O31mdW5jdGlvbiBnZW5lcmF0ZUltZ0F0dHJzKHtzcmMsdW5vcHRpbWl6ZWQsbGF5b3V0LHdpZHRoLHF1YWxpdHksc2l6ZXMsbG9hZGVyfSl7aWYodW5vcHRpbWl6ZWQpe3JldHVybntzcmMsc3JjU2V0OnVuZGVmaW5lZCxzaXplczp1bmRlZmluZWR9O31jb25zdHt3aWR0aHMsa2luZH09Z2V0V2lkdGhzKHdpZHRoLGxheW91dCxzaXplcyk7Y29uc3QgbGFzdD13aWR0aHMubGVuZ3RoLTE7cmV0dXJue3NpemVzOiFzaXplcyYma2luZD09PSd3Jz8nMTAwdncnOnNpemVzLHNyY1NldDp3aWR0aHMubWFwKCh3LGkpPT5gJHtsb2FkZXIoe3NyYyxxdWFsaXR5LHdpZHRoOnd9KX0gJHtraW5kPT09J3cnP3c6aSsxfSR7a2luZH1gKS5qb2luKCcsICcpLC8vIEl0J3MgaW50ZW5kZWQgdG8ga2VlcCBgc3JjYCB0aGUgbGFzdCBhdHRyaWJ1dGUgYmVjYXVzZSBSZWFjdCB1cGRhdGVzXG4vLyBhdHRyaWJ1dGVzIGluIG9yZGVyLiBJZiB3ZSBrZWVwIGBzcmNgIHRoZSBmaXJzdCBvbmUsIFNhZmFyaSB3aWxsXG4vLyBpbW1lZGlhdGVseSBzdGFydCB0byBmZXRjaCBgc3JjYCwgYmVmb3JlIGBzaXplc2AgYW5kIGBzcmNTZXRgIGFyZSBldmVuXG4vLyB1cGRhdGVkIGJ5IFJlYWN0LiBUaGF0IGNhdXNlcyBtdWx0aXBsZSB1bm5lY2Vzc2FyeSByZXF1ZXN0cyBpZiBgc3JjU2V0YFxuLy8gYW5kIGBzaXplc2AgYXJlIGRlZmluZWQuXG4vLyBUaGlzIGJ1ZyBjYW5ub3QgYmUgcmVwcm9kdWNlZCBpbiBDaHJvbWUgb3IgRmlyZWZveC5cbnNyYzpsb2FkZXIoe3NyYyxxdWFsaXR5LHdpZHRoOndpZHRoc1tsYXN0XX0pfTt9ZnVuY3Rpb24gZ2V0SW50KHgpe2lmKHR5cGVvZiB4PT09J251bWJlcicpe3JldHVybiB4O31pZih0eXBlb2YgeD09PSdzdHJpbmcnKXtyZXR1cm4gcGFyc2VJbnQoeCwxMCk7fXJldHVybiB1bmRlZmluZWQ7fWZ1bmN0aW9uIGRlZmF1bHRJbWFnZUxvYWRlcihsb2FkZXJQcm9wcyl7Y29uc3QgbG9hZD1sb2FkZXJzLmdldChjb25maWdMb2FkZXIpO2lmKGxvYWQpe3JldHVybiBsb2FkKCgwLF9leHRlbmRzMi5kZWZhdWx0KSh7cm9vdDpjb25maWdQYXRofSxsb2FkZXJQcm9wcykpO310aHJvdyBuZXcgRXJyb3IoYFVua25vd24gXCJsb2FkZXJcIiBmb3VuZCBpbiBcIm5leHQuY29uZmlnLmpzXCIuIEV4cGVjdGVkOiAke19pbWFnZUNvbmZpZy5WQUxJRF9MT0FERVJTLmpvaW4oJywgJyl9LiBSZWNlaXZlZDogJHtjb25maWdMb2FkZXJ9YCk7fS8vIFNlZSBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL3EvMzk3Nzc4MzMvMjY2NTM1IGZvciB3aHkgd2UgdXNlIHRoaXMgcmVmXG4vLyBoYW5kbGVyIGluc3RlYWQgb2YgdGhlIGltZydzIG9uTG9hZCBhdHRyaWJ1dGUuXG5mdW5jdGlvbiByZW1vdmVQbGFjZWhvbGRlcihpbWcscGxhY2Vob2xkZXIpe2lmKHBsYWNlaG9sZGVyPT09J2JsdXInJiZpbWcpe2NvbnN0IGhhbmRsZUxvYWQ9KCk9PntpZighaW1nLnNyYy5zdGFydHNXaXRoKCdkYXRhOicpKXtjb25zdCBwPSdkZWNvZGUnaW4gaW1nP2ltZy5kZWNvZGUoKTpQcm9taXNlLnJlc29sdmUoKTtwLmNhdGNoKCgpPT57fSkudGhlbigoKT0+e2ltZy5zdHlsZS5maWx0ZXI9J25vbmUnO2ltZy5zdHlsZS5iYWNrZ3JvdW5kU2l6ZT0nbm9uZSc7aW1nLnN0eWxlLmJhY2tncm91bmRJbWFnZT0nbm9uZSc7fSk7fX07aWYoaW1nLmNvbXBsZXRlKXsvLyBJZiB0aGUgcmVhbCBpbWFnZSBmYWlscyB0byBsb2FkLCB0aGlzIHdpbGwgc3RpbGwgcmVtb3ZlIHRoZSBwbGFjZWhvbGRlci5cbi8vIFRoaXMgaXMgdGhlIGRlc2lyZWQgYmVoYXZpb3IgZm9yIG5vdywgYW5kIHdpbGwgYmUgcmV2aXNpdGVkIHdoZW4gZXJyb3Jcbi8vIGhhbmRsaW5nIGlzIHdvcmtlZCBvbiBmb3IgdGhlIGltYWdlIGNvbXBvbmVudCBpdHNlbGYuXG5oYW5kbGVMb2FkKCk7fWVsc2V7aW1nLm9ubG9hZD1oYW5kbGVMb2FkO319fWZ1bmN0aW9uIEltYWdlKF9yZWYpe2xldHtzcmMsc2l6ZXMsdW5vcHRpbWl6ZWQ9ZmFsc2UscHJpb3JpdHk9ZmFsc2UsbG9hZGluZyxjbGFzc05hbWUscXVhbGl0eSx3aWR0aCxoZWlnaHQsb2JqZWN0Rml0LG9iamVjdFBvc2l0aW9uLGxvYWRlcj1kZWZhdWx0SW1hZ2VMb2FkZXIscGxhY2Vob2xkZXI9J2VtcHR5JyxibHVyRGF0YVVSTH09X3JlZixhbGw9KDAsX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UyLmRlZmF1bHQpKF9yZWYsW1wic3JjXCIsXCJzaXplc1wiLFwidW5vcHRpbWl6ZWRcIixcInByaW9yaXR5XCIsXCJsb2FkaW5nXCIsXCJjbGFzc05hbWVcIixcInF1YWxpdHlcIixcIndpZHRoXCIsXCJoZWlnaHRcIixcIm9iamVjdEZpdFwiLFwib2JqZWN0UG9zaXRpb25cIixcImxvYWRlclwiLFwicGxhY2Vob2xkZXJcIixcImJsdXJEYXRhVVJMXCJdKTtsZXQgcmVzdD1hbGw7bGV0IGxheW91dD1zaXplcz8ncmVzcG9uc2l2ZSc6J2ludHJpbnNpYyc7aWYoJ2xheW91dCdpbiByZXN0KXsvLyBPdmVycmlkZSBkZWZhdWx0IGxheW91dCBpZiB0aGUgdXNlciBzcGVjaWZpZWQgb25lOlxuaWYocmVzdC5sYXlvdXQpbGF5b3V0PXJlc3QubGF5b3V0Oy8vIFJlbW92ZSBwcm9wZXJ0eSBzbyBpdCdzIG5vdCBzcHJlYWQgaW50byBpbWFnZTpcbmRlbGV0ZSByZXN0WydsYXlvdXQnXTt9bGV0IHN0YXRpY1NyYz0nJztpZihpc1N0YXRpY0ltcG9ydChzcmMpKXtjb25zdCBzdGF0aWNJbWFnZURhdGE9aXNTdGF0aWNSZXF1aXJlKHNyYyk/c3JjLmRlZmF1bHQ6c3JjO2lmKCFzdGF0aWNJbWFnZURhdGEuc3JjKXt0aHJvdyBuZXcgRXJyb3IoYEFuIG9iamVjdCBzaG91bGQgb25seSBiZSBwYXNzZWQgdG8gdGhlIGltYWdlIGNvbXBvbmVudCBzcmMgcGFyYW1ldGVyIGlmIGl0IGNvbWVzIGZyb20gYSBzdGF0aWMgaW1hZ2UgaW1wb3J0LiBJdCBtdXN0IGluY2x1ZGUgc3JjLiBSZWNlaXZlZCAke0pTT04uc3RyaW5naWZ5KHN0YXRpY0ltYWdlRGF0YSl9YCk7fWJsdXJEYXRhVVJMPWJsdXJEYXRhVVJMfHxzdGF0aWNJbWFnZURhdGEuYmx1ckRhdGFVUkw7c3RhdGljU3JjPXN0YXRpY0ltYWdlRGF0YS5zcmM7aWYoIWxheW91dHx8bGF5b3V0IT09J2ZpbGwnKXtoZWlnaHQ9aGVpZ2h0fHxzdGF0aWNJbWFnZURhdGEuaGVpZ2h0O3dpZHRoPXdpZHRofHxzdGF0aWNJbWFnZURhdGEud2lkdGg7aWYoIXN0YXRpY0ltYWdlRGF0YS5oZWlnaHR8fCFzdGF0aWNJbWFnZURhdGEud2lkdGgpe3Rocm93IG5ldyBFcnJvcihgQW4gb2JqZWN0IHNob3VsZCBvbmx5IGJlIHBhc3NlZCB0byB0aGUgaW1hZ2UgY29tcG9uZW50IHNyYyBwYXJhbWV0ZXIgaWYgaXQgY29tZXMgZnJvbSBhIHN0YXRpYyBpbWFnZSBpbXBvcnQuIEl0IG11c3QgaW5jbHVkZSBoZWlnaHQgYW5kIHdpZHRoLiBSZWNlaXZlZCAke0pTT04uc3RyaW5naWZ5KHN0YXRpY0ltYWdlRGF0YSl9YCk7fX19c3JjPXR5cGVvZiBzcmM9PT0nc3RyaW5nJz9zcmM6c3RhdGljU3JjO2NvbnN0IHdpZHRoSW50PWdldEludCh3aWR0aCk7Y29uc3QgaGVpZ2h0SW50PWdldEludChoZWlnaHQpO2NvbnN0IHF1YWxpdHlJbnQ9Z2V0SW50KHF1YWxpdHkpO2lmKHByb2Nlc3MuZW52Lk5PREVfRU5WIT09J3Byb2R1Y3Rpb24nKXtpZighc3JjKXt0aHJvdyBuZXcgRXJyb3IoYEltYWdlIGlzIG1pc3NpbmcgcmVxdWlyZWQgXCJzcmNcIiBwcm9wZXJ0eS4gTWFrZSBzdXJlIHlvdSBwYXNzIFwic3JjXCIgaW4gcHJvcHMgdG8gdGhlIFxcYG5leHQvaW1hZ2VcXGAgY29tcG9uZW50LiBSZWNlaXZlZDogJHtKU09OLnN0cmluZ2lmeSh7d2lkdGgsaGVpZ2h0LHF1YWxpdHl9KX1gKTt9aWYoIVZBTElEX0xBWU9VVF9WQUxVRVMuaW5jbHVkZXMobGF5b3V0KSl7dGhyb3cgbmV3IEVycm9yKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBpbnZhbGlkIFwibGF5b3V0XCIgcHJvcGVydHkuIFByb3ZpZGVkIFwiJHtsYXlvdXR9XCIgc2hvdWxkIGJlIG9uZSBvZiAke1ZBTElEX0xBWU9VVF9WQUxVRVMubWFwKFN0cmluZykuam9pbignLCcpfS5gKTt9aWYoIVZBTElEX0xPQURJTkdfVkFMVUVTLmluY2x1ZGVzKGxvYWRpbmcpKXt0aHJvdyBuZXcgRXJyb3IoYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaGFzIGludmFsaWQgXCJsb2FkaW5nXCIgcHJvcGVydHkuIFByb3ZpZGVkIFwiJHtsb2FkaW5nfVwiIHNob3VsZCBiZSBvbmUgb2YgJHtWQUxJRF9MT0FESU5HX1ZBTFVFUy5tYXAoU3RyaW5nKS5qb2luKCcsJyl9LmApO31pZihwcmlvcml0eSYmbG9hZGluZz09PSdsYXp5Jyl7dGhyb3cgbmV3IEVycm9yKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBib3RoIFwicHJpb3JpdHlcIiBhbmQgXCJsb2FkaW5nPSdsYXp5J1wiIHByb3BlcnRpZXMuIE9ubHkgb25lIHNob3VsZCBiZSB1c2VkLmApO31pZihwbGFjZWhvbGRlcj09PSdibHVyJyl7aWYoKHdpZHRoSW50fHwwKSooaGVpZ2h0SW50fHwwKTwxNjAwKXtjb25zb2xlLndhcm4oYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaXMgc21hbGxlciB0aGFuIDQweDQwLiBDb25zaWRlciByZW1vdmluZyB0aGUgXCJwbGFjZWhvbGRlcj0nYmx1cidcIiBwcm9wZXJ0eSB0byBpbXByb3ZlIHBlcmZvcm1hbmNlLmApO31pZighYmx1ckRhdGFVUkwpe2NvbnN0IFZBTElEX0JMVVJfRVhUPVsnanBlZycsJ3BuZycsJ3dlYnAnXTsvLyBzaG91bGQgbWF0Y2ggbmV4dC1pbWFnZS1sb2FkZXJcbnRocm93IG5ldyBFcnJvcihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgXCJwbGFjZWhvbGRlcj0nYmx1cidcIiBwcm9wZXJ0eSBidXQgaXMgbWlzc2luZyB0aGUgXCJibHVyRGF0YVVSTFwiIHByb3BlcnR5LlxuICAgICAgICAgIFBvc3NpYmxlIHNvbHV0aW9uczpcbiAgICAgICAgICAgIC0gQWRkIGEgXCJibHVyRGF0YVVSTFwiIHByb3BlcnR5LCB0aGUgY29udGVudHMgc2hvdWxkIGJlIGEgc21hbGwgRGF0YSBVUkwgdG8gcmVwcmVzZW50IHRoZSBpbWFnZVxuICAgICAgICAgICAgLSBDaGFuZ2UgdGhlIFwic3JjXCIgcHJvcGVydHkgdG8gYSBzdGF0aWMgaW1wb3J0IHdpdGggb25lIG9mIHRoZSBzdXBwb3J0ZWQgZmlsZSB0eXBlczogJHtWQUxJRF9CTFVSX0VYVC5qb2luKCcsJyl9XG4gICAgICAgICAgICAtIFJlbW92ZSB0aGUgXCJwbGFjZWhvbGRlclwiIHByb3BlcnR5LCBlZmZlY3RpdmVseSBubyBibHVyIGVmZmVjdFxuICAgICAgICAgIFJlYWQgbW9yZTogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvcGxhY2Vob2xkZXItYmx1ci1kYXRhLXVybGApO319fWxldCBpc0xhenk9IXByaW9yaXR5JiYobG9hZGluZz09PSdsYXp5J3x8dHlwZW9mIGxvYWRpbmc9PT0ndW5kZWZpbmVkJyk7aWYoc3JjJiZzcmMuc3RhcnRzV2l0aCgnZGF0YTonKSl7Ly8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSFRUUC9CYXNpY3Nfb2ZfSFRUUC9EYXRhX1VSSXNcbnVub3B0aW1pemVkPXRydWU7aXNMYXp5PWZhbHNlO31jb25zdFtzZXRSZWYsaXNJbnRlcnNlY3RlZF09KDAsX3VzZUludGVyc2VjdGlvbi51c2VJbnRlcnNlY3Rpb24pKHtyb290TWFyZ2luOicyMDBweCcsZGlzYWJsZWQ6IWlzTGF6eX0pO2NvbnN0IGlzVmlzaWJsZT0haXNMYXp5fHxpc0ludGVyc2VjdGVkO2xldCB3cmFwcGVyU3R5bGU7bGV0IHNpemVyU3R5bGU7bGV0IHNpemVyU3ZnO2xldCBpbWdTdHlsZT0oMCxfZXh0ZW5kczIuZGVmYXVsdCkoe3Bvc2l0aW9uOidhYnNvbHV0ZScsdG9wOjAsbGVmdDowLGJvdHRvbTowLHJpZ2h0OjAsYm94U2l6aW5nOidib3JkZXItYm94JyxwYWRkaW5nOjAsYm9yZGVyOidub25lJyxtYXJnaW46J2F1dG8nLGRpc3BsYXk6J2Jsb2NrJyx3aWR0aDowLGhlaWdodDowLG1pbldpZHRoOicxMDAlJyxtYXhXaWR0aDonMTAwJScsbWluSGVpZ2h0OicxMDAlJyxtYXhIZWlnaHQ6JzEwMCUnLG9iamVjdEZpdCxvYmplY3RQb3NpdGlvbn0scGxhY2Vob2xkZXI9PT0nYmx1cic/e2ZpbHRlcjonYmx1cigyMHB4KScsYmFja2dyb3VuZFNpemU6J2NvdmVyJyxiYWNrZ3JvdW5kSW1hZ2U6YHVybChcIiR7Ymx1ckRhdGFVUkx9XCIpYH06dW5kZWZpbmVkKTtpZih0eXBlb2Ygd2lkdGhJbnQhPT0ndW5kZWZpbmVkJyYmdHlwZW9mIGhlaWdodEludCE9PSd1bmRlZmluZWQnJiZsYXlvdXQhPT0nZmlsbCcpey8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgLz5cbmNvbnN0IHF1b3RpZW50PWhlaWdodEludC93aWR0aEludDtjb25zdCBwYWRkaW5nVG9wPWlzTmFOKHF1b3RpZW50KT8nMTAwJSc6YCR7cXVvdGllbnQqMTAwfSVgO2lmKGxheW91dD09PSdyZXNwb25zaXZlJyl7Ly8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJyZXNwb25zaXZlXCIgLz5cbndyYXBwZXJTdHlsZT17ZGlzcGxheTonYmxvY2snLG92ZXJmbG93OidoaWRkZW4nLHBvc2l0aW9uOidyZWxhdGl2ZScsYm94U2l6aW5nOidib3JkZXItYm94JyxtYXJnaW46MH07c2l6ZXJTdHlsZT17ZGlzcGxheTonYmxvY2snLGJveFNpemluZzonYm9yZGVyLWJveCcscGFkZGluZ1RvcH07fWVsc2UgaWYobGF5b3V0PT09J2ludHJpbnNpYycpey8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwiaW50cmluc2ljXCIgLz5cbndyYXBwZXJTdHlsZT17ZGlzcGxheTonaW5saW5lLWJsb2NrJyxtYXhXaWR0aDonMTAwJScsb3ZlcmZsb3c6J2hpZGRlbicscG9zaXRpb246J3JlbGF0aXZlJyxib3hTaXppbmc6J2JvcmRlci1ib3gnLG1hcmdpbjowfTtzaXplclN0eWxlPXtib3hTaXppbmc6J2JvcmRlci1ib3gnLGRpc3BsYXk6J2Jsb2NrJyxtYXhXaWR0aDonMTAwJSd9O3NpemVyU3ZnPWA8c3ZnIHdpZHRoPVwiJHt3aWR0aEludH1cIiBoZWlnaHQ9XCIke2hlaWdodEludH1cIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgdmVyc2lvbj1cIjEuMVwiLz5gO31lbHNlIGlmKGxheW91dD09PSdmaXhlZCcpey8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwiZml4ZWRcIiAvPlxud3JhcHBlclN0eWxlPXtvdmVyZmxvdzonaGlkZGVuJyxib3hTaXppbmc6J2JvcmRlci1ib3gnLGRpc3BsYXk6J2lubGluZS1ibG9jaycscG9zaXRpb246J3JlbGF0aXZlJyx3aWR0aDp3aWR0aEludCxoZWlnaHQ6aGVpZ2h0SW50fTt9fWVsc2UgaWYodHlwZW9mIHdpZHRoSW50PT09J3VuZGVmaW5lZCcmJnR5cGVvZiBoZWlnaHRJbnQ9PT0ndW5kZWZpbmVkJyYmbGF5b3V0PT09J2ZpbGwnKXsvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiBsYXlvdXQ9XCJmaWxsXCIgLz5cbndyYXBwZXJTdHlsZT17ZGlzcGxheTonYmxvY2snLG92ZXJmbG93OidoaWRkZW4nLHBvc2l0aW9uOidhYnNvbHV0ZScsdG9wOjAsbGVmdDowLGJvdHRvbTowLHJpZ2h0OjAsYm94U2l6aW5nOidib3JkZXItYm94JyxtYXJnaW46MH07fWVsc2V7Ly8gPEltYWdlIHNyYz1cImkucG5nXCIgLz5cbmlmKHByb2Nlc3MuZW52Lk5PREVfRU5WIT09J3Byb2R1Y3Rpb24nKXt0aHJvdyBuZXcgRXJyb3IoYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgbXVzdCB1c2UgXCJ3aWR0aFwiIGFuZCBcImhlaWdodFwiIHByb3BlcnRpZXMgb3IgXCJsYXlvdXQ9J2ZpbGwnXCIgcHJvcGVydHkuYCk7fX1sZXQgaW1nQXR0cmlidXRlcz17c3JjOidkYXRhOmltYWdlL2dpZjtiYXNlNjQsUjBsR09EbGhBUUFCQUlBQUFBQUFBUC8vL3lINUJBRUFBQUFBTEFBQUFBQUJBQUVBQUFJQlJBQTcnLHNyY1NldDp1bmRlZmluZWQsc2l6ZXM6dW5kZWZpbmVkfTtpZihpc1Zpc2libGUpe2ltZ0F0dHJpYnV0ZXM9Z2VuZXJhdGVJbWdBdHRycyh7c3JjLHVub3B0aW1pemVkLGxheW91dCx3aWR0aDp3aWR0aEludCxxdWFsaXR5OnF1YWxpdHlJbnQsc2l6ZXMsbG9hZGVyfSk7fXJldHVybi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIse3N0eWxlOndyYXBwZXJTdHlsZX0sc2l6ZXJTdHlsZT8vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImRpdlwiLHtzdHlsZTpzaXplclN0eWxlfSxzaXplclN2Zz8vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImltZ1wiLHtzdHlsZTp7bWF4V2lkdGg6JzEwMCUnLGRpc3BsYXk6J2Jsb2NrJyxtYXJnaW46MCxib3JkZXI6J25vbmUnLHBhZGRpbmc6MH0sYWx0OlwiXCIsXCJhcmlhLWhpZGRlblwiOnRydWUscm9sZTpcInByZXNlbnRhdGlvblwiLHNyYzpgZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCwkeygwLF90b0Jhc2UudG9CYXNlNjQpKHNpemVyU3ZnKX1gfSk6bnVsbCk6bnVsbCwhaXNWaXNpYmxlJiYvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcIm5vc2NyaXB0XCIsbnVsbCwvKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImltZ1wiLE9iamVjdC5hc3NpZ24oe30scmVzdCxnZW5lcmF0ZUltZ0F0dHJzKHtzcmMsdW5vcHRpbWl6ZWQsbGF5b3V0LHdpZHRoOndpZHRoSW50LHF1YWxpdHk6cXVhbGl0eUludCxzaXplcyxsb2FkZXJ9KSx7c3JjOnNyYyxkZWNvZGluZzpcImFzeW5jXCIsc2l6ZXM6c2l6ZXMsc3R5bGU6aW1nU3R5bGUsY2xhc3NOYW1lOmNsYXNzTmFtZX0pKSksLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIixPYmplY3QuYXNzaWduKHt9LHJlc3QsaW1nQXR0cmlidXRlcyx7ZGVjb2Rpbmc6XCJhc3luY1wiLGNsYXNzTmFtZTpjbGFzc05hbWUscmVmOmVsZW1lbnQ9PntzZXRSZWYoZWxlbWVudCk7cmVtb3ZlUGxhY2Vob2xkZXIoZWxlbWVudCxwbGFjZWhvbGRlcik7fSxzdHlsZTppbWdTdHlsZX0pKSxwcmlvcml0eT8vKiNfX1BVUkVfXyovIC8vIE5vdGUgaG93IHdlIG9taXQgdGhlIGBocmVmYCBhdHRyaWJ1dGUsIGFzIGl0IHdvdWxkIG9ubHkgYmUgcmVsZXZhbnRcbi8vIGZvciBicm93c2VycyB0aGF0IGRvIG5vdCBzdXBwb3J0IGBpbWFnZXNyY3NldGAsIGFuZCBpbiB0aG9zZSBjYXNlc1xuLy8gaXQgd291bGQgbGlrZWx5IGNhdXNlIHRoZSBpbmNvcnJlY3QgaW1hZ2UgdG8gYmUgcHJlbG9hZGVkLlxuLy9cbi8vIGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL3NlbWFudGljcy5odG1sI2F0dHItbGluay1pbWFnZXNyY3NldFxuX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChfaGVhZC5kZWZhdWx0LG51bGwsLyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJsaW5rXCIse2tleTonX19uaW1nLScraW1nQXR0cmlidXRlcy5zcmMraW1nQXR0cmlidXRlcy5zcmNTZXQraW1nQXR0cmlidXRlcy5zaXplcyxyZWw6XCJwcmVsb2FkXCIsYXM6XCJpbWFnZVwiLGhyZWY6aW1nQXR0cmlidXRlcy5zcmNTZXQ/dW5kZWZpbmVkOmltZ0F0dHJpYnV0ZXMuc3JjLy8gQHRzLWlnbm9yZTogaW1hZ2VzcmNzZXQgaXMgbm90IHlldCBpbiB0aGUgbGluayBlbGVtZW50IHR5cGVcbixpbWFnZXNyY3NldDppbWdBdHRyaWJ1dGVzLnNyY1NldC8vIEB0cy1pZ25vcmU6IGltYWdlc2l6ZXMgaXMgbm90IHlldCBpbiB0aGUgbGluayBlbGVtZW50IHR5cGVcbixpbWFnZXNpemVzOmltZ0F0dHJpYnV0ZXMuc2l6ZXN9KSk6bnVsbCk7fS8vQlVJTFQgSU4gTE9BREVSU1xuZnVuY3Rpb24gbm9ybWFsaXplU3JjKHNyYyl7cmV0dXJuIHNyY1swXT09PScvJz9zcmMuc2xpY2UoMSk6c3JjO31mdW5jdGlvbiBpbWdpeExvYWRlcih7cm9vdCxzcmMsd2lkdGgscXVhbGl0eX0pey8vIERlbW86IGh0dHBzOi8vc3RhdGljLmltZ2l4Lm5ldC9kYWlzeS5wbmc/Zm9ybWF0PWF1dG8mZml0PW1heCZ3PTMwMFxuY29uc3QgcGFyYW1zPVsnYXV0bz1mb3JtYXQnLCdmaXQ9bWF4Jywndz0nK3dpZHRoXTtsZXQgcGFyYW1zU3RyaW5nPScnO2lmKHF1YWxpdHkpe3BhcmFtcy5wdXNoKCdxPScrcXVhbGl0eSk7fWlmKHBhcmFtcy5sZW5ndGgpe3BhcmFtc1N0cmluZz0nPycrcGFyYW1zLmpvaW4oJyYnKTt9cmV0dXJuYCR7cm9vdH0ke25vcm1hbGl6ZVNyYyhzcmMpfSR7cGFyYW1zU3RyaW5nfWA7fWZ1bmN0aW9uIGFrYW1haUxvYWRlcih7cm9vdCxzcmMsd2lkdGh9KXtyZXR1cm5gJHtyb290fSR7bm9ybWFsaXplU3JjKHNyYyl9P2ltd2lkdGg9JHt3aWR0aH1gO31mdW5jdGlvbiBjbG91ZGluYXJ5TG9hZGVyKHtyb290LHNyYyx3aWR0aCxxdWFsaXR5fSl7Ly8gRGVtbzogaHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vZGVtby9pbWFnZS91cGxvYWQvd18zMDAsY19saW1pdCxxX2F1dG8vdHVydGxlcy5qcGdcbmNvbnN0IHBhcmFtcz1bJ2ZfYXV0bycsJ2NfbGltaXQnLCd3Xycrd2lkdGgsJ3FfJysocXVhbGl0eXx8J2F1dG8nKV07bGV0IHBhcmFtc1N0cmluZz1wYXJhbXMuam9pbignLCcpKycvJztyZXR1cm5gJHtyb290fSR7cGFyYW1zU3RyaW5nfSR7bm9ybWFsaXplU3JjKHNyYyl9YDt9ZnVuY3Rpb24gZGVmYXVsdExvYWRlcih7cm9vdCxzcmMsd2lkdGgscXVhbGl0eX0pe2lmKHByb2Nlc3MuZW52Lk5PREVfRU5WIT09J3Byb2R1Y3Rpb24nKXtjb25zdCBtaXNzaW5nVmFsdWVzPVtdOy8vIHRoZXNlIHNob3VsZCBhbHdheXMgYmUgcHJvdmlkZWQgYnV0IG1ha2Ugc3VyZSB0aGV5IGFyZVxuaWYoIXNyYyltaXNzaW5nVmFsdWVzLnB1c2goJ3NyYycpO2lmKCF3aWR0aCltaXNzaW5nVmFsdWVzLnB1c2goJ3dpZHRoJyk7aWYobWlzc2luZ1ZhbHVlcy5sZW5ndGg+MCl7dGhyb3cgbmV3IEVycm9yKGBOZXh0IEltYWdlIE9wdGltaXphdGlvbiByZXF1aXJlcyAke21pc3NpbmdWYWx1ZXMuam9pbignLCAnKX0gdG8gYmUgcHJvdmlkZWQuIE1ha2Ugc3VyZSB5b3UgcGFzcyB0aGVtIGFzIHByb3BzIHRvIHRoZSBcXGBuZXh0L2ltYWdlXFxgIGNvbXBvbmVudC4gUmVjZWl2ZWQ6ICR7SlNPTi5zdHJpbmdpZnkoe3NyYyx3aWR0aCxxdWFsaXR5fSl9YCk7fWlmKHNyYy5zdGFydHNXaXRoKCcvLycpKXt0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBwYXJzZSBzcmMgXCIke3NyY31cIiBvbiBcXGBuZXh0L2ltYWdlXFxgLCBwcm90b2NvbC1yZWxhdGl2ZSBVUkwgKC8vKSBtdXN0IGJlIGNoYW5nZWQgdG8gYW4gYWJzb2x1dGUgVVJMIChodHRwOi8vIG9yIGh0dHBzOi8vKWApO31pZighc3JjLnN0YXJ0c1dpdGgoJy8nKSYmY29uZmlnRG9tYWlucyl7bGV0IHBhcnNlZFNyYzt0cnl7cGFyc2VkU3JjPW5ldyBVUkwoc3JjKTt9Y2F0Y2goZXJyKXtjb25zb2xlLmVycm9yKGVycik7dGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gcGFyc2Ugc3JjIFwiJHtzcmN9XCIgb24gXFxgbmV4dC9pbWFnZVxcYCwgaWYgdXNpbmcgcmVsYXRpdmUgaW1hZ2UgaXQgbXVzdCBzdGFydCB3aXRoIGEgbGVhZGluZyBzbGFzaCBcIi9cIiBvciBiZSBhbiBhYnNvbHV0ZSBVUkwgKGh0dHA6Ly8gb3IgaHR0cHM6Ly8pYCk7fWlmKCFjb25maWdEb21haW5zLmluY2x1ZGVzKHBhcnNlZFNyYy5ob3N0bmFtZSkpe3Rocm93IG5ldyBFcnJvcihgSW52YWxpZCBzcmMgcHJvcCAoJHtzcmN9KSBvbiBcXGBuZXh0L2ltYWdlXFxgLCBob3N0bmFtZSBcIiR7cGFyc2VkU3JjLmhvc3RuYW1lfVwiIGlzIG5vdCBjb25maWd1cmVkIHVuZGVyIGltYWdlcyBpbiB5b3VyIFxcYG5leHQuY29uZmlnLmpzXFxgXFxuYCtgU2VlIG1vcmUgaW5mbzogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvbmV4dC1pbWFnZS11bmNvbmZpZ3VyZWQtaG9zdGApO319fXJldHVybmAke3Jvb3R9P3VybD0ke2VuY29kZVVSSUNvbXBvbmVudChzcmMpfSZ3PSR7d2lkdGh9JnE9JHtxdWFsaXR5fHw3NX1gO31cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWltYWdlLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO3ZhciBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZD1yZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkXCIpO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMuZGVmYXVsdD12b2lkIDA7dmFyIF9yZWFjdD1faW50ZXJvcFJlcXVpcmVXaWxkY2FyZChyZXF1aXJlKFwicmVhY3RcIikpO3ZhciBfcm91dGVyPXJlcXVpcmUoXCIuLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3JvdXRlclwiKTt2YXIgX3JvdXRlcjI9cmVxdWlyZShcIi4vcm91dGVyXCIpO3ZhciBfdXNlSW50ZXJzZWN0aW9uPXJlcXVpcmUoXCIuL3VzZS1pbnRlcnNlY3Rpb25cIik7Y29uc3QgcHJlZmV0Y2hlZD17fTtmdW5jdGlvbiBwcmVmZXRjaChyb3V0ZXIsaHJlZixhcyxvcHRpb25zKXtpZih0eXBlb2Ygd2luZG93PT09J3VuZGVmaW5lZCd8fCFyb3V0ZXIpcmV0dXJuO2lmKCEoMCxfcm91dGVyLmlzTG9jYWxVUkwpKGhyZWYpKXJldHVybjsvLyBQcmVmZXRjaCB0aGUgSlNPTiBwYWdlIGlmIGFza2VkIChvbmx5IGluIHRoZSBjbGllbnQpXG4vLyBXZSBuZWVkIHRvIGhhbmRsZSBhIHByZWZldGNoIGVycm9yIGhlcmUgc2luY2Ugd2UgbWF5IGJlXG4vLyBsb2FkaW5nIHdpdGggcHJpb3JpdHkgd2hpY2ggY2FuIHJlamVjdCBidXQgd2UgZG9uJ3Rcbi8vIHdhbnQgdG8gZm9yY2UgbmF2aWdhdGlvbiBzaW5jZSB0aGlzIGlzIG9ubHkgYSBwcmVmZXRjaFxucm91dGVyLnByZWZldGNoKGhyZWYsYXMsb3B0aW9ucykuY2F0Y2goZXJyPT57aWYocHJvY2Vzcy5lbnYuTk9ERV9FTlYhPT0ncHJvZHVjdGlvbicpey8vIHJldGhyb3cgdG8gc2hvdyBpbnZhbGlkIFVSTCBlcnJvcnNcbnRocm93IGVycjt9fSk7Y29uc3QgY3VyTG9jYWxlPW9wdGlvbnMmJnR5cGVvZiBvcHRpb25zLmxvY2FsZSE9PSd1bmRlZmluZWQnP29wdGlvbnMubG9jYWxlOnJvdXRlciYmcm91dGVyLmxvY2FsZTsvLyBKb2luIG9uIGFuIGludmFsaWQgVVJJIGNoYXJhY3RlclxucHJlZmV0Y2hlZFtocmVmKyclJythcysoY3VyTG9jYWxlPyclJytjdXJMb2NhbGU6JycpXT10cnVlO31mdW5jdGlvbiBpc01vZGlmaWVkRXZlbnQoZXZlbnQpe2NvbnN0e3RhcmdldH09ZXZlbnQuY3VycmVudFRhcmdldDtyZXR1cm4gdGFyZ2V0JiZ0YXJnZXQhPT0nX3NlbGYnfHxldmVudC5tZXRhS2V5fHxldmVudC5jdHJsS2V5fHxldmVudC5zaGlmdEtleXx8ZXZlbnQuYWx0S2V5fHwvLyB0cmlnZ2VycyByZXNvdXJjZSBkb3dubG9hZFxuZXZlbnQubmF0aXZlRXZlbnQmJmV2ZW50Lm5hdGl2ZUV2ZW50LndoaWNoPT09Mjt9ZnVuY3Rpb24gbGlua0NsaWNrZWQoZSxyb3V0ZXIsaHJlZixhcyxyZXBsYWNlLHNoYWxsb3csc2Nyb2xsLGxvY2FsZSl7Y29uc3R7bm9kZU5hbWV9PWUuY3VycmVudFRhcmdldDtpZihub2RlTmFtZT09PSdBJyYmKGlzTW9kaWZpZWRFdmVudChlKXx8ISgwLF9yb3V0ZXIuaXNMb2NhbFVSTCkoaHJlZikpKXsvLyBpZ25vcmUgY2xpY2sgZm9yIGJyb3dzZXLigJlzIGRlZmF1bHQgYmVoYXZpb3JcbnJldHVybjt9ZS5wcmV2ZW50RGVmYXVsdCgpOy8vICBhdm9pZCBzY3JvbGwgZm9yIHVybHMgd2l0aCBhbmNob3IgcmVmc1xuaWYoc2Nyb2xsPT1udWxsJiZhcy5pbmRleE9mKCcjJyk+PTApe3Njcm9sbD1mYWxzZTt9Ly8gcmVwbGFjZSBzdGF0ZSBpbnN0ZWFkIG9mIHB1c2ggaWYgcHJvcCBpcyBwcmVzZW50XG5yb3V0ZXJbcmVwbGFjZT8ncmVwbGFjZSc6J3B1c2gnXShocmVmLGFzLHtzaGFsbG93LGxvY2FsZSxzY3JvbGx9KTt9ZnVuY3Rpb24gTGluayhwcm9wcyl7aWYocHJvY2Vzcy5lbnYuTk9ERV9FTlYhPT0ncHJvZHVjdGlvbicpe2Z1bmN0aW9uIGNyZWF0ZVByb3BFcnJvcihhcmdzKXtyZXR1cm4gbmV3IEVycm9yKGBGYWlsZWQgcHJvcCB0eXBlOiBUaGUgcHJvcCBcXGAke2FyZ3Mua2V5fVxcYCBleHBlY3RzIGEgJHthcmdzLmV4cGVjdGVkfSBpbiBcXGA8TGluaz5cXGAsIGJ1dCBnb3QgXFxgJHthcmdzLmFjdHVhbH1cXGAgaW5zdGVhZC5gKyh0eXBlb2Ygd2luZG93IT09J3VuZGVmaW5lZCc/XCJcXG5PcGVuIHlvdXIgYnJvd3NlcidzIGNvbnNvbGUgdG8gdmlldyB0aGUgQ29tcG9uZW50IHN0YWNrIHRyYWNlLlwiOicnKSk7fS8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG5jb25zdCByZXF1aXJlZFByb3BzR3VhcmQ9e2hyZWY6dHJ1ZX07Y29uc3QgcmVxdWlyZWRQcm9wcz1PYmplY3Qua2V5cyhyZXF1aXJlZFByb3BzR3VhcmQpO3JlcXVpcmVkUHJvcHMuZm9yRWFjaChrZXk9PntpZihrZXk9PT0naHJlZicpe2lmKHByb3BzW2tleV09PW51bGx8fHR5cGVvZiBwcm9wc1trZXldIT09J3N0cmluZycmJnR5cGVvZiBwcm9wc1trZXldIT09J29iamVjdCcpe3Rocm93IGNyZWF0ZVByb3BFcnJvcih7a2V5LGV4cGVjdGVkOidgc3RyaW5nYCBvciBgb2JqZWN0YCcsYWN0dWFsOnByb3BzW2tleV09PT1udWxsPydudWxsJzp0eXBlb2YgcHJvcHNba2V5XX0pO319ZWxzZXsvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuY29uc3QgXz1rZXk7fX0pOy8vIFR5cGVTY3JpcHQgdHJpY2sgZm9yIHR5cGUtZ3VhcmRpbmc6XG5jb25zdCBvcHRpb25hbFByb3BzR3VhcmQ9e2FzOnRydWUscmVwbGFjZTp0cnVlLHNjcm9sbDp0cnVlLHNoYWxsb3c6dHJ1ZSxwYXNzSHJlZjp0cnVlLHByZWZldGNoOnRydWUsbG9jYWxlOnRydWV9O2NvbnN0IG9wdGlvbmFsUHJvcHM9T2JqZWN0LmtleXMob3B0aW9uYWxQcm9wc0d1YXJkKTtvcHRpb25hbFByb3BzLmZvckVhY2goa2V5PT57Y29uc3QgdmFsVHlwZT10eXBlb2YgcHJvcHNba2V5XTtpZihrZXk9PT0nYXMnKXtpZihwcm9wc1trZXldJiZ2YWxUeXBlIT09J3N0cmluZycmJnZhbFR5cGUhPT0nb2JqZWN0Jyl7dGhyb3cgY3JlYXRlUHJvcEVycm9yKHtrZXksZXhwZWN0ZWQ6J2BzdHJpbmdgIG9yIGBvYmplY3RgJyxhY3R1YWw6dmFsVHlwZX0pO319ZWxzZSBpZihrZXk9PT0nbG9jYWxlJyl7aWYocHJvcHNba2V5XSYmdmFsVHlwZSE9PSdzdHJpbmcnKXt0aHJvdyBjcmVhdGVQcm9wRXJyb3Ioe2tleSxleHBlY3RlZDonYHN0cmluZ2AnLGFjdHVhbDp2YWxUeXBlfSk7fX1lbHNlIGlmKGtleT09PSdyZXBsYWNlJ3x8a2V5PT09J3Njcm9sbCd8fGtleT09PSdzaGFsbG93J3x8a2V5PT09J3Bhc3NIcmVmJ3x8a2V5PT09J3ByZWZldGNoJyl7aWYocHJvcHNba2V5XSE9bnVsbCYmdmFsVHlwZSE9PSdib29sZWFuJyl7dGhyb3cgY3JlYXRlUHJvcEVycm9yKHtrZXksZXhwZWN0ZWQ6J2Bib29sZWFuYCcsYWN0dWFsOnZhbFR5cGV9KTt9fWVsc2V7Ly8gVHlwZVNjcmlwdCB0cmljayBmb3IgdHlwZS1ndWFyZGluZzpcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbmNvbnN0IF89a2V5O319KTsvLyBUaGlzIGhvb2sgaXMgaW4gYSBjb25kaXRpb25hbCBidXQgdGhhdCBpcyBvayBiZWNhdXNlIGBwcm9jZXNzLmVudi5OT0RFX0VOVmAgbmV2ZXIgY2hhbmdlc1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG5jb25zdCBoYXNXYXJuZWQ9X3JlYWN0LmRlZmF1bHQudXNlUmVmKGZhbHNlKTtpZihwcm9wcy5wcmVmZXRjaCYmIWhhc1dhcm5lZC5jdXJyZW50KXtoYXNXYXJuZWQuY3VycmVudD10cnVlO2NvbnNvbGUud2FybignTmV4dC5qcyBhdXRvLXByZWZldGNoZXMgYXV0b21hdGljYWxseSBiYXNlZCBvbiB2aWV3cG9ydC4gVGhlIHByZWZldGNoIGF0dHJpYnV0ZSBpcyBubyBsb25nZXIgbmVlZGVkLiBNb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9wcmVmZXRjaC10cnVlLWRlcHJlY2F0ZWQnKTt9fWNvbnN0IHA9cHJvcHMucHJlZmV0Y2ghPT1mYWxzZTtjb25zdCByb3V0ZXI9KDAsX3JvdXRlcjIudXNlUm91dGVyKSgpO2NvbnN0e2hyZWYsYXN9PV9yZWFjdC5kZWZhdWx0LnVzZU1lbW8oKCk9Pntjb25zdFtyZXNvbHZlZEhyZWYscmVzb2x2ZWRBc109KDAsX3JvdXRlci5yZXNvbHZlSHJlZikocm91dGVyLHByb3BzLmhyZWYsdHJ1ZSk7cmV0dXJue2hyZWY6cmVzb2x2ZWRIcmVmLGFzOnByb3BzLmFzPygwLF9yb3V0ZXIucmVzb2x2ZUhyZWYpKHJvdXRlcixwcm9wcy5hcyk6cmVzb2x2ZWRBc3x8cmVzb2x2ZWRIcmVmfTt9LFtyb3V0ZXIscHJvcHMuaHJlZixwcm9wcy5hc10pO2xldHtjaGlsZHJlbixyZXBsYWNlLHNoYWxsb3csc2Nyb2xsLGxvY2FsZX09cHJvcHM7Ly8gRGVwcmVjYXRlZC4gV2FybmluZyBzaG93biBieSBwcm9wVHlwZSBjaGVjay4gSWYgdGhlIGNoaWxkcmVuIHByb3ZpZGVkIGlzIGEgc3RyaW5nICg8TGluaz5leGFtcGxlPC9MaW5rPikgd2Ugd3JhcCBpdCBpbiBhbiA8YT4gdGFnXG5pZih0eXBlb2YgY2hpbGRyZW49PT0nc3RyaW5nJyl7Y2hpbGRyZW49LyojX19QVVJFX18qL19yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJhXCIsbnVsbCxjaGlsZHJlbik7fS8vIFRoaXMgd2lsbCByZXR1cm4gdGhlIGZpcnN0IGNoaWxkLCBpZiBtdWx0aXBsZSBhcmUgcHJvdmlkZWQgaXQgd2lsbCB0aHJvdyBhbiBlcnJvclxubGV0IGNoaWxkO2lmKHByb2Nlc3MuZW52Lk5PREVfRU5WPT09J2RldmVsb3BtZW50Jyl7dHJ5e2NoaWxkPV9yZWFjdC5DaGlsZHJlbi5vbmx5KGNoaWxkcmVuKTt9Y2F0Y2goZXJyKXt0aHJvdyBuZXcgRXJyb3IoYE11bHRpcGxlIGNoaWxkcmVuIHdlcmUgcGFzc2VkIHRvIDxMaW5rPiB3aXRoIFxcYGhyZWZcXGAgb2YgXFxgJHtwcm9wcy5ocmVmfVxcYCBidXQgb25seSBvbmUgY2hpbGQgaXMgc3VwcG9ydGVkIGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL2xpbmstbXVsdGlwbGUtY2hpbGRyZW5gKyh0eXBlb2Ygd2luZG93IT09J3VuZGVmaW5lZCc/XCJcXG5PcGVuIHlvdXIgYnJvd3NlcidzIGNvbnNvbGUgdG8gdmlldyB0aGUgQ29tcG9uZW50IHN0YWNrIHRyYWNlLlwiOicnKSk7fX1lbHNle2NoaWxkPV9yZWFjdC5DaGlsZHJlbi5vbmx5KGNoaWxkcmVuKTt9Y29uc3QgY2hpbGRSZWY9Y2hpbGQmJnR5cGVvZiBjaGlsZD09PSdvYmplY3QnJiZjaGlsZC5yZWY7Y29uc3Rbc2V0SW50ZXJzZWN0aW9uUmVmLGlzVmlzaWJsZV09KDAsX3VzZUludGVyc2VjdGlvbi51c2VJbnRlcnNlY3Rpb24pKHtyb290TWFyZ2luOicyMDBweCd9KTtjb25zdCBzZXRSZWY9X3JlYWN0LmRlZmF1bHQudXNlQ2FsbGJhY2soZWw9PntzZXRJbnRlcnNlY3Rpb25SZWYoZWwpO2lmKGNoaWxkUmVmKXtpZih0eXBlb2YgY2hpbGRSZWY9PT0nZnVuY3Rpb24nKWNoaWxkUmVmKGVsKTtlbHNlIGlmKHR5cGVvZiBjaGlsZFJlZj09PSdvYmplY3QnKXtjaGlsZFJlZi5jdXJyZW50PWVsO319fSxbY2hpbGRSZWYsc2V0SW50ZXJzZWN0aW9uUmVmXSk7KDAsX3JlYWN0LnVzZUVmZmVjdCkoKCk9Pntjb25zdCBzaG91bGRQcmVmZXRjaD1pc1Zpc2libGUmJnAmJigwLF9yb3V0ZXIuaXNMb2NhbFVSTCkoaHJlZik7Y29uc3QgY3VyTG9jYWxlPXR5cGVvZiBsb2NhbGUhPT0ndW5kZWZpbmVkJz9sb2NhbGU6cm91dGVyJiZyb3V0ZXIubG9jYWxlO2NvbnN0IGlzUHJlZmV0Y2hlZD1wcmVmZXRjaGVkW2hyZWYrJyUnK2FzKyhjdXJMb2NhbGU/JyUnK2N1ckxvY2FsZTonJyldO2lmKHNob3VsZFByZWZldGNoJiYhaXNQcmVmZXRjaGVkKXtwcmVmZXRjaChyb3V0ZXIsaHJlZixhcyx7bG9jYWxlOmN1ckxvY2FsZX0pO319LFthcyxocmVmLGlzVmlzaWJsZSxsb2NhbGUscCxyb3V0ZXJdKTtjb25zdCBjaGlsZFByb3BzPXtyZWY6c2V0UmVmLG9uQ2xpY2s6ZT0+e2lmKGNoaWxkLnByb3BzJiZ0eXBlb2YgY2hpbGQucHJvcHMub25DbGljaz09PSdmdW5jdGlvbicpe2NoaWxkLnByb3BzLm9uQ2xpY2soZSk7fWlmKCFlLmRlZmF1bHRQcmV2ZW50ZWQpe2xpbmtDbGlja2VkKGUscm91dGVyLGhyZWYsYXMscmVwbGFjZSxzaGFsbG93LHNjcm9sbCxsb2NhbGUpO319fTtjaGlsZFByb3BzLm9uTW91c2VFbnRlcj1lPT57aWYoISgwLF9yb3V0ZXIuaXNMb2NhbFVSTCkoaHJlZikpcmV0dXJuO2lmKGNoaWxkLnByb3BzJiZ0eXBlb2YgY2hpbGQucHJvcHMub25Nb3VzZUVudGVyPT09J2Z1bmN0aW9uJyl7Y2hpbGQucHJvcHMub25Nb3VzZUVudGVyKGUpO31wcmVmZXRjaChyb3V0ZXIsaHJlZixhcyx7cHJpb3JpdHk6dHJ1ZX0pO307Ly8gSWYgY2hpbGQgaXMgYW4gPGE+IHRhZyBhbmQgZG9lc24ndCBoYXZlIGEgaHJlZiBhdHRyaWJ1dGUsIG9yIGlmIHRoZSAncGFzc0hyZWYnIHByb3BlcnR5IGlzXG4vLyBkZWZpbmVkLCB3ZSBzcGVjaWZ5IHRoZSBjdXJyZW50ICdocmVmJywgc28gdGhhdCByZXBldGl0aW9uIGlzIG5vdCBuZWVkZWQgYnkgdGhlIHVzZXJcbmlmKHByb3BzLnBhc3NIcmVmfHxjaGlsZC50eXBlPT09J2EnJiYhKCdocmVmJ2luIGNoaWxkLnByb3BzKSl7Y29uc3QgY3VyTG9jYWxlPXR5cGVvZiBsb2NhbGUhPT0ndW5kZWZpbmVkJz9sb2NhbGU6cm91dGVyJiZyb3V0ZXIubG9jYWxlOy8vIHdlIG9ubHkgcmVuZGVyIGRvbWFpbiBsb2NhbGVzIGlmIHdlIGFyZSBjdXJyZW50bHkgb24gYSBkb21haW4gbG9jYWxlXG4vLyBzbyB0aGF0IGxvY2FsZSBsaW5rcyBhcmUgc3RpbGwgdmlzaXRhYmxlIGluIGRldmVsb3BtZW50L3ByZXZpZXcgZW52c1xuY29uc3QgbG9jYWxlRG9tYWluPXJvdXRlciYmcm91dGVyLmlzTG9jYWxlRG9tYWluJiYoMCxfcm91dGVyLmdldERvbWFpbkxvY2FsZSkoYXMsY3VyTG9jYWxlLHJvdXRlciYmcm91dGVyLmxvY2FsZXMscm91dGVyJiZyb3V0ZXIuZG9tYWluTG9jYWxlcyk7Y2hpbGRQcm9wcy5ocmVmPWxvY2FsZURvbWFpbnx8KDAsX3JvdXRlci5hZGRCYXNlUGF0aCkoKDAsX3JvdXRlci5hZGRMb2NhbGUpKGFzLGN1ckxvY2FsZSxyb3V0ZXImJnJvdXRlci5kZWZhdWx0TG9jYWxlKSk7fXJldHVybi8qI19fUFVSRV9fKi9fcmVhY3QuZGVmYXVsdC5jbG9uZUVsZW1lbnQoY2hpbGQsY2hpbGRQcm9wcyk7fXZhciBfZGVmYXVsdD1MaW5rO2V4cG9ydHMuZGVmYXVsdD1fZGVmYXVsdDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxpbmsuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaD1yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaDtleHBvcnRzLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoPXZvaWQgMDsvKipcbiAqIFJlbW92ZXMgdGhlIHRyYWlsaW5nIHNsYXNoIG9mIGEgcGF0aCBpZiB0aGVyZSBpcyBvbmUuIFByZXNlcnZlcyB0aGUgcm9vdCBwYXRoIGAvYC5cbiAqL2Z1bmN0aW9uIHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGgpe3JldHVybiBwYXRoLmVuZHNXaXRoKCcvJykmJnBhdGghPT0nLyc/cGF0aC5zbGljZSgwLC0xKTpwYXRoO30vKipcbiAqIE5vcm1hbGl6ZXMgdGhlIHRyYWlsaW5nIHNsYXNoIG9mIGEgcGF0aCBhY2NvcmRpbmcgdG8gdGhlIGB0cmFpbGluZ1NsYXNoYCBvcHRpb25cbiAqIGluIGBuZXh0LmNvbmZpZy5qc2AuXG4gKi9jb25zdCBub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaD1wcm9jZXNzLmVudi5fX05FWFRfVFJBSUxJTkdfU0xBU0g/cGF0aD0+e2lmKC9cXC5bXi9dK1xcLz8kLy50ZXN0KHBhdGgpKXtyZXR1cm4gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aCk7fWVsc2UgaWYocGF0aC5lbmRzV2l0aCgnLycpKXtyZXR1cm4gcGF0aDt9ZWxzZXtyZXR1cm4gcGF0aCsnLyc7fX06cmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2g7ZXhwb3J0cy5ub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaD1ub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vcm1hbGl6ZS10cmFpbGluZy1zbGFzaC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLmNhbmNlbElkbGVDYWxsYmFjaz1leHBvcnRzLnJlcXVlc3RJZGxlQ2FsbGJhY2s9dm9pZCAwO2NvbnN0IHJlcXVlc3RJZGxlQ2FsbGJhY2s9dHlwZW9mIHNlbGYhPT0ndW5kZWZpbmVkJyYmc2VsZi5yZXF1ZXN0SWRsZUNhbGxiYWNrfHxmdW5jdGlvbihjYil7bGV0IHN0YXJ0PURhdGUubm93KCk7cmV0dXJuIHNldFRpbWVvdXQoZnVuY3Rpb24oKXtjYih7ZGlkVGltZW91dDpmYWxzZSx0aW1lUmVtYWluaW5nOmZ1bmN0aW9uKCl7cmV0dXJuIE1hdGgubWF4KDAsNTAtKERhdGUubm93KCktc3RhcnQpKTt9fSk7fSwxKTt9O2V4cG9ydHMucmVxdWVzdElkbGVDYWxsYmFjaz1yZXF1ZXN0SWRsZUNhbGxiYWNrO2NvbnN0IGNhbmNlbElkbGVDYWxsYmFjaz10eXBlb2Ygc2VsZiE9PSd1bmRlZmluZWQnJiZzZWxmLmNhbmNlbElkbGVDYWxsYmFja3x8ZnVuY3Rpb24oaWQpe3JldHVybiBjbGVhclRpbWVvdXQoaWQpO307ZXhwb3J0cy5jYW5jZWxJZGxlQ2FsbGJhY2s9Y2FuY2VsSWRsZUNhbGxiYWNrO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVxdWVzdC1pZGxlLWNhbGxiYWNrLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO3ZhciBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0PXJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlRGVmYXVsdFwiKTtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLm1hcmtBc3NldEVycm9yPW1hcmtBc3NldEVycm9yO2V4cG9ydHMuaXNBc3NldEVycm9yPWlzQXNzZXRFcnJvcjtleHBvcnRzLmdldENsaWVudEJ1aWxkTWFuaWZlc3Q9Z2V0Q2xpZW50QnVpbGRNYW5pZmVzdDtleHBvcnRzLmRlZmF1bHQ9dm9pZCAwO3ZhciBfZ2V0QXNzZXRQYXRoRnJvbVJvdXRlPV9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvZ2V0LWFzc2V0LXBhdGgtZnJvbS1yb3V0ZVwiKSk7dmFyIF9yZXF1ZXN0SWRsZUNhbGxiYWNrPXJlcXVpcmUoXCIuL3JlcXVlc3QtaWRsZS1jYWxsYmFja1wiKTsvLyAzLjhzIHdhcyBhcmJpdHJhcmlseSBjaG9zZW4gYXMgaXQncyB3aGF0IGh0dHBzOi8vd2ViLmRldi9pbnRlcmFjdGl2ZVxuLy8gY29uc2lkZXJzIGFzIFwiR29vZFwiIHRpbWUtdG8taW50ZXJhY3RpdmUuIFdlIG11c3QgYXNzdW1lIHNvbWV0aGluZyB3ZW50XG4vLyB3cm9uZyBiZXlvbmQgdGhpcyBwb2ludCwgYW5kIHRoZW4gZmFsbC1iYWNrIHRvIGEgZnVsbCBwYWdlIHRyYW5zaXRpb24gdG9cbi8vIHNob3cgdGhlIHVzZXIgc29tZXRoaW5nIG9mIHZhbHVlLlxuY29uc3QgTVNfTUFYX0lETEVfREVMQVk9MzgwMDtmdW5jdGlvbiB3aXRoRnV0dXJlKGtleSxtYXAsZ2VuZXJhdG9yKXtsZXQgZW50cnk9bWFwLmdldChrZXkpO2lmKGVudHJ5KXtpZignZnV0dXJlJ2luIGVudHJ5KXtyZXR1cm4gZW50cnkuZnV0dXJlO31yZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGVudHJ5KTt9bGV0IHJlc29sdmVyO2NvbnN0IHByb209bmV3IFByb21pc2UocmVzb2x2ZT0+e3Jlc29sdmVyPXJlc29sdmU7fSk7bWFwLnNldChrZXksZW50cnk9e3Jlc29sdmU6cmVzb2x2ZXIsZnV0dXJlOnByb219KTtyZXR1cm4gZ2VuZXJhdG9yPy8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1zZXF1ZW5jZXNcbmdlbmVyYXRvcigpLnRoZW4odmFsdWU9PihyZXNvbHZlcih2YWx1ZSksdmFsdWUpKTpwcm9tO31mdW5jdGlvbiBoYXNQcmVmZXRjaChsaW5rKXt0cnl7bGluaz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaW5rJyk7cmV0dXJuKC8vIGRldGVjdCBJRTExIHNpbmNlIGl0IHN1cHBvcnRzIHByZWZldGNoIGJ1dCBpc24ndCBkZXRlY3RlZFxuLy8gd2l0aCByZWxMaXN0LnN1cHBvcnRcbiEhd2luZG93Lk1TSW5wdXRNZXRob2RDb250ZXh0JiYhIWRvY3VtZW50LmRvY3VtZW50TW9kZXx8bGluay5yZWxMaXN0LnN1cHBvcnRzKCdwcmVmZXRjaCcpKTt9Y2F0Y2goX3VudXNlZCl7cmV0dXJuIGZhbHNlO319Y29uc3QgY2FuUHJlZmV0Y2g9aGFzUHJlZmV0Y2goKTtmdW5jdGlvbiBwcmVmZXRjaFZpYURvbShocmVmLGFzLGxpbmspe3JldHVybiBuZXcgUHJvbWlzZSgocmVzLHJlaik9PntpZihkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBsaW5rW3JlbD1cInByZWZldGNoXCJdW2hyZWZePVwiJHtocmVmfVwiXWApKXtyZXR1cm4gcmVzKCk7fWxpbms9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGluaycpOy8vIFRoZSBvcmRlciBvZiBwcm9wZXJ0eSBhc3NpZ25tZW50IGhlcmUgaXMgaW50ZW50aW9uYWw6XG5pZihhcylsaW5rLmFzPWFzO2xpbmsucmVsPWBwcmVmZXRjaGA7bGluay5jcm9zc09yaWdpbj1wcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOO2xpbmsub25sb2FkPXJlcztsaW5rLm9uZXJyb3I9cmVqOy8vIGBocmVmYCBzaG91bGQgYWx3YXlzIGJlIGxhc3Q6XG5saW5rLmhyZWY9aHJlZjtkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKGxpbmspO30pO31jb25zdCBBU1NFVF9MT0FEX0VSUk9SPVN5bWJvbCgnQVNTRVRfTE9BRF9FUlJPUicpOy8vIFRPRE86IHVuZXhwb3J0XG5mdW5jdGlvbiBtYXJrQXNzZXRFcnJvcihlcnIpe3JldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkoZXJyLEFTU0VUX0xPQURfRVJST1Ise30pO31mdW5jdGlvbiBpc0Fzc2V0RXJyb3IoZXJyKXtyZXR1cm4gZXJyJiZBU1NFVF9MT0FEX0VSUk9SIGluIGVycjt9ZnVuY3Rpb24gYXBwZW5kU2NyaXB0KHNyYyxzY3JpcHQpe3JldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSxyZWplY3QpPT57c2NyaXB0PWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpOy8vIFRoZSBvcmRlciBvZiBwcm9wZXJ0eSBhc3NpZ25tZW50IGhlcmUgaXMgaW50ZW50aW9uYWwuXG4vLyAxLiBTZXR1cCBzdWNjZXNzL2ZhaWx1cmUgaG9va3MgaW4gY2FzZSB0aGUgYnJvd3NlciBzeW5jaHJvbm91c2x5XG4vLyAgICBleGVjdXRlcyB3aGVuIGBzcmNgIGlzIHNldC5cbnNjcmlwdC5vbmxvYWQ9cmVzb2x2ZTtzY3JpcHQub25lcnJvcj0oKT0+cmVqZWN0KG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc2NyaXB0OiAke3NyY31gKSkpOy8vIDIuIENvbmZpZ3VyZSB0aGUgY3Jvc3Mtb3JpZ2luIGF0dHJpYnV0ZSBiZWZvcmUgc2V0dGluZyBgc3JjYCBpbiBjYXNlIHRoZVxuLy8gICAgYnJvd3NlciBiZWdpbnMgdG8gZmV0Y2guXG5zY3JpcHQuY3Jvc3NPcmlnaW49cHJvY2Vzcy5lbnYuX19ORVhUX0NST1NTX09SSUdJTjsvLyAzLiBGaW5hbGx5LCBzZXQgdGhlIHNvdXJjZSBhbmQgaW5qZWN0IGludG8gdGhlIERPTSBpbiBjYXNlIHRoZSBjaGlsZFxuLy8gICAgbXVzdCBiZSBhcHBlbmRlZCBmb3IgZmV0Y2hpbmcgdG8gc3RhcnQuXG5zY3JpcHQuc3JjPXNyYztkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHNjcmlwdCk7fSk7fS8vIFJlc29sdmUgYSBwcm9taXNlIHRoYXQgdGltZXMgb3V0IGFmdGVyIGdpdmVuIGFtb3VudCBvZiBtaWxsaXNlY29uZHMuXG5mdW5jdGlvbiByZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0KHAsbXMsZXJyKXtyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUscmVqZWN0KT0+e2xldCBjYW5jZWxsZWQ9ZmFsc2U7cC50aGVuKHI9PnsvLyBSZXNvbHZlZCwgY2FuY2VsIHRoZSB0aW1lb3V0XG5jYW5jZWxsZWQ9dHJ1ZTtyZXNvbHZlKHIpO30pLmNhdGNoKHJlamVjdCk7KDAsX3JlcXVlc3RJZGxlQ2FsbGJhY2sucmVxdWVzdElkbGVDYWxsYmFjaykoKCk9PnNldFRpbWVvdXQoKCk9PntpZighY2FuY2VsbGVkKXtyZWplY3QoZXJyKTt9fSxtcykpO30pO30vLyBUT0RPOiBzdG9wIGV4cG9ydGluZyBvciBjYWNoZSB0aGUgZmFpbHVyZVxuLy8gSXQnZCBiZSBiZXN0IHRvIHN0b3AgZXhwb3J0aW5nIHRoaXMuIEl0J3MgYW4gaW1wbGVtZW50YXRpb24gZGV0YWlsLiBXZSdyZVxuLy8gb25seSBleHBvcnRpbmcgaXQgZm9yIGJhY2t3YXJkcyBjb21wYXRpYmlsdHkgd2l0aCB0aGUgYHBhZ2UtbG9hZGVyYC5cbi8vIE9ubHkgY2FjaGUgdGhpcyByZXNwb25zZSBhcyBhIGxhc3QgcmVzb3J0IGlmIHdlIGNhbm5vdCBlbGltaW5hdGUgYWxsIG90aGVyXG4vLyBjb2RlIGJyYW5jaGVzIHRoYXQgdXNlIHRoZSBCdWlsZCBNYW5pZmVzdCBDYWxsYmFjayBhbmQgcHVzaCB0aGVtIHRocm91Z2hcbi8vIHRoZSBSb3V0ZSBMb2FkZXIgaW50ZXJmYWNlLlxuZnVuY3Rpb24gZ2V0Q2xpZW50QnVpbGRNYW5pZmVzdCgpe2lmKHNlbGYuX19CVUlMRF9NQU5JRkVTVCl7cmV0dXJuIFByb21pc2UucmVzb2x2ZShzZWxmLl9fQlVJTERfTUFOSUZFU1QpO31jb25zdCBvbkJ1aWxkTWFuaWZlc3Q9bmV3IFByb21pc2UocmVzb2x2ZT0+ey8vIE1hbmRhdG9yeSBiZWNhdXNlIHRoaXMgaXMgbm90IGNvbmN1cnJlbnQgc2FmZTpcbmNvbnN0IGNiPXNlbGYuX19CVUlMRF9NQU5JRkVTVF9DQjtzZWxmLl9fQlVJTERfTUFOSUZFU1RfQ0I9KCk9PntyZXNvbHZlKHNlbGYuX19CVUlMRF9NQU5JRkVTVCk7Y2ImJmNiKCk7fTt9KTtyZXR1cm4gcmVzb2x2ZVByb21pc2VXaXRoVGltZW91dChvbkJ1aWxkTWFuaWZlc3QsTVNfTUFYX0lETEVfREVMQVksbWFya0Fzc2V0RXJyb3IobmV3IEVycm9yKCdGYWlsZWQgdG8gbG9hZCBjbGllbnQgYnVpbGQgbWFuaWZlc3QnKSkpO31mdW5jdGlvbiBnZXRGaWxlc0ZvclJvdXRlKGFzc2V0UHJlZml4LHJvdXRlKXtpZihwcm9jZXNzLmVudi5OT0RFX0VOVj09PSdkZXZlbG9wbWVudCcpe3JldHVybiBQcm9taXNlLnJlc29sdmUoe3NjcmlwdHM6W2Fzc2V0UHJlZml4KycvX25leHQvc3RhdGljL2NodW5rcy9wYWdlcycrZW5jb2RlVVJJKCgwLF9nZXRBc3NldFBhdGhGcm9tUm91dGUuZGVmYXVsdCkocm91dGUsJy5qcycpKV0sLy8gU3R5bGVzIGFyZSBoYW5kbGVkIGJ5IGBzdHlsZS1sb2FkZXJgIGluIGRldmVsb3BtZW50OlxuY3NzOltdfSk7fXJldHVybiBnZXRDbGllbnRCdWlsZE1hbmlmZXN0KCkudGhlbihtYW5pZmVzdD0+e2lmKCEocm91dGUgaW4gbWFuaWZlc3QpKXt0aHJvdyBtYXJrQXNzZXRFcnJvcihuZXcgRXJyb3IoYEZhaWxlZCB0byBsb29rdXAgcm91dGU6ICR7cm91dGV9YCkpO31jb25zdCBhbGxGaWxlcz1tYW5pZmVzdFtyb3V0ZV0ubWFwKGVudHJ5PT5hc3NldFByZWZpeCsnL19uZXh0LycrZW5jb2RlVVJJKGVudHJ5KSk7cmV0dXJue3NjcmlwdHM6YWxsRmlsZXMuZmlsdGVyKHY9PnYuZW5kc1dpdGgoJy5qcycpKSxjc3M6YWxsRmlsZXMuZmlsdGVyKHY9PnYuZW5kc1dpdGgoJy5jc3MnKSl9O30pO31mdW5jdGlvbiBjcmVhdGVSb3V0ZUxvYWRlcihhc3NldFByZWZpeCl7Y29uc3QgZW50cnlwb2ludHM9bmV3IE1hcCgpO2NvbnN0IGxvYWRlZFNjcmlwdHM9bmV3IE1hcCgpO2NvbnN0IHN0eWxlU2hlZXRzPW5ldyBNYXAoKTtjb25zdCByb3V0ZXM9bmV3IE1hcCgpO2Z1bmN0aW9uIG1heWJlRXhlY3V0ZVNjcmlwdChzcmMpe2xldCBwcm9tPWxvYWRlZFNjcmlwdHMuZ2V0KHNyYyk7aWYocHJvbSl7cmV0dXJuIHByb207fS8vIFNraXAgZXhlY3V0aW5nIHNjcmlwdCBpZiBpdCdzIGFscmVhZHkgaW4gdGhlIERPTTpcbmlmKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYHNjcmlwdFtzcmNePVwiJHtzcmN9XCJdYCkpe3JldHVybiBQcm9taXNlLnJlc29sdmUoKTt9bG9hZGVkU2NyaXB0cy5zZXQoc3JjLHByb209YXBwZW5kU2NyaXB0KHNyYykpO3JldHVybiBwcm9tO31mdW5jdGlvbiBmZXRjaFN0eWxlU2hlZXQoaHJlZil7bGV0IHByb209c3R5bGVTaGVldHMuZ2V0KGhyZWYpO2lmKHByb20pe3JldHVybiBwcm9tO31zdHlsZVNoZWV0cy5zZXQoaHJlZixwcm9tPWZldGNoKGhyZWYpLnRoZW4ocmVzPT57aWYoIXJlcy5vayl7dGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gbG9hZCBzdHlsZXNoZWV0OiAke2hyZWZ9YCk7fXJldHVybiByZXMudGV4dCgpLnRoZW4odGV4dD0+KHtocmVmOmhyZWYsY29udGVudDp0ZXh0fSkpO30pLmNhdGNoKGVycj0+e3Rocm93IG1hcmtBc3NldEVycm9yKGVycik7fSkpO3JldHVybiBwcm9tO31yZXR1cm57d2hlbkVudHJ5cG9pbnQocm91dGUpe3JldHVybiB3aXRoRnV0dXJlKHJvdXRlLGVudHJ5cG9pbnRzKTt9LG9uRW50cnlwb2ludChyb3V0ZSxleGVjdXRlKXtQcm9taXNlLnJlc29sdmUoZXhlY3V0ZSkudGhlbihmbj0+Zm4oKSkudGhlbihleHBvcnRzPT4oe2NvbXBvbmVudDpleHBvcnRzJiZleHBvcnRzLmRlZmF1bHR8fGV4cG9ydHMsZXhwb3J0czpleHBvcnRzfSksZXJyPT4oe2Vycm9yOmVycn0pKS50aGVuKGlucHV0PT57Y29uc3Qgb2xkPWVudHJ5cG9pbnRzLmdldChyb3V0ZSk7ZW50cnlwb2ludHMuc2V0KHJvdXRlLGlucHV0KTtpZihvbGQmJidyZXNvbHZlJ2luIG9sZClvbGQucmVzb2x2ZShpbnB1dCk7fSk7fSxsb2FkUm91dGUocm91dGUscHJlZmV0Y2gpe3JldHVybiB3aXRoRnV0dXJlKHJvdXRlLHJvdXRlcywoKT0+e3JldHVybiByZXNvbHZlUHJvbWlzZVdpdGhUaW1lb3V0KGdldEZpbGVzRm9yUm91dGUoYXNzZXRQcmVmaXgscm91dGUpLnRoZW4oKHtzY3JpcHRzLGNzc30pPT57cmV0dXJuIFByb21pc2UuYWxsKFtlbnRyeXBvaW50cy5oYXMocm91dGUpP1tdOlByb21pc2UuYWxsKHNjcmlwdHMubWFwKG1heWJlRXhlY3V0ZVNjcmlwdCkpLFByb21pc2UuYWxsKGNzcy5tYXAoZmV0Y2hTdHlsZVNoZWV0KSldKTt9KS50aGVuKHJlcz0+e3JldHVybiB0aGlzLndoZW5FbnRyeXBvaW50KHJvdXRlKS50aGVuKGVudHJ5cG9pbnQ9Pih7ZW50cnlwb2ludCxzdHlsZXM6cmVzWzFdfSkpO30pLE1TX01BWF9JRExFX0RFTEFZLG1hcmtBc3NldEVycm9yKG5ldyBFcnJvcihgUm91dGUgZGlkIG5vdCBjb21wbGV0ZSBsb2FkaW5nOiAke3JvdXRlfWApKSkudGhlbigoe2VudHJ5cG9pbnQsc3R5bGVzfSk9Pntjb25zdCByZXM9T2JqZWN0LmFzc2lnbih7c3R5bGVzOnN0eWxlc30sZW50cnlwb2ludCk7cmV0dXJuJ2Vycm9yJ2luIGVudHJ5cG9pbnQ/ZW50cnlwb2ludDpyZXM7fSkuY2F0Y2goZXJyPT57aWYocHJlZmV0Y2gpey8vIHdlIGRvbid0IHdhbnQgdG8gY2FjaGUgZXJyb3JzIGR1cmluZyBwcmVmZXRjaFxudGhyb3cgZXJyO31yZXR1cm57ZXJyb3I6ZXJyfTt9KTt9KTt9LHByZWZldGNoKHJvdXRlKXsvLyBodHRwczovL2dpdGh1Yi5jb20vR29vZ2xlQ2hyb21lTGFicy9xdWlja2xpbmsvYmxvYi80NTNhNjYxZmExZmE5NDBlMmQyZTA0NDQ1MjM5OGUzOGM2N2E5OGZiL3NyYy9pbmRleC5tanMjTDExNS1MMTE4XG4vLyBMaWNlbnNlOiBBcGFjaGUgMi4wXG5sZXQgY247aWYoY249bmF2aWdhdG9yLmNvbm5lY3Rpb24pey8vIERvbid0IHByZWZldGNoIGlmIHVzaW5nIDJHIG9yIGlmIFNhdmUtRGF0YSBpcyBlbmFibGVkLlxuaWYoY24uc2F2ZURhdGF8fC8yZy8udGVzdChjbi5lZmZlY3RpdmVUeXBlKSlyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7fXJldHVybiBnZXRGaWxlc0ZvclJvdXRlKGFzc2V0UHJlZml4LHJvdXRlKS50aGVuKG91dHB1dD0+UHJvbWlzZS5hbGwoY2FuUHJlZmV0Y2g/b3V0cHV0LnNjcmlwdHMubWFwKHNjcmlwdD0+cHJlZmV0Y2hWaWFEb20oc2NyaXB0LCdzY3JpcHQnKSk6W10pKS50aGVuKCgpPT57KDAsX3JlcXVlc3RJZGxlQ2FsbGJhY2sucmVxdWVzdElkbGVDYWxsYmFjaykoKCk9PnRoaXMubG9hZFJvdXRlKHJvdXRlLHRydWUpLmNhdGNoKCgpPT57fSkpO30pLmNhdGNoKC8vIHN3YWxsb3cgcHJlZmV0Y2ggZXJyb3JzXG4oKT0+e30pO319O312YXIgX2RlZmF1bHQ9Y3JlYXRlUm91dGVMb2FkZXI7ZXhwb3J0cy5kZWZhdWx0PV9kZWZhdWx0O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGUtbG9hZGVyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO3ZhciBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZD1yZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkXCIpO3ZhciBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0PXJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2ludGVyb3BSZXF1aXJlRGVmYXVsdFwiKTtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLnVzZVJvdXRlcj11c2VSb3V0ZXI7ZXhwb3J0cy5tYWtlUHVibGljUm91dGVySW5zdGFuY2U9bWFrZVB1YmxpY1JvdXRlckluc3RhbmNlO2V4cG9ydHMuY3JlYXRlUm91dGVyPWV4cG9ydHMud2l0aFJvdXRlcj1leHBvcnRzLmRlZmF1bHQ9dm9pZCAwO3ZhciBfcmVhY3Q9X2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwicmVhY3RcIikpO3ZhciBfcm91dGVyMj1faW50ZXJvcFJlcXVpcmVXaWxkY2FyZChyZXF1aXJlKFwiLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci9yb3V0ZXJcIikpO2V4cG9ydHMuUm91dGVyPV9yb3V0ZXIyLmRlZmF1bHQ7ZXhwb3J0cy5OZXh0Um91dGVyPV9yb3V0ZXIyLk5leHRSb3V0ZXI7dmFyIF9yb3V0ZXJDb250ZXh0PXJlcXVpcmUoXCIuLi9uZXh0LXNlcnZlci9saWIvcm91dGVyLWNvbnRleHRcIik7dmFyIF93aXRoUm91dGVyPV9pbnRlcm9wUmVxdWlyZURlZmF1bHQocmVxdWlyZShcIi4vd2l0aC1yb3V0ZXJcIikpO2V4cG9ydHMud2l0aFJvdXRlcj1fd2l0aFJvdXRlci5kZWZhdWx0Oy8qIGdsb2JhbCB3aW5kb3cgKi9jb25zdCBzaW5nbGV0b25Sb3V0ZXI9e3JvdXRlcjpudWxsLC8vIGhvbGRzIHRoZSBhY3R1YWwgcm91dGVyIGluc3RhbmNlXG5yZWFkeUNhbGxiYWNrczpbXSxyZWFkeShjYil7aWYodGhpcy5yb3V0ZXIpcmV0dXJuIGNiKCk7aWYodHlwZW9mIHdpbmRvdyE9PSd1bmRlZmluZWQnKXt0aGlzLnJlYWR5Q2FsbGJhY2tzLnB1c2goY2IpO319fTsvLyBDcmVhdGUgcHVibGljIHByb3BlcnRpZXMgYW5kIG1ldGhvZHMgb2YgdGhlIHJvdXRlciBpbiB0aGUgc2luZ2xldG9uUm91dGVyXG5jb25zdCB1cmxQcm9wZXJ0eUZpZWxkcz1bJ3BhdGhuYW1lJywncm91dGUnLCdxdWVyeScsJ2FzUGF0aCcsJ2NvbXBvbmVudHMnLCdpc0ZhbGxiYWNrJywnYmFzZVBhdGgnLCdsb2NhbGUnLCdsb2NhbGVzJywnZGVmYXVsdExvY2FsZScsJ2lzUmVhZHknLCdpc1ByZXZpZXcnLCdpc0xvY2FsZURvbWFpbiddO2NvbnN0IHJvdXRlckV2ZW50cz1bJ3JvdXRlQ2hhbmdlU3RhcnQnLCdiZWZvcmVIaXN0b3J5Q2hhbmdlJywncm91dGVDaGFuZ2VDb21wbGV0ZScsJ3JvdXRlQ2hhbmdlRXJyb3InLCdoYXNoQ2hhbmdlU3RhcnQnLCdoYXNoQ2hhbmdlQ29tcGxldGUnXTtjb25zdCBjb3JlTWV0aG9kRmllbGRzPVsncHVzaCcsJ3JlcGxhY2UnLCdyZWxvYWQnLCdiYWNrJywncHJlZmV0Y2gnLCdiZWZvcmVQb3BTdGF0ZSddOy8vIEV2ZW50cyBpcyBhIHN0YXRpYyBwcm9wZXJ0eSBvbiB0aGUgcm91dGVyLCB0aGUgcm91dGVyIGRvZXNuJ3QgaGF2ZSB0byBiZSBpbml0aWFsaXplZCB0byB1c2UgaXRcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShzaW5nbGV0b25Sb3V0ZXIsJ2V2ZW50cycse2dldCgpe3JldHVybiBfcm91dGVyMi5kZWZhdWx0LmV2ZW50czt9fSk7dXJsUHJvcGVydHlGaWVsZHMuZm9yRWFjaChmaWVsZD0+ey8vIEhlcmUgd2UgbmVlZCB0byB1c2UgT2JqZWN0LmRlZmluZVByb3BlcnR5IGJlY2F1c2Ugd2UgbmVlZCB0byByZXR1cm5cbi8vIHRoZSBwcm9wZXJ0eSBhc3NpZ25lZCB0byB0aGUgYWN0dWFsIHJvdXRlclxuLy8gVGhlIHZhbHVlIG1pZ2h0IGdldCBjaGFuZ2VkIGFzIHdlIGNoYW5nZSByb3V0ZXMgYW5kIHRoaXMgaXMgdGhlXG4vLyBwcm9wZXIgd2F5IHRvIGFjY2VzcyBpdFxuT2JqZWN0LmRlZmluZVByb3BlcnR5KHNpbmdsZXRvblJvdXRlcixmaWVsZCx7Z2V0KCl7Y29uc3Qgcm91dGVyPWdldFJvdXRlcigpO3JldHVybiByb3V0ZXJbZmllbGRdO319KTt9KTtjb3JlTWV0aG9kRmllbGRzLmZvckVhY2goZmllbGQ9PnsvLyBXZSBkb24ndCByZWFsbHkga25vdyB0aGUgdHlwZXMgaGVyZSwgc28gd2UgYWRkIHRoZW0gbGF0ZXIgaW5zdGVhZFxuO3NpbmdsZXRvblJvdXRlcltmaWVsZF09KC4uLmFyZ3MpPT57Y29uc3Qgcm91dGVyPWdldFJvdXRlcigpO3JldHVybiByb3V0ZXJbZmllbGRdKC4uLmFyZ3MpO307fSk7cm91dGVyRXZlbnRzLmZvckVhY2goZXZlbnQ9PntzaW5nbGV0b25Sb3V0ZXIucmVhZHkoKCk9Pntfcm91dGVyMi5kZWZhdWx0LmV2ZW50cy5vbihldmVudCwoLi4uYXJncyk9Pntjb25zdCBldmVudEZpZWxkPWBvbiR7ZXZlbnQuY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9JHtldmVudC5zdWJzdHJpbmcoMSl9YDtjb25zdCBfc2luZ2xldG9uUm91dGVyPXNpbmdsZXRvblJvdXRlcjtpZihfc2luZ2xldG9uUm91dGVyW2V2ZW50RmllbGRdKXt0cnl7X3NpbmdsZXRvblJvdXRlcltldmVudEZpZWxkXSguLi5hcmdzKTt9Y2F0Y2goZXJyKXtjb25zb2xlLmVycm9yKGBFcnJvciB3aGVuIHJ1bm5pbmcgdGhlIFJvdXRlciBldmVudDogJHtldmVudEZpZWxkfWApO2NvbnNvbGUuZXJyb3IoYCR7ZXJyLm1lc3NhZ2V9XFxuJHtlcnIuc3RhY2t9YCk7fX19KTt9KTt9KTtmdW5jdGlvbiBnZXRSb3V0ZXIoKXtpZighc2luZ2xldG9uUm91dGVyLnJvdXRlcil7Y29uc3QgbWVzc2FnZT0nTm8gcm91dGVyIGluc3RhbmNlIGZvdW5kLlxcbicrJ1lvdSBzaG91bGQgb25seSB1c2UgXCJuZXh0L3JvdXRlclwiIG9uIHRoZSBjbGllbnQgc2lkZSBvZiB5b3VyIGFwcC5cXG4nO3Rocm93IG5ldyBFcnJvcihtZXNzYWdlKTt9cmV0dXJuIHNpbmdsZXRvblJvdXRlci5yb3V0ZXI7fS8vIEV4cG9ydCB0aGUgc2luZ2xldG9uUm91dGVyIGFuZCB0aGlzIGlzIHRoZSBwdWJsaWMgQVBJLlxudmFyIF9kZWZhdWx0PXNpbmdsZXRvblJvdXRlcjsvLyBSZWV4cG9ydCB0aGUgd2l0aFJvdXRlIEhPQ1xuZXhwb3J0cy5kZWZhdWx0PV9kZWZhdWx0O2Z1bmN0aW9uIHVzZVJvdXRlcigpe3JldHVybiBfcmVhY3QuZGVmYXVsdC51c2VDb250ZXh0KF9yb3V0ZXJDb250ZXh0LlJvdXRlckNvbnRleHQpO30vLyBJTlRFUk5BTCBBUElTXG4vLyAtLS0tLS0tLS0tLS0tXG4vLyAoZG8gbm90IHVzZSBmb2xsb3dpbmcgZXhwb3J0cyBpbnNpZGUgdGhlIGFwcClcbi8vIENyZWF0ZSBhIHJvdXRlciBhbmQgYXNzaWduIGl0IGFzIHRoZSBzaW5nbGV0b24gaW5zdGFuY2UuXG4vLyBUaGlzIGlzIHVzZWQgaW4gY2xpZW50IHNpZGUgd2hlbiB3ZSBhcmUgaW5pdGlsaXppbmcgdGhlIGFwcC5cbi8vIFRoaXMgc2hvdWxkICoqbm90KiogYmUgdXNlZCBpbnNpZGUgdGhlIHNlcnZlci5cbmNvbnN0IGNyZWF0ZVJvdXRlcj0oLi4uYXJncyk9PntzaW5nbGV0b25Sb3V0ZXIucm91dGVyPW5ldyBfcm91dGVyMi5kZWZhdWx0KC4uLmFyZ3MpO3NpbmdsZXRvblJvdXRlci5yZWFkeUNhbGxiYWNrcy5mb3JFYWNoKGNiPT5jYigpKTtzaW5nbGV0b25Sb3V0ZXIucmVhZHlDYWxsYmFja3M9W107cmV0dXJuIHNpbmdsZXRvblJvdXRlci5yb3V0ZXI7fTsvLyBUaGlzIGZ1bmN0aW9uIGlzIHVzZWQgdG8gY3JlYXRlIHRoZSBgd2l0aFJvdXRlcmAgcm91dGVyIGluc3RhbmNlXG5leHBvcnRzLmNyZWF0ZVJvdXRlcj1jcmVhdGVSb3V0ZXI7ZnVuY3Rpb24gbWFrZVB1YmxpY1JvdXRlckluc3RhbmNlKHJvdXRlcil7Y29uc3QgX3JvdXRlcj1yb3V0ZXI7Y29uc3QgaW5zdGFuY2U9e307Zm9yKGNvbnN0IHByb3BlcnR5IG9mIHVybFByb3BlcnR5RmllbGRzKXtpZih0eXBlb2YgX3JvdXRlcltwcm9wZXJ0eV09PT0nb2JqZWN0Jyl7aW5zdGFuY2VbcHJvcGVydHldPU9iamVjdC5hc3NpZ24oQXJyYXkuaXNBcnJheShfcm91dGVyW3Byb3BlcnR5XSk/W106e30sX3JvdXRlcltwcm9wZXJ0eV0pOy8vIG1ha2VzIHN1cmUgcXVlcnkgaXMgbm90IHN0YXRlZnVsXG5jb250aW51ZTt9aW5zdGFuY2VbcHJvcGVydHldPV9yb3V0ZXJbcHJvcGVydHldO30vLyBFdmVudHMgaXMgYSBzdGF0aWMgcHJvcGVydHkgb24gdGhlIHJvdXRlciwgdGhlIHJvdXRlciBkb2Vzbid0IGhhdmUgdG8gYmUgaW5pdGlhbGl6ZWQgdG8gdXNlIGl0XG5pbnN0YW5jZS5ldmVudHM9X3JvdXRlcjIuZGVmYXVsdC5ldmVudHM7Y29yZU1ldGhvZEZpZWxkcy5mb3JFYWNoKGZpZWxkPT57aW5zdGFuY2VbZmllbGRdPSguLi5hcmdzKT0+e3JldHVybiBfcm91dGVyW2ZpZWxkXSguLi5hcmdzKTt9O30pO3JldHVybiBpbnN0YW5jZTt9XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy51c2VJbnRlcnNlY3Rpb249dXNlSW50ZXJzZWN0aW9uO3ZhciBfcmVhY3Q9cmVxdWlyZShcInJlYWN0XCIpO3ZhciBfcmVxdWVzdElkbGVDYWxsYmFjaz1yZXF1aXJlKFwiLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2tcIik7Y29uc3QgaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXI9dHlwZW9mIEludGVyc2VjdGlvbk9ic2VydmVyIT09J3VuZGVmaW5lZCc7ZnVuY3Rpb24gdXNlSW50ZXJzZWN0aW9uKHtyb290TWFyZ2luLGRpc2FibGVkfSl7Y29uc3QgaXNEaXNhYmxlZD1kaXNhYmxlZHx8IWhhc0ludGVyc2VjdGlvbk9ic2VydmVyO2NvbnN0IHVub2JzZXJ2ZT0oMCxfcmVhY3QudXNlUmVmKSgpO2NvbnN0W3Zpc2libGUsc2V0VmlzaWJsZV09KDAsX3JlYWN0LnVzZVN0YXRlKShmYWxzZSk7Y29uc3Qgc2V0UmVmPSgwLF9yZWFjdC51c2VDYWxsYmFjaykoZWw9PntpZih1bm9ic2VydmUuY3VycmVudCl7dW5vYnNlcnZlLmN1cnJlbnQoKTt1bm9ic2VydmUuY3VycmVudD11bmRlZmluZWQ7fWlmKGlzRGlzYWJsZWR8fHZpc2libGUpcmV0dXJuO2lmKGVsJiZlbC50YWdOYW1lKXt1bm9ic2VydmUuY3VycmVudD1vYnNlcnZlKGVsLGlzVmlzaWJsZT0+aXNWaXNpYmxlJiZzZXRWaXNpYmxlKGlzVmlzaWJsZSkse3Jvb3RNYXJnaW59KTt9fSxbaXNEaXNhYmxlZCxyb290TWFyZ2luLHZpc2libGVdKTsoMCxfcmVhY3QudXNlRWZmZWN0KSgoKT0+e2lmKCFoYXNJbnRlcnNlY3Rpb25PYnNlcnZlcil7aWYoIXZpc2libGUpe2NvbnN0IGlkbGVDYWxsYmFjaz0oMCxfcmVxdWVzdElkbGVDYWxsYmFjay5yZXF1ZXN0SWRsZUNhbGxiYWNrKSgoKT0+c2V0VmlzaWJsZSh0cnVlKSk7cmV0dXJuKCk9PigwLF9yZXF1ZXN0SWRsZUNhbGxiYWNrLmNhbmNlbElkbGVDYWxsYmFjaykoaWRsZUNhbGxiYWNrKTt9fX0sW3Zpc2libGVdKTtyZXR1cm5bc2V0UmVmLHZpc2libGVdO31mdW5jdGlvbiBvYnNlcnZlKGVsZW1lbnQsY2FsbGJhY2ssb3B0aW9ucyl7Y29uc3R7aWQsb2JzZXJ2ZXIsZWxlbWVudHN9PWNyZWF0ZU9ic2VydmVyKG9wdGlvbnMpO2VsZW1lbnRzLnNldChlbGVtZW50LGNhbGxiYWNrKTtvYnNlcnZlci5vYnNlcnZlKGVsZW1lbnQpO3JldHVybiBmdW5jdGlvbiB1bm9ic2VydmUoKXtlbGVtZW50cy5kZWxldGUoZWxlbWVudCk7b2JzZXJ2ZXIudW5vYnNlcnZlKGVsZW1lbnQpOy8vIERlc3Ryb3kgb2JzZXJ2ZXIgd2hlbiB0aGVyZSdzIG5vdGhpbmcgbGVmdCB0byB3YXRjaDpcbmlmKGVsZW1lbnRzLnNpemU9PT0wKXtvYnNlcnZlci5kaXNjb25uZWN0KCk7b2JzZXJ2ZXJzLmRlbGV0ZShpZCk7fX07fWNvbnN0IG9ic2VydmVycz1uZXcgTWFwKCk7ZnVuY3Rpb24gY3JlYXRlT2JzZXJ2ZXIob3B0aW9ucyl7Y29uc3QgaWQ9b3B0aW9ucy5yb290TWFyZ2lufHwnJztsZXQgaW5zdGFuY2U9b2JzZXJ2ZXJzLmdldChpZCk7aWYoaW5zdGFuY2Upe3JldHVybiBpbnN0YW5jZTt9Y29uc3QgZWxlbWVudHM9bmV3IE1hcCgpO2NvbnN0IG9ic2VydmVyPW5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihlbnRyaWVzPT57ZW50cmllcy5mb3JFYWNoKGVudHJ5PT57Y29uc3QgY2FsbGJhY2s9ZWxlbWVudHMuZ2V0KGVudHJ5LnRhcmdldCk7Y29uc3QgaXNWaXNpYmxlPWVudHJ5LmlzSW50ZXJzZWN0aW5nfHxlbnRyeS5pbnRlcnNlY3Rpb25SYXRpbz4wO2lmKGNhbGxiYWNrJiZpc1Zpc2libGUpe2NhbGxiYWNrKGlzVmlzaWJsZSk7fX0pO30sb3B0aW9ucyk7b2JzZXJ2ZXJzLnNldChpZCxpbnN0YW5jZT17aWQsb2JzZXJ2ZXIsZWxlbWVudHN9KTtyZXR1cm4gaW5zdGFuY2U7fVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlLWludGVyc2VjdGlvbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjt2YXIgX2ludGVyb3BSZXF1aXJlRGVmYXVsdD1yZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHRcIik7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5kZWZhdWx0PXdpdGhSb3V0ZXI7dmFyIF9yZWFjdD1faW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJyZWFjdFwiKSk7dmFyIF9yb3V0ZXI9cmVxdWlyZShcIi4vcm91dGVyXCIpO2Z1bmN0aW9uIHdpdGhSb3V0ZXIoQ29tcG9zZWRDb21wb25lbnQpe2Z1bmN0aW9uIFdpdGhSb3V0ZXJXcmFwcGVyKHByb3BzKXtyZXR1cm4vKiNfX1BVUkVfXyovX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChDb21wb3NlZENvbXBvbmVudCxPYmplY3QuYXNzaWduKHtyb3V0ZXI6KDAsX3JvdXRlci51c2VSb3V0ZXIpKCl9LHByb3BzKSk7fVdpdGhSb3V0ZXJXcmFwcGVyLmdldEluaXRpYWxQcm9wcz1Db21wb3NlZENvbXBvbmVudC5nZXRJbml0aWFsUHJvcHMvLyBUaGlzIGlzIG5lZWRlZCB0byBhbGxvdyBjaGVja2luZyBmb3IgY3VzdG9tIGdldEluaXRpYWxQcm9wcyBpbiBfYXBwXG47V2l0aFJvdXRlcldyYXBwZXIub3JpZ0dldEluaXRpYWxQcm9wcz1Db21wb3NlZENvbXBvbmVudC5vcmlnR2V0SW5pdGlhbFByb3BzO2lmKHByb2Nlc3MuZW52Lk5PREVfRU5WIT09J3Byb2R1Y3Rpb24nKXtjb25zdCBuYW1lPUNvbXBvc2VkQ29tcG9uZW50LmRpc3BsYXlOYW1lfHxDb21wb3NlZENvbXBvbmVudC5uYW1lfHwnVW5rbm93bic7V2l0aFJvdXRlcldyYXBwZXIuZGlzcGxheU5hbWU9YHdpdGhSb3V0ZXIoJHtuYW1lfSlgO31yZXR1cm4gV2l0aFJvdXRlcldyYXBwZXI7fVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9d2l0aC1yb3V0ZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5ub3JtYWxpemVMb2NhbGVQYXRoPW5vcm1hbGl6ZUxvY2FsZVBhdGg7ZnVuY3Rpb24gbm9ybWFsaXplTG9jYWxlUGF0aChwYXRobmFtZSxsb2NhbGVzKXtsZXQgZGV0ZWN0ZWRMb2NhbGU7Ly8gZmlyc3QgaXRlbSB3aWxsIGJlIGVtcHR5IHN0cmluZyBmcm9tIHNwbGl0dGluZyBhdCBmaXJzdCBjaGFyXG5jb25zdCBwYXRobmFtZVBhcnRzPXBhdGhuYW1lLnNwbGl0KCcvJyk7KGxvY2FsZXN8fFtdKS5zb21lKGxvY2FsZT0+e2lmKHBhdGhuYW1lUGFydHNbMV0udG9Mb3dlckNhc2UoKT09PWxvY2FsZS50b0xvd2VyQ2FzZSgpKXtkZXRlY3RlZExvY2FsZT1sb2NhbGU7cGF0aG5hbWVQYXJ0cy5zcGxpY2UoMSwxKTtwYXRobmFtZT1wYXRobmFtZVBhcnRzLmpvaW4oJy8nKXx8Jy8nO3JldHVybiB0cnVlO31yZXR1cm4gZmFsc2U7fSk7cmV0dXJue3BhdGhuYW1lLGRldGVjdGVkTG9jYWxlfTt9XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub3JtYWxpemUtbG9jYWxlLXBhdGguanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5kZWZhdWx0PW1pdHQ7Lypcbk1JVCBMaWNlbnNlXG5cbkNvcHlyaWdodCAoYykgSmFzb24gTWlsbGVyIChodHRwczovL2phc29uZm9ybWF0LmNvbS8pXG5cblBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGUgXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCwgZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdCBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnM6XG5cblRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuXG5USEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbiovIC8vIFRoaXMgZmlsZSBpcyBiYXNlZCBvbiBodHRwczovL2dpdGh1Yi5jb20vZGV2ZWxvcGl0L21pdHQvYmxvYi92MS4xLjMvc3JjL2luZGV4LmpzXG4vLyBJdCdzIGJlZW4gZWRpdGVkIGZvciB0aGUgbmVlZHMgb2YgdGhpcyBzY3JpcHRcbi8vIFNlZSB0aGUgTElDRU5TRSBhdCB0aGUgdG9wIG9mIHRoZSBmaWxlXG5mdW5jdGlvbiBtaXR0KCl7Y29uc3QgYWxsPU9iamVjdC5jcmVhdGUobnVsbCk7cmV0dXJue29uKHR5cGUsaGFuZGxlcil7OyhhbGxbdHlwZV18fChhbGxbdHlwZV09W10pKS5wdXNoKGhhbmRsZXIpO30sb2ZmKHR5cGUsaGFuZGxlcil7aWYoYWxsW3R5cGVdKXthbGxbdHlwZV0uc3BsaWNlKGFsbFt0eXBlXS5pbmRleE9mKGhhbmRsZXIpPj4+MCwxKTt9fSxlbWl0KHR5cGUsLi4uZXZ0cyl7Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGFycmF5LWNhbGxiYWNrLXJldHVyblxuOyhhbGxbdHlwZV18fFtdKS5zbGljZSgpLm1hcChoYW5kbGVyPT57aGFuZGxlciguLi5ldnRzKTt9KTt9fTt9XG4vLyMgc291cmNlTWFwcGluZ1VSTD1taXR0LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMuZ2V0RG9tYWluTG9jYWxlPWdldERvbWFpbkxvY2FsZTtleHBvcnRzLmFkZExvY2FsZT1hZGRMb2NhbGU7ZXhwb3J0cy5kZWxMb2NhbGU9ZGVsTG9jYWxlO2V4cG9ydHMuaGFzQmFzZVBhdGg9aGFzQmFzZVBhdGg7ZXhwb3J0cy5hZGRCYXNlUGF0aD1hZGRCYXNlUGF0aDtleHBvcnRzLmRlbEJhc2VQYXRoPWRlbEJhc2VQYXRoO2V4cG9ydHMuaXNMb2NhbFVSTD1pc0xvY2FsVVJMO2V4cG9ydHMuaW50ZXJwb2xhdGVBcz1pbnRlcnBvbGF0ZUFzO2V4cG9ydHMucmVzb2x2ZUhyZWY9cmVzb2x2ZUhyZWY7ZXhwb3J0cy5kZWZhdWx0PXZvaWQgMDt2YXIgX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2g9cmVxdWlyZShcIi4uLy4uLy4uL2NsaWVudC9ub3JtYWxpemUtdHJhaWxpbmctc2xhc2hcIik7dmFyIF9yb3V0ZUxvYWRlcj1yZXF1aXJlKFwiLi4vLi4vLi4vY2xpZW50L3JvdXRlLWxvYWRlclwiKTt2YXIgX2Rlbm9ybWFsaXplUGFnZVBhdGg9cmVxdWlyZShcIi4uLy4uL3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGhcIik7dmFyIF9ub3JtYWxpemVMb2NhbGVQYXRoPXJlcXVpcmUoXCIuLi9pMThuL25vcm1hbGl6ZS1sb2NhbGUtcGF0aFwiKTt2YXIgX21pdHQ9X2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi4vbWl0dFwiKSk7dmFyIF91dGlscz1yZXF1aXJlKFwiLi4vdXRpbHNcIik7dmFyIF9pc0R5bmFtaWM9cmVxdWlyZShcIi4vdXRpbHMvaXMtZHluYW1pY1wiKTt2YXIgX3BhcnNlUmVsYXRpdmVVcmw9cmVxdWlyZShcIi4vdXRpbHMvcGFyc2UtcmVsYXRpdmUtdXJsXCIpO3ZhciBfcXVlcnlzdHJpbmc9cmVxdWlyZShcIi4vdXRpbHMvcXVlcnlzdHJpbmdcIik7dmFyIF9yZXNvbHZlUmV3cml0ZXM9X2ludGVyb3BSZXF1aXJlRGVmYXVsdChyZXF1aXJlKFwiLi91dGlscy9yZXNvbHZlLXJld3JpdGVzXCIpKTt2YXIgX3JvdXRlTWF0Y2hlcj1yZXF1aXJlKFwiLi91dGlscy9yb3V0ZS1tYXRjaGVyXCIpO3ZhciBfcm91dGVSZWdleD1yZXF1aXJlKFwiLi91dGlscy9yb3V0ZS1yZWdleFwiKTtmdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KG9iail7cmV0dXJuIG9iaiYmb2JqLl9fZXNNb2R1bGU/b2JqOntkZWZhdWx0Om9ian07fS8vIHRzbGludDpkaXNhYmxlOm5vLWNvbnNvbGVcbmxldCBkZXRlY3REb21haW5Mb2NhbGU7aWYocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCl7ZGV0ZWN0RG9tYWluTG9jYWxlPXJlcXVpcmUoJy4uL2kxOG4vZGV0ZWN0LWRvbWFpbi1sb2NhbGUnKS5kZXRlY3REb21haW5Mb2NhbGU7fWNvbnN0IGJhc2VQYXRoPXByb2Nlc3MuZW52Ll9fTkVYVF9ST1VURVJfQkFTRVBBVEh8fCcnO2Z1bmN0aW9uIGJ1aWxkQ2FuY2VsbGF0aW9uRXJyb3IoKXtyZXR1cm4gT2JqZWN0LmFzc2lnbihuZXcgRXJyb3IoJ1JvdXRlIENhbmNlbGxlZCcpLHtjYW5jZWxsZWQ6dHJ1ZX0pO31mdW5jdGlvbiBhZGRQYXRoUHJlZml4KHBhdGgscHJlZml4KXtyZXR1cm4gcHJlZml4JiZwYXRoLnN0YXJ0c1dpdGgoJy8nKT9wYXRoPT09Jy8nPygwLF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKShwcmVmaXgpOmAke3ByZWZpeH0ke3BhdGhOb1F1ZXJ5SGFzaChwYXRoKT09PScvJz9wYXRoLnN1YnN0cmluZygxKTpwYXRofWA6cGF0aDt9ZnVuY3Rpb24gZ2V0RG9tYWluTG9jYWxlKHBhdGgsbG9jYWxlLGxvY2FsZXMsZG9tYWluTG9jYWxlcyl7aWYocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCl7bG9jYWxlPWxvY2FsZXx8KDAsX25vcm1hbGl6ZUxvY2FsZVBhdGgubm9ybWFsaXplTG9jYWxlUGF0aCkocGF0aCxsb2NhbGVzKS5kZXRlY3RlZExvY2FsZTtjb25zdCBkZXRlY3RlZERvbWFpbj1kZXRlY3REb21haW5Mb2NhbGUoZG9tYWluTG9jYWxlcyx1bmRlZmluZWQsbG9jYWxlKTtpZihkZXRlY3RlZERvbWFpbil7cmV0dXJuYGh0dHAke2RldGVjdGVkRG9tYWluLmh0dHA/Jyc6J3MnfTovLyR7ZGV0ZWN0ZWREb21haW4uZG9tYWlufSR7YmFzZVBhdGh8fCcnfSR7bG9jYWxlPT09ZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZT8nJzpgLyR7bG9jYWxlfWB9JHtwYXRofWA7fXJldHVybiBmYWxzZTt9cmV0dXJuIGZhbHNlO31mdW5jdGlvbiBhZGRMb2NhbGUocGF0aCxsb2NhbGUsZGVmYXVsdExvY2FsZSl7aWYocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCl7Y29uc3QgcGF0aG5hbWU9cGF0aE5vUXVlcnlIYXNoKHBhdGgpO2NvbnN0IHBhdGhMb3dlcj1wYXRobmFtZS50b0xvd2VyQ2FzZSgpO2NvbnN0IGxvY2FsZUxvd2VyPWxvY2FsZSYmbG9jYWxlLnRvTG93ZXJDYXNlKCk7cmV0dXJuIGxvY2FsZSYmbG9jYWxlIT09ZGVmYXVsdExvY2FsZSYmIXBhdGhMb3dlci5zdGFydHNXaXRoKCcvJytsb2NhbGVMb3dlcisnLycpJiZwYXRoTG93ZXIhPT0nLycrbG9jYWxlTG93ZXI/YWRkUGF0aFByZWZpeChwYXRoLCcvJytsb2NhbGUpOnBhdGg7fXJldHVybiBwYXRoO31mdW5jdGlvbiBkZWxMb2NhbGUocGF0aCxsb2NhbGUpe2lmKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpe2NvbnN0IHBhdGhuYW1lPXBhdGhOb1F1ZXJ5SGFzaChwYXRoKTtjb25zdCBwYXRoTG93ZXI9cGF0aG5hbWUudG9Mb3dlckNhc2UoKTtjb25zdCBsb2NhbGVMb3dlcj1sb2NhbGUmJmxvY2FsZS50b0xvd2VyQ2FzZSgpO3JldHVybiBsb2NhbGUmJihwYXRoTG93ZXIuc3RhcnRzV2l0aCgnLycrbG9jYWxlTG93ZXIrJy8nKXx8cGF0aExvd2VyPT09Jy8nK2xvY2FsZUxvd2VyKT8ocGF0aG5hbWUubGVuZ3RoPT09bG9jYWxlLmxlbmd0aCsxPycvJzonJykrcGF0aC5zdWJzdHIobG9jYWxlLmxlbmd0aCsxKTpwYXRoO31yZXR1cm4gcGF0aDt9ZnVuY3Rpb24gcGF0aE5vUXVlcnlIYXNoKHBhdGgpe2NvbnN0IHF1ZXJ5SW5kZXg9cGF0aC5pbmRleE9mKCc/Jyk7Y29uc3QgaGFzaEluZGV4PXBhdGguaW5kZXhPZignIycpO2lmKHF1ZXJ5SW5kZXg+LTF8fGhhc2hJbmRleD4tMSl7cGF0aD1wYXRoLnN1YnN0cmluZygwLHF1ZXJ5SW5kZXg+LTE/cXVlcnlJbmRleDpoYXNoSW5kZXgpO31yZXR1cm4gcGF0aDt9ZnVuY3Rpb24gaGFzQmFzZVBhdGgocGF0aCl7cGF0aD1wYXRoTm9RdWVyeUhhc2gocGF0aCk7cmV0dXJuIHBhdGg9PT1iYXNlUGF0aHx8cGF0aC5zdGFydHNXaXRoKGJhc2VQYXRoKycvJyk7fWZ1bmN0aW9uIGFkZEJhc2VQYXRoKHBhdGgpey8vIHdlIG9ubHkgYWRkIHRoZSBiYXNlcGF0aCBvbiByZWxhdGl2ZSB1cmxzXG5yZXR1cm4gYWRkUGF0aFByZWZpeChwYXRoLGJhc2VQYXRoKTt9ZnVuY3Rpb24gZGVsQmFzZVBhdGgocGF0aCl7cGF0aD1wYXRoLnNsaWNlKGJhc2VQYXRoLmxlbmd0aCk7aWYoIXBhdGguc3RhcnRzV2l0aCgnLycpKXBhdGg9YC8ke3BhdGh9YDtyZXR1cm4gcGF0aDt9LyoqXG4gKiBEZXRlY3RzIHdoZXRoZXIgYSBnaXZlbiB1cmwgaXMgcm91dGFibGUgYnkgdGhlIE5leHQuanMgcm91dGVyIChicm93c2VyIG9ubHkpLlxuICovZnVuY3Rpb24gaXNMb2NhbFVSTCh1cmwpey8vIHByZXZlbnQgYSBoeWRyYXRpb24gbWlzbWF0Y2ggb24gaHJlZiBmb3IgdXJsIHdpdGggYW5jaG9yIHJlZnNcbmlmKHVybC5zdGFydHNXaXRoKCcvJyl8fHVybC5zdGFydHNXaXRoKCcjJyl8fHVybC5zdGFydHNXaXRoKCc/JykpcmV0dXJuIHRydWU7dHJ5ey8vIGFic29sdXRlIHVybHMgY2FuIGJlIGxvY2FsIGlmIHRoZXkgYXJlIG9uIHRoZSBzYW1lIG9yaWdpblxuY29uc3QgbG9jYXRpb25PcmlnaW49KDAsX3V0aWxzLmdldExvY2F0aW9uT3JpZ2luKSgpO2NvbnN0IHJlc29sdmVkPW5ldyBVUkwodXJsLGxvY2F0aW9uT3JpZ2luKTtyZXR1cm4gcmVzb2x2ZWQub3JpZ2luPT09bG9jYXRpb25PcmlnaW4mJmhhc0Jhc2VQYXRoKHJlc29sdmVkLnBhdGhuYW1lKTt9Y2F0Y2goXyl7cmV0dXJuIGZhbHNlO319ZnVuY3Rpb24gaW50ZXJwb2xhdGVBcyhyb3V0ZSxhc1BhdGhuYW1lLHF1ZXJ5KXtsZXQgaW50ZXJwb2xhdGVkUm91dGU9Jyc7Y29uc3QgZHluYW1pY1JlZ2V4PSgwLF9yb3V0ZVJlZ2V4LmdldFJvdXRlUmVnZXgpKHJvdXRlKTtjb25zdCBkeW5hbWljR3JvdXBzPWR5bmFtaWNSZWdleC5ncm91cHM7Y29uc3QgZHluYW1pY01hdGNoZXM9Ly8gVHJ5IHRvIG1hdGNoIHRoZSBkeW5hbWljIHJvdXRlIGFnYWluc3QgdGhlIGFzUGF0aFxuKGFzUGF0aG5hbWUhPT1yb3V0ZT8oMCxfcm91dGVNYXRjaGVyLmdldFJvdXRlTWF0Y2hlcikoZHluYW1pY1JlZ2V4KShhc1BhdGhuYW1lKTonJyl8fC8vIEZhbGwgYmFjayB0byByZWFkaW5nIHRoZSB2YWx1ZXMgZnJvbSB0aGUgaHJlZlxuLy8gVE9ETzogc2hvdWxkIHRoaXMgdGFrZSBwcmlvcml0eTsgYWxzbyBuZWVkIHRvIGNoYW5nZSBpbiB0aGUgcm91dGVyLlxucXVlcnk7aW50ZXJwb2xhdGVkUm91dGU9cm91dGU7Y29uc3QgcGFyYW1zPU9iamVjdC5rZXlzKGR5bmFtaWNHcm91cHMpO2lmKCFwYXJhbXMuZXZlcnkocGFyYW09PntsZXQgdmFsdWU9ZHluYW1pY01hdGNoZXNbcGFyYW1dfHwnJztjb25zdHtyZXBlYXQsb3B0aW9uYWx9PWR5bmFtaWNHcm91cHNbcGFyYW1dOy8vIHN1cHBvcnQgc2luZ2xlLWxldmVsIGNhdGNoLWFsbFxuLy8gVE9ETzogbW9yZSByb2J1c3QgaGFuZGxpbmcgZm9yIHVzZXItZXJyb3IgKHBhc3NpbmcgYC9gKVxubGV0IHJlcGxhY2VkPWBbJHtyZXBlYXQ/Jy4uLic6Jyd9JHtwYXJhbX1dYDtpZihvcHRpb25hbCl7cmVwbGFjZWQ9YCR7IXZhbHVlPycvJzonJ31bJHtyZXBsYWNlZH1dYDt9aWYocmVwZWF0JiYhQXJyYXkuaXNBcnJheSh2YWx1ZSkpdmFsdWU9W3ZhbHVlXTtyZXR1cm4ob3B0aW9uYWx8fHBhcmFtIGluIGR5bmFtaWNNYXRjaGVzKSYmKC8vIEludGVycG9sYXRlIGdyb3VwIGludG8gZGF0YSBVUkwgaWYgcHJlc2VudFxuaW50ZXJwb2xhdGVkUm91dGU9aW50ZXJwb2xhdGVkUm91dGUucmVwbGFjZShyZXBsYWNlZCxyZXBlYXQ/dmFsdWUubWFwKC8vIHRoZXNlIHZhbHVlcyBzaG91bGQgYmUgZnVsbHkgZW5jb2RlZCBpbnN0ZWFkIG9mIGp1c3Rcbi8vIHBhdGggZGVsaW1pdGVyIGVzY2FwZWQgc2luY2UgdGhleSBhcmUgYmVpbmcgaW5zZXJ0ZWRcbi8vIGludG8gdGhlIFVSTCBhbmQgd2UgZXhwZWN0IFVSTCBlbmNvZGVkIHNlZ21lbnRzXG4vLyB3aGVuIHBhcnNpbmcgZHluYW1pYyByb3V0ZSBwYXJhbXNcbnNlZ21lbnQ9PmVuY29kZVVSSUNvbXBvbmVudChzZWdtZW50KSkuam9pbignLycpOmVuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSkpfHwnLycpO30pKXtpbnRlcnBvbGF0ZWRSb3V0ZT0nJzsvLyBkaWQgbm90IHNhdGlzZnkgYWxsIHJlcXVpcmVtZW50c1xuLy8gbi5iLiBXZSBpZ25vcmUgdGhpcyBlcnJvciBiZWNhdXNlIHdlIGhhbmRsZSB3YXJuaW5nIGZvciB0aGlzIGNhc2UgaW5cbi8vIGRldmVsb3BtZW50IGluIHRoZSBgPExpbms+YCBjb21wb25lbnQgZGlyZWN0bHkuXG59cmV0dXJue3BhcmFtcyxyZXN1bHQ6aW50ZXJwb2xhdGVkUm91dGV9O31mdW5jdGlvbiBvbWl0UGFybXNGcm9tUXVlcnkocXVlcnkscGFyYW1zKXtjb25zdCBmaWx0ZXJlZFF1ZXJ5PXt9O09iamVjdC5rZXlzKHF1ZXJ5KS5mb3JFYWNoKGtleT0+e2lmKCFwYXJhbXMuaW5jbHVkZXMoa2V5KSl7ZmlsdGVyZWRRdWVyeVtrZXldPXF1ZXJ5W2tleV07fX0pO3JldHVybiBmaWx0ZXJlZFF1ZXJ5O30vKipcbiAqIFJlc29sdmVzIGEgZ2l2ZW4gaHlwZXJsaW5rIHdpdGggYSBjZXJ0YWluIHJvdXRlciBzdGF0ZSAoYmFzZVBhdGggbm90IGluY2x1ZGVkKS5cbiAqIFByZXNlcnZlcyBhYnNvbHV0ZSB1cmxzLlxuICovZnVuY3Rpb24gcmVzb2x2ZUhyZWYocm91dGVyLGhyZWYscmVzb2x2ZUFzKXsvLyB3ZSB1c2UgYSBkdW1teSBiYXNlIHVybCBmb3IgcmVsYXRpdmUgdXJsc1xubGV0IGJhc2U7Y29uc3QgdXJsQXNTdHJpbmc9dHlwZW9mIGhyZWY9PT0nc3RyaW5nJz9ocmVmOigwLF91dGlscy5mb3JtYXRXaXRoVmFsaWRhdGlvbikoaHJlZik7dHJ5e2Jhc2U9bmV3IFVSTCh1cmxBc1N0cmluZy5zdGFydHNXaXRoKCcjJyk/cm91dGVyLmFzUGF0aDpyb3V0ZXIucGF0aG5hbWUsJ2h0dHA6Ly9uJyk7fWNhdGNoKF8pey8vIGZhbGxiYWNrIHRvIC8gZm9yIGludmFsaWQgYXNQYXRoIHZhbHVlcyBlLmcuIC8vXG5iYXNlPW5ldyBVUkwoJy8nLCdodHRwOi8vbicpO30vLyBSZXR1cm4gYmVjYXVzZSBpdCBjYW5ub3QgYmUgcm91dGVkIGJ5IHRoZSBOZXh0LmpzIHJvdXRlclxuaWYoIWlzTG9jYWxVUkwodXJsQXNTdHJpbmcpKXtyZXR1cm4gcmVzb2x2ZUFzP1t1cmxBc1N0cmluZ106dXJsQXNTdHJpbmc7fXRyeXtjb25zdCBmaW5hbFVybD1uZXcgVVJMKHVybEFzU3RyaW5nLGJhc2UpO2ZpbmFsVXJsLnBhdGhuYW1lPSgwLF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoLm5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKShmaW5hbFVybC5wYXRobmFtZSk7bGV0IGludGVycG9sYXRlZEFzPScnO2lmKCgwLF9pc0R5bmFtaWMuaXNEeW5hbWljUm91dGUpKGZpbmFsVXJsLnBhdGhuYW1lKSYmZmluYWxVcmwuc2VhcmNoUGFyYW1zJiZyZXNvbHZlQXMpe2NvbnN0IHF1ZXJ5PSgwLF9xdWVyeXN0cmluZy5zZWFyY2hQYXJhbXNUb1VybFF1ZXJ5KShmaW5hbFVybC5zZWFyY2hQYXJhbXMpO2NvbnN0e3Jlc3VsdCxwYXJhbXN9PWludGVycG9sYXRlQXMoZmluYWxVcmwucGF0aG5hbWUsZmluYWxVcmwucGF0aG5hbWUscXVlcnkpO2lmKHJlc3VsdCl7aW50ZXJwb2xhdGVkQXM9KDAsX3V0aWxzLmZvcm1hdFdpdGhWYWxpZGF0aW9uKSh7cGF0aG5hbWU6cmVzdWx0LGhhc2g6ZmluYWxVcmwuaGFzaCxxdWVyeTpvbWl0UGFybXNGcm9tUXVlcnkocXVlcnkscGFyYW1zKX0pO319Ly8gaWYgdGhlIG9yaWdpbiBkaWRuJ3QgY2hhbmdlLCBpdCBtZWFucyB3ZSByZWNlaXZlZCBhIHJlbGF0aXZlIGhyZWZcbmNvbnN0IHJlc29sdmVkSHJlZj1maW5hbFVybC5vcmlnaW49PT1iYXNlLm9yaWdpbj9maW5hbFVybC5ocmVmLnNsaWNlKGZpbmFsVXJsLm9yaWdpbi5sZW5ndGgpOmZpbmFsVXJsLmhyZWY7cmV0dXJuIHJlc29sdmVBcz9bcmVzb2x2ZWRIcmVmLGludGVycG9sYXRlZEFzfHxyZXNvbHZlZEhyZWZdOnJlc29sdmVkSHJlZjt9Y2F0Y2goXyl7cmV0dXJuIHJlc29sdmVBcz9bdXJsQXNTdHJpbmddOnVybEFzU3RyaW5nO319ZnVuY3Rpb24gc3RyaXBPcmlnaW4odXJsKXtjb25zdCBvcmlnaW49KDAsX3V0aWxzLmdldExvY2F0aW9uT3JpZ2luKSgpO3JldHVybiB1cmwuc3RhcnRzV2l0aChvcmlnaW4pP3VybC5zdWJzdHJpbmcob3JpZ2luLmxlbmd0aCk6dXJsO31mdW5jdGlvbiBwcmVwYXJlVXJsQXMocm91dGVyLHVybCxhcyl7Ly8gSWYgdXJsIGFuZCBhcyBwcm92aWRlZCBhcyBhbiBvYmplY3QgcmVwcmVzZW50YXRpb24sXG4vLyB3ZSdsbCBmb3JtYXQgdGhlbSBpbnRvIHRoZSBzdHJpbmcgdmVyc2lvbiBoZXJlLlxubGV0W3Jlc29sdmVkSHJlZixyZXNvbHZlZEFzXT1yZXNvbHZlSHJlZihyb3V0ZXIsdXJsLHRydWUpO2NvbnN0IG9yaWdpbj0oMCxfdXRpbHMuZ2V0TG9jYXRpb25PcmlnaW4pKCk7Y29uc3QgaHJlZkhhZE9yaWdpbj1yZXNvbHZlZEhyZWYuc3RhcnRzV2l0aChvcmlnaW4pO2NvbnN0IGFzSGFkT3JpZ2luPXJlc29sdmVkQXMmJnJlc29sdmVkQXMuc3RhcnRzV2l0aChvcmlnaW4pO3Jlc29sdmVkSHJlZj1zdHJpcE9yaWdpbihyZXNvbHZlZEhyZWYpO3Jlc29sdmVkQXM9cmVzb2x2ZWRBcz9zdHJpcE9yaWdpbihyZXNvbHZlZEFzKTpyZXNvbHZlZEFzO2NvbnN0IHByZXBhcmVkVXJsPWhyZWZIYWRPcmlnaW4/cmVzb2x2ZWRIcmVmOmFkZEJhc2VQYXRoKHJlc29sdmVkSHJlZik7Y29uc3QgcHJlcGFyZWRBcz1hcz9zdHJpcE9yaWdpbihyZXNvbHZlSHJlZihyb3V0ZXIsYXMpKTpyZXNvbHZlZEFzfHxyZXNvbHZlZEhyZWY7cmV0dXJue3VybDpwcmVwYXJlZFVybCxhczphc0hhZE9yaWdpbj9wcmVwYXJlZEFzOmFkZEJhc2VQYXRoKHByZXBhcmVkQXMpfTt9ZnVuY3Rpb24gcmVzb2x2ZUR5bmFtaWNSb3V0ZShwYXRobmFtZSxwYWdlcyl7Y29uc3QgY2xlYW5QYXRobmFtZT0oMCxfbm9ybWFsaXplVHJhaWxpbmdTbGFzaC5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCkoKDAsX2Rlbm9ybWFsaXplUGFnZVBhdGguZGVub3JtYWxpemVQYWdlUGF0aCkocGF0aG5hbWUpKTtpZihjbGVhblBhdGhuYW1lPT09Jy80MDQnfHxjbGVhblBhdGhuYW1lPT09Jy9fZXJyb3InKXtyZXR1cm4gcGF0aG5hbWU7fS8vIGhhbmRsZSByZXNvbHZpbmcgaHJlZiBmb3IgZHluYW1pYyByb3V0ZXNcbmlmKCFwYWdlcy5pbmNsdWRlcyhjbGVhblBhdGhuYW1lKSl7Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGFycmF5LWNhbGxiYWNrLXJldHVyblxucGFnZXMuc29tZShwYWdlPT57aWYoKDAsX2lzRHluYW1pYy5pc0R5bmFtaWNSb3V0ZSkocGFnZSkmJigwLF9yb3V0ZVJlZ2V4LmdldFJvdXRlUmVnZXgpKHBhZ2UpLnJlLnRlc3QoY2xlYW5QYXRobmFtZSkpe3BhdGhuYW1lPXBhZ2U7cmV0dXJuIHRydWU7fX0pO31yZXR1cm4oMCxfbm9ybWFsaXplVHJhaWxpbmdTbGFzaC5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCkocGF0aG5hbWUpO31jb25zdCBtYW51YWxTY3JvbGxSZXN0b3JhdGlvbj1wcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OJiZ0eXBlb2Ygd2luZG93IT09J3VuZGVmaW5lZCcmJidzY3JvbGxSZXN0b3JhdGlvbidpbiB3aW5kb3cuaGlzdG9yeSYmISFmdW5jdGlvbigpe3RyeXtsZXQgdj0nX19uZXh0JzsvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tc2VxdWVuY2VzXG5yZXR1cm4gc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSh2LHYpLHNlc3Npb25TdG9yYWdlLnJlbW92ZUl0ZW0odiksdHJ1ZTt9Y2F0Y2gobil7fX0oKTtjb25zdCBTU0dfREFUQV9OT1RfRk9VTkQ9U3ltYm9sKCdTU0dfREFUQV9OT1RfRk9VTkQnKTtmdW5jdGlvbiBmZXRjaFJldHJ5KHVybCxhdHRlbXB0cyl7cmV0dXJuIGZldGNoKHVybCx7Ly8gQ29va2llcyBhcmUgcmVxdWlyZWQgdG8gYmUgcHJlc2VudCBmb3IgTmV4dC5qcycgU1NHIFwiUHJldmlldyBNb2RlXCIuXG4vLyBDb29raWVzIG1heSBhbHNvIGJlIHJlcXVpcmVkIGZvciBgZ2V0U2VydmVyU2lkZVByb3BzYC5cbi8vXG4vLyA+IGBmZXRjaGAgd29u4oCZdCBzZW5kIGNvb2tpZXMsIHVubGVzcyB5b3Ugc2V0IHRoZSBjcmVkZW50aWFscyBpbml0XG4vLyA+IG9wdGlvbi5cbi8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9GZXRjaF9BUEkvVXNpbmdfRmV0Y2hcbi8vXG4vLyA+IEZvciBtYXhpbXVtIGJyb3dzZXIgY29tcGF0aWJpbGl0eSB3aGVuIGl0IGNvbWVzIHRvIHNlbmRpbmcgJlxuLy8gPiByZWNlaXZpbmcgY29va2llcywgYWx3YXlzIHN1cHBseSB0aGUgYGNyZWRlbnRpYWxzOiAnc2FtZS1vcmlnaW4nYFxuLy8gPiBvcHRpb24gaW5zdGVhZCBvZiByZWx5aW5nIG9uIHRoZSBkZWZhdWx0LlxuLy8gaHR0cHM6Ly9naXRodWIuY29tL2dpdGh1Yi9mZXRjaCNjYXZlYXRzXG5jcmVkZW50aWFsczonc2FtZS1vcmlnaW4nfSkudGhlbihyZXM9PntpZighcmVzLm9rKXtpZihhdHRlbXB0cz4xJiZyZXMuc3RhdHVzPj01MDApe3JldHVybiBmZXRjaFJldHJ5KHVybCxhdHRlbXB0cy0xKTt9aWYocmVzLnN0YXR1cz09PTQwNCl7cmV0dXJuIHJlcy5qc29uKCkudGhlbihkYXRhPT57aWYoZGF0YS5ub3RGb3VuZCl7cmV0dXJue25vdEZvdW5kOlNTR19EQVRBX05PVF9GT1VORH07fXRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3RhdGljIHByb3BzYCk7fSk7fXRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgc3RhdGljIHByb3BzYCk7fXJldHVybiByZXMuanNvbigpO30pO31mdW5jdGlvbiBmZXRjaE5leHREYXRhKGRhdGFIcmVmLGlzU2VydmVyUmVuZGVyKXtyZXR1cm4gZmV0Y2hSZXRyeShkYXRhSHJlZixpc1NlcnZlclJlbmRlcj8zOjEpLmNhdGNoKGVycj0+ey8vIFdlIHNob3VsZCBvbmx5IHRyaWdnZXIgYSBzZXJ2ZXItc2lkZSB0cmFuc2l0aW9uIGlmIHRoaXMgd2FzIGNhdXNlZFxuLy8gb24gYSBjbGllbnQtc2lkZSB0cmFuc2l0aW9uLiBPdGhlcndpc2UsIHdlJ2QgZ2V0IGludG8gYW4gaW5maW5pdGVcbi8vIGxvb3AuXG5pZighaXNTZXJ2ZXJSZW5kZXIpeygwLF9yb3V0ZUxvYWRlci5tYXJrQXNzZXRFcnJvcikoZXJyKTt9dGhyb3cgZXJyO30pO31jbGFzcyBSb3V0ZXJ7LyoqXG4gICAqIE1hcCBvZiBhbGwgY29tcG9uZW50cyBsb2FkZWQgaW4gYFJvdXRlcmBcbiAgICovIC8vIFN0YXRpYyBEYXRhIENhY2hlXG4vLyBJbi1mbGlnaHQgU2VydmVyIERhdGEgUmVxdWVzdHMsIGZvciBkZWR1cGluZ1xuY29uc3RydWN0b3IoX3BhdGhuYW1lLF9xdWVyeSxfYXMse2luaXRpYWxQcm9wcyxwYWdlTG9hZGVyLEFwcCx3cmFwQXBwLENvbXBvbmVudCxlcnIsc3Vic2NyaXB0aW9uLGlzRmFsbGJhY2ssbG9jYWxlLGxvY2FsZXMsZGVmYXVsdExvY2FsZSxkb21haW5Mb2NhbGVzLGlzUHJldmlld30pe3RoaXMucm91dGU9dm9pZCAwO3RoaXMucGF0aG5hbWU9dm9pZCAwO3RoaXMucXVlcnk9dm9pZCAwO3RoaXMuYXNQYXRoPXZvaWQgMDt0aGlzLmJhc2VQYXRoPXZvaWQgMDt0aGlzLmNvbXBvbmVudHM9dm9pZCAwO3RoaXMuc2RjPXt9O3RoaXMuc2RyPXt9O3RoaXMuc3ViPXZvaWQgMDt0aGlzLmNsYz12b2lkIDA7dGhpcy5wYWdlTG9hZGVyPXZvaWQgMDt0aGlzLl9icHM9dm9pZCAwO3RoaXMuZXZlbnRzPXZvaWQgMDt0aGlzLl93cmFwQXBwPXZvaWQgMDt0aGlzLmlzU3NyPXZvaWQgMDt0aGlzLmlzRmFsbGJhY2s9dm9pZCAwO3RoaXMuX2luRmxpZ2h0Um91dGU9dm9pZCAwO3RoaXMuX3NoYWxsb3c9dm9pZCAwO3RoaXMubG9jYWxlPXZvaWQgMDt0aGlzLmxvY2FsZXM9dm9pZCAwO3RoaXMuZGVmYXVsdExvY2FsZT12b2lkIDA7dGhpcy5kb21haW5Mb2NhbGVzPXZvaWQgMDt0aGlzLmlzUmVhZHk9dm9pZCAwO3RoaXMuaXNQcmV2aWV3PXZvaWQgMDt0aGlzLmlzTG9jYWxlRG9tYWluPXZvaWQgMDt0aGlzLl9pZHg9MDt0aGlzLm9uUG9wU3RhdGU9ZT0+e2NvbnN0IHN0YXRlPWUuc3RhdGU7aWYoIXN0YXRlKXsvLyBXZSBnZXQgc3RhdGUgYXMgdW5kZWZpbmVkIGZvciB0d28gcmVhc29ucy5cbi8vICAxLiBXaXRoIG9sZGVyIHNhZmFyaSAoPCA4KSBhbmQgb2xkZXIgY2hyb21lICg8IDM0KVxuLy8gIDIuIFdoZW4gdGhlIFVSTCBjaGFuZ2VkIHdpdGggI1xuLy9cbi8vIEluIHRoZSBib3RoIGNhc2VzLCB3ZSBkb24ndCBuZWVkIHRvIHByb2NlZWQgYW5kIGNoYW5nZSB0aGUgcm91dGUuXG4vLyAoYXMgaXQncyBhbHJlYWR5IGNoYW5nZWQpXG4vLyBCdXQgd2UgY2FuIHNpbXBseSByZXBsYWNlIHRoZSBzdGF0ZSB3aXRoIHRoZSBuZXcgY2hhbmdlcy5cbi8vIEFjdHVhbGx5LCBmb3IgKDEpIHdlIGRvbid0IG5lZWQgdG8gbm90aGluZy4gQnV0IGl0J3MgaGFyZCB0byBkZXRlY3QgdGhhdCBldmVudC5cbi8vIFNvLCBkb2luZyB0aGUgZm9sbG93aW5nIGZvciAoMSkgZG9lcyBubyBoYXJtLlxuY29uc3R7cGF0aG5hbWUscXVlcnl9PXRoaXM7dGhpcy5jaGFuZ2VTdGF0ZSgncmVwbGFjZVN0YXRlJywoMCxfdXRpbHMuZm9ybWF0V2l0aFZhbGlkYXRpb24pKHtwYXRobmFtZTphZGRCYXNlUGF0aChwYXRobmFtZSkscXVlcnl9KSwoMCxfdXRpbHMuZ2V0VVJMKSgpKTtyZXR1cm47fWlmKCFzdGF0ZS5fX04pe3JldHVybjt9bGV0IGZvcmNlZFNjcm9sbDtjb25zdHt1cmwsYXMsb3B0aW9ucyxpZHh9PXN0YXRlO2lmKHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04pe2lmKG1hbnVhbFNjcm9sbFJlc3RvcmF0aW9uKXtpZih0aGlzLl9pZHghPT1pZHgpey8vIFNuYXBzaG90IGN1cnJlbnQgc2Nyb2xsIHBvc2l0aW9uOlxudHJ5e3Nlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ19fbmV4dF9zY3JvbGxfJyt0aGlzLl9pZHgsSlNPTi5zdHJpbmdpZnkoe3g6c2VsZi5wYWdlWE9mZnNldCx5OnNlbGYucGFnZVlPZmZzZXR9KSk7fWNhdGNoKF91bnVzZWQpe30vLyBSZXN0b3JlIG9sZCBzY3JvbGwgcG9zaXRpb246XG50cnl7Y29uc3Qgdj1zZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdfX25leHRfc2Nyb2xsXycraWR4KTtmb3JjZWRTY3JvbGw9SlNPTi5wYXJzZSh2KTt9Y2F0Y2goX3VudXNlZDIpe2ZvcmNlZFNjcm9sbD17eDowLHk6MH07fX19fXRoaXMuX2lkeD1pZHg7Y29uc3R7cGF0aG5hbWV9PSgwLF9wYXJzZVJlbGF0aXZlVXJsLnBhcnNlUmVsYXRpdmVVcmwpKHVybCk7Ly8gTWFrZSBzdXJlIHdlIGRvbid0IHJlLXJlbmRlciBvbiBpbml0aWFsIGxvYWQsXG4vLyBjYW4gYmUgY2F1c2VkIGJ5IG5hdmlnYXRpbmcgYmFjayBmcm9tIGFuIGV4dGVybmFsIHNpdGVcbmlmKHRoaXMuaXNTc3ImJmFzPT09dGhpcy5hc1BhdGgmJnBhdGhuYW1lPT09dGhpcy5wYXRobmFtZSl7cmV0dXJuO30vLyBJZiB0aGUgZG93bnN0cmVhbSBhcHBsaWNhdGlvbiByZXR1cm5zIGZhbHN5LCByZXR1cm4uXG4vLyBUaGV5IHdpbGwgdGhlbiBiZSByZXNwb25zaWJsZSBmb3IgaGFuZGxpbmcgdGhlIGV2ZW50LlxuaWYodGhpcy5fYnBzJiYhdGhpcy5fYnBzKHN0YXRlKSl7cmV0dXJuO310aGlzLmNoYW5nZSgncmVwbGFjZVN0YXRlJyx1cmwsYXMsT2JqZWN0LmFzc2lnbih7fSxvcHRpb25zLHtzaGFsbG93Om9wdGlvbnMuc2hhbGxvdyYmdGhpcy5fc2hhbGxvdyxsb2NhbGU6b3B0aW9ucy5sb2NhbGV8fHRoaXMuZGVmYXVsdExvY2FsZX0pLGZvcmNlZFNjcm9sbCk7fTsvLyByZXByZXNlbnRzIHRoZSBjdXJyZW50IGNvbXBvbmVudCBrZXlcbnRoaXMucm91dGU9KDAsX25vcm1hbGl6ZVRyYWlsaW5nU2xhc2gucmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gpKF9wYXRobmFtZSk7Ly8gc2V0IHVwIHRoZSBjb21wb25lbnQgY2FjaGUgKGJ5IHJvdXRlIGtleXMpXG50aGlzLmNvbXBvbmVudHM9e307Ly8gV2Ugc2hvdWxkIG5vdCBrZWVwIHRoZSBjYWNoZSwgaWYgdGhlcmUncyBhbiBlcnJvclxuLy8gT3RoZXJ3aXNlLCB0aGlzIGNhdXNlIGlzc3VlcyB3aGVuIHdoZW4gZ29pbmcgYmFjayBhbmRcbi8vIGNvbWUgYWdhaW4gdG8gdGhlIGVycm9yZWQgcGFnZS5cbmlmKF9wYXRobmFtZSE9PScvX2Vycm9yJyl7dGhpcy5jb21wb25lbnRzW3RoaXMucm91dGVdPXtDb21wb25lbnQsaW5pdGlhbDp0cnVlLHByb3BzOmluaXRpYWxQcm9wcyxlcnIsX19OX1NTRzppbml0aWFsUHJvcHMmJmluaXRpYWxQcm9wcy5fX05fU1NHLF9fTl9TU1A6aW5pdGlhbFByb3BzJiZpbml0aWFsUHJvcHMuX19OX1NTUH07fXRoaXMuY29tcG9uZW50c1snL19hcHAnXT17Q29tcG9uZW50OkFwcCxzdHlsZVNoZWV0czpbLyogL19hcHAgZG9lcyBub3QgbmVlZCBpdHMgc3R5bGVzaGVldHMgbWFuYWdlZCAqL119Oy8vIEJhY2t3YXJkcyBjb21wYXQgZm9yIFJvdXRlci5yb3V0ZXIuZXZlbnRzXG4vLyBUT0RPOiBTaG91bGQgYmUgcmVtb3ZlIHRoZSBmb2xsb3dpbmcgbWFqb3IgdmVyc2lvbiBhcyBpdCB3YXMgbmV2ZXIgZG9jdW1lbnRlZFxudGhpcy5ldmVudHM9Um91dGVyLmV2ZW50czt0aGlzLnBhZ2VMb2FkZXI9cGFnZUxvYWRlcjt0aGlzLnBhdGhuYW1lPV9wYXRobmFtZTt0aGlzLnF1ZXJ5PV9xdWVyeTsvLyBpZiBhdXRvIHByZXJlbmRlcmVkIGFuZCBkeW5hbWljIHJvdXRlIHdhaXQgdG8gdXBkYXRlIGFzUGF0aFxuLy8gdW50aWwgYWZ0ZXIgbW91bnQgdG8gcHJldmVudCBoeWRyYXRpb24gbWlzbWF0Y2hcbmNvbnN0IGF1dG9FeHBvcnREeW5hbWljPSgwLF9pc0R5bmFtaWMuaXNEeW5hbWljUm91dGUpKF9wYXRobmFtZSkmJnNlbGYuX19ORVhUX0RBVEFfXy5hdXRvRXhwb3J0O3RoaXMuYXNQYXRoPWF1dG9FeHBvcnREeW5hbWljP19wYXRobmFtZTpfYXM7dGhpcy5iYXNlUGF0aD1iYXNlUGF0aDt0aGlzLnN1Yj1zdWJzY3JpcHRpb247dGhpcy5jbGM9bnVsbDt0aGlzLl93cmFwQXBwPXdyYXBBcHA7Ly8gbWFrZSBzdXJlIHRvIGlnbm9yZSBleHRyYSBwb3BTdGF0ZSBpbiBzYWZhcmkgb24gbmF2aWdhdGluZ1xuLy8gYmFjayBmcm9tIGV4dGVybmFsIHNpdGVcbnRoaXMuaXNTc3I9dHJ1ZTt0aGlzLmlzRmFsbGJhY2s9aXNGYWxsYmFjazt0aGlzLmlzUmVhZHk9ISEoc2VsZi5fX05FWFRfREFUQV9fLmdzc3B8fHNlbGYuX19ORVhUX0RBVEFfXy5naXB8fCFhdXRvRXhwb3J0RHluYW1pYyYmIXNlbGYubG9jYXRpb24uc2VhcmNoJiYhcHJvY2Vzcy5lbnYuX19ORVhUX0hBU19SRVdSSVRFUyk7dGhpcy5pc1ByZXZpZXc9ISFpc1ByZXZpZXc7dGhpcy5pc0xvY2FsZURvbWFpbj1mYWxzZTtpZihwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKXt0aGlzLmxvY2FsZT1sb2NhbGU7dGhpcy5sb2NhbGVzPWxvY2FsZXM7dGhpcy5kZWZhdWx0TG9jYWxlPWRlZmF1bHRMb2NhbGU7dGhpcy5kb21haW5Mb2NhbGVzPWRvbWFpbkxvY2FsZXM7dGhpcy5pc0xvY2FsZURvbWFpbj0hIWRldGVjdERvbWFpbkxvY2FsZShkb21haW5Mb2NhbGVzLHNlbGYubG9jYXRpb24uaG9zdG5hbWUpO31pZih0eXBlb2Ygd2luZG93IT09J3VuZGVmaW5lZCcpey8vIG1ha2Ugc3VyZSBcImFzXCIgZG9lc24ndCBzdGFydCB3aXRoIGRvdWJsZSBzbGFzaGVzIG9yIGVsc2UgaXQgY2FuXG4vLyB0aHJvdyBhbiBlcnJvciBhcyBpdCdzIGNvbnNpZGVyZWQgaW52YWxpZFxuaWYoX2FzLnN1YnN0cigwLDIpIT09Jy8vJyl7Ly8gaW4gb3JkZXIgZm9yIGBlLnN0YXRlYCB0byB3b3JrIG9uIHRoZSBgb25wb3BzdGF0ZWAgZXZlbnRcbi8vIHdlIGhhdmUgdG8gcmVnaXN0ZXIgdGhlIGluaXRpYWwgcm91dGUgdXBvbiBpbml0aWFsaXphdGlvblxuY29uc3Qgb3B0aW9ucz17bG9jYWxlfTtvcHRpb25zLl9zaG91bGRSZXNvbHZlSHJlZj1fYXMhPT1fcGF0aG5hbWU7dGhpcy5jaGFuZ2VTdGF0ZSgncmVwbGFjZVN0YXRlJywoMCxfdXRpbHMuZm9ybWF0V2l0aFZhbGlkYXRpb24pKHtwYXRobmFtZTphZGRCYXNlUGF0aChfcGF0aG5hbWUpLHF1ZXJ5Ol9xdWVyeX0pLCgwLF91dGlscy5nZXRVUkwpKCksb3B0aW9ucyk7fXdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdwb3BzdGF0ZScsdGhpcy5vblBvcFN0YXRlKTsvLyBlbmFibGUgY3VzdG9tIHNjcm9sbCByZXN0b3JhdGlvbiBoYW5kbGluZyB3aGVuIGF2YWlsYWJsZVxuLy8gb3RoZXJ3aXNlIGZhbGxiYWNrIHRvIGJyb3dzZXIncyBkZWZhdWx0IGhhbmRsaW5nXG5pZihwcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OKXtpZihtYW51YWxTY3JvbGxSZXN0b3JhdGlvbil7d2luZG93Lmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb249J21hbnVhbCc7fX19fXJlbG9hZCgpe3dpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTt9LyoqXG4gICAqIEdvIGJhY2sgaW4gaGlzdG9yeVxuICAgKi9iYWNrKCl7d2luZG93Lmhpc3RvcnkuYmFjaygpO30vKipcbiAgICogUGVyZm9ybXMgYSBgcHVzaFN0YXRlYCB3aXRoIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gdXJsIG9mIHRoZSByb3V0ZVxuICAgKiBAcGFyYW0gYXMgbWFza3MgYHVybGAgZm9yIHRoZSBicm93c2VyXG4gICAqIEBwYXJhbSBvcHRpb25zIG9iamVjdCB5b3UgY2FuIGRlZmluZSBgc2hhbGxvd2AgYW5kIG90aGVyIG9wdGlvbnNcbiAgICovcHVzaCh1cmwsYXMsb3B0aW9ucz17fSl7aWYocHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTil7Ly8gVE9ETzogcmVtb3ZlIGluIHRoZSBmdXR1cmUgd2hlbiB3ZSB1cGRhdGUgaGlzdG9yeSBiZWZvcmUgcm91dGUgY2hhbmdlXG4vLyBpcyBjb21wbGV0ZSwgYXMgdGhlIHBvcHN0YXRlIGV2ZW50IHNob3VsZCBoYW5kbGUgdGhpcyBjYXB0dXJlLlxuaWYobWFudWFsU2Nyb2xsUmVzdG9yYXRpb24pe3RyeXsvLyBTbmFwc2hvdCBzY3JvbGwgcG9zaXRpb24gcmlnaHQgYmVmb3JlIG5hdmlnYXRpbmcgdG8gYSBuZXcgcGFnZTpcbnNlc3Npb25TdG9yYWdlLnNldEl0ZW0oJ19fbmV4dF9zY3JvbGxfJyt0aGlzLl9pZHgsSlNPTi5zdHJpbmdpZnkoe3g6c2VsZi5wYWdlWE9mZnNldCx5OnNlbGYucGFnZVlPZmZzZXR9KSk7fWNhdGNoKF91bnVzZWQzKXt9fX07KHt1cmwsYXN9PXByZXBhcmVVcmxBcyh0aGlzLHVybCxhcykpO3JldHVybiB0aGlzLmNoYW5nZSgncHVzaFN0YXRlJyx1cmwsYXMsb3B0aW9ucyk7fS8qKlxuICAgKiBQZXJmb3JtcyBhIGByZXBsYWNlU3RhdGVgIHdpdGggYXJndW1lbnRzXG4gICAqIEBwYXJhbSB1cmwgb2YgdGhlIHJvdXRlXG4gICAqIEBwYXJhbSBhcyBtYXNrcyBgdXJsYCBmb3IgdGhlIGJyb3dzZXJcbiAgICogQHBhcmFtIG9wdGlvbnMgb2JqZWN0IHlvdSBjYW4gZGVmaW5lIGBzaGFsbG93YCBhbmQgb3RoZXIgb3B0aW9uc1xuICAgKi9yZXBsYWNlKHVybCxhcyxvcHRpb25zPXt9KXs7KHt1cmwsYXN9PXByZXBhcmVVcmxBcyh0aGlzLHVybCxhcykpO3JldHVybiB0aGlzLmNoYW5nZSgncmVwbGFjZVN0YXRlJyx1cmwsYXMsb3B0aW9ucyk7fWFzeW5jIGNoYW5nZShtZXRob2QsdXJsLGFzLG9wdGlvbnMsZm9yY2VkU2Nyb2xsKXtpZighaXNMb2NhbFVSTCh1cmwpKXt3aW5kb3cubG9jYXRpb24uaHJlZj11cmw7cmV0dXJuIGZhbHNlO31jb25zdCBzaG91bGRSZXNvbHZlSHJlZj11cmw9PT1hc3x8b3B0aW9ucy5faHx8b3B0aW9ucy5fc2hvdWxkUmVzb2x2ZUhyZWY7Ly8gZm9yIHN0YXRpYyBwYWdlcyB3aXRoIHF1ZXJ5IHBhcmFtcyBpbiB0aGUgVVJMIHdlIGRlbGF5XG4vLyBtYXJraW5nIHRoZSByb3V0ZXIgcmVhZHkgdW50aWwgYWZ0ZXIgdGhlIHF1ZXJ5IGlzIHVwZGF0ZWRcbmlmKG9wdGlvbnMuX2gpe3RoaXMuaXNSZWFkeT10cnVlO31sZXQgbG9jYWxlQ2hhbmdlPW9wdGlvbnMubG9jYWxlIT09dGhpcy5sb2NhbGU7aWYocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCl7dGhpcy5sb2NhbGU9b3B0aW9ucy5sb2NhbGU9PT1mYWxzZT90aGlzLmRlZmF1bHRMb2NhbGU6b3B0aW9ucy5sb2NhbGV8fHRoaXMubG9jYWxlO2lmKHR5cGVvZiBvcHRpb25zLmxvY2FsZT09PSd1bmRlZmluZWQnKXtvcHRpb25zLmxvY2FsZT10aGlzLmxvY2FsZTt9Y29uc3QgcGFyc2VkQXM9KDAsX3BhcnNlUmVsYXRpdmVVcmwucGFyc2VSZWxhdGl2ZVVybCkoaGFzQmFzZVBhdGgoYXMpP2RlbEJhc2VQYXRoKGFzKTphcyk7Y29uc3QgbG9jYWxlUGF0aFJlc3VsdD0oMCxfbm9ybWFsaXplTG9jYWxlUGF0aC5ub3JtYWxpemVMb2NhbGVQYXRoKShwYXJzZWRBcy5wYXRobmFtZSx0aGlzLmxvY2FsZXMpO2lmKGxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGUpe3RoaXMubG9jYWxlPWxvY2FsZVBhdGhSZXN1bHQuZGV0ZWN0ZWRMb2NhbGU7cGFyc2VkQXMucGF0aG5hbWU9YWRkQmFzZVBhdGgocGFyc2VkQXMucGF0aG5hbWUpO2FzPSgwLF91dGlscy5mb3JtYXRXaXRoVmFsaWRhdGlvbikocGFyc2VkQXMpO3VybD1hZGRCYXNlUGF0aCgoMCxfbm9ybWFsaXplTG9jYWxlUGF0aC5ub3JtYWxpemVMb2NhbGVQYXRoKShoYXNCYXNlUGF0aCh1cmwpP2RlbEJhc2VQYXRoKHVybCk6dXJsLHRoaXMubG9jYWxlcykucGF0aG5hbWUpO31sZXQgZGlkTmF2aWdhdGU9ZmFsc2U7Ly8gd2UgbmVlZCB0byB3cmFwIHRoaXMgaW4gdGhlIGVudiBjaGVjayBhZ2FpbiBzaW5jZSByZWdlbmVyYXRvciBydW50aW1lXG4vLyBtb3ZlcyB0aGlzIG9uIGl0cyBvd24gZHVlIHRvIHRoZSByZXR1cm5cbmlmKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpe3ZhciBfdGhpcyRsb2NhbGVzOy8vIGlmIHRoZSBsb2NhbGUgaXNuJ3QgY29uZmlndXJlZCBoYXJkIG5hdmlnYXRlIHRvIHNob3cgNDA0IHBhZ2VcbmlmKCEoKF90aGlzJGxvY2FsZXM9dGhpcy5sb2NhbGVzKSE9bnVsbCYmX3RoaXMkbG9jYWxlcy5pbmNsdWRlcyh0aGlzLmxvY2FsZSkpKXtwYXJzZWRBcy5wYXRobmFtZT1hZGRMb2NhbGUocGFyc2VkQXMucGF0aG5hbWUsdGhpcy5sb2NhbGUpO3dpbmRvdy5sb2NhdGlvbi5ocmVmPSgwLF91dGlscy5mb3JtYXRXaXRoVmFsaWRhdGlvbikocGFyc2VkQXMpOy8vIHRoaXMgd2FzIHByZXZpb3VzbHkgYSByZXR1cm4gYnV0IHdhcyByZW1vdmVkIGluIGZhdm9yXG4vLyBvZiBiZXR0ZXIgZGVhZCBjb2RlIGVsaW1pbmF0aW9uIHdpdGggcmVnZW5lcmF0b3IgcnVudGltZVxuZGlkTmF2aWdhdGU9dHJ1ZTt9fWNvbnN0IGRldGVjdGVkRG9tYWluPWRldGVjdERvbWFpbkxvY2FsZSh0aGlzLmRvbWFpbkxvY2FsZXMsdW5kZWZpbmVkLHRoaXMubG9jYWxlKTsvLyB3ZSBuZWVkIHRvIHdyYXAgdGhpcyBpbiB0aGUgZW52IGNoZWNrIGFnYWluIHNpbmNlIHJlZ2VuZXJhdG9yIHJ1bnRpbWVcbi8vIG1vdmVzIHRoaXMgb24gaXRzIG93biBkdWUgdG8gdGhlIHJldHVyblxuaWYocHJvY2Vzcy5lbnYuX19ORVhUX0kxOE5fU1VQUE9SVCl7Ly8gaWYgd2UgYXJlIG5hdmlnYXRpbmcgdG8gYSBkb21haW4gbG9jYWxlIGVuc3VyZSB3ZSByZWRpcmVjdCB0byB0aGVcbi8vIGNvcnJlY3QgZG9tYWluXG5pZighZGlkTmF2aWdhdGUmJmRldGVjdGVkRG9tYWluJiZ0aGlzLmlzTG9jYWxlRG9tYWluJiZzZWxmLmxvY2F0aW9uLmhvc3RuYW1lIT09ZGV0ZWN0ZWREb21haW4uZG9tYWluKXtjb25zdCBhc05vQmFzZVBhdGg9ZGVsQmFzZVBhdGgoYXMpO3dpbmRvdy5sb2NhdGlvbi5ocmVmPWBodHRwJHtkZXRlY3RlZERvbWFpbi5odHRwPycnOidzJ306Ly8ke2RldGVjdGVkRG9tYWluLmRvbWFpbn0ke2FkZEJhc2VQYXRoKGAke3RoaXMubG9jYWxlPT09ZGV0ZWN0ZWREb21haW4uZGVmYXVsdExvY2FsZT8nJzpgLyR7dGhpcy5sb2NhbGV9YH0ke2FzTm9CYXNlUGF0aD09PScvJz8nJzphc05vQmFzZVBhdGh9YHx8Jy8nKX1gOy8vIHRoaXMgd2FzIHByZXZpb3VzbHkgYSByZXR1cm4gYnV0IHdhcyByZW1vdmVkIGluIGZhdm9yXG4vLyBvZiBiZXR0ZXIgZGVhZCBjb2RlIGVsaW1pbmF0aW9uIHdpdGggcmVnZW5lcmF0b3IgcnVudGltZVxuZGlkTmF2aWdhdGU9dHJ1ZTt9fWlmKGRpZE5hdmlnYXRlKXtyZXR1cm4gbmV3IFByb21pc2UoKCk9Pnt9KTt9fWlmKCFvcHRpb25zLl9oKXt0aGlzLmlzU3NyPWZhbHNlO30vLyBtYXJraW5nIHJvdXRlIGNoYW5nZXMgYXMgYSBuYXZpZ2F0aW9uIHN0YXJ0IGVudHJ5XG5pZihfdXRpbHMuU1Qpe3BlcmZvcm1hbmNlLm1hcmsoJ3JvdXRlQ2hhbmdlJyk7fWNvbnN0e3NoYWxsb3c9ZmFsc2V9PW9wdGlvbnM7Y29uc3Qgcm91dGVQcm9wcz17c2hhbGxvd307aWYodGhpcy5faW5GbGlnaHRSb3V0ZSl7dGhpcy5hYm9ydENvbXBvbmVudExvYWQodGhpcy5faW5GbGlnaHRSb3V0ZSxyb3V0ZVByb3BzKTt9YXM9YWRkQmFzZVBhdGgoYWRkTG9jYWxlKGhhc0Jhc2VQYXRoKGFzKT9kZWxCYXNlUGF0aChhcyk6YXMsb3B0aW9ucy5sb2NhbGUsdGhpcy5kZWZhdWx0TG9jYWxlKSk7Y29uc3QgY2xlYW5lZEFzPWRlbExvY2FsZShoYXNCYXNlUGF0aChhcyk/ZGVsQmFzZVBhdGgoYXMpOmFzLHRoaXMubG9jYWxlKTt0aGlzLl9pbkZsaWdodFJvdXRlPWFzOy8vIElmIHRoZSB1cmwgY2hhbmdlIGlzIG9ubHkgcmVsYXRlZCB0byBhIGhhc2ggY2hhbmdlXG4vLyBXZSBzaG91bGQgbm90IHByb2NlZWQuIFdlIHNob3VsZCBvbmx5IGNoYW5nZSB0aGUgc3RhdGUuXG4vLyBXQVJOSU5HOiBgX2hgIGlzIGFuIGludGVybmFsIG9wdGlvbiBmb3IgaGFuZGluZyBOZXh0LmpzIGNsaWVudC1zaWRlXG4vLyBoeWRyYXRpb24uIFlvdXIgYXBwIHNob3VsZCBfbmV2ZXJfIHVzZSB0aGlzIHByb3BlcnR5LiBJdCBtYXkgY2hhbmdlIGF0XG4vLyBhbnkgdGltZSB3aXRob3V0IG5vdGljZS5cbmlmKCFvcHRpb25zLl9oJiZ0aGlzLm9ubHlBSGFzaENoYW5nZShjbGVhbmVkQXMpKXt0aGlzLmFzUGF0aD1jbGVhbmVkQXM7Um91dGVyLmV2ZW50cy5lbWl0KCdoYXNoQ2hhbmdlU3RhcnQnLGFzLHJvdXRlUHJvcHMpOy8vIFRPRE86IGRvIHdlIG5lZWQgdGhlIHJlc29sdmVkIGhyZWYgd2hlbiBvbmx5IGEgaGFzaCBjaGFuZ2U/XG50aGlzLmNoYW5nZVN0YXRlKG1ldGhvZCx1cmwsYXMsb3B0aW9ucyk7dGhpcy5zY3JvbGxUb0hhc2goY2xlYW5lZEFzKTt0aGlzLm5vdGlmeSh0aGlzLmNvbXBvbmVudHNbdGhpcy5yb3V0ZV0sbnVsbCk7Um91dGVyLmV2ZW50cy5lbWl0KCdoYXNoQ2hhbmdlQ29tcGxldGUnLGFzLHJvdXRlUHJvcHMpO3JldHVybiB0cnVlO31sZXQgcGFyc2VkPSgwLF9wYXJzZVJlbGF0aXZlVXJsLnBhcnNlUmVsYXRpdmVVcmwpKHVybCk7bGV0e3BhdGhuYW1lLHF1ZXJ5fT1wYXJzZWQ7Ly8gVGhlIGJ1aWxkIG1hbmlmZXN0IG5lZWRzIHRvIGJlIGxvYWRlZCBiZWZvcmUgYXV0by1zdGF0aWMgZHluYW1pYyBwYWdlc1xuLy8gZ2V0IHRoZWlyIHF1ZXJ5IHBhcmFtZXRlcnMgdG8gYWxsb3cgZW5zdXJpbmcgdGhleSBjYW4gYmUgcGFyc2VkIHByb3Blcmx5XG4vLyB3aGVuIHJld3JpdHRlbiB0b1xubGV0IHBhZ2VzLHJld3JpdGVzO3RyeXtwYWdlcz1hd2FpdCB0aGlzLnBhZ2VMb2FkZXIuZ2V0UGFnZUxpc3QoKTsoe19fcmV3cml0ZXM6cmV3cml0ZXN9PWF3YWl0KDAsX3JvdXRlTG9hZGVyLmdldENsaWVudEJ1aWxkTWFuaWZlc3QpKCkpO31jYXRjaChlcnIpey8vIElmIHdlIGZhaWwgdG8gcmVzb2x2ZSB0aGUgcGFnZSBsaXN0IG9yIGNsaWVudC1idWlsZCBtYW5pZmVzdCwgd2UgbXVzdFxuLy8gZG8gYSBzZXJ2ZXItc2lkZSB0cmFuc2l0aW9uOlxud2luZG93LmxvY2F0aW9uLmhyZWY9YXM7cmV0dXJuIGZhbHNlO30vLyBJZiBhc2tlZCB0byBjaGFuZ2UgdGhlIGN1cnJlbnQgVVJMIHdlIHNob3VsZCByZWxvYWQgdGhlIGN1cnJlbnQgcGFnZVxuLy8gKG5vdCBsb2NhdGlvbi5yZWxvYWQoKSBidXQgcmVsb2FkIGdldEluaXRpYWxQcm9wcyBhbmQgb3RoZXIgTmV4dC5qcyBzdHVmZnMpXG4vLyBXZSBhbHNvIG5lZWQgdG8gc2V0IHRoZSBtZXRob2QgPSByZXBsYWNlU3RhdGUgYWx3YXlzXG4vLyBhcyB0aGlzIHNob3VsZCBub3QgZ28gaW50byB0aGUgaGlzdG9yeSAoVGhhdCdzIGhvdyBicm93c2VycyB3b3JrKVxuLy8gV2Ugc2hvdWxkIGNvbXBhcmUgdGhlIG5ldyBhc1BhdGggdG8gdGhlIGN1cnJlbnQgYXNQYXRoLCBub3QgdGhlIHVybFxuaWYoIXRoaXMudXJsSXNOZXcoY2xlYW5lZEFzKSYmIWxvY2FsZUNoYW5nZSl7bWV0aG9kPSdyZXBsYWNlU3RhdGUnO30vLyB3ZSBuZWVkIHRvIHJlc29sdmUgdGhlIGFzIHZhbHVlIHVzaW5nIHJld3JpdGVzIGZvciBkeW5hbWljIFNTR1xuLy8gcGFnZXMgdG8gYWxsb3cgYnVpbGRpbmcgdGhlIGRhdGEgVVJMIGNvcnJlY3RseVxubGV0IHJlc29sdmVkQXM9YXM7Ly8gdXJsIGFuZCBhcyBzaG91bGQgYWx3YXlzIGJlIHByZWZpeGVkIHdpdGggYmFzZVBhdGggYnkgdGhpc1xuLy8gcG9pbnQgYnkgZWl0aGVyIG5leHQvbGluayBvciByb3V0ZXIucHVzaC9yZXBsYWNlIHNvIHN0cmlwIHRoZVxuLy8gYmFzZVBhdGggZnJvbSB0aGUgcGF0aG5hbWUgdG8gbWF0Y2ggdGhlIHBhZ2VzIGRpciAxLXRvLTFcbnBhdGhuYW1lPXBhdGhuYW1lPygwLF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoLnJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKShkZWxCYXNlUGF0aChwYXRobmFtZSkpOnBhdGhuYW1lO2lmKHNob3VsZFJlc29sdmVIcmVmJiZwYXRobmFtZSE9PScvX2Vycm9yJyl7O29wdGlvbnMuX3Nob3VsZFJlc29sdmVIcmVmPXRydWU7aWYocHJvY2Vzcy5lbnYuX19ORVhUX0hBU19SRVdSSVRFUyYmYXMuc3RhcnRzV2l0aCgnLycpKXtjb25zdCByZXdyaXRlc1Jlc3VsdD0oMCxfcmVzb2x2ZVJld3JpdGVzLmRlZmF1bHQpKGFkZEJhc2VQYXRoKGFkZExvY2FsZShjbGVhbmVkQXMsdGhpcy5sb2NhbGUpKSxwYWdlcyxyZXdyaXRlcyxxdWVyeSxwPT5yZXNvbHZlRHluYW1pY1JvdXRlKHAscGFnZXMpLHRoaXMubG9jYWxlcyk7cmVzb2x2ZWRBcz1yZXdyaXRlc1Jlc3VsdC5hc1BhdGg7aWYocmV3cml0ZXNSZXN1bHQubWF0Y2hlZFBhZ2UmJnJld3JpdGVzUmVzdWx0LnJlc29sdmVkSHJlZil7Ly8gaWYgdGhpcyBkaXJlY3RseSBtYXRjaGVzIGEgcGFnZSB3ZSBuZWVkIHRvIHVwZGF0ZSB0aGUgaHJlZiB0b1xuLy8gYWxsb3cgdGhlIGNvcnJlY3QgcGFnZSBjaHVuayB0byBiZSBsb2FkZWRcbnBhdGhuYW1lPXJld3JpdGVzUmVzdWx0LnJlc29sdmVkSHJlZjtwYXJzZWQucGF0aG5hbWU9YWRkQmFzZVBhdGgocGF0aG5hbWUpO3VybD0oMCxfdXRpbHMuZm9ybWF0V2l0aFZhbGlkYXRpb24pKHBhcnNlZCk7fX1lbHNle3BhcnNlZC5wYXRobmFtZT1yZXNvbHZlRHluYW1pY1JvdXRlKHBhdGhuYW1lLHBhZ2VzKTtpZihwYXJzZWQucGF0aG5hbWUhPT1wYXRobmFtZSl7cGF0aG5hbWU9cGFyc2VkLnBhdGhuYW1lO3BhcnNlZC5wYXRobmFtZT1hZGRCYXNlUGF0aChwYXRobmFtZSk7dXJsPSgwLF91dGlscy5mb3JtYXRXaXRoVmFsaWRhdGlvbikocGFyc2VkKTt9fX1jb25zdCByb3V0ZT0oMCxfbm9ybWFsaXplVHJhaWxpbmdTbGFzaC5yZW1vdmVQYXRoVHJhaWxpbmdTbGFzaCkocGF0aG5hbWUpO2lmKCFpc0xvY2FsVVJMKGFzKSl7aWYocHJvY2Vzcy5lbnYuTk9ERV9FTlYhPT0ncHJvZHVjdGlvbicpe3Rocm93IG5ldyBFcnJvcihgSW52YWxpZCBocmVmOiBcIiR7dXJsfVwiIGFuZCBhczogXCIke2FzfVwiLCByZWNlaXZlZCByZWxhdGl2ZSBocmVmIGFuZCBleHRlcm5hbCBhc2ArYFxcblNlZSBtb3JlIGluZm86IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL2ludmFsaWQtcmVsYXRpdmUtdXJsLWV4dGVybmFsLWFzYCk7fXdpbmRvdy5sb2NhdGlvbi5ocmVmPWFzO3JldHVybiBmYWxzZTt9cmVzb2x2ZWRBcz1kZWxMb2NhbGUoZGVsQmFzZVBhdGgocmVzb2x2ZWRBcyksdGhpcy5sb2NhbGUpO2lmKCgwLF9pc0R5bmFtaWMuaXNEeW5hbWljUm91dGUpKHJvdXRlKSl7Y29uc3QgcGFyc2VkQXM9KDAsX3BhcnNlUmVsYXRpdmVVcmwucGFyc2VSZWxhdGl2ZVVybCkocmVzb2x2ZWRBcyk7Y29uc3QgYXNQYXRobmFtZT1wYXJzZWRBcy5wYXRobmFtZTtjb25zdCByb3V0ZVJlZ2V4PSgwLF9yb3V0ZVJlZ2V4LmdldFJvdXRlUmVnZXgpKHJvdXRlKTtjb25zdCByb3V0ZU1hdGNoPSgwLF9yb3V0ZU1hdGNoZXIuZ2V0Um91dGVNYXRjaGVyKShyb3V0ZVJlZ2V4KShhc1BhdGhuYW1lKTtjb25zdCBzaG91bGRJbnRlcnBvbGF0ZT1yb3V0ZT09PWFzUGF0aG5hbWU7Y29uc3QgaW50ZXJwb2xhdGVkQXM9c2hvdWxkSW50ZXJwb2xhdGU/aW50ZXJwb2xhdGVBcyhyb3V0ZSxhc1BhdGhuYW1lLHF1ZXJ5KTp7fTtpZighcm91dGVNYXRjaHx8c2hvdWxkSW50ZXJwb2xhdGUmJiFpbnRlcnBvbGF0ZWRBcy5yZXN1bHQpe2NvbnN0IG1pc3NpbmdQYXJhbXM9T2JqZWN0LmtleXMocm91dGVSZWdleC5ncm91cHMpLmZpbHRlcihwYXJhbT0+IXF1ZXJ5W3BhcmFtXSk7aWYobWlzc2luZ1BhcmFtcy5sZW5ndGg+MCl7aWYocHJvY2Vzcy5lbnYuTk9ERV9FTlYhPT0ncHJvZHVjdGlvbicpe2NvbnNvbGUud2FybihgJHtzaG91bGRJbnRlcnBvbGF0ZT9gSW50ZXJwb2xhdGluZyBocmVmYDpgTWlzbWF0Y2hpbmcgXFxgYXNcXGAgYW5kIFxcYGhyZWZcXGBgfSBmYWlsZWQgdG8gbWFudWFsbHkgcHJvdmlkZSBgK2B0aGUgcGFyYW1zOiAke21pc3NpbmdQYXJhbXMuam9pbignLCAnKX0gaW4gdGhlIFxcYGhyZWZcXGAncyBcXGBxdWVyeVxcYGApO310aHJvdyBuZXcgRXJyb3IoKHNob3VsZEludGVycG9sYXRlP2BUaGUgcHJvdmlkZWQgXFxgaHJlZlxcYCAoJHt1cmx9KSB2YWx1ZSBpcyBtaXNzaW5nIHF1ZXJ5IHZhbHVlcyAoJHttaXNzaW5nUGFyYW1zLmpvaW4oJywgJyl9KSB0byBiZSBpbnRlcnBvbGF0ZWQgcHJvcGVybHkuIGA6YFRoZSBwcm92aWRlZCBcXGBhc1xcYCB2YWx1ZSAoJHthc1BhdGhuYW1lfSkgaXMgaW5jb21wYXRpYmxlIHdpdGggdGhlIFxcYGhyZWZcXGAgdmFsdWUgKCR7cm91dGV9KS4gYCkrYFJlYWQgbW9yZTogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvJHtzaG91bGRJbnRlcnBvbGF0ZT8naHJlZi1pbnRlcnBvbGF0aW9uLWZhaWxlZCc6J2luY29tcGF0aWJsZS1ocmVmLWFzJ31gKTt9fWVsc2UgaWYoc2hvdWxkSW50ZXJwb2xhdGUpe2FzPSgwLF91dGlscy5mb3JtYXRXaXRoVmFsaWRhdGlvbikoT2JqZWN0LmFzc2lnbih7fSxwYXJzZWRBcyx7cGF0aG5hbWU6aW50ZXJwb2xhdGVkQXMucmVzdWx0LHF1ZXJ5Om9taXRQYXJtc0Zyb21RdWVyeShxdWVyeSxpbnRlcnBvbGF0ZWRBcy5wYXJhbXMpfSkpO31lbHNley8vIE1lcmdlIHBhcmFtcyBpbnRvIGBxdWVyeWAsIG92ZXJ3cml0aW5nIGFueSBzcGVjaWZpZWQgaW4gc2VhcmNoXG5PYmplY3QuYXNzaWduKHF1ZXJ5LHJvdXRlTWF0Y2gpO319Um91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZVN0YXJ0Jyxhcyxyb3V0ZVByb3BzKTt0cnl7dmFyIF9zZWxmJF9fTkVYVF9EQVRBX18kcCxfc2VsZiRfX05FWFRfREFUQV9fJHAyLF9vcHRpb25zJHNjcm9sbDtsZXQgcm91dGVJbmZvPWF3YWl0IHRoaXMuZ2V0Um91dGVJbmZvKHJvdXRlLHBhdGhuYW1lLHF1ZXJ5LGFzLHJlc29sdmVkQXMscm91dGVQcm9wcyk7bGV0e2Vycm9yLHByb3BzLF9fTl9TU0csX19OX1NTUH09cm91dGVJbmZvOy8vIGhhbmRsZSByZWRpcmVjdCBvbiBjbGllbnQtdHJhbnNpdGlvblxuaWYoKF9fTl9TU0d8fF9fTl9TU1ApJiZwcm9wcyl7aWYocHJvcHMucGFnZVByb3BzJiZwcm9wcy5wYWdlUHJvcHMuX19OX1JFRElSRUNUKXtjb25zdCBkZXN0aW5hdGlvbj1wcm9wcy5wYWdlUHJvcHMuX19OX1JFRElSRUNUOy8vIGNoZWNrIGlmIGRlc3RpbmF0aW9uIGlzIGludGVybmFsIChyZXNvbHZlcyB0byBhIHBhZ2UpIGFuZCBhdHRlbXB0XG4vLyBjbGllbnQtbmF2aWdhdGlvbiBpZiBpdCBpcyBmYWxsaW5nIGJhY2sgdG8gaGFyZCBuYXZpZ2F0aW9uIGlmXG4vLyBpdCdzIG5vdFxuaWYoZGVzdGluYXRpb24uc3RhcnRzV2l0aCgnLycpKXtjb25zdCBwYXJzZWRIcmVmPSgwLF9wYXJzZVJlbGF0aXZlVXJsLnBhcnNlUmVsYXRpdmVVcmwpKGRlc3RpbmF0aW9uKTtwYXJzZWRIcmVmLnBhdGhuYW1lPXJlc29sdmVEeW5hbWljUm91dGUocGFyc2VkSHJlZi5wYXRobmFtZSxwYWdlcyk7aWYocGFnZXMuaW5jbHVkZXMocGFyc2VkSHJlZi5wYXRobmFtZSkpe2NvbnN0e3VybDpuZXdVcmwsYXM6bmV3QXN9PXByZXBhcmVVcmxBcyh0aGlzLGRlc3RpbmF0aW9uLGRlc3RpbmF0aW9uKTtyZXR1cm4gdGhpcy5jaGFuZ2UobWV0aG9kLG5ld1VybCxuZXdBcyxvcHRpb25zKTt9fXdpbmRvdy5sb2NhdGlvbi5ocmVmPWRlc3RpbmF0aW9uO3JldHVybiBuZXcgUHJvbWlzZSgoKT0+e30pO310aGlzLmlzUHJldmlldz0hIXByb3BzLl9fTl9QUkVWSUVXOy8vIGhhbmRsZSBTU0cgZGF0YSA0MDRcbmlmKHByb3BzLm5vdEZvdW5kPT09U1NHX0RBVEFfTk9UX0ZPVU5EKXtsZXQgbm90Rm91bmRSb3V0ZTt0cnl7YXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudCgnLzQwNCcpO25vdEZvdW5kUm91dGU9Jy80MDQnO31jYXRjaChfKXtub3RGb3VuZFJvdXRlPScvX2Vycm9yJzt9cm91dGVJbmZvPWF3YWl0IHRoaXMuZ2V0Um91dGVJbmZvKG5vdEZvdW5kUm91dGUsbm90Rm91bmRSb3V0ZSxxdWVyeSxhcyxyZXNvbHZlZEFzLHtzaGFsbG93OmZhbHNlfSk7fX1Sb3V0ZXIuZXZlbnRzLmVtaXQoJ2JlZm9yZUhpc3RvcnlDaGFuZ2UnLGFzLHJvdXRlUHJvcHMpO3RoaXMuY2hhbmdlU3RhdGUobWV0aG9kLHVybCxhcyxvcHRpb25zKTtpZihwcm9jZXNzLmVudi5OT0RFX0VOViE9PSdwcm9kdWN0aW9uJyl7Y29uc3QgYXBwQ29tcD10aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10uQ29tcG9uZW50O3dpbmRvdy5uZXh0LmlzUHJlcmVuZGVyZWQ9YXBwQ29tcC5nZXRJbml0aWFsUHJvcHM9PT1hcHBDb21wLm9yaWdHZXRJbml0aWFsUHJvcHMmJiFyb3V0ZUluZm8uQ29tcG9uZW50LmdldEluaXRpYWxQcm9wczt9aWYob3B0aW9ucy5faCYmcGF0aG5hbWU9PT0nL19lcnJvcicmJigoX3NlbGYkX19ORVhUX0RBVEFfXyRwPXNlbGYuX19ORVhUX0RBVEFfXy5wcm9wcyk9PW51bGw/dm9pZCAwOihfc2VsZiRfX05FWFRfREFUQV9fJHAyPV9zZWxmJF9fTkVYVF9EQVRBX18kcC5wYWdlUHJvcHMpPT1udWxsP3ZvaWQgMDpfc2VsZiRfX05FWFRfREFUQV9fJHAyLnN0YXR1c0NvZGUpPT09NTAwJiZwcm9wcyE9bnVsbCYmcHJvcHMucGFnZVByb3BzKXsvLyBlbnN1cmUgc3RhdHVzQ29kZSBpcyBzdGlsbCBjb3JyZWN0IGZvciBzdGF0aWMgNTAwIHBhZ2Vcbi8vIHdoZW4gdXBkYXRpbmcgcXVlcnkgaW5mb3JtYXRpb25cbnByb3BzLnBhZ2VQcm9wcy5zdGF0dXNDb2RlPTUwMDt9Ly8gc2hhbGxvdyByb3V0aW5nIGlzIG9ubHkgYWxsb3dlZCBmb3Igc2FtZSBwYWdlIFVSTCBjaGFuZ2VzLlxuY29uc3QgaXNWYWxpZFNoYWxsb3dSb3V0ZT1vcHRpb25zLnNoYWxsb3cmJnRoaXMucm91dGU9PT1yb3V0ZTtjb25zdCBzaG91bGRTY3JvbGw9KF9vcHRpb25zJHNjcm9sbD1vcHRpb25zLnNjcm9sbCkhPW51bGw/X29wdGlvbnMkc2Nyb2xsOiFpc1ZhbGlkU2hhbGxvd1JvdXRlO2NvbnN0IHJlc2V0U2Nyb2xsPXNob3VsZFNjcm9sbD97eDowLHk6MH06bnVsbDthd2FpdCB0aGlzLnNldChyb3V0ZSxwYXRobmFtZSxxdWVyeSxjbGVhbmVkQXMscm91dGVJbmZvLGZvcmNlZFNjcm9sbCE9bnVsbD9mb3JjZWRTY3JvbGw6cmVzZXRTY3JvbGwpLmNhdGNoKGU9PntpZihlLmNhbmNlbGxlZCllcnJvcj1lcnJvcnx8ZTtlbHNlIHRocm93IGU7fSk7aWYoZXJyb3Ipe1JvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VFcnJvcicsZXJyb3IsY2xlYW5lZEFzLHJvdXRlUHJvcHMpO3Rocm93IGVycm9yO31pZihwcm9jZXNzLmVudi5fX05FWFRfSTE4Tl9TVVBQT1JUKXtpZih0aGlzLmxvY2FsZSl7ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50Lmxhbmc9dGhpcy5sb2NhbGU7fX1Sb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlQ29tcGxldGUnLGFzLHJvdXRlUHJvcHMpO3JldHVybiB0cnVlO31jYXRjaChlcnIpe2lmKGVyci5jYW5jZWxsZWQpe3JldHVybiBmYWxzZTt9dGhyb3cgZXJyO319Y2hhbmdlU3RhdGUobWV0aG9kLHVybCxhcyxvcHRpb25zPXt9KXtpZihwcm9jZXNzLmVudi5OT0RFX0VOViE9PSdwcm9kdWN0aW9uJyl7aWYodHlwZW9mIHdpbmRvdy5oaXN0b3J5PT09J3VuZGVmaW5lZCcpe2NvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5IGlzIG5vdCBhdmFpbGFibGUuYCk7cmV0dXJuO31pZih0eXBlb2Ygd2luZG93Lmhpc3RvcnlbbWV0aG9kXT09PSd1bmRlZmluZWQnKXtjb25zb2xlLmVycm9yKGBXYXJuaW5nOiB3aW5kb3cuaGlzdG9yeS4ke21ldGhvZH0gaXMgbm90IGF2YWlsYWJsZWApO3JldHVybjt9fWlmKG1ldGhvZCE9PSdwdXNoU3RhdGUnfHwoMCxfdXRpbHMuZ2V0VVJMKSgpIT09YXMpe3RoaXMuX3NoYWxsb3c9b3B0aW9ucy5zaGFsbG93O3dpbmRvdy5oaXN0b3J5W21ldGhvZF0oe3VybCxhcyxvcHRpb25zLF9fTjp0cnVlLGlkeDp0aGlzLl9pZHg9bWV0aG9kIT09J3B1c2hTdGF0ZSc/dGhpcy5faWR4OnRoaXMuX2lkeCsxfSwvLyBNb3N0IGJyb3dzZXJzIGN1cnJlbnRseSBpZ25vcmVzIHRoaXMgcGFyYW1ldGVyLCBhbHRob3VnaCB0aGV5IG1heSB1c2UgaXQgaW4gdGhlIGZ1dHVyZS5cbi8vIFBhc3NpbmcgdGhlIGVtcHR5IHN0cmluZyBoZXJlIHNob3VsZCBiZSBzYWZlIGFnYWluc3QgZnV0dXJlIGNoYW5nZXMgdG8gdGhlIG1ldGhvZC5cbi8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9IaXN0b3J5L3JlcGxhY2VTdGF0ZVxuJycsYXMpO319YXN5bmMgaGFuZGxlUm91dGVJbmZvRXJyb3IoZXJyLHBhdGhuYW1lLHF1ZXJ5LGFzLHJvdXRlUHJvcHMsbG9hZEVycm9yRmFpbCl7aWYoZXJyLmNhbmNlbGxlZCl7Ly8gYnViYmxlIHVwIGNhbmNlbGxhdGlvbiBlcnJvcnNcbnRocm93IGVycjt9aWYoKDAsX3JvdXRlTG9hZGVyLmlzQXNzZXRFcnJvcikoZXJyKXx8bG9hZEVycm9yRmFpbCl7Um91dGVyLmV2ZW50cy5lbWl0KCdyb3V0ZUNoYW5nZUVycm9yJyxlcnIsYXMscm91dGVQcm9wcyk7Ly8gSWYgd2UgY2FuJ3QgbG9hZCB0aGUgcGFnZSBpdCBjb3VsZCBiZSBvbmUgb2YgZm9sbG93aW5nIHJlYXNvbnNcbi8vICAxLiBQYWdlIGRvZXNuJ3QgZXhpc3RzXG4vLyAgMi4gUGFnZSBkb2VzIGV4aXN0IGluIGEgZGlmZmVyZW50IHpvbmVcbi8vICAzLiBJbnRlcm5hbCBlcnJvciB3aGlsZSBsb2FkaW5nIHRoZSBwYWdlXG4vLyBTbywgZG9pbmcgYSBoYXJkIHJlbG9hZCBpcyB0aGUgcHJvcGVyIHdheSB0byBkZWFsIHdpdGggdGhpcy5cbndpbmRvdy5sb2NhdGlvbi5ocmVmPWFzOy8vIENoYW5naW5nIHRoZSBVUkwgZG9lc24ndCBibG9jayBleGVjdXRpbmcgdGhlIGN1cnJlbnQgY29kZSBwYXRoLlxuLy8gU28gbGV0J3MgdGhyb3cgYSBjYW5jZWxsYXRpb24gZXJyb3Igc3RvcCB0aGUgcm91dGluZyBsb2dpYy5cbnRocm93IGJ1aWxkQ2FuY2VsbGF0aW9uRXJyb3IoKTt9dHJ5e2xldCBDb21wb25lbnQ7bGV0IHN0eWxlU2hlZXRzO2xldCBwcm9wcztpZih0eXBlb2YgQ29tcG9uZW50PT09J3VuZGVmaW5lZCd8fHR5cGVvZiBzdHlsZVNoZWV0cz09PSd1bmRlZmluZWQnKXs7KHtwYWdlOkNvbXBvbmVudCxzdHlsZVNoZWV0c309YXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudCgnL19lcnJvcicpKTt9Y29uc3Qgcm91dGVJbmZvPXtwcm9wcyxDb21wb25lbnQsc3R5bGVTaGVldHMsZXJyLGVycm9yOmVycn07aWYoIXJvdXRlSW5mby5wcm9wcyl7dHJ5e3JvdXRlSW5mby5wcm9wcz1hd2FpdCB0aGlzLmdldEluaXRpYWxQcm9wcyhDb21wb25lbnQse2VycixwYXRobmFtZSxxdWVyeX0pO31jYXRjaChnaXBFcnIpe2NvbnNvbGUuZXJyb3IoJ0Vycm9yIGluIGVycm9yIHBhZ2UgYGdldEluaXRpYWxQcm9wc2A6ICcsZ2lwRXJyKTtyb3V0ZUluZm8ucHJvcHM9e307fX1yZXR1cm4gcm91dGVJbmZvO31jYXRjaChyb3V0ZUluZm9FcnIpe3JldHVybiB0aGlzLmhhbmRsZVJvdXRlSW5mb0Vycm9yKHJvdXRlSW5mb0VycixwYXRobmFtZSxxdWVyeSxhcyxyb3V0ZVByb3BzLHRydWUpO319YXN5bmMgZ2V0Um91dGVJbmZvKHJvdXRlLHBhdGhuYW1lLHF1ZXJ5LGFzLHJlc29sdmVkQXMscm91dGVQcm9wcyl7dHJ5e2NvbnN0IGV4aXN0aW5nUm91dGVJbmZvPXRoaXMuY29tcG9uZW50c1tyb3V0ZV07aWYocm91dGVQcm9wcy5zaGFsbG93JiZleGlzdGluZ1JvdXRlSW5mbyYmdGhpcy5yb3V0ZT09PXJvdXRlKXtyZXR1cm4gZXhpc3RpbmdSb3V0ZUluZm87fWNvbnN0IGNhY2hlZFJvdXRlSW5mbz1leGlzdGluZ1JvdXRlSW5mbyYmJ2luaXRpYWwnaW4gZXhpc3RpbmdSb3V0ZUluZm8/dW5kZWZpbmVkOmV4aXN0aW5nUm91dGVJbmZvO2NvbnN0IHJvdXRlSW5mbz1jYWNoZWRSb3V0ZUluZm8/Y2FjaGVkUm91dGVJbmZvOmF3YWl0IHRoaXMuZmV0Y2hDb21wb25lbnQocm91dGUpLnRoZW4ocmVzPT4oe0NvbXBvbmVudDpyZXMucGFnZSxzdHlsZVNoZWV0czpyZXMuc3R5bGVTaGVldHMsX19OX1NTRzpyZXMubW9kLl9fTl9TU0csX19OX1NTUDpyZXMubW9kLl9fTl9TU1B9KSk7Y29uc3R7Q29tcG9uZW50LF9fTl9TU0csX19OX1NTUH09cm91dGVJbmZvO2lmKHByb2Nlc3MuZW52Lk5PREVfRU5WIT09J3Byb2R1Y3Rpb24nKXtjb25zdHtpc1ZhbGlkRWxlbWVudFR5cGV9PXJlcXVpcmUoJ3JlYWN0LWlzJyk7aWYoIWlzVmFsaWRFbGVtZW50VHlwZShDb21wb25lbnQpKXt0aHJvdyBuZXcgRXJyb3IoYFRoZSBkZWZhdWx0IGV4cG9ydCBpcyBub3QgYSBSZWFjdCBDb21wb25lbnQgaW4gcGFnZTogXCIke3BhdGhuYW1lfVwiYCk7fX1sZXQgZGF0YUhyZWY7aWYoX19OX1NTR3x8X19OX1NTUCl7ZGF0YUhyZWY9dGhpcy5wYWdlTG9hZGVyLmdldERhdGFIcmVmKCgwLF91dGlscy5mb3JtYXRXaXRoVmFsaWRhdGlvbikoe3BhdGhuYW1lLHF1ZXJ5fSkscmVzb2x2ZWRBcyxfX05fU1NHLHRoaXMubG9jYWxlKTt9Y29uc3QgcHJvcHM9YXdhaXQgdGhpcy5fZ2V0RGF0YSgoKT0+X19OX1NTRz90aGlzLl9nZXRTdGF0aWNEYXRhKGRhdGFIcmVmKTpfX05fU1NQP3RoaXMuX2dldFNlcnZlckRhdGEoZGF0YUhyZWYpOnRoaXMuZ2V0SW5pdGlhbFByb3BzKENvbXBvbmVudCwvLyB3ZSBwcm92aWRlIEFwcFRyZWUgbGF0ZXIgc28gdGhpcyBuZWVkcyB0byBiZSBgYW55YFxue3BhdGhuYW1lLHF1ZXJ5LGFzUGF0aDphcyxsb2NhbGU6dGhpcy5sb2NhbGUsbG9jYWxlczp0aGlzLmxvY2FsZXMsZGVmYXVsdExvY2FsZTp0aGlzLmRlZmF1bHRMb2NhbGV9KSk7cm91dGVJbmZvLnByb3BzPXByb3BzO3RoaXMuY29tcG9uZW50c1tyb3V0ZV09cm91dGVJbmZvO3JldHVybiByb3V0ZUluZm87fWNhdGNoKGVycil7cmV0dXJuIHRoaXMuaGFuZGxlUm91dGVJbmZvRXJyb3IoZXJyLHBhdGhuYW1lLHF1ZXJ5LGFzLHJvdXRlUHJvcHMpO319c2V0KHJvdXRlLHBhdGhuYW1lLHF1ZXJ5LGFzLGRhdGEscmVzZXRTY3JvbGwpe3RoaXMuaXNGYWxsYmFjaz1mYWxzZTt0aGlzLnJvdXRlPXJvdXRlO3RoaXMucGF0aG5hbWU9cGF0aG5hbWU7dGhpcy5xdWVyeT1xdWVyeTt0aGlzLmFzUGF0aD1hcztyZXR1cm4gdGhpcy5ub3RpZnkoZGF0YSxyZXNldFNjcm9sbCk7fS8qKlxuICAgKiBDYWxsYmFjayB0byBleGVjdXRlIGJlZm9yZSByZXBsYWNpbmcgcm91dGVyIHN0YXRlXG4gICAqIEBwYXJhbSBjYiBjYWxsYmFjayB0byBiZSBleGVjdXRlZFxuICAgKi9iZWZvcmVQb3BTdGF0ZShjYil7dGhpcy5fYnBzPWNiO31vbmx5QUhhc2hDaGFuZ2UoYXMpe2lmKCF0aGlzLmFzUGF0aClyZXR1cm4gZmFsc2U7Y29uc3Rbb2xkVXJsTm9IYXNoLG9sZEhhc2hdPXRoaXMuYXNQYXRoLnNwbGl0KCcjJyk7Y29uc3RbbmV3VXJsTm9IYXNoLG5ld0hhc2hdPWFzLnNwbGl0KCcjJyk7Ly8gTWFrZXMgc3VyZSB3ZSBzY3JvbGwgdG8gdGhlIHByb3ZpZGVkIGhhc2ggaWYgdGhlIHVybC9oYXNoIGFyZSB0aGUgc2FtZVxuaWYobmV3SGFzaCYmb2xkVXJsTm9IYXNoPT09bmV3VXJsTm9IYXNoJiZvbGRIYXNoPT09bmV3SGFzaCl7cmV0dXJuIHRydWU7fS8vIElmIHRoZSB1cmxzIGFyZSBjaGFuZ2UsIHRoZXJlJ3MgbW9yZSB0aGFuIGEgaGFzaCBjaGFuZ2VcbmlmKG9sZFVybE5vSGFzaCE9PW5ld1VybE5vSGFzaCl7cmV0dXJuIGZhbHNlO30vLyBJZiB0aGUgaGFzaCBoYXMgY2hhbmdlZCwgdGhlbiBpdCdzIGEgaGFzaCBvbmx5IGNoYW5nZS5cbi8vIFRoaXMgY2hlY2sgaXMgbmVjZXNzYXJ5IHRvIGhhbmRsZSBib3RoIHRoZSBlbnRlciBhbmRcbi8vIGxlYXZlIGhhc2ggPT09ICcnIGNhc2VzLiBUaGUgaWRlbnRpdHkgY2FzZSBmYWxscyB0aHJvdWdoXG4vLyBhbmQgaXMgdHJlYXRlZCBhcyBhIG5leHQgcmVsb2FkLlxucmV0dXJuIG9sZEhhc2ghPT1uZXdIYXNoO31zY3JvbGxUb0hhc2goYXMpe2NvbnN0WyxoYXNoXT1hcy5zcGxpdCgnIycpOy8vIFNjcm9sbCB0byB0b3AgaWYgdGhlIGhhc2ggaXMganVzdCBgI2Agd2l0aCBubyB2YWx1ZSBvciBgI3RvcGBcbi8vIFRvIG1pcnJvciBicm93c2Vyc1xuaWYoaGFzaD09PScnfHxoYXNoPT09J3RvcCcpe3dpbmRvdy5zY3JvbGxUbygwLDApO3JldHVybjt9Ly8gRmlyc3Qgd2UgY2hlY2sgaWYgdGhlIGVsZW1lbnQgYnkgaWQgaXMgZm91bmRcbmNvbnN0IGlkRWw9ZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaGFzaCk7aWYoaWRFbCl7aWRFbC5zY3JvbGxJbnRvVmlldygpO3JldHVybjt9Ly8gSWYgdGhlcmUncyBubyBlbGVtZW50IHdpdGggdGhlIGlkLCB3ZSBjaGVjayB0aGUgYG5hbWVgIHByb3BlcnR5XG4vLyBUbyBtaXJyb3IgYnJvd3NlcnNcbmNvbnN0IG5hbWVFbD1kb2N1bWVudC5nZXRFbGVtZW50c0J5TmFtZShoYXNoKVswXTtpZihuYW1lRWwpe25hbWVFbC5zY3JvbGxJbnRvVmlldygpO319dXJsSXNOZXcoYXNQYXRoKXtyZXR1cm4gdGhpcy5hc1BhdGghPT1hc1BhdGg7fS8qKlxuICAgKiBQcmVmZXRjaCBwYWdlIGNvZGUsIHlvdSBtYXkgd2FpdCBmb3IgdGhlIGRhdGEgZHVyaW5nIHBhZ2UgcmVuZGVyaW5nLlxuICAgKiBUaGlzIGZlYXR1cmUgb25seSB3b3JrcyBpbiBwcm9kdWN0aW9uIVxuICAgKiBAcGFyYW0gdXJsIHRoZSBocmVmIG9mIHByZWZldGNoZWQgcGFnZVxuICAgKiBAcGFyYW0gYXNQYXRoIHRoZSBhcyBwYXRoIG9mIHRoZSBwcmVmZXRjaGVkIHBhZ2VcbiAgICovYXN5bmMgcHJlZmV0Y2godXJsLGFzUGF0aD11cmwsb3B0aW9ucz17fSl7bGV0IHBhcnNlZD0oMCxfcGFyc2VSZWxhdGl2ZVVybC5wYXJzZVJlbGF0aXZlVXJsKSh1cmwpO2xldHtwYXRobmFtZX09cGFyc2VkO2lmKHByb2Nlc3MuZW52Ll9fTkVYVF9JMThOX1NVUFBPUlQpe2lmKG9wdGlvbnMubG9jYWxlPT09ZmFsc2Upe3BhdGhuYW1lPSgwLF9ub3JtYWxpemVMb2NhbGVQYXRoLm5vcm1hbGl6ZUxvY2FsZVBhdGgpKHBhdGhuYW1lLHRoaXMubG9jYWxlcykucGF0aG5hbWU7cGFyc2VkLnBhdGhuYW1lPXBhdGhuYW1lO3VybD0oMCxfdXRpbHMuZm9ybWF0V2l0aFZhbGlkYXRpb24pKHBhcnNlZCk7bGV0IHBhcnNlZEFzPSgwLF9wYXJzZVJlbGF0aXZlVXJsLnBhcnNlUmVsYXRpdmVVcmwpKGFzUGF0aCk7Y29uc3QgbG9jYWxlUGF0aFJlc3VsdD0oMCxfbm9ybWFsaXplTG9jYWxlUGF0aC5ub3JtYWxpemVMb2NhbGVQYXRoKShwYXJzZWRBcy5wYXRobmFtZSx0aGlzLmxvY2FsZXMpO3BhcnNlZEFzLnBhdGhuYW1lPWxvY2FsZVBhdGhSZXN1bHQucGF0aG5hbWU7b3B0aW9ucy5sb2NhbGU9bG9jYWxlUGF0aFJlc3VsdC5kZXRlY3RlZExvY2FsZXx8dGhpcy5kZWZhdWx0TG9jYWxlO2FzUGF0aD0oMCxfdXRpbHMuZm9ybWF0V2l0aFZhbGlkYXRpb24pKHBhcnNlZEFzKTt9fWNvbnN0IHBhZ2VzPWF3YWl0IHRoaXMucGFnZUxvYWRlci5nZXRQYWdlTGlzdCgpO2xldCByZXNvbHZlZEFzPWFzUGF0aDtpZihwcm9jZXNzLmVudi5fX05FWFRfSEFTX1JFV1JJVEVTJiZhc1BhdGguc3RhcnRzV2l0aCgnLycpKXtsZXQgcmV3cml0ZXM7KHtfX3Jld3JpdGVzOnJld3JpdGVzfT1hd2FpdCgwLF9yb3V0ZUxvYWRlci5nZXRDbGllbnRCdWlsZE1hbmlmZXN0KSgpKTtjb25zdCByZXdyaXRlc1Jlc3VsdD0oMCxfcmVzb2x2ZVJld3JpdGVzLmRlZmF1bHQpKGFkZEJhc2VQYXRoKGFkZExvY2FsZShhc1BhdGgsdGhpcy5sb2NhbGUpKSxwYWdlcyxyZXdyaXRlcyxwYXJzZWQucXVlcnkscD0+cmVzb2x2ZUR5bmFtaWNSb3V0ZShwLHBhZ2VzKSx0aGlzLmxvY2FsZXMpO3Jlc29sdmVkQXM9ZGVsTG9jYWxlKGRlbEJhc2VQYXRoKHJld3JpdGVzUmVzdWx0LmFzUGF0aCksdGhpcy5sb2NhbGUpO2lmKHJld3JpdGVzUmVzdWx0Lm1hdGNoZWRQYWdlJiZyZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWYpey8vIGlmIHRoaXMgZGlyZWN0bHkgbWF0Y2hlcyBhIHBhZ2Ugd2UgbmVlZCB0byB1cGRhdGUgdGhlIGhyZWYgdG9cbi8vIGFsbG93IHRoZSBjb3JyZWN0IHBhZ2UgY2h1bmsgdG8gYmUgbG9hZGVkXG5wYXRobmFtZT1yZXdyaXRlc1Jlc3VsdC5yZXNvbHZlZEhyZWY7cGFyc2VkLnBhdGhuYW1lPXBhdGhuYW1lO3VybD0oMCxfdXRpbHMuZm9ybWF0V2l0aFZhbGlkYXRpb24pKHBhcnNlZCk7fX1lbHNle3BhcnNlZC5wYXRobmFtZT1yZXNvbHZlRHluYW1pY1JvdXRlKHBhcnNlZC5wYXRobmFtZSxwYWdlcyk7aWYocGFyc2VkLnBhdGhuYW1lIT09cGF0aG5hbWUpe3BhdGhuYW1lPXBhcnNlZC5wYXRobmFtZTtwYXJzZWQucGF0aG5hbWU9cGF0aG5hbWU7dXJsPSgwLF91dGlscy5mb3JtYXRXaXRoVmFsaWRhdGlvbikocGFyc2VkKTt9fWNvbnN0IHJvdXRlPSgwLF9ub3JtYWxpemVUcmFpbGluZ1NsYXNoLnJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKShwYXRobmFtZSk7Ly8gUHJlZmV0Y2ggaXMgbm90IHN1cHBvcnRlZCBpbiBkZXZlbG9wbWVudCBtb2RlIGJlY2F1c2UgaXQgd291bGQgdHJpZ2dlciBvbi1kZW1hbmQtZW50cmllc1xuaWYocHJvY2Vzcy5lbnYuTk9ERV9FTlYhPT0ncHJvZHVjdGlvbicpe3JldHVybjt9YXdhaXQgUHJvbWlzZS5hbGwoW3RoaXMucGFnZUxvYWRlci5faXNTc2cocm91dGUpLnRoZW4oaXNTc2c9PntyZXR1cm4gaXNTc2c/dGhpcy5fZ2V0U3RhdGljRGF0YSh0aGlzLnBhZ2VMb2FkZXIuZ2V0RGF0YUhyZWYodXJsLHJlc29sdmVkQXMsdHJ1ZSx0eXBlb2Ygb3B0aW9ucy5sb2NhbGUhPT0ndW5kZWZpbmVkJz9vcHRpb25zLmxvY2FsZTp0aGlzLmxvY2FsZSkpOmZhbHNlO30pLHRoaXMucGFnZUxvYWRlcltvcHRpb25zLnByaW9yaXR5Pydsb2FkUGFnZSc6J3ByZWZldGNoJ10ocm91dGUpXSk7fWFzeW5jIGZldGNoQ29tcG9uZW50KHJvdXRlKXtsZXQgY2FuY2VsbGVkPWZhbHNlO2NvbnN0IGNhbmNlbD10aGlzLmNsYz0oKT0+e2NhbmNlbGxlZD10cnVlO307Y29uc3QgY29tcG9uZW50UmVzdWx0PWF3YWl0IHRoaXMucGFnZUxvYWRlci5sb2FkUGFnZShyb3V0ZSk7aWYoY2FuY2VsbGVkKXtjb25zdCBlcnJvcj1uZXcgRXJyb3IoYEFib3J0IGZldGNoaW5nIGNvbXBvbmVudCBmb3Igcm91dGU6IFwiJHtyb3V0ZX1cImApO2Vycm9yLmNhbmNlbGxlZD10cnVlO3Rocm93IGVycm9yO31pZihjYW5jZWw9PT10aGlzLmNsYyl7dGhpcy5jbGM9bnVsbDt9cmV0dXJuIGNvbXBvbmVudFJlc3VsdDt9X2dldERhdGEoZm4pe2xldCBjYW5jZWxsZWQ9ZmFsc2U7Y29uc3QgY2FuY2VsPSgpPT57Y2FuY2VsbGVkPXRydWU7fTt0aGlzLmNsYz1jYW5jZWw7cmV0dXJuIGZuKCkudGhlbihkYXRhPT57aWYoY2FuY2VsPT09dGhpcy5jbGMpe3RoaXMuY2xjPW51bGw7fWlmKGNhbmNlbGxlZCl7Y29uc3QgZXJyPW5ldyBFcnJvcignTG9hZGluZyBpbml0aWFsIHByb3BzIGNhbmNlbGxlZCcpO2Vyci5jYW5jZWxsZWQ9dHJ1ZTt0aHJvdyBlcnI7fXJldHVybiBkYXRhO30pO31fZ2V0U3RhdGljRGF0YShkYXRhSHJlZil7Y29uc3R7aHJlZjpjYWNoZUtleX09bmV3IFVSTChkYXRhSHJlZix3aW5kb3cubG9jYXRpb24uaHJlZik7aWYocHJvY2Vzcy5lbnYuTk9ERV9FTlY9PT0ncHJvZHVjdGlvbicmJiF0aGlzLmlzUHJldmlldyYmdGhpcy5zZGNbY2FjaGVLZXldKXtyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMuc2RjW2NhY2hlS2V5XSk7fXJldHVybiBmZXRjaE5leHREYXRhKGRhdGFIcmVmLHRoaXMuaXNTc3IpLnRoZW4oZGF0YT0+e3RoaXMuc2RjW2NhY2hlS2V5XT1kYXRhO3JldHVybiBkYXRhO30pO31fZ2V0U2VydmVyRGF0YShkYXRhSHJlZil7Y29uc3R7aHJlZjpyZXNvdXJjZUtleX09bmV3IFVSTChkYXRhSHJlZix3aW5kb3cubG9jYXRpb24uaHJlZik7aWYodGhpcy5zZHJbcmVzb3VyY2VLZXldKXtyZXR1cm4gdGhpcy5zZHJbcmVzb3VyY2VLZXldO31yZXR1cm4gdGhpcy5zZHJbcmVzb3VyY2VLZXldPWZldGNoTmV4dERhdGEoZGF0YUhyZWYsdGhpcy5pc1NzcikudGhlbihkYXRhPT57ZGVsZXRlIHRoaXMuc2RyW3Jlc291cmNlS2V5XTtyZXR1cm4gZGF0YTt9KS5jYXRjaChlcnI9PntkZWxldGUgdGhpcy5zZHJbcmVzb3VyY2VLZXldO3Rocm93IGVycjt9KTt9Z2V0SW5pdGlhbFByb3BzKENvbXBvbmVudCxjdHgpe2NvbnN0e0NvbXBvbmVudDpBcHB9PXRoaXMuY29tcG9uZW50c1snL19hcHAnXTtjb25zdCBBcHBUcmVlPXRoaXMuX3dyYXBBcHAoQXBwKTtjdHguQXBwVHJlZT1BcHBUcmVlO3JldHVybigwLF91dGlscy5sb2FkR2V0SW5pdGlhbFByb3BzKShBcHAse0FwcFRyZWUsQ29tcG9uZW50LHJvdXRlcjp0aGlzLGN0eH0pO31hYm9ydENvbXBvbmVudExvYWQoYXMscm91dGVQcm9wcyl7aWYodGhpcy5jbGMpe1JvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VFcnJvcicsYnVpbGRDYW5jZWxsYXRpb25FcnJvcigpLGFzLHJvdXRlUHJvcHMpO3RoaXMuY2xjKCk7dGhpcy5jbGM9bnVsbDt9fW5vdGlmeShkYXRhLHJlc2V0U2Nyb2xsKXtyZXR1cm4gdGhpcy5zdWIoZGF0YSx0aGlzLmNvbXBvbmVudHNbJy9fYXBwJ10uQ29tcG9uZW50LHJlc2V0U2Nyb2xsKTt9fWV4cG9ydHMuZGVmYXVsdD1Sb3V0ZXI7Um91dGVyLmV2ZW50cz0oMCxfbWl0dC5kZWZhdWx0KSgpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMuZm9ybWF0VXJsPWZvcm1hdFVybDt2YXIgcXVlcnlzdHJpbmc9X2ludGVyb3BSZXF1aXJlV2lsZGNhcmQocmVxdWlyZShcIi4vcXVlcnlzdHJpbmdcIikpO2Z1bmN0aW9uIF9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSgpe2lmKHR5cGVvZiBXZWFrTWFwIT09XCJmdW5jdGlvblwiKXJldHVybiBudWxsO3ZhciBjYWNoZT1uZXcgV2Vha01hcCgpO19nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZT1mdW5jdGlvbigpe3JldHVybiBjYWNoZTt9O3JldHVybiBjYWNoZTt9ZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQob2JqKXtpZihvYmomJm9iai5fX2VzTW9kdWxlKXtyZXR1cm4gb2JqO31pZihvYmo9PT1udWxsfHx0eXBlb2Ygb2JqIT09XCJvYmplY3RcIiYmdHlwZW9mIG9iaiE9PVwiZnVuY3Rpb25cIil7cmV0dXJue2RlZmF1bHQ6b2JqfTt9dmFyIGNhY2hlPV9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSgpO2lmKGNhY2hlJiZjYWNoZS5oYXMob2JqKSl7cmV0dXJuIGNhY2hlLmdldChvYmopO312YXIgbmV3T2JqPXt9O3ZhciBoYXNQcm9wZXJ0eURlc2NyaXB0b3I9T2JqZWN0LmRlZmluZVByb3BlcnR5JiZPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO2Zvcih2YXIga2V5IGluIG9iail7aWYoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaixrZXkpKXt2YXIgZGVzYz1oYXNQcm9wZXJ0eURlc2NyaXB0b3I/T2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmosa2V5KTpudWxsO2lmKGRlc2MmJihkZXNjLmdldHx8ZGVzYy5zZXQpKXtPYmplY3QuZGVmaW5lUHJvcGVydHkobmV3T2JqLGtleSxkZXNjKTt9ZWxzZXtuZXdPYmpba2V5XT1vYmpba2V5XTt9fX1uZXdPYmouZGVmYXVsdD1vYmo7aWYoY2FjaGUpe2NhY2hlLnNldChvYmosbmV3T2JqKTt9cmV0dXJuIG5ld09iajt9Ly8gRm9ybWF0IGZ1bmN0aW9uIG1vZGlmaWVkIGZyb20gbm9kZWpzXG4vLyBDb3B5cmlnaHQgSm95ZW50LCBJbmMuIGFuZCBvdGhlciBOb2RlIGNvbnRyaWJ1dG9ycy5cbi8vXG4vLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYVxuLy8gY29weSBvZiB0aGlzIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZVxuLy8gXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmUgd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nXG4vLyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsXG4vLyBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0XG4vLyBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzbywgc3ViamVjdCB0byB0aGVcbi8vIGZvbGxvd2luZyBjb25kaXRpb25zOlxuLy9cbi8vIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkXG4vLyBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cbi8vXG4vLyBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTXG4vLyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4vLyBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOXG4vLyBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSxcbi8vIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUlxuLy8gT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFNPRlRXQVJFIE9SIFRIRVxuLy8gVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbmNvbnN0IHNsYXNoZWRQcm90b2NvbHM9L2h0dHBzP3xmdHB8Z29waGVyfGZpbGUvO2Z1bmN0aW9uIGZvcm1hdFVybCh1cmxPYmope2xldHthdXRoLGhvc3RuYW1lfT11cmxPYmo7bGV0IHByb3RvY29sPXVybE9iai5wcm90b2NvbHx8Jyc7bGV0IHBhdGhuYW1lPXVybE9iai5wYXRobmFtZXx8Jyc7bGV0IGhhc2g9dXJsT2JqLmhhc2h8fCcnO2xldCBxdWVyeT11cmxPYmoucXVlcnl8fCcnO2xldCBob3N0PWZhbHNlO2F1dGg9YXV0aD9lbmNvZGVVUklDb21wb25lbnQoYXV0aCkucmVwbGFjZSgvJTNBL2ksJzonKSsnQCc6Jyc7aWYodXJsT2JqLmhvc3Qpe2hvc3Q9YXV0aCt1cmxPYmouaG9zdDt9ZWxzZSBpZihob3N0bmFtZSl7aG9zdD1hdXRoKyh+aG9zdG5hbWUuaW5kZXhPZignOicpP2BbJHtob3N0bmFtZX1dYDpob3N0bmFtZSk7aWYodXJsT2JqLnBvcnQpe2hvc3QrPSc6Jyt1cmxPYmoucG9ydDt9fWlmKHF1ZXJ5JiZ0eXBlb2YgcXVlcnk9PT0nb2JqZWN0Jyl7cXVlcnk9U3RyaW5nKHF1ZXJ5c3RyaW5nLnVybFF1ZXJ5VG9TZWFyY2hQYXJhbXMocXVlcnkpKTt9bGV0IHNlYXJjaD11cmxPYmouc2VhcmNofHxxdWVyeSYmYD8ke3F1ZXJ5fWB8fCcnO2lmKHByb3RvY29sJiZwcm90b2NvbC5zdWJzdHIoLTEpIT09JzonKXByb3RvY29sKz0nOic7aWYodXJsT2JqLnNsYXNoZXN8fCghcHJvdG9jb2x8fHNsYXNoZWRQcm90b2NvbHMudGVzdChwcm90b2NvbCkpJiZob3N0IT09ZmFsc2Upe2hvc3Q9Jy8vJysoaG9zdHx8JycpO2lmKHBhdGhuYW1lJiZwYXRobmFtZVswXSE9PScvJylwYXRobmFtZT0nLycrcGF0aG5hbWU7fWVsc2UgaWYoIWhvc3Qpe2hvc3Q9Jyc7fWlmKGhhc2gmJmhhc2hbMF0hPT0nIycpaGFzaD0nIycraGFzaDtpZihzZWFyY2gmJnNlYXJjaFswXSE9PSc/JylzZWFyY2g9Jz8nK3NlYXJjaDtwYXRobmFtZT1wYXRobmFtZS5yZXBsYWNlKC9bPyNdL2csZW5jb2RlVVJJQ29tcG9uZW50KTtzZWFyY2g9c2VhcmNoLnJlcGxhY2UoJyMnLCclMjMnKTtyZXR1cm5gJHtwcm90b2NvbH0ke2hvc3R9JHtwYXRobmFtZX0ke3NlYXJjaH0ke2hhc2h9YDt9XG4vLyMgc291cmNlTWFwcGluZ1VSTD1mb3JtYXQtdXJsLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMuaXNEeW5hbWljUm91dGU9aXNEeW5hbWljUm91dGU7Ly8gSWRlbnRpZnkgL1twYXJhbV0vIGluIHJvdXRlIHN0cmluZ1xuY29uc3QgVEVTVF9ST1VURT0vXFwvXFxbW14vXSs/XFxdKD89XFwvfCQpLztmdW5jdGlvbiBpc0R5bmFtaWNSb3V0ZShyb3V0ZSl7cmV0dXJuIFRFU1RfUk9VVEUudGVzdChyb3V0ZSk7fVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aXMtZHluYW1pYy5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLnBhcnNlUmVsYXRpdmVVcmw9cGFyc2VSZWxhdGl2ZVVybDt2YXIgX3V0aWxzPXJlcXVpcmUoXCIuLi8uLi91dGlsc1wiKTt2YXIgX3F1ZXJ5c3RyaW5nPXJlcXVpcmUoXCIuL3F1ZXJ5c3RyaW5nXCIpOy8qKlxuICogUGFyc2VzIHBhdGgtcmVsYXRpdmUgdXJscyAoZS5nLiBgL2hlbGxvL3dvcmxkP2Zvbz1iYXJgKS4gSWYgdXJsIGlzbid0IHBhdGgtcmVsYXRpdmVcbiAqIChlLmcuIGAuL2hlbGxvYCkgdGhlbiBhdCBsZWFzdCBiYXNlIG11c3QgYmUuXG4gKiBBYnNvbHV0ZSB1cmxzIGFyZSByZWplY3RlZCB3aXRoIG9uZSBleGNlcHRpb24sIGluIHRoZSBicm93c2VyLCBhYnNvbHV0ZSB1cmxzIHRoYXQgYXJlIG9uXG4gKiB0aGUgY3VycmVudCBvcmlnaW4gd2lsbCBiZSBwYXJzZWQgYXMgcmVsYXRpdmVcbiAqL2Z1bmN0aW9uIHBhcnNlUmVsYXRpdmVVcmwodXJsLGJhc2Upe2NvbnN0IGdsb2JhbEJhc2U9bmV3IFVSTCh0eXBlb2Ygd2luZG93PT09J3VuZGVmaW5lZCc/J2h0dHA6Ly9uJzooMCxfdXRpbHMuZ2V0TG9jYXRpb25PcmlnaW4pKCkpO2NvbnN0IHJlc29sdmVkQmFzZT1iYXNlP25ldyBVUkwoYmFzZSxnbG9iYWxCYXNlKTpnbG9iYWxCYXNlO2NvbnN0e3BhdGhuYW1lLHNlYXJjaFBhcmFtcyxzZWFyY2gsaGFzaCxocmVmLG9yaWdpbn09bmV3IFVSTCh1cmwscmVzb2x2ZWRCYXNlKTtpZihvcmlnaW4hPT1nbG9iYWxCYXNlLm9yaWdpbil7dGhyb3cgbmV3IEVycm9yKGBpbnZhcmlhbnQ6IGludmFsaWQgcmVsYXRpdmUgVVJMLCByb3V0ZXIgcmVjZWl2ZWQgJHt1cmx9YCk7fXJldHVybntwYXRobmFtZSxxdWVyeTooMCxfcXVlcnlzdHJpbmcuc2VhcmNoUGFyYW1zVG9VcmxRdWVyeSkoc2VhcmNoUGFyYW1zKSxzZWFyY2gsaGFzaCxocmVmOmhyZWYuc2xpY2UoZ2xvYmFsQmFzZS5vcmlnaW4ubGVuZ3RoKX07fVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFyc2UtcmVsYXRpdmUtdXJsLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMuc2VhcmNoUGFyYW1zVG9VcmxRdWVyeT1zZWFyY2hQYXJhbXNUb1VybFF1ZXJ5O2V4cG9ydHMudXJsUXVlcnlUb1NlYXJjaFBhcmFtcz11cmxRdWVyeVRvU2VhcmNoUGFyYW1zO2V4cG9ydHMuYXNzaWduPWFzc2lnbjtmdW5jdGlvbiBzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5KHNlYXJjaFBhcmFtcyl7Y29uc3QgcXVlcnk9e307c2VhcmNoUGFyYW1zLmZvckVhY2goKHZhbHVlLGtleSk9PntpZih0eXBlb2YgcXVlcnlba2V5XT09PSd1bmRlZmluZWQnKXtxdWVyeVtrZXldPXZhbHVlO31lbHNlIGlmKEFycmF5LmlzQXJyYXkocXVlcnlba2V5XSkpeztxdWVyeVtrZXldLnB1c2godmFsdWUpO31lbHNle3F1ZXJ5W2tleV09W3F1ZXJ5W2tleV0sdmFsdWVdO319KTtyZXR1cm4gcXVlcnk7fWZ1bmN0aW9uIHN0cmluZ2lmeVVybFF1ZXJ5UGFyYW0ocGFyYW0pe2lmKHR5cGVvZiBwYXJhbT09PSdzdHJpbmcnfHx0eXBlb2YgcGFyYW09PT0nbnVtYmVyJyYmIWlzTmFOKHBhcmFtKXx8dHlwZW9mIHBhcmFtPT09J2Jvb2xlYW4nKXtyZXR1cm4gU3RyaW5nKHBhcmFtKTt9ZWxzZXtyZXR1cm4nJzt9fWZ1bmN0aW9uIHVybFF1ZXJ5VG9TZWFyY2hQYXJhbXModXJsUXVlcnkpe2NvbnN0IHJlc3VsdD1uZXcgVVJMU2VhcmNoUGFyYW1zKCk7T2JqZWN0LmVudHJpZXModXJsUXVlcnkpLmZvckVhY2goKFtrZXksdmFsdWVdKT0+e2lmKEFycmF5LmlzQXJyYXkodmFsdWUpKXt2YWx1ZS5mb3JFYWNoKGl0ZW09PnJlc3VsdC5hcHBlbmQoa2V5LHN0cmluZ2lmeVVybFF1ZXJ5UGFyYW0oaXRlbSkpKTt9ZWxzZXtyZXN1bHQuc2V0KGtleSxzdHJpbmdpZnlVcmxRdWVyeVBhcmFtKHZhbHVlKSk7fX0pO3JldHVybiByZXN1bHQ7fWZ1bmN0aW9uIGFzc2lnbih0YXJnZXQsLi4uc2VhcmNoUGFyYW1zTGlzdCl7c2VhcmNoUGFyYW1zTGlzdC5mb3JFYWNoKHNlYXJjaFBhcmFtcz0+e0FycmF5LmZyb20oc2VhcmNoUGFyYW1zLmtleXMoKSkuZm9yRWFjaChrZXk9PnRhcmdldC5kZWxldGUoa2V5KSk7c2VhcmNoUGFyYW1zLmZvckVhY2goKHZhbHVlLGtleSk9PnRhcmdldC5hcHBlbmQoa2V5LHZhbHVlKSk7fSk7cmV0dXJuIHRhcmdldDt9XG4vLyMgc291cmNlTWFwcGluZ1VSTD1xdWVyeXN0cmluZy5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLmdldFJvdXRlTWF0Y2hlcj1nZXRSb3V0ZU1hdGNoZXI7ZnVuY3Rpb24gZ2V0Um91dGVNYXRjaGVyKHJvdXRlUmVnZXgpe2NvbnN0e3JlLGdyb3Vwc309cm91dGVSZWdleDtyZXR1cm4gcGF0aG5hbWU9Pntjb25zdCByb3V0ZU1hdGNoPXJlLmV4ZWMocGF0aG5hbWUpO2lmKCFyb3V0ZU1hdGNoKXtyZXR1cm4gZmFsc2U7fWNvbnN0IGRlY29kZT1wYXJhbT0+e3RyeXtyZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KHBhcmFtKTt9Y2F0Y2goXyl7Y29uc3QgZXJyPW5ldyBFcnJvcignZmFpbGVkIHRvIGRlY29kZSBwYXJhbScpO2Vyci5jb2RlPSdERUNPREVfRkFJTEVEJzt0aHJvdyBlcnI7fX07Y29uc3QgcGFyYW1zPXt9O09iamVjdC5rZXlzKGdyb3VwcykuZm9yRWFjaChzbHVnTmFtZT0+e2NvbnN0IGc9Z3JvdXBzW3NsdWdOYW1lXTtjb25zdCBtPXJvdXRlTWF0Y2hbZy5wb3NdO2lmKG0hPT11bmRlZmluZWQpe3BhcmFtc1tzbHVnTmFtZV09fm0uaW5kZXhPZignLycpP20uc3BsaXQoJy8nKS5tYXAoZW50cnk9PmRlY29kZShlbnRyeSkpOmcucmVwZWF0P1tkZWNvZGUobSldOmRlY29kZShtKTt9fSk7cmV0dXJuIHBhcmFtczt9O31cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlLW1hdGNoZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5nZXRSb3V0ZVJlZ2V4PWdldFJvdXRlUmVnZXg7Ly8gdGhpcyBpc24ndCBpbXBvcnRpbmcgdGhlIGVzY2FwZS1zdHJpbmctcmVnZXggbW9kdWxlXG4vLyB0byByZWR1Y2UgYnl0ZXNcbmZ1bmN0aW9uIGVzY2FwZVJlZ2V4KHN0cil7cmV0dXJuIHN0ci5yZXBsYWNlKC9bfFxcXFx7fSgpW1xcXV4kKyo/Li1dL2csJ1xcXFwkJicpO31mdW5jdGlvbiBwYXJzZVBhcmFtZXRlcihwYXJhbSl7Y29uc3Qgb3B0aW9uYWw9cGFyYW0uc3RhcnRzV2l0aCgnWycpJiZwYXJhbS5lbmRzV2l0aCgnXScpO2lmKG9wdGlvbmFsKXtwYXJhbT1wYXJhbS5zbGljZSgxLC0xKTt9Y29uc3QgcmVwZWF0PXBhcmFtLnN0YXJ0c1dpdGgoJy4uLicpO2lmKHJlcGVhdCl7cGFyYW09cGFyYW0uc2xpY2UoMyk7fXJldHVybntrZXk6cGFyYW0scmVwZWF0LG9wdGlvbmFsfTt9ZnVuY3Rpb24gZ2V0Um91dGVSZWdleChub3JtYWxpemVkUm91dGUpe2NvbnN0IHNlZ21lbnRzPShub3JtYWxpemVkUm91dGUucmVwbGFjZSgvXFwvJC8sJycpfHwnLycpLnNsaWNlKDEpLnNwbGl0KCcvJyk7Y29uc3QgZ3JvdXBzPXt9O2xldCBncm91cEluZGV4PTE7Y29uc3QgcGFyYW1ldGVyaXplZFJvdXRlPXNlZ21lbnRzLm1hcChzZWdtZW50PT57aWYoc2VnbWVudC5zdGFydHNXaXRoKCdbJykmJnNlZ21lbnQuZW5kc1dpdGgoJ10nKSl7Y29uc3R7a2V5LG9wdGlvbmFsLHJlcGVhdH09cGFyc2VQYXJhbWV0ZXIoc2VnbWVudC5zbGljZSgxLC0xKSk7Z3JvdXBzW2tleV09e3Bvczpncm91cEluZGV4KysscmVwZWF0LG9wdGlvbmFsfTtyZXR1cm4gcmVwZWF0P29wdGlvbmFsPycoPzovKC4rPykpPyc6Jy8oLis/KSc6Jy8oW14vXSs/KSc7fWVsc2V7cmV0dXJuYC8ke2VzY2FwZVJlZ2V4KHNlZ21lbnQpfWA7fX0pLmpvaW4oJycpOy8vIGRlYWQgY29kZSBlbGltaW5hdGUgZm9yIGJyb3dzZXIgc2luY2UgaXQncyBvbmx5IG5lZWRlZFxuLy8gd2hpbGUgZ2VuZXJhdGluZyByb3V0ZXMtbWFuaWZlc3RcbmlmKHR5cGVvZiB3aW5kb3c9PT0ndW5kZWZpbmVkJyl7bGV0IHJvdXRlS2V5Q2hhckNvZGU9OTc7bGV0IHJvdXRlS2V5Q2hhckxlbmd0aD0xOy8vIGJ1aWxkcyBhIG1pbmltYWwgcm91dGVLZXkgdXNpbmcgb25seSBhLXogYW5kIG1pbmltYWwgbnVtYmVyIG9mIGNoYXJhY3RlcnNcbmNvbnN0IGdldFNhZmVSb3V0ZUtleT0oKT0+e2xldCByb3V0ZUtleT0nJztmb3IobGV0IGk9MDtpPHJvdXRlS2V5Q2hhckxlbmd0aDtpKyspe3JvdXRlS2V5Kz1TdHJpbmcuZnJvbUNoYXJDb2RlKHJvdXRlS2V5Q2hhckNvZGUpO3JvdXRlS2V5Q2hhckNvZGUrKztpZihyb3V0ZUtleUNoYXJDb2RlPjEyMil7cm91dGVLZXlDaGFyTGVuZ3RoKys7cm91dGVLZXlDaGFyQ29kZT05Nzt9fXJldHVybiByb3V0ZUtleTt9O2NvbnN0IHJvdXRlS2V5cz17fTtsZXQgbmFtZWRQYXJhbWV0ZXJpemVkUm91dGU9c2VnbWVudHMubWFwKHNlZ21lbnQ9PntpZihzZWdtZW50LnN0YXJ0c1dpdGgoJ1snKSYmc2VnbWVudC5lbmRzV2l0aCgnXScpKXtjb25zdHtrZXksb3B0aW9uYWwscmVwZWF0fT1wYXJzZVBhcmFtZXRlcihzZWdtZW50LnNsaWNlKDEsLTEpKTsvLyByZXBsYWNlIGFueSBub24td29yZCBjaGFyYWN0ZXJzIHNpbmNlIHRoZXkgY2FuIGJyZWFrXG4vLyB0aGUgbmFtZWQgcmVnZXhcbmxldCBjbGVhbmVkS2V5PWtleS5yZXBsYWNlKC9cXFcvZywnJyk7bGV0IGludmFsaWRLZXk9ZmFsc2U7Ly8gY2hlY2sgaWYgdGhlIGtleSBpcyBzdGlsbCBpbnZhbGlkIGFuZCBmYWxsYmFjayB0byB1c2luZyBhIGtub3duXG4vLyBzYWZlIGtleVxuaWYoY2xlYW5lZEtleS5sZW5ndGg9PT0wfHxjbGVhbmVkS2V5Lmxlbmd0aD4zMCl7aW52YWxpZEtleT10cnVlO31pZighaXNOYU4ocGFyc2VJbnQoY2xlYW5lZEtleS5zdWJzdHIoMCwxKSkpKXtpbnZhbGlkS2V5PXRydWU7fWlmKGludmFsaWRLZXkpe2NsZWFuZWRLZXk9Z2V0U2FmZVJvdXRlS2V5KCk7fXJvdXRlS2V5c1tjbGVhbmVkS2V5XT1rZXk7cmV0dXJuIHJlcGVhdD9vcHRpb25hbD9gKD86Lyg/PCR7Y2xlYW5lZEtleX0+Lis/KSk/YDpgLyg/PCR7Y2xlYW5lZEtleX0+Lis/KWA6YC8oPzwke2NsZWFuZWRLZXl9PlteL10rPylgO31lbHNle3JldHVybmAvJHtlc2NhcGVSZWdleChzZWdtZW50KX1gO319KS5qb2luKCcnKTtyZXR1cm57cmU6bmV3IFJlZ0V4cChgXiR7cGFyYW1ldGVyaXplZFJvdXRlfSg/Oi8pPyRgKSxncm91cHMscm91dGVLZXlzLG5hbWVkUmVnZXg6YF4ke25hbWVkUGFyYW1ldGVyaXplZFJvdXRlfSg/Oi8pPyRgfTt9cmV0dXJue3JlOm5ldyBSZWdFeHAoYF4ke3BhcmFtZXRlcml6ZWRSb3V0ZX0oPzovKT8kYCksZ3JvdXBzfTt9XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZS1yZWdleC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLmV4ZWNPbmNlPWV4ZWNPbmNlO2V4cG9ydHMuZ2V0TG9jYXRpb25PcmlnaW49Z2V0TG9jYXRpb25PcmlnaW47ZXhwb3J0cy5nZXRVUkw9Z2V0VVJMO2V4cG9ydHMuZ2V0RGlzcGxheU5hbWU9Z2V0RGlzcGxheU5hbWU7ZXhwb3J0cy5pc1Jlc1NlbnQ9aXNSZXNTZW50O2V4cG9ydHMubG9hZEdldEluaXRpYWxQcm9wcz1sb2FkR2V0SW5pdGlhbFByb3BzO2V4cG9ydHMuZm9ybWF0V2l0aFZhbGlkYXRpb249Zm9ybWF0V2l0aFZhbGlkYXRpb247ZXhwb3J0cy5TVD1leHBvcnRzLlNQPWV4cG9ydHMudXJsT2JqZWN0S2V5cz12b2lkIDA7dmFyIF9mb3JtYXRVcmw9cmVxdWlyZShcIi4vcm91dGVyL3V0aWxzL2Zvcm1hdC11cmxcIik7LyoqXG4gKiBVdGlsc1xuICovZnVuY3Rpb24gZXhlY09uY2UoZm4pe2xldCB1c2VkPWZhbHNlO2xldCByZXN1bHQ7cmV0dXJuKC4uLmFyZ3MpPT57aWYoIXVzZWQpe3VzZWQ9dHJ1ZTtyZXN1bHQ9Zm4oLi4uYXJncyk7fXJldHVybiByZXN1bHQ7fTt9ZnVuY3Rpb24gZ2V0TG9jYXRpb25PcmlnaW4oKXtjb25zdHtwcm90b2NvbCxob3N0bmFtZSxwb3J0fT13aW5kb3cubG9jYXRpb247cmV0dXJuYCR7cHJvdG9jb2x9Ly8ke2hvc3RuYW1lfSR7cG9ydD8nOicrcG9ydDonJ31gO31mdW5jdGlvbiBnZXRVUkwoKXtjb25zdHtocmVmfT13aW5kb3cubG9jYXRpb247Y29uc3Qgb3JpZ2luPWdldExvY2F0aW9uT3JpZ2luKCk7cmV0dXJuIGhyZWYuc3Vic3RyaW5nKG9yaWdpbi5sZW5ndGgpO31mdW5jdGlvbiBnZXREaXNwbGF5TmFtZShDb21wb25lbnQpe3JldHVybiB0eXBlb2YgQ29tcG9uZW50PT09J3N0cmluZyc/Q29tcG9uZW50OkNvbXBvbmVudC5kaXNwbGF5TmFtZXx8Q29tcG9uZW50Lm5hbWV8fCdVbmtub3duJzt9ZnVuY3Rpb24gaXNSZXNTZW50KHJlcyl7cmV0dXJuIHJlcy5maW5pc2hlZHx8cmVzLmhlYWRlcnNTZW50O31hc3luYyBmdW5jdGlvbiBsb2FkR2V0SW5pdGlhbFByb3BzKEFwcCxjdHgpe2lmKHByb2Nlc3MuZW52Lk5PREVfRU5WIT09J3Byb2R1Y3Rpb24nKXt2YXIgX0FwcCRwcm90b3R5cGU7aWYoKF9BcHAkcHJvdG90eXBlPUFwcC5wcm90b3R5cGUpIT1udWxsJiZfQXBwJHByb3RvdHlwZS5nZXRJbml0aWFsUHJvcHMpe2NvbnN0IG1lc3NhZ2U9YFwiJHtnZXREaXNwbGF5TmFtZShBcHApfS5nZXRJbml0aWFsUHJvcHMoKVwiIGlzIGRlZmluZWQgYXMgYW4gaW5zdGFuY2UgbWV0aG9kIC0gdmlzaXQgaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvZ2V0LWluaXRpYWwtcHJvcHMtYXMtYW4taW5zdGFuY2UtbWV0aG9kIGZvciBtb3JlIGluZm9ybWF0aW9uLmA7dGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO319Ly8gd2hlbiBjYWxsZWQgZnJvbSBfYXBwIGBjdHhgIGlzIG5lc3RlZCBpbiBgY3R4YFxuY29uc3QgcmVzPWN0eC5yZXN8fGN0eC5jdHgmJmN0eC5jdHgucmVzO2lmKCFBcHAuZ2V0SW5pdGlhbFByb3BzKXtpZihjdHguY3R4JiZjdHguQ29tcG9uZW50KXsvLyBAdHMtaWdub3JlIHBhZ2VQcm9wcyBkZWZhdWx0XG5yZXR1cm57cGFnZVByb3BzOmF3YWl0IGxvYWRHZXRJbml0aWFsUHJvcHMoY3R4LkNvbXBvbmVudCxjdHguY3R4KX07fXJldHVybnt9O31jb25zdCBwcm9wcz1hd2FpdCBBcHAuZ2V0SW5pdGlhbFByb3BzKGN0eCk7aWYocmVzJiZpc1Jlc1NlbnQocmVzKSl7cmV0dXJuIHByb3BzO31pZighcHJvcHMpe2NvbnN0IG1lc3NhZ2U9YFwiJHtnZXREaXNwbGF5TmFtZShBcHApfS5nZXRJbml0aWFsUHJvcHMoKVwiIHNob3VsZCByZXNvbHZlIHRvIGFuIG9iamVjdC4gQnV0IGZvdW5kIFwiJHtwcm9wc31cIiBpbnN0ZWFkLmA7dGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO31pZihwcm9jZXNzLmVudi5OT0RFX0VOViE9PSdwcm9kdWN0aW9uJyl7aWYoT2JqZWN0LmtleXMocHJvcHMpLmxlbmd0aD09PTAmJiFjdHguY3R4KXtjb25zb2xlLndhcm4oYCR7Z2V0RGlzcGxheU5hbWUoQXBwKX0gcmV0dXJuZWQgYW4gZW1wdHkgb2JqZWN0IGZyb20gXFxgZ2V0SW5pdGlhbFByb3BzXFxgLiBUaGlzIGRlLW9wdGltaXplcyBhbmQgcHJldmVudHMgYXV0b21hdGljIHN0YXRpYyBvcHRpbWl6YXRpb24uIGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL2VtcHR5LW9iamVjdC1nZXRJbml0aWFsUHJvcHNgKTt9fXJldHVybiBwcm9wczt9Y29uc3QgdXJsT2JqZWN0S2V5cz1bJ2F1dGgnLCdoYXNoJywnaG9zdCcsJ2hvc3RuYW1lJywnaHJlZicsJ3BhdGgnLCdwYXRobmFtZScsJ3BvcnQnLCdwcm90b2NvbCcsJ3F1ZXJ5Jywnc2VhcmNoJywnc2xhc2hlcyddO2V4cG9ydHMudXJsT2JqZWN0S2V5cz11cmxPYmplY3RLZXlzO2Z1bmN0aW9uIGZvcm1hdFdpdGhWYWxpZGF0aW9uKHVybCl7aWYocHJvY2Vzcy5lbnYuTk9ERV9FTlY9PT0nZGV2ZWxvcG1lbnQnKXtpZih1cmwhPT1udWxsJiZ0eXBlb2YgdXJsPT09J29iamVjdCcpe09iamVjdC5rZXlzKHVybCkuZm9yRWFjaChrZXk9PntpZih1cmxPYmplY3RLZXlzLmluZGV4T2Yoa2V5KT09PS0xKXtjb25zb2xlLndhcm4oYFVua25vd24ga2V5IHBhc3NlZCB2aWEgdXJsT2JqZWN0IGludG8gdXJsLmZvcm1hdDogJHtrZXl9YCk7fX0pO319cmV0dXJuKDAsX2Zvcm1hdFVybC5mb3JtYXRVcmwpKHVybCk7fWNvbnN0IFNQPXR5cGVvZiBwZXJmb3JtYW5jZSE9PSd1bmRlZmluZWQnO2V4cG9ydHMuU1A9U1A7Y29uc3QgU1Q9U1AmJnR5cGVvZiBwZXJmb3JtYW5jZS5tYXJrPT09J2Z1bmN0aW9uJyYmdHlwZW9mIHBlcmZvcm1hbmNlLm1lYXN1cmU9PT0nZnVuY3Rpb24nO2V4cG9ydHMuU1Q9U1Q7XG4vLyMgc291cmNlTWFwcGluZ1VSTD11dGlscy5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtleHBvcnRzLl9fZXNNb2R1bGU9dHJ1ZTtleHBvcnRzLm5vcm1hbGl6ZVBhdGhTZXA9bm9ybWFsaXplUGF0aFNlcDtleHBvcnRzLmRlbm9ybWFsaXplUGFnZVBhdGg9ZGVub3JtYWxpemVQYWdlUGF0aDtmdW5jdGlvbiBub3JtYWxpemVQYXRoU2VwKHBhdGgpe3JldHVybiBwYXRoLnJlcGxhY2UoL1xcXFwvZywnLycpO31mdW5jdGlvbiBkZW5vcm1hbGl6ZVBhZ2VQYXRoKHBhZ2Upe3BhZ2U9bm9ybWFsaXplUGF0aFNlcChwYWdlKTtpZihwYWdlLnN0YXJ0c1dpdGgoJy9pbmRleC8nKSl7cGFnZT1wYWdlLnNsaWNlKDYpO31lbHNlIGlmKHBhZ2U9PT0nL2luZGV4Jyl7cGFnZT0nLyc7fXJldHVybiBwYWdlO31cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRlbm9ybWFsaXplLXBhZ2UtcGF0aC5qcy5tYXAiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZGlzdC9jbGllbnQvaW1hZ2UnKVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Rpc3QvY2xpZW50L2xpbmsnKVxuIiwiZnVuY3Rpb24gX2V4dGVuZHMoKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uICh0YXJnZXQpIHtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXTtcblxuICAgICAgZm9yICh2YXIga2V5IGluIHNvdXJjZSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkge1xuICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9O1xuXG4gIHJldHVybiBfZXh0ZW5kcy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9leHRlbmRzOyIsImZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgXCJkZWZhdWx0XCI6IG9ialxuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQ7IiwidmFyIF90eXBlb2YgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy90eXBlb2ZcIik7XG5cbmZ1bmN0aW9uIF9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSgpIHtcbiAgaWYgKHR5cGVvZiBXZWFrTWFwICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBudWxsO1xuICB2YXIgY2FjaGUgPSBuZXcgV2Vha01hcCgpO1xuXG4gIF9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSA9IGZ1bmN0aW9uIF9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSgpIHtcbiAgICByZXR1cm4gY2FjaGU7XG4gIH07XG5cbiAgcmV0dXJuIGNhY2hlO1xufVxuXG5mdW5jdGlvbiBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZChvYmopIHtcbiAgaWYgKG9iaiAmJiBvYmouX19lc01vZHVsZSkge1xuICAgIHJldHVybiBvYmo7XG4gIH1cblxuICBpZiAob2JqID09PSBudWxsIHx8IF90eXBlb2Yob2JqKSAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2Ygb2JqICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByZXR1cm4ge1xuICAgICAgXCJkZWZhdWx0XCI6IG9ialxuICAgIH07XG4gIH1cblxuICB2YXIgY2FjaGUgPSBfZ2V0UmVxdWlyZVdpbGRjYXJkQ2FjaGUoKTtcblxuICBpZiAoY2FjaGUgJiYgY2FjaGUuaGFzKG9iaikpIHtcbiAgICByZXR1cm4gY2FjaGUuZ2V0KG9iaik7XG4gIH1cblxuICB2YXIgbmV3T2JqID0ge307XG4gIHZhciBoYXNQcm9wZXJ0eURlc2NyaXB0b3IgPSBPYmplY3QuZGVmaW5lUHJvcGVydHkgJiYgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcjtcblxuICBmb3IgKHZhciBrZXkgaW4gb2JqKSB7XG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIGtleSkpIHtcbiAgICAgIHZhciBkZXNjID0gaGFzUHJvcGVydHlEZXNjcmlwdG9yID8gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvYmosIGtleSkgOiBudWxsO1xuXG4gICAgICBpZiAoZGVzYyAmJiAoZGVzYy5nZXQgfHwgZGVzYy5zZXQpKSB7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShuZXdPYmosIGtleSwgZGVzYyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBuZXdPYmpba2V5XSA9IG9ialtrZXldO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIG5ld09ialtcImRlZmF1bHRcIl0gPSBvYmo7XG5cbiAgaWYgKGNhY2hlKSB7XG4gICAgY2FjaGUuc2V0KG9iaiwgbmV3T2JqKTtcbiAgfVxuXG4gIHJldHVybiBuZXdPYmo7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2ludGVyb3BSZXF1aXJlV2lsZGNhcmQ7IiwiZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkge1xuICBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTtcbiAgdmFyIHRhcmdldCA9IHt9O1xuICB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7XG4gIHZhciBrZXksIGk7XG5cbiAgZm9yIChpID0gMDsgaSA8IHNvdXJjZUtleXMubGVuZ3RoOyBpKyspIHtcbiAgICBrZXkgPSBzb3VyY2VLZXlzW2ldO1xuICAgIGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7XG4gICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgfVxuXG4gIHJldHVybiB0YXJnZXQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2U7IiwiZnVuY3Rpb24gX3R5cGVvZihvYmopIHtcbiAgXCJAYmFiZWwvaGVscGVycyAtIHR5cGVvZlwiO1xuXG4gIGlmICh0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA9PT0gXCJzeW1ib2xcIikge1xuICAgIG1vZHVsZS5leHBvcnRzID0gX3R5cGVvZiA9IGZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7XG4gICAgICByZXR1cm4gdHlwZW9mIG9iajtcbiAgICB9O1xuICB9IGVsc2Uge1xuICAgIG1vZHVsZS5leHBvcnRzID0gX3R5cGVvZiA9IGZ1bmN0aW9uIF90eXBlb2Yob2JqKSB7XG4gICAgICByZXR1cm4gb2JqICYmIHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvYmouY29uc3RydWN0b3IgPT09IFN5bWJvbCAmJiBvYmogIT09IFN5bWJvbC5wcm90b3R5cGUgPyBcInN5bWJvbFwiIDogdHlwZW9mIG9iajtcbiAgICB9O1xuICB9XG5cbiAgcmV0dXJuIF90eXBlb2Yob2JqKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfdHlwZW9mOyIsIi8qKiBAbGljZW5zZSBSZWFjdCB2MTcuMC4yXG4gKiByZWFjdC1pcy5kZXZlbG9wbWVudC5qc1xuICpcbiAqIENvcHlyaWdodCAoYykgRmFjZWJvb2ssIEluYy4gYW5kIGl0cyBhZmZpbGlhdGVzLlxuICpcbiAqIFRoaXMgc291cmNlIGNvZGUgaXMgbGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlIGZvdW5kIGluIHRoZVxuICogTElDRU5TRSBmaWxlIGluIHRoZSByb290IGRpcmVjdG9yeSBvZiB0aGlzIHNvdXJjZSB0cmVlLlxuICovXG5cbid1c2Ugc3RyaWN0JztcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAoZnVuY3Rpb24oKSB7XG4ndXNlIHN0cmljdCc7XG5cbi8vIEFUVEVOVElPTlxuLy8gV2hlbiBhZGRpbmcgbmV3IHN5bWJvbHMgdG8gdGhpcyBmaWxlLFxuLy8gUGxlYXNlIGNvbnNpZGVyIGFsc28gYWRkaW5nIHRvICdyZWFjdC1kZXZ0b29scy1zaGFyZWQvc3JjL2JhY2tlbmQvUmVhY3RTeW1ib2xzJ1xuLy8gVGhlIFN5bWJvbCB1c2VkIHRvIHRhZyB0aGUgUmVhY3RFbGVtZW50LWxpa2UgdHlwZXMuIElmIHRoZXJlIGlzIG5vIG5hdGl2ZSBTeW1ib2xcbi8vIG5vciBwb2x5ZmlsbCwgdGhlbiBhIHBsYWluIG51bWJlciBpcyB1c2VkIGZvciBwZXJmb3JtYW5jZS5cbnZhciBSRUFDVF9FTEVNRU5UX1RZUEUgPSAweGVhYzc7XG52YXIgUkVBQ1RfUE9SVEFMX1RZUEUgPSAweGVhY2E7XG52YXIgUkVBQ1RfRlJBR01FTlRfVFlQRSA9IDB4ZWFjYjtcbnZhciBSRUFDVF9TVFJJQ1RfTU9ERV9UWVBFID0gMHhlYWNjO1xudmFyIFJFQUNUX1BST0ZJTEVSX1RZUEUgPSAweGVhZDI7XG52YXIgUkVBQ1RfUFJPVklERVJfVFlQRSA9IDB4ZWFjZDtcbnZhciBSRUFDVF9DT05URVhUX1RZUEUgPSAweGVhY2U7XG52YXIgUkVBQ1RfRk9SV0FSRF9SRUZfVFlQRSA9IDB4ZWFkMDtcbnZhciBSRUFDVF9TVVNQRU5TRV9UWVBFID0gMHhlYWQxO1xudmFyIFJFQUNUX1NVU1BFTlNFX0xJU1RfVFlQRSA9IDB4ZWFkODtcbnZhciBSRUFDVF9NRU1PX1RZUEUgPSAweGVhZDM7XG52YXIgUkVBQ1RfTEFaWV9UWVBFID0gMHhlYWQ0O1xudmFyIFJFQUNUX0JMT0NLX1RZUEUgPSAweGVhZDk7XG52YXIgUkVBQ1RfU0VSVkVSX0JMT0NLX1RZUEUgPSAweGVhZGE7XG52YXIgUkVBQ1RfRlVOREFNRU5UQUxfVFlQRSA9IDB4ZWFkNTtcbnZhciBSRUFDVF9TQ09QRV9UWVBFID0gMHhlYWQ3O1xudmFyIFJFQUNUX09QQVFVRV9JRF9UWVBFID0gMHhlYWUwO1xudmFyIFJFQUNUX0RFQlVHX1RSQUNJTkdfTU9ERV9UWVBFID0gMHhlYWUxO1xudmFyIFJFQUNUX09GRlNDUkVFTl9UWVBFID0gMHhlYWUyO1xudmFyIFJFQUNUX0xFR0FDWV9ISURERU5fVFlQRSA9IDB4ZWFlMztcblxuaWYgKHR5cGVvZiBTeW1ib2wgPT09ICdmdW5jdGlvbicgJiYgU3ltYm9sLmZvcikge1xuICB2YXIgc3ltYm9sRm9yID0gU3ltYm9sLmZvcjtcbiAgUkVBQ1RfRUxFTUVOVF9UWVBFID0gc3ltYm9sRm9yKCdyZWFjdC5lbGVtZW50Jyk7XG4gIFJFQUNUX1BPUlRBTF9UWVBFID0gc3ltYm9sRm9yKCdyZWFjdC5wb3J0YWwnKTtcbiAgUkVBQ1RfRlJBR01FTlRfVFlQRSA9IHN5bWJvbEZvcigncmVhY3QuZnJhZ21lbnQnKTtcbiAgUkVBQ1RfU1RSSUNUX01PREVfVFlQRSA9IHN5bWJvbEZvcigncmVhY3Quc3RyaWN0X21vZGUnKTtcbiAgUkVBQ1RfUFJPRklMRVJfVFlQRSA9IHN5bWJvbEZvcigncmVhY3QucHJvZmlsZXInKTtcbiAgUkVBQ1RfUFJPVklERVJfVFlQRSA9IHN5bWJvbEZvcigncmVhY3QucHJvdmlkZXInKTtcbiAgUkVBQ1RfQ09OVEVYVF9UWVBFID0gc3ltYm9sRm9yKCdyZWFjdC5jb250ZXh0Jyk7XG4gIFJFQUNUX0ZPUldBUkRfUkVGX1RZUEUgPSBzeW1ib2xGb3IoJ3JlYWN0LmZvcndhcmRfcmVmJyk7XG4gIFJFQUNUX1NVU1BFTlNFX1RZUEUgPSBzeW1ib2xGb3IoJ3JlYWN0LnN1c3BlbnNlJyk7XG4gIFJFQUNUX1NVU1BFTlNFX0xJU1RfVFlQRSA9IHN5bWJvbEZvcigncmVhY3Quc3VzcGVuc2VfbGlzdCcpO1xuICBSRUFDVF9NRU1PX1RZUEUgPSBzeW1ib2xGb3IoJ3JlYWN0Lm1lbW8nKTtcbiAgUkVBQ1RfTEFaWV9UWVBFID0gc3ltYm9sRm9yKCdyZWFjdC5sYXp5Jyk7XG4gIFJFQUNUX0JMT0NLX1RZUEUgPSBzeW1ib2xGb3IoJ3JlYWN0LmJsb2NrJyk7XG4gIFJFQUNUX1NFUlZFUl9CTE9DS19UWVBFID0gc3ltYm9sRm9yKCdyZWFjdC5zZXJ2ZXIuYmxvY2snKTtcbiAgUkVBQ1RfRlVOREFNRU5UQUxfVFlQRSA9IHN5bWJvbEZvcigncmVhY3QuZnVuZGFtZW50YWwnKTtcbiAgUkVBQ1RfU0NPUEVfVFlQRSA9IHN5bWJvbEZvcigncmVhY3Quc2NvcGUnKTtcbiAgUkVBQ1RfT1BBUVVFX0lEX1RZUEUgPSBzeW1ib2xGb3IoJ3JlYWN0Lm9wYXF1ZS5pZCcpO1xuICBSRUFDVF9ERUJVR19UUkFDSU5HX01PREVfVFlQRSA9IHN5bWJvbEZvcigncmVhY3QuZGVidWdfdHJhY2VfbW9kZScpO1xuICBSRUFDVF9PRkZTQ1JFRU5fVFlQRSA9IHN5bWJvbEZvcigncmVhY3Qub2Zmc2NyZWVuJyk7XG4gIFJFQUNUX0xFR0FDWV9ISURERU5fVFlQRSA9IHN5bWJvbEZvcigncmVhY3QubGVnYWN5X2hpZGRlbicpO1xufVxuXG4vLyBGaWx0ZXIgY2VydGFpbiBET00gYXR0cmlidXRlcyAoZS5nLiBzcmMsIGhyZWYpIGlmIHRoZWlyIHZhbHVlcyBhcmUgZW1wdHkgc3RyaW5ncy5cblxudmFyIGVuYWJsZVNjb3BlQVBJID0gZmFsc2U7IC8vIEV4cGVyaW1lbnRhbCBDcmVhdGUgRXZlbnQgSGFuZGxlIEFQSS5cblxuZnVuY3Rpb24gaXNWYWxpZEVsZW1lbnRUeXBlKHR5cGUpIHtcbiAgaWYgKHR5cGVvZiB0eXBlID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdHlwZSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHJldHVybiB0cnVlO1xuICB9IC8vIE5vdGU6IHR5cGVvZiBtaWdodCBiZSBvdGhlciB0aGFuICdzeW1ib2wnIG9yICdudW1iZXInIChlLmcuIGlmIGl0J3MgYSBwb2x5ZmlsbCkuXG5cblxuICBpZiAodHlwZSA9PT0gUkVBQ1RfRlJBR01FTlRfVFlQRSB8fCB0eXBlID09PSBSRUFDVF9QUk9GSUxFUl9UWVBFIHx8IHR5cGUgPT09IFJFQUNUX0RFQlVHX1RSQUNJTkdfTU9ERV9UWVBFIHx8IHR5cGUgPT09IFJFQUNUX1NUUklDVF9NT0RFX1RZUEUgfHwgdHlwZSA9PT0gUkVBQ1RfU1VTUEVOU0VfVFlQRSB8fCB0eXBlID09PSBSRUFDVF9TVVNQRU5TRV9MSVNUX1RZUEUgfHwgdHlwZSA9PT0gUkVBQ1RfTEVHQUNZX0hJRERFTl9UWVBFIHx8IGVuYWJsZVNjb3BlQVBJICkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgaWYgKHR5cGVvZiB0eXBlID09PSAnb2JqZWN0JyAmJiB0eXBlICE9PSBudWxsKSB7XG4gICAgaWYgKHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX0xBWllfVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9NRU1PX1RZUEUgfHwgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfUFJPVklERVJfVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9DT05URVhUX1RZUEUgfHwgdHlwZS4kJHR5cGVvZiA9PT0gUkVBQ1RfRk9SV0FSRF9SRUZfVFlQRSB8fCB0eXBlLiQkdHlwZW9mID09PSBSRUFDVF9GVU5EQU1FTlRBTF9UWVBFIHx8IHR5cGUuJCR0eXBlb2YgPT09IFJFQUNUX0JMT0NLX1RZUEUgfHwgdHlwZVswXSA9PT0gUkVBQ1RfU0VSVkVSX0JMT0NLX1RZUEUpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBmYWxzZTtcbn1cblxuZnVuY3Rpb24gdHlwZU9mKG9iamVjdCkge1xuICBpZiAodHlwZW9mIG9iamVjdCA9PT0gJ29iamVjdCcgJiYgb2JqZWN0ICE9PSBudWxsKSB7XG4gICAgdmFyICQkdHlwZW9mID0gb2JqZWN0LiQkdHlwZW9mO1xuXG4gICAgc3dpdGNoICgkJHR5cGVvZikge1xuICAgICAgY2FzZSBSRUFDVF9FTEVNRU5UX1RZUEU6XG4gICAgICAgIHZhciB0eXBlID0gb2JqZWN0LnR5cGU7XG5cbiAgICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgICAgY2FzZSBSRUFDVF9GUkFHTUVOVF9UWVBFOlxuICAgICAgICAgIGNhc2UgUkVBQ1RfUFJPRklMRVJfVFlQRTpcbiAgICAgICAgICBjYXNlIFJFQUNUX1NUUklDVF9NT0RFX1RZUEU6XG4gICAgICAgICAgY2FzZSBSRUFDVF9TVVNQRU5TRV9UWVBFOlxuICAgICAgICAgIGNhc2UgUkVBQ1RfU1VTUEVOU0VfTElTVF9UWVBFOlxuICAgICAgICAgICAgcmV0dXJuIHR5cGU7XG5cbiAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdmFyICQkdHlwZW9mVHlwZSA9IHR5cGUgJiYgdHlwZS4kJHR5cGVvZjtcblxuICAgICAgICAgICAgc3dpdGNoICgkJHR5cGVvZlR5cGUpIHtcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9DT05URVhUX1RZUEU6XG4gICAgICAgICAgICAgIGNhc2UgUkVBQ1RfRk9SV0FSRF9SRUZfVFlQRTpcbiAgICAgICAgICAgICAgY2FzZSBSRUFDVF9MQVpZX1RZUEU6XG4gICAgICAgICAgICAgIGNhc2UgUkVBQ1RfTUVNT19UWVBFOlxuICAgICAgICAgICAgICBjYXNlIFJFQUNUX1BST1ZJREVSX1RZUEU6XG4gICAgICAgICAgICAgICAgcmV0dXJuICQkdHlwZW9mVHlwZTtcblxuICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIHJldHVybiAkJHR5cGVvZjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICB9XG5cbiAgICAgIGNhc2UgUkVBQ1RfUE9SVEFMX1RZUEU6XG4gICAgICAgIHJldHVybiAkJHR5cGVvZjtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxudmFyIENvbnRleHRDb25zdW1lciA9IFJFQUNUX0NPTlRFWFRfVFlQRTtcbnZhciBDb250ZXh0UHJvdmlkZXIgPSBSRUFDVF9QUk9WSURFUl9UWVBFO1xudmFyIEVsZW1lbnQgPSBSRUFDVF9FTEVNRU5UX1RZUEU7XG52YXIgRm9yd2FyZFJlZiA9IFJFQUNUX0ZPUldBUkRfUkVGX1RZUEU7XG52YXIgRnJhZ21lbnQgPSBSRUFDVF9GUkFHTUVOVF9UWVBFO1xudmFyIExhenkgPSBSRUFDVF9MQVpZX1RZUEU7XG52YXIgTWVtbyA9IFJFQUNUX01FTU9fVFlQRTtcbnZhciBQb3J0YWwgPSBSRUFDVF9QT1JUQUxfVFlQRTtcbnZhciBQcm9maWxlciA9IFJFQUNUX1BST0ZJTEVSX1RZUEU7XG52YXIgU3RyaWN0TW9kZSA9IFJFQUNUX1NUUklDVF9NT0RFX1RZUEU7XG52YXIgU3VzcGVuc2UgPSBSRUFDVF9TVVNQRU5TRV9UWVBFO1xudmFyIGhhc1dhcm5lZEFib3V0RGVwcmVjYXRlZElzQXN5bmNNb2RlID0gZmFsc2U7XG52YXIgaGFzV2FybmVkQWJvdXREZXByZWNhdGVkSXNDb25jdXJyZW50TW9kZSA9IGZhbHNlOyAvLyBBc3luY01vZGUgc2hvdWxkIGJlIGRlcHJlY2F0ZWRcblxuZnVuY3Rpb24gaXNBc3luY01vZGUob2JqZWN0KSB7XG4gIHtcbiAgICBpZiAoIWhhc1dhcm5lZEFib3V0RGVwcmVjYXRlZElzQXN5bmNNb2RlKSB7XG4gICAgICBoYXNXYXJuZWRBYm91dERlcHJlY2F0ZWRJc0FzeW5jTW9kZSA9IHRydWU7IC8vIFVzaW5nIGNvbnNvbGVbJ3dhcm4nXSB0byBldmFkZSBCYWJlbCBhbmQgRVNMaW50XG5cbiAgICAgIGNvbnNvbGVbJ3dhcm4nXSgnVGhlIFJlYWN0SXMuaXNBc3luY01vZGUoKSBhbGlhcyBoYXMgYmVlbiBkZXByZWNhdGVkLCAnICsgJ2FuZCB3aWxsIGJlIHJlbW92ZWQgaW4gUmVhY3QgMTgrLicpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGlzQ29uY3VycmVudE1vZGUob2JqZWN0KSB7XG4gIHtcbiAgICBpZiAoIWhhc1dhcm5lZEFib3V0RGVwcmVjYXRlZElzQ29uY3VycmVudE1vZGUpIHtcbiAgICAgIGhhc1dhcm5lZEFib3V0RGVwcmVjYXRlZElzQ29uY3VycmVudE1vZGUgPSB0cnVlOyAvLyBVc2luZyBjb25zb2xlWyd3YXJuJ10gdG8gZXZhZGUgQmFiZWwgYW5kIEVTTGludFxuXG4gICAgICBjb25zb2xlWyd3YXJuJ10oJ1RoZSBSZWFjdElzLmlzQ29uY3VycmVudE1vZGUoKSBhbGlhcyBoYXMgYmVlbiBkZXByZWNhdGVkLCAnICsgJ2FuZCB3aWxsIGJlIHJlbW92ZWQgaW4gUmVhY3QgMTgrLicpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGlzQ29udGV4dENvbnN1bWVyKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX0NPTlRFWFRfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzQ29udGV4dFByb3ZpZGVyKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX1BST1ZJREVSX1RZUEU7XG59XG5mdW5jdGlvbiBpc0VsZW1lbnQob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlb2Ygb2JqZWN0ID09PSAnb2JqZWN0JyAmJiBvYmplY3QgIT09IG51bGwgJiYgb2JqZWN0LiQkdHlwZW9mID09PSBSRUFDVF9FTEVNRU5UX1RZUEU7XG59XG5mdW5jdGlvbiBpc0ZvcndhcmRSZWYob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfRk9SV0FSRF9SRUZfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzRnJhZ21lbnQob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfRlJBR01FTlRfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzTGF6eShvYmplY3QpIHtcbiAgcmV0dXJuIHR5cGVPZihvYmplY3QpID09PSBSRUFDVF9MQVpZX1RZUEU7XG59XG5mdW5jdGlvbiBpc01lbW8ob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfTUVNT19UWVBFO1xufVxuZnVuY3Rpb24gaXNQb3J0YWwob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfUE9SVEFMX1RZUEU7XG59XG5mdW5jdGlvbiBpc1Byb2ZpbGVyKG9iamVjdCkge1xuICByZXR1cm4gdHlwZU9mKG9iamVjdCkgPT09IFJFQUNUX1BST0ZJTEVSX1RZUEU7XG59XG5mdW5jdGlvbiBpc1N0cmljdE1vZGUob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfU1RSSUNUX01PREVfVFlQRTtcbn1cbmZ1bmN0aW9uIGlzU3VzcGVuc2Uob2JqZWN0KSB7XG4gIHJldHVybiB0eXBlT2Yob2JqZWN0KSA9PT0gUkVBQ1RfU1VTUEVOU0VfVFlQRTtcbn1cblxuZXhwb3J0cy5Db250ZXh0Q29uc3VtZXIgPSBDb250ZXh0Q29uc3VtZXI7XG5leHBvcnRzLkNvbnRleHRQcm92aWRlciA9IENvbnRleHRQcm92aWRlcjtcbmV4cG9ydHMuRWxlbWVudCA9IEVsZW1lbnQ7XG5leHBvcnRzLkZvcndhcmRSZWYgPSBGb3J3YXJkUmVmO1xuZXhwb3J0cy5GcmFnbWVudCA9IEZyYWdtZW50O1xuZXhwb3J0cy5MYXp5ID0gTGF6eTtcbmV4cG9ydHMuTWVtbyA9IE1lbW87XG5leHBvcnRzLlBvcnRhbCA9IFBvcnRhbDtcbmV4cG9ydHMuUHJvZmlsZXIgPSBQcm9maWxlcjtcbmV4cG9ydHMuU3RyaWN0TW9kZSA9IFN0cmljdE1vZGU7XG5leHBvcnRzLlN1c3BlbnNlID0gU3VzcGVuc2U7XG5leHBvcnRzLmlzQXN5bmNNb2RlID0gaXNBc3luY01vZGU7XG5leHBvcnRzLmlzQ29uY3VycmVudE1vZGUgPSBpc0NvbmN1cnJlbnRNb2RlO1xuZXhwb3J0cy5pc0NvbnRleHRDb25zdW1lciA9IGlzQ29udGV4dENvbnN1bWVyO1xuZXhwb3J0cy5pc0NvbnRleHRQcm92aWRlciA9IGlzQ29udGV4dFByb3ZpZGVyO1xuZXhwb3J0cy5pc0VsZW1lbnQgPSBpc0VsZW1lbnQ7XG5leHBvcnRzLmlzRm9yd2FyZFJlZiA9IGlzRm9yd2FyZFJlZjtcbmV4cG9ydHMuaXNGcmFnbWVudCA9IGlzRnJhZ21lbnQ7XG5leHBvcnRzLmlzTGF6eSA9IGlzTGF6eTtcbmV4cG9ydHMuaXNNZW1vID0gaXNNZW1vO1xuZXhwb3J0cy5pc1BvcnRhbCA9IGlzUG9ydGFsO1xuZXhwb3J0cy5pc1Byb2ZpbGVyID0gaXNQcm9maWxlcjtcbmV4cG9ydHMuaXNTdHJpY3RNb2RlID0gaXNTdHJpY3RNb2RlO1xuZXhwb3J0cy5pc1N1c3BlbnNlID0gaXNTdXNwZW5zZTtcbmV4cG9ydHMuaXNWYWxpZEVsZW1lbnRUeXBlID0gaXNWYWxpZEVsZW1lbnRUeXBlO1xuZXhwb3J0cy50eXBlT2YgPSB0eXBlT2Y7XG4gIH0pKCk7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9janMvcmVhY3QtaXMucHJvZHVjdGlvbi5taW4uanMnKTtcbn0gZWxzZSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9janMvcmVhY3QtaXMuZGV2ZWxvcG1lbnQuanMnKTtcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBjb250ZW50ZnVsL3JpY2gtdGV4dC1yZWFjdC1yZW5kZXJlclwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGhlYWRsZXNzdWkvcmVhY3RcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNsYXNzbmFtZXNcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNvbnRlbnRmdWxcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImpzLWNvb2tpZVwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci1jb250ZXh0LmpzXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci91dGlscy9nZXQtYXNzZXQtcGF0aC1mcm9tLXJvdXRlLmpzXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3RvLWJhc2UtNjQuanNcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9zZXJ2ZXIvaW1hZ2UtY29uZmlnLmpzXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2hlYWRcIik7OyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvcm91dGVyXCIpOzsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTs7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOzsiLCIvKiAoaWdub3JlZCkgKi8iXSwic291cmNlUm9vdCI6IiJ9