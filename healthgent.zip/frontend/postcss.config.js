const config = require("@healthgent/common/src/config/postcss.config");
module.exports = {...config};