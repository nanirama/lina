import { NextPage, GetStaticProps } from "next";
import { useRouter } from "next/router";
import Link from "next/link";
import { format } from "date-fns";

import { getAllPosts, getPost, Post } from "../../lib/blog";
import BlogTemplate from "../../components/blog/BlogTemplate";
import PostContent from "../../components/blog/PostContent";
import Custom404 from "./404";

type BlogProps = {
  post: Post;
};

const Blog: NextPage<BlogProps> = ({ post }) => {
  const router = useRouter();

  if (!post?.slug) {
    return <Custom404 loading={router.isFallback} />;
  }

  return (
    <BlogTemplate>
      <section className="pt-12 md:pt-16 px-6 flex flex-col items-center justify-center">
        <div className="container">
          <Link href="/blog">
            <a className="text-sm">← Back to Lina Blog home</a>
          </Link>
        </div>
        <div className="container flex flex-col items-center my-8 md:my-12">
          <h1 className="text-4xl">{post.title}</h1>
          <time className="text-xs text-gray-500" dateTime={post.date}>
            {format(new Date(post.date), "LLLL d, yyyy")}
          </time>
          <img
            alt={post.featuredImage.node.altText}
            src={post.featuredImage?.node?.sourceUrl}
            className="my-8 md:px-12"
          />
          <PostContent>{post.content}</PostContent>
        </div>
      </section>
    </BlogTemplate>
  );
};

export const getStaticProps: GetStaticProps = async ({ params }) => {
  const post = await getPost(params!.slug as string);
  return { props: { post } };
};

export async function getStaticPaths() {
  const allPosts = await getAllPosts();

  return {
    paths: allPosts.edges.map(({ node }) => `/blog/${node.slug}`) || [],
    fallback: true,
  };
}

export default Blog;
