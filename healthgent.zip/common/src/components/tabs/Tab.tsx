/**
 * UNUSED
 */
import React from "react";

interface Props {
  label: string;
}

const Tab: React.FC<Props> = () => {
  return <> </>;
};

export default Tab;
