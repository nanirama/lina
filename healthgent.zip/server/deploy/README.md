# Nginx config
nginx is used as a reverse proxy for node instances managed by pm2. TLS certs
are managed by LetsEncrypt/certbot. 